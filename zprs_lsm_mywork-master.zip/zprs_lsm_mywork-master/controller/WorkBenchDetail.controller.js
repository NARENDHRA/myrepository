sap.ui.define([
	"lsmmyworkbench/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmmyworkbench/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Controller, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("lsmmyworkbench.controller.WorkBenchDetail", {
		formatter: formatter,
		onInit: function() {
			this.getRouter().getRoute("workBenchDetail").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(evt) {
			/*if ("workBenchDetail" !== evt.getParameter("name")) {
				return;
			} else {*/

			var lvfiletype = evt.getParameter("arguments").filetype;
			var lvinvoiceNumber = evt.getParameter("arguments").invoiceNumber;
			//	var lvlineItemNumber =  evt.getParameter("arguments").lineItemNumber;
			var lvseqnr = evt.getParameter("arguments").seqnr;
			//this.getView().byId("wbDetail").setTitle(" Inovice Number : "+lvinvoiceNumber+" (review)");
			//this.displayData(lvfiletype, lvinvoiceNumber, lvseqnr);
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("InvHeaderSet", {
					ZzinvoiceNumber: lvinvoiceNumber,
					Zzfiletype: lvfiletype,
					Zzseqnr: lvseqnr
				});

				this._bindTable("/" + sObjectPath + "/InvHeaderToDetail");
			}.bind(this));
			//	}
		},

		_bindTable: function(sObjectPath) {
			var oDataModel = this.getModel(),
				oTable = this.getTable();
			var that = this;
			oTable.setBusy(true);
			var oModelLocal = new sap.ui.model.json.JSONModel();
			oDataModel.read(sObjectPath, {
				success: function(oData, response) {
					oModelLocal.setData({
						modelData: oData.results
					});
					oTable.setModel(oModelLocal);
					oTable.setSelectionMode("None");
					oTable.bindRows("/modelData");
					that.getView().byId("lblToolbar").setText(oData.results[0].Zzphase + "  " + oData.results[0].ZzphaseName +
						" Inovice Number : " +
						oData.results[0].ZzinvoiceNumber + " (review)");
					oTable.setBusy(false);
				},
				error: function(oError) {
					oTable.setBusy(false);
				}

			});
		},
		getTable: function() {
			var oTable = this.getView().byId("MyWBDetailSTable");
			return oTable.getTable();
		},
		navTobackWorkBen: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("worklist", true);
		}

	});

});