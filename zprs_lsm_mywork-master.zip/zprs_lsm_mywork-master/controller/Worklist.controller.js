sap.ui.define([
		"lsmmyworkbench/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History",
		"lsmmyworkbench/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
		"use strict";

		return BaseController.extend("lsmmyworkbench.controller.Worklist", {

			formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.getView().setBusy(true);
			this.bServiceFlag = true;
			this.bTimeKeeperServiceFlag = true;
			var jsonModel = new sap.ui.model.json.JSONModel({
				"MyDashboard": true,
				"MyWorkbench": false,
				"ManageBudget": false,
				"TimeKeeperRate": false,
				"MyMatter": false,
				"MatterSummary": false,

				"ExchangeRates": false,
				"Reports": false,
				Bukrs: true,
				Gjahr: true,
				Werks: true,
				Hkont: true,
				Status: true,
				RecordType: true,
				Posid: true
			}, true);
			this.getView().setModel(jsonModel, "JsonKey");

			var JsonModelButton = new JSONModel({
				"Print": false,
				"Accept": false,
				"Approve": false,
				"Reject": false,
				"UploadAttc": false,
				"Save": false,
				"invStatus":true,
				"payStatus":false,
				Pending: 0,
				Approved: 0,
				Rejected: 0,
				InProcess: 0,
				HoldBudget: 0
				
			}, true);
			this.getView().setModel(JsonModelButton, "JModelButton");

			var sideNavigation,
				oViewModel,
				iOriginalBusyDelay;

			/*	sideNavigation = this.getView().byId('sideNavigation');
				//var expanded = !sideNavigation.getExpanded();
				sideNavigation.setExpanded(false);*/

			this._oTableSearchState = [];

			//this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			this._oTableSearchState = [];

			this.pendingAndHoldBudgetTab(); // function calling for displaying button in footer 
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

		//	this.getRouter().getRoute("lsmClient").attachPatternMatched(this._onObjectMatched, this);

			this.sideKey = "";
			this._mFilters = {
				"pending": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "01")],
				"inProcess": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "04")],
				"approved": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "02")],
				"rejected": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "03")],
				"holdBudget": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "05")],
			

			};

			//	this.oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			//	this.oDataModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV/");
			//	this._showFormFragment("MyDashboard");

		},

	

		handleDataReceived: function(oEvent) {
			// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV");
			var oModel = this.getOwnerComponent().getModel();

			var oViewModel = this.getModel("JModelButton");

			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Pending", oData);
				},
				filters: this._mFilters.pending
			});

			// read the count for InProcess
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/InProcess", oData);
				},
				filters: this._mFilters.inProcess
			});

			// read the count for Approved
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Approved", oData);
				},
				filters: this._mFilters.approved
			});

			// read the count for Rejected
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Rejected", oData);
				},
				filters: this._mFilters.rejected
			});
			// read the count for HoldBudget
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/HoldBudget", oData);
					this.getView().setBusy(false);
				}.bind(this),
				filters: this._mFilters.holdBudget
			});
			
		},

		_onObjectMatched: function(evt) {
			var a = this.sideKey;

			if (a === "TimeKeeperRate") {

				this.getView().setModel(this.oDataModel1);
				var MyDashboard = "MyDashboard";
				this.setCurrentTab(MyDashboard);
			}
		},
		getTable: function() {
			var oTable = this.getView().byId("MyWorkBenchSTable");
			return oTable.getTable();
		},
		onBeforeRebindTable: function(oEvent) {

			var SegmentKey = this.getView().byId("idIconTabBarNoIconsLSM").getSelectedKey();
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			mBindingParams.filters = aFilter;
		},
		onSelectIconTabBarMyWB: function(oEvent) {
			var that = this;
			var segmbtnKey = oEvent.mParameters.key;
				var segmbtnpayKey = oEvent.mParameters.key;
			var aFilter = [],
				path = "ZzinvStatus";
			var oTab = this.getTable(),
				cntx = oTab.getBinding("items");
			//SegmentKey = oEvent.getParameters().key;
			//    cntx.aApplicationFilters = null;

			/*if (segmbtnKey.search("my") >= 0) {
			var	segmbtnKey1 = segmbtnKey.replace("my", '');
				path = "ZzpayStatus";
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey1));
			}else{
			aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));	
			}*/
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));
			cntx.filter(aFilter, "Application");

			switch (segmbtnKey) {
				case "01":
					that.pendingAndHoldBudgetTab();
					break;
				case "04":
					that.in_ProcessTab();
					break;
				case "02":
					that.approvedAndRejectTab();
					break;
				case "03":
					that.approvedAndRejectTab();
					break;
				case "05":
					that.pendingAndHoldBudgetTab();
					break;
			

			}
		},

		myPaymentTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/invStatus", false);
			oViewModel.setProperty("/payStatus", true);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},

		pendingAndHoldBudgetTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", true);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", true);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},
		in_ProcessTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", true);
			oViewModel.setProperty("/Reject", true);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},
		approvedAndRejectTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},
		_allSegmButtonFalse: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
			oViewModel.setProperty("/Save", false);
			//	this.getView().byId("printAsPDF").setVisible(false);
		},
		sideNavigationMyWorkBench: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
		},
		setCurrentTab: function(SelKey) {
			var jKey = this.getView().getModel("JsonKey");

			$.each(jKey.getData(), function(pn, v) {
				if (pn === SelKey) {
					jKey.setProperty("/" + pn, true);
				} else {
					jKey.setProperty("/" + pn, false);
				}

			});
		},

	

		pressDetailWorkBench: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext().getObject();

			this.getRouter().navTo("workBenchDetail", {
				filetype: obj.Zzfiletype,
				invoiceNumber: obj.ZzinvoiceNumber,
				seqnr: obj.Zzseqnr
			}, true);
		},

		pressNavigaAccrulas: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext().getObject();

			this.getRouter().navTo("accruals", {
				LawFirmMatterId: obj.Pspid

			}, true);
		},
		buttonSetVisible: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", true);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/Save", true);

		},

		onPressPrint: function(oEvent) {

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV/");
			var oView = this.getView(),
				oJson = new sap.ui.model.json.JSONModel();
			oModel.read("/InvHeaderSet", {
				/*	parameters: {
						select: 'ZzbillingOfficeName,ZzinvoiceTotal'
					},*/
				success: function(oData) {
					var results = oData.results;
					var aRes = [];
					var sum = 0;
					for (var i = 0; i < results.length; i++) {
						if (i + 1 < results.length) {
							if (results[i].ZzbillingOfficeName === results[i + 1].ZzbillingOfficeName) {
								sum += parseFloat(results[i].ZzinvoiceTotal);
							} else {
								var obj = {
									"ZzbillingOfficeName": results[i].ZzbillingOfficeName,
									"ZzinvoiceTotal": sum
								};
								aRes.push(obj);
							}
						}
					}
					oJson.setData({
						"invModelData": aRes
					});
					oView.setModel(oJson, "invModel");
				}
			});
			
			
		

			/*	var that, myWBSmartTable, WBTable, pURL, oModel, url, invoiceNo;
				that = this;
				myWBSmartTable = this.getView().byId("MyWorkBenchSTable");
				WBTable = this.getView().byId("idwbTable");
				oModel = this.getView().getModel();
				var servUri = oModel.sServiceUrl;
				invoiceNo = WBTable.getSelectedItem().getBindingContext().getObject().ZzinvoiceNumber;
				var sRead = "/PrintInvoiceCollection(Vbeln='" + invoiceNo + "')" + "/$value";
				var mainUri = servUri + sRead;
				sap.m.URLHelper.redirect(mainUri, "_blank");*/

		},
		getTableMannegeBudget: function() {
			var otbl = this.getView().byId("ManBudgetSTable");
			return otbl.getTable();
		},
		// Manage Budget Save Functionality 
		onPressSave: function(oEvent) {
			var that, oselectedManageBudget, oTable, oSelectedRows, batchChanges, src;
			that = this;
			oTable = this.getTableMannegeBudget();
			oSelectedRows = oTable.getSelectedIndices();
			src = oEvent.getSource();
			var arrBukrs = [],
				arrWerks = [],
				arrPspid = [],
				arrVendor = [],
				arrStatus = [],
				arrGjahr = [],
				arrPosid = [],
				arrHkont = [],
				arrAmount = [],
				arrRecordType = [],
				arrCurrency = [];
			batchChanges = [];

			$.each(oTable.getSelectedIndices(), function(i, o) {

				var obj = oTable.getContextByIndex(o).getObject();
				arrBukrs.push(obj.Bukrs);
				arrWerks.push(obj.Werks);
				arrPspid.push(obj.Pspid);
				arrVendor.push(obj.Vendor);
				arrStatus.push(obj.Status);
				arrGjahr.push(obj.Gjahr);
				arrPosid.push(obj.Posid);
				arrHkont.push(obj.Hkont);
				arrAmount.push(obj.Amount);
				arrRecordType.push(obj.RecordType);
				arrCurrency.push(obj.Currency);

				oselectedManageBudget = {
					Bukrs: arrBukrs.join("|"),
					Werks: arrWerks.join("|"),
					Pspid: arrPspid.join("|"),
					Vendor: arrVendor.join("|"),
					Status: arrStatus.join("|"),
					Gjahr: arrGjahr.join("|"),
					Posid: arrPosid.join("|"),
					Hkont: arrHkont.join("|"),
					Amount: arrAmount.join("|"),
					RecordType: arrRecordType.join("|"),
					Currency: arrCurrency.join("|")
				};

				//batchChanges.push(that.oDataModel.createBatchOperation("/BudgetChange", "PSO", oselectedManageBudget));
			});

			//var VMatterModel = this.getModel("VMatterModel");
			/*that.oDataModel.callFunction("/BudgetChange", {
				method: "GET",
				urlParameters: oselectedManageBudget,
				success: function(oData) {
					var s = oData;
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});*/
			/*	that.oDataModel.addBatchChangeOperations(batchChanges);
				//submit changes and refresh the table and display message&nbsp;\&nbsp;
				that.oDataModel.setUseBatch(true);
				that.oDataModel.submitBatch(function(data) {
					var receivedData = data.__batchResponses[0].__changeResponses;

				}, function(err) {
					//alert("Error occurred", err);  
				});*/
		},
		// Approve Functionality
		onPressApprove: function(oEvent) {
			var that, oselectedManageBudget, oTable, oSelectedRows, batchChanges, src;
			that = this;
			oTable = this.getTableMannegeBudget();
			oSelectedRows = oTable.getSelectedIndices();
			src = oEvent.getSource();
			var arrBukrs = [],
				arrWerks = [],
				arrPspid = [],
				arrVendor = [],
				arrStatus = [],
				arrGjahr = [],
				arrPosid = [],
				arrHkont = [],
				arrAmount = [],
				arrRecordType = [],
				arrCurrency = [];
			batchChanges = [];
			var MBudgetSTable = this.getView().byId("ManBudgetSTable");
			if (MBudgetSTable.getDomRef() !== null) {
				$.each(oTable.getSelectedIndices(), function(i, o) {

					var obj = oTable.getContextByIndex(o).getObject();
					arrBukrs.push(obj.Bukrs);
					arrWerks.push(obj.Werks);
					arrPspid.push(obj.Pspid);
					arrVendor.push(obj.Vendor);
					arrStatus.push(obj.Status);
					arrGjahr.push(obj.Gjahr);
					arrPosid.push(obj.Posid);
					arrHkont.push(obj.Hkont);
					arrAmount.push(obj.Amount);
					arrRecordType.push(obj.RecordType);
					arrCurrency.push(obj.Currency);

					oselectedManageBudget = {
						Bukrs: arrBukrs.join("|"),
						Werks: arrWerks.join("|"),
						Pspid: arrPspid.join("|"),
						Vendor: arrVendor.join("|"),
						Status: arrStatus.join("|"),
						Gjahr: arrGjahr.join("|"),
						Posid: arrPosid.join("|"),
						Hkont: arrHkont.join("|"),
						Amount: arrAmount.join("|"),
						RecordType: arrRecordType.join("|"),
						Currency: arrCurrency.join("|")
					};

				});
			}
			/*that.oDataModel.callFunction("/BudgetApprove", {
				method: "GET",
				urlParameters: oselectedManageBudget,
				success: function(oData) {
					var s = oData;
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});*/
		},
		onSelectReport: function(oEvent) {
			/*var IconTabFilterKey = oEvent.getParameter("item").selectedKey;
			var oDataModelRep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			if(IconTabFilterKey ==="Spendkey"){
			this.getView().setModel(oDataModelRep);
			}else{
			this.getView().setModel(oDataModelRep);	
			}*/
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		onPrintAsPDFPress: function() {
			var ctrlString = "width=800px, height=600px";
			var wind = window.open("", "PrintWindow", ctrlString);
			var chart1 = $("#application-LSMClient-display-component---worklist--idVizFrame1").outerHTML();
			var chart2 = $("#application-LSMClient-display-component---worklist--idVizFrame2").outerHTML();
			var chart3 = $("#application-LSMClient-display-component---worklist--idVizFrame3").outerHTML();
			var chart4 = $("#application-LSMClient-display-component---worklist--idVizFrame4").outerHTML();

			wind.document.write(chart1 + "<br/>" + chart2 + "<br/>" + chart3 + "<br/>" + chart4);
			wind.print();
			wind.close();
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		/*onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},*/

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onAfterRendering: function() {
			/*	if (this.getView().byId("idVizFrame1")) {
					var oVizFrame = this.getView().byId("idVizFrame1");
					var oPopOver = this.getView().byId("idPopOver1");
					oPopOver.connect(oVizFrame.getVizUid());

					var oVizFrame2 = this.getView().byId("idVizFrame2");
					var oPopOver2 = this.getView().byId("idPopOver2");
					oPopOver2.connect(oVizFrame2.getVizUid());

					var oVizFrame3 = this.getView().byId("idVizFrame3");
					var oPopOver3 = this.getView().byId("idPopOver3");
					oPopOver3.connect(oVizFrame3.getVizUid());

					var oVizFrame4 = this.getView().byId("idVizFrame4");
					var oPopOver4 = this.getView().byId("idPopOver4");
					oPopOver4.connect(oVizFrame4.getVizUid());
				}*/
			if (this.getView().byId("MyWorkBenchSTable")) {
			/*	var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame21");
				var oPopOver = this.getView().byId("idPopOver21");
				oPopOver.connect(oVizFrame.getVizUid());*/
				this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			}
		},
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("MatterType", FilterOperator.Contains, sQuery)];
				}
				//this._applySearch(oTableSearchState);
			}

		}

		});
	}
);