jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsmmyworkbench/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsmmyworkbench/test/integration/pages/Worklist",
		"lsmmyworkbench/test/integration/pages/Object",
		"lsmmyworkbench/test/integration/pages/NotFound",
		"lsmmyworkbench/test/integration/pages/Browser",
		"lsmmyworkbench/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmmyworkbench.view."
	});

	sap.ui.require([
		"lsmmyworkbench/test/integration/WorklistJourney",
		"lsmmyworkbench/test/integration/ObjectJourney",
		"lsmmyworkbench/test/integration/NavigationJourney",
		"lsmmyworkbench/test/integration/NotFoundJourney",
		"lsmmyworkbench/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});