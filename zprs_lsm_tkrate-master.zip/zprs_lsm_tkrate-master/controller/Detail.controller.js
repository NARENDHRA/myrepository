/*global location */
jQuery.sap.require("jszip");
sap.ui.define([
	"lsmtkrate/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"lsmtkrate/model/formatter"
], function(BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("lsmtkrate.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			this.setModel(oViewModel, "detailView");

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

		},
		getTable: function() {
			var oTable = this.getView().byId("TimeKeepersmartTable");
			return oTable.getTable();
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			var oViewModel = this.getModel("detailView");

			// this.getModel().metadataLoaded().then( function() {
			var sObjectPath = this.getView().getModel().createKey("MatterDataSet", {
				Pspid: sObjectId
			});
			var sObjPath = "/" + sObjectPath + "/CrecupdSet";
			this.sPath = sObjPath;
			var oTable = this.getView().byId("TimeKeepersmartTable");

			oTable.rebindTable();
			// this._bindView("/" + sObjectPath +"/CrecupdSet");
			// }.bind(this));
			// var that = this;
			// that.oPathsrv = sObjPath;
			// var oMDLocal = new sap.ui.model.json.JSONModel();
			// var oModel = that.getView().getModel();
			// var oTable = this.getView().byId("TimeKeepersmartTable");
			// oTable.setEntitySet(sObjPath);
			// oModel.read(sObjPath, {

			// 	success: function(data, response) {
			// 		oMDLocal.setData({
			// 			modelData: data.results
			// 		});
			// 		var oTable = that.getTable();
			// 		oTable.setModel(oMDLocal);
			// 		// oTable.setSelectionMode("None");
			// 		oTable.bindRows("/modelData");
			// 		oViewModel.setProperty("/busy", false);
			// 		oTable.setBusy(false);
			// 	},
			// 	error: function(oError) {
			// 		oViewModel.setProperty("/busy", false);
			// 	}

			// });
		},
		onbeforeRebindTable: function(evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath);
		},

		// Excel upload Functn  
		handleUpload: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file, action);

			}

		},
		// Excel Sheet read function method
		_import: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}
					// if (sheetData[0]["Name"] === undefined && sheetData[0]["Classification"] === undefined && sheetData[0]["Role"] ===
					//  undefined && sheetData[0]["Designation"] === undefined) {
					//  sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
					//   title: "Error",
					//   styleClass: "sapUiSizeCompact messageBox",
					//   icon: sap.m.MessageBox.Icon.ERROR,
					//   actions: [sap.m.MessageBox.Action.OK]
					//  });
					//  //this.getView().byId("fileUploader").setValue("");
					//  return false;
					// }
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["RecordType"] === undefined) {
							sheetData[i]["RecordType"] = "";
						}
						if (sheetData[i]["Matter"] === undefined) {
							sheetData[i]["Matter"] = "";
						}
						if (sheetData[i]["TimeKeeper"] === undefined) {
							sheetData[i]["TimeKeeper"] = "";
						}
						if (sheetData[i]["Timekeeper Name"] === undefined) {
							sheetData[i]["Timekeeper Name"] = "";
						}
						if (sheetData[i]["Rate"] === undefined) {
							sheetData[i]["Rate"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["PricingUnit"] === undefined) {
							sheetData[i]["PricingUnit"] = "";
						}
						if (sheetData[i]["Unit"] === undefined) {
							sheetData[i]["Unit"] = "";
						}
						if (sheetData[i]["DateFrom"] === undefined) {
							sheetData[i]["DateFrom"] = "";
						}
						if (sheetData[i]["DateTo"] === undefined) {
							sheetData[i]["DateTo"] = "";
						}
						if (sheetData[i]["Type"] === undefined) {
							sheetData[i]["Type"] = "";
						}

					}
					that.abd(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		onApprove: function() {
			this.abd([], "APR");
		},
		abd: function(newData, action1) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var RecordType = data["RecordType"].trim();
				var Matter = data["Matter"].trim();
				var TimeKeeper = data["TimeKeeper"].trim();
				var TimekeeperName = data["Timekeeper Name"].trim();
				var Rate = data["Rate"].trim();
				var Currency = data["Currency"].trim();
				var PricingUnit = data["PricingUnit"].trim();
				var Unit = data["Unit"].trim();
				var DateFrom = new Date(data["DateFrom"].trim());
				var DateTo = new Date(data["DateTo"].trim());
				var Type = data["Type"].trim();
				var obj = {
					//	"RecordType": RecordType,
					"Pspid": Matter,
					"Pernr": TimeKeeper,
					"Sname": TimekeeperName,
					"RecordType": RecordType,
					"Kbetr": Rate,
					"Kpein": PricingUnit,
					"Kmein": Unit,
					"Datab": DateFrom,
					"Datbi": DateTo,
					"Kschl": Type,
					"Action": "Pen",
					"Konwa": Currency
						// "Kunnr": "",
						// "Pernr": "",

					// "Datab": null,
					// "Datbi": null

				};

				if (RecordType === "" && Matter === "" && TimeKeeper === "" && TimekeeperName === "" && Rate === "" && Currency === "" &&
					PricingUnit === "" && Unit === "" && DateFrom === "" && DateTo === "" && Type === "") {
					continue;
				} else {
					objArray.push(obj);
				}
			}
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/");
			var oEntity = {
				"Uname": "UGOUDARB01",
				CrecToUser: objArray
			};
			var oSmtTable = this.getView().byId("TimeKeepersmartTable"),
				tbl = oSmtTable.getTable();
			tbl.setBusy(true);
			oModel.create("UserdataSet", oEntity, {
				success: function(oData, oResp) {
					// var smg = oData.Message;
					var smg = "SUCCESS:Condition Record Uploaded.Pending for Approval";
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getBinding("rows").refresh(true);
					tbl.setBusy(false);
				},
				error: function(oErr) {
					var smg = oErr.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}

			});
		},
		onExportExcelTimeKepeer: function(evt) {
			var sUrl = this.getModel() + this.oPathsrv + "?$format=xlsx";
			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */

		_bindView: function(sObjectPath) {
			this._sObjectPath = sObjectPath;
			this.getView().byId("TimeKeepersmartTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			// // // Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			// this.getView().bindElement({
			// 	path : sObjectPath,
			// 	events: {
			// 		change : this._onBindingChange.bind(this),
			// 		dataRequested : function () {
			// 			oViewModel.setProperty("/busy", true);
			// 		},
			// 		dataReceived: function () {
			// 			oViewModel.setProperty("/busy", false);
			// 		}
			// 	}
			// });
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Kunnr,
				sObjectName = oObject.Datbi,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		onTKRateSave: function() {
			var oTable;
			oTable = this.getView().byId("TimeKeepersmartTable").getTable();
			var objArray = [];

			$.each(oTable.getSelectedIndices(), function(i, o) {
				var obj = oTable.getContextByIndex(o).getObject();
				obj.Action = "APR";
				delete obj["__metadata"];
				objArray.push(obj);
			});
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/");
			var oEntity = {
				"Uname": "UGOUDARB01",
				CrecToUser: objArray
			};
			var oSmtTable = this.getView().byId("TimeKeepersmartTable"),
				tbl = oSmtTable.getTable();
			tbl.setBusy(true);
			oModel.create("UserdataSet", oEntity, {
				success: function() {
					var smg = "SUCCESS:Selected pending records Approved";
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getBinding().refresh(true);
					tbl.setBusy(false);
				},
				error: function(oErr) {
					var smg = oErr.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}

			});
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});