jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	], function () {
		"use strict";

		return {
			/**
			 * Rounds the currency value to 2 digits
			 *
			 * @public
			 * @param {string} sValue value to be formatted
			 * @returns {string} formatted currency value with 2 digits
			 */
			currencyValue : function (sValue) {
				if (!sValue) {
					return "";
				}

				return parseFloat(sValue).toFixed(2);
			},
			
		 statusTKText : function(sValue){
		 	if(sValue === "P"){
		 		return "Pending";
		 	}
		 	if(sValue === "A"){
		 		return "Approved";
		 	}
		 },
		 statusTKStatus : function(sValue){
		 	if(sValue === "P"){
		 		return "Warning";
		 	}
		 	if(sValue === "A"){
		 		return "Success";
		 	}
		 },
		 formatDate: function(dt) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "medium",
				UTC: true
			});

			var dateStr = dateFormat.format(dt);
			return dateStr;
		}
		};

	}
);