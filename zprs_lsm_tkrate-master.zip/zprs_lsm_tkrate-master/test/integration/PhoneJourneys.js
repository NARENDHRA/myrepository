jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"lsmtkrate/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"lsmtkrate/test/integration/pages/App",
	"lsmtkrate/test/integration/pages/Browser",
	"lsmtkrate/test/integration/pages/Master",
	"lsmtkrate/test/integration/pages/Detail",
	"lsmtkrate/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmtkrate.view."
	});

	sap.ui.require([
		"lsmtkrate/test/integration/NavigationJourneyPhone",
		"lsmtkrate/test/integration/NotFoundJourneyPhone",
		"lsmtkrate/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});