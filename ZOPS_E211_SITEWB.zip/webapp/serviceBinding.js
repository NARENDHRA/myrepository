function initModel() {
	var sUrl = "/sap/opu/odata/sap/ZOPS_EMS_SITE_WORKBENCH_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}