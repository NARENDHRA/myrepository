sap.ui.define([
	"com/p66/sitewb/ZOPS_E211_SITEWB/test/unit/controller/SiteSearchView.controller"
], function () {
	"use strict";
});