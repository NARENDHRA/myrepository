sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.p66.sitewb.ZOPS_E211_SITEWB.controller.SiteSearchView", {
		onInit: function () {
			this.getRouter();
			this.getRouter().getRoute("SiteSearchViewsec").attachPatternMatched(this._onNavBackMatch, this);
			this._onUserCallFn();
		},
		/*onInitSmartFilterBar: function (evt) {
			var s = evt.getSource(),
				Maxesults = s.getControlByKey("DimUnit");
			Maxesults.setValue("100");
		},*/
		_onNavBackMatch: function (evt) {
			this.getView().byId("swbFilterBar").search();
		},
		_onUserCallFn: function () {
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			oModel.read("/IntExtUserSet", {
				success: function (odata) {
					that.User = odata.results[0].userType;
					if (that.User !== "I") {
						that.getView().byId("dyPageIdSw").getHeader().setVisible(false);
					}
				},
				error: function (error) {}
			});
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onPressLineItemSiteNo: function (evt) {
			var siteNoVal = evt.getSource().getBindingContext().getObject().site_num;
			var oSitePhase = evt.getSource().getBindingContext().getObject().site_phase;
			var oUser = this.User;
			this.getRouter().navTo("SiteInfoViewsec", {
				siteNo: siteNoVal,
				sitephase: oSitePhase,
				User: oUser
			});
		},
		handleValueHelp: function () {

		},
		onPressNonEnvironmentalNewSite: function (evt) {
			var OnewSiteAction = evt.getSource().getText();
			var oUser = this.User;
			this.getRouter().navTo("SiteInfoViewsec", {
				NewSiteAction: OnewSiteAction,
				User: oUser
			});

		}

	});
});