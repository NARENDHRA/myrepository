sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	'sap/ui/core/Fragment',
	'sap/m/Token',
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/List',
	'sap/m/StandardListItem'
], function (Controller, History, Fragment, Token, Button, Dialog, List, StandardListItem) {
	"use strict";
	var uList = [];
	var property;
	var site_num;
	return Controller.extend("com.p66.sitewb.ZOPS_E211_SITEWB.controller.SiteInfoView", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.p66.sitewb.ZOPS_E211_SITEWB.view.SiteInfoView
		 */
		onInit: function () {
			// debugger;
			var oLocalModel = new sap.ui.model.json.JSONModel({
				oFieldEdit: false,
				visSaveBtn: false,
				visCancelBtn: false,
				visEditBtn: true,
				visAddDelete: false,
				visbleDelinationTab: true,
				visbleRegTab: true,
				visibleclaimsTab: true,
				visbleMasterTab: true,
				visbleFinanceTab: true,
				visbleStrategyTab: true,
				visbleConSultContactsTab: true,
				visSaveDraftBtn: true,
				visConvertClaimnBtn: true,
				DelBtn: true,
				CCEDbtn: true,
				oVSSiteNo: "None",
				oVSLiaCompy: "None",
				oVSPCC: "None",
				oVSLCCenter: "None",
				oVSECC: "None",
				oVSECCenter: "None",
				oVSCurrency: "None",
				oVSPlanType: "None",
				oVSPlanStatus: "None",
				oVSProjectName: "None",
				oErrorMessage: "",
				oUserNameIp: "",
				enSubmit: false,
				successmsg: []
			});
			this.getView().setModel(oLocalModel, "LocalModel");
			this.getOwnerComponent().getModel().setDefaultBindingMode("TwoWay");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("SiteInfoViewsec").attachPatternMatched(this._onObjectMatched, this);
		},
		onIntialSiteType: function (evt) {
			var oPageId;
			if (!oPageId) {
				oPageId = this.getView().byId("infoPageIds");
			}
			if (this.oSiteCreate === "Non-Environmental Site |") {
				evt.getSource().setValue("2");
				oPageId.setTitle("Non-Environmental Site");
			} else if (this.oSiteCreate === "Environmental Site |") {
				evt.getSource().setValue("1");
				oPageId.setTitle("Environmental Site");
			} else if (this.oSiteCreate === "New Claim") {
				evt.getSource().setValue("3");
				oPageId.setTitle("New Claim");
			}
		},
		onIntialSitestatus: function (evt) {
			if (this.oSiteCreate) {
				evt.getSource().setValue("S");
			}
		},
		onIntialSitePhase: function (evt) {
			if (this.oSiteCreate) {
				evt.getSource().setValue("ASM");
			}
		},
		onIntialSiteCurrency: function (evt) {
			if (this.oSiteCreate) {
				evt.getSource().setValue("USD");
			}
		},

		_onObjectMatched: function (evt) {
			var oViewModel = this.getView().getModel("LocalModel");
			var oval = evt.getParameters().arguments.siteNo;
			var oSitePhase = this._ositephase = evt.getParameters().arguments.sitephase;
			var oUser = evt.getParameters().arguments.User;
			this.oSiteCreate = evt.getParameters().arguments.NewSiteAction;
			this.oSitePahse = oSitePhase;
			this.ositeNo = oval;
			if (oval) {
				var oFincStTable = this.getView().byId("swbFinProjTable");
				var oDelineationRectable = this.getView().byId("swbDelineationRecTable");
				var oStrategyPlans = this.getView().byId("swbStrategyTable");
				var oConsultbl = this.getView().byId("swbConsultContcTable");
				var oRegulatorytbl = this.getView().byId("swbReglatoryTableID");
				var oClaimsTbl = this.getView().byId("swbClaimsTable");
				var a = "/zops_c_site_workbench(site_num='" + oval + "')";
				var spath = this.sPath = a;
				this.getView().bindElement(spath);
				oFincStTable.setProperty("tableBindingPath", this.sPath + "/to_projects");
				oFincStTable.rebindTable(true);
				oDelineationRectable.setProperty("tableBindingPath", this.sPath + "/to_declrecp");
				oDelineationRectable.rebindTable(true);
				oStrategyPlans.setProperty("tableBindingPath", this.sPath + "/to_strplan");
				oStrategyPlans.rebindTable(true);
				oConsultbl.setProperty("tableBindingPath", this.sPath + "/to_consconc");
				oConsultbl.rebindTable(true);
				oRegulatorytbl.setProperty("tableBindingPath", this.sPath + "/to_regprmts");
				oRegulatorytbl.rebindTable(true);
				oClaimsTbl.setProperty("tableBindingPath", this.sPath + "/to_claims");
				oClaimsTbl.rebindTable(true);
				if (oval.includes("CLM")) {
					oViewModel.setProperty("/CCEDbtn", true);
				} else {
					oViewModel.setProperty("/CCEDbtn", false);
				}
				if (oSitePhase === "CLM") {
					//debugger;
					oViewModel.setProperty("/visbleDelinationTab", false);
					oViewModel.setProperty("/visbleRegTab", false);
				} else {
					oViewModel.setProperty("/visibleclaimsTab", false);
				}
			} else {
				var oModel = this.getView().getModel();
				var oContextTypes = oModel.createEntry("/zops_c_site_workbench", {});
				this.getView().setBindingContext(oContextTypes);
			}
			this._onCreateSitesFn();
			this._onTabFnVisofUser(oUser, oViewModel);
		},
		_onTabFnVisofUser: function (user, olModel) {
			if (user === "I") {
				if (this.oSiteCreate === "Non-Environmental Site |") {
					olModel.setProperty("/visbleDelinationTab", false);
					olModel.setProperty("/visbleRegTab", false);
					olModel.setProperty("/visibleclaimsTab", true);
				} else if (this.oSiteCreate === "Environmental Site |") {
					olModel.setProperty("/visibleclaimsTab", true);
				} else if (this.oSiteCreate === "New Claim") {
					olModel.setProperty("/visbleDelinationTab", false);
					olModel.setProperty("/visbleRegTab", false);
					olModel.setProperty("/visibleclaimsTab", true);
				}
				olModel.setProperty("/visSaveDraftBtn", true);
				olModel.setProperty("/DelBtn", true);
				olModel.setProperty("/visConvertClaimnBtn", true);
			} else if (user === "E") {
				if (this.oSiteCreate === "Non-Environmental Site |") {
					olModel.setProperty("/visbleDelinationTab", false);
					olModel.setProperty("/visbleRegTab", false);
					olModel.setProperty("/visbleConSultContactsTab", false);
					olModel.setProperty("/visibleclaimsTab", false);
				} else if (this.oSiteCreate === "Environmental Site |") {
					olModel.setProperty("/visbleConSultContactsTab", false);
					olModel.setProperty("/visibleclaimsTab", false);
				} else if (this.oSiteCreate === "New Claim") {
					olModel.setProperty("/visbleDelinationTab", false);
					olModel.setProperty("/visbleRegTab", false);
					olModel.setProperty("/visbleConSultContactsTab", false);
					olModel.setProperty("/visibleclaimsTab", false);
				}
				olModel.setProperty("/visSaveDraftBtn", true);
				olModel.setProperty("/DelBtn", true);
				olModel.setProperty("/visConvertClaimnBtn", false);
			}
		},
		_onCreateSitesFn: function () {
			var oVModel = this.getView().getModel("LocalModel");
			if (this.oSiteCreate) {
				this.getView().unbindElement();
				oVModel.setProperty("/DelBtn", false);
				this.onPressEditfn();
			} else {
				oVModel.setProperty("/DelBtn", true);
				oVModel.setProperty("/visEditBtn", true);
			}
		},
		onNavBackPress: function (evt) {
			var oViewModel = this.getView().getModel("LocalModel");
			oViewModel.setProperty("/oFieldEdit", false);
			this.getView().unbindElement();
			var oModel = this.getOwnerComponent().getModel();
			var oContextTypes = oModel.createEntry("/zops_c_site_workbench", {});
			this.getView().setBindingContext(oContextTypes);
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("SiteSearchViewsec", false);
			}
			this.onPressCancelBtn();
			this._onVisibiltyfn();
			this._oTableRemoveItems();

			this.getView().byId("idSmartFormClaimsInfo").unbindElement();
			this.getView().byId("swbFinProjTable").getTable().removeAllItems();
			this.getView().byId("swbDelineationRecTable").getTable().removeAllItems();
			this.getView().byId("swbStrategyTable").getTable().removeAllItems();
			this.getView().byId("swbConsultContcTable").getTable().removeAllItems();
			this.getView().byId("swbReglatoryTableID").getTable().removeAllItems();
			this.getView().byId("swbClaimsTable").getTable().removeAllItems();
		},
		_oTableRemoveItems: function () {
			this.getView().byId("swbFinProjTable").unbindContext();
			this.getView().byId("swbDelineationRecTable").unbindContext();
			this.getView().byId("swbStrategyTable").unbindContext();
			this.getView().byId("swbConsultContcTable").unbindContext();
			this.getView().byId("swbReglatoryTableID").unbindContext();
			this.getView().byId("swbClaimsTable").unbindContext();

		},
		_onVisibiltyfn: function () {
			var oViewModel = this.getView().getModel("LocalModel");
			oViewModel.setProperty("/visbleDelinationTab", true);
			oViewModel.setProperty("/visbleRegTab", true);
			oViewModel.setProperty("/visibleclaimsTab", true);
		},
		onControlContxChangesEdit: function (evt) {
			if (this.oSiteCreate) {
				evt.getSource().setEditable(true);
			} else {
				evt.getParameters().editable = false;
				evt.getSource().setContextEditable(false);
				evt.getSource().setEditable(false);
			}
		},
		onControlContxChanges: function (evt) {
			if (this.sflag === true) {
				evt.getSource().setEditable(true);
			} else if (this.sflag === false) {
				evt.getSource().setEditable(true);
			}
		},
		onBeforeRebindTableFinance: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_projects");
		},
		onBeforeRebindTableDelRec: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_declrecp");
		},
		onBeforeRebindTableStgPlans: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_strplan");
		},
		onBeforeRebindTableConsultTbl: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_consconc");
		},
		onBeforeRebindTableRelatoryPermits: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_regprmts");
		},
		onBeforeRebindTableClaims: function (evt) {
			var oSrc = evt.getSource();
			oSrc.setTableBindingPath(this.sPath + "/to_claims");
		},

		//* edit button function to edit the and update the existing data..
		onPressEditfn: function (evt) {
			this.sflag = true;
			var oViewModel = this.getView().getModel("LocalModel");
			oViewModel.setProperty("/oFieldEdit", true);
			oViewModel.setProperty("/visSaveBtn", true);
			oViewModel.setProperty("/visCancelBtn", true);
			oViewModel.setProperty("/visEditBtn", false);
			oViewModel.setProperty("/visAddDelete", true);
		},
		/*onSelectUname: function (evt) {
		var username =	this.getView().byId("a").getValue();
		var oModel = this.getOwnerComponent().getModel();
		var det = oModel.readEntry("/zops_c_site_workbench", {});
		
		},*/
		//* Cancle button fucntionalty and non editable(display) mode... 
		onPressCancelBtn: function (evt) {
			this.sflag = false;
			if (this.ositeNo) {
				var a = this.getOwnerComponent().getModel();
				var oVModel = this.getView().getModel("LocalModel");
				oVModel.setProperty("/oFieldEdit", false);
				oVModel.setProperty("/visSaveBtn", false);
				oVModel.setProperty("/visCancelBtn", false);
				oVModel.setProperty("/visEditBtn", true);
				oVModel.setProperty("/visAddDelete", false);
				oVModel.setProperty("/DelBtn", true);
				a.resetChanges();
			} else {
				var oModel = this.getOwnerComponent().getModel();
				var oContextTypes = oModel.createEntry("/zops_c_site_workbench", {});
				this.getView().setBindingContext(oContextTypes);
				this.getView().byId("swbFinProjTable").getTable().removeAllItems();
				this.getView().byId("swbDelineationRecTable").getTable().removeAllItems();
				this.getView().byId("swbStrategyTable").getTable().removeAllItems();
				this.getView().byId("swbConsultContcTable").getTable().removeAllItems();
				this.getView().byId("swbReglatoryTableID").getTable().removeAllItems();
			}
		},

		//* SAVE fUNCTION AND CREATE FUNCTION ..... 
		onPressSaveSBtn: function (evt) {
			var oSitestatus;
			var oViewModel = this.getView().getModel("LocalModel");
			var oButton = evt.getSource();
			var oBtnState = evt.getSource().getCustomData()[0].getValue();
			var oDelTblData = [],
				oFinTblData = [],
				oStagTblData = [],
				oConslData = [],
				oReglData = [],
				oCliamsData = [];
			var oModel = this.getOwnerComponent().getModel();
			var oTablDelrec = this.getView().byId("swbDelineationRecTable").getTable();
			var oFinStTab = this.getView().byId("swbFinProjTable").getTable();
			var oStrategyPlansTbl = this.getView().byId("swbStrategyTable").getTable();
			var oConsulTbl = this.getView().byId("swbConsultContcTable").getTable();
			var oRegulatoryTbl = this.getView().byId("swbReglatoryTableID").getTable();
			var ocntx = this.getView().getBindingContext();
			var obj = ocntx.getObject();
			if (oBtnState === "Save") {
				obj.is_draft = false;
				//obj.status = "CMPL";  
				oSitestatus = "A";

			} else if (oBtnState === "SaveDraft") {
				obj.is_draft = true;
				//obj.status = "DRFT";
				oSitestatus = "D";
			}
			delete(obj.__metadata);
			this._oTblFinanceFunction(oFinStTab, oFinTblData);
			this._oTblDelFunction(oTablDelrec, oDelTblData);
			this._oTblStrategyTblFunction(oStrategyPlansTbl, oStagTblData);
			this._oTblConsultTblFunction(oConsulTbl, oConslData);
			this._oTblRegulaTblFunction(oRegulatoryTbl, oReglData);
			// debugger;
			if (this._ositephase === "CLM") {
				var oClaimsTabTbl = this.getView().byId("swbClaimsTable").getTable();
				this._oTblClaimsTblFunction(oClaimsTabTbl, oCliamsData);
				obj.to_claims = oCliamsData;
			}

			var toMessages = [{
				"site_num": obj.site_num,
				"operator": "test",
				"site_status": oSitestatus
			}];

			obj.to_projects = oFinTblData;
			obj.to_declrecp = oDelTblData;
			obj.to_strplan = oStagTblData;
			obj.to_consconc = oConslData;
			obj.to_regprmts = oReglData;
			obj.to_msgs = toMessages;

			var oSitenum = obj.site_num;
			var oBkursPay = obj.bukrs_payment;
			var oBukrsLaibilty = obj.bukrs_liability;
			var oKostlLiblty = obj.kostl_liability;
			var oProjectname = obj.project_name;
			var oMandatory = [];
			if (!oSitenum || !oBkursPay || !oBukrsLaibilty || !oKostlLiblty || !obj.bukrs_expense || !obj.kostl_expense ||
				!obj.curr || !obj.sys_type || !oProjectname) {
				if (!oSitenum) {
					oViewModel.setProperty("/oVSSiteNo", "Error");
					var objs = {
						"ErrorText": "Please enter valid Site Number value"
					};
					oMandatory.push(objs);
				}
				if (!oBkursPay) {
					// oViewModel.setProperty("/oVSPCC", "Error");
					var obj = {
						"ErrorText": "Please enter valid Payment Company Code value"
					};
					oMandatory.push(obj);
				}
				if (!oBukrsLaibilty) {
					// oViewModel.setProperty("/oVSLiaCompy", "Error");
					var obj1 = {
						"ErrorText": "Please enter valid Liability Company Code value"
					};
					oMandatory.push(obj1);
				}
				if (!oKostlLiblty) {
					// oViewModel.setProperty("/oVSLCCenter", "Error");
					var obj2 = {
						"ErrorText": "Please enter valid Liability Cost Center value"
					};
					oMandatory.push(obj2);
				}
				if (!obj.bukrs_expense) {
					// oViewModel.setProperty("/oVSECC", "Error");
					var obj3 = {
						"ErrorText": "Please enter valid Expense Company Code value"
					};
					oMandatory.push(obj3);
				}
				if (!obj.kostl_expense) {
					// oViewModel.setProperty("/oVSECCenter", "Error");
					var obj4 = {
						"ErrorText": "Please enter valid Expense Cost Center value"
					};
					oMandatory.push(obj4);
				}
				// if (!obj.curr) {
				// 	oViewModel.setProperty("/oVSCurrency", "Error");
				// }
				if (!obj.sys_type) {
					// oViewModel.setProperty("/oVSPlanType", "Error");
					var obj5 = {
						"ErrorText": "Please enter valid System Type value"
					};
					oMandatory.push(obj5);
				}
				if (!oProjectname) {
					oViewModel.setProperty("/oVSProjectName", "Error");
					var obj6 = {
						"ErrorText": "Please enter valid Project Name value"
					};
					oMandatory.push(obj6);
				}
				// sap.m.MessageBox.warning("Provide all the Mandatory fields");
				var ovalidationModel = new sap.ui.model.json.JSONModel();
				var oresults = {
					"res": oMandatory
				};
				ovalidationModel.setData(oresults);
				this.getView().setModel(ovalidationModel, "VMsgModel");
				if (!this._ValdDialog) {
					this._ValdDialog = sap.ui.xmlfragment("com.p66.sitewb.ZOPS_E211_SITEWB.fragments.ValidationMessage", this);
					this.getView().addDependent(this._ValdDialog);
				}
				this._ValdDialog.open();
				return;
			}
			if (this.oSiteCreate === "New Claim") {
				obj.site_num = "CLM" + obj.site_num;
			}
			if (oBtnState === "ConvertClaim") {
				var osno = obj.site_num.split("CLM")[1];
				obj.site_num = osno;
			}
			var oPayLoad = obj;

			var that = this;
			oModel.create("/zops_c_site_workbench", oPayLoad, {
				//that.getView().byId(swbFinProjTable).rebindTable();
				success: function (odata) {
					if (oBtnState === "SaveDraft") {
						that.onNavBackPress();
					}
					that.oMsgMessagedialog(odata.to_msgs);
					// sap.m.MessageBox.show("Data Posted Successfully" + odata.getData("to_msgs").hasOwnProperty(property));
					// that.onPressCancelBtn();
					// oViewModel.setProperty("/enSubmit", true);
				},
				error: function (error) {
					// var oresp = error.responseText;
					// var oMessage = oresp.split("error")[5].split(",")[3].split("'")[1];
					var oMessage = "Error while posting the data";
					sap.m.MessageBox.error(oMessage);
				}
			});
		},
		onPresMsgClose: function (evt) {
			this._ValdDialog.close();
			this._ValdDialog = "";
		},
		oMsgMessagedialog: function (msgdata) {
			var oMsgModel = new sap.ui.model.json.JSONModel();
			oMsgModel.setData(msgdata.results);
			var oViewmodel = this.getView().getModel("LocalModel");
			oViewmodel.setProperty("/successmsg", msgdata.results);
			if (!this._pressDialog) {
				this._pressDialog = sap.ui.xmlfragment("com.p66.sitewb.ZOPS_E211_SITEWB.fragments.SucessMessage", this);
				this.getView().addDependent(this._pressDialog);
			}
			this._pressDialog.open();
		},
		onPressSuccessMsgClose: function (evt) {
			var oViewModel = this.getView().getModel("LocalModel");
			this._pressDialog.close();
			this._pressDialog = "";
			//this.onPressCancelBtn();
			oViewModel.setProperty("/enSubmit", true);
		},
		_oTblClaimsTblFunction: function (tbl, oCliamsData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oCliamsData.push(object);
			});
			return oCliamsData;

		},
		_oTblRegulaTblFunction: function (tbl, oReglData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oReglData.push(object);
			});
			return oReglData;
		},
		_oTblConsultTblFunction: function (tbl, oConslData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oConslData.push(object);
			});
			return oConslData;
		},
		_oTblFinanceFunction: function (tbl, oFinTblData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oFinTblData.push(object);
			});
			return oFinTblData;
		},
		_oTblDelFunction: function (tbl, oDelTblData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oDelTblData.push(object);
			});
			return oDelTblData;
		},
		_oTblStrategyTblFunction: function (tbl, oStagTblData) {
			var object;
			var oItems = tbl.getItems();
			$.each(oItems, function (i, o) {
				object = o.getBindingContext().getObject();
				delete(object.__metadata);
				oStagTblData.push(object);
			});
			return oStagTblData;
		},
		/*Dele press functtion for  table
		onDeleteFinanceItemPress: function (evt) {
			var otbl = evt.getSource(),
				oModel = this.getOwnerComponent().getModel(),
				oContext = evt.getParameter("listItem"),
				sPath = oContext.getBindingContextPath(),
				vMessage = "Are you sure you want to delete this items??";
			sap.m.MessageBox.show(vMessage, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirm",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.No],
				onClose: function (oAction) {
					if (oAction === 'YES') {
						otbl.removeItem(oContext);
						oModel.resetChanges([sPath]);
					}
				}.bind(this)
			});
		},*/
		handleAddFinancePress: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_projects", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{pspid}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{post1}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{accr_proj}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{non_env}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{ovhd_est}",
						required: true,
						editable: true,
						uomVisible: false,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})
					// new sap.ui.comp.smartfield.SmartField({
					// 	value: "{curr}",
					// 	required: true,
					// 	editable: true,
					// 	innerControlsCreated: function (evt) {
					// 		evt.getSource().setEditable(true);
					// 	}.bind(this)
					// })
				]
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleAddDelinRecpot: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_delrecpt", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{rcpt_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{sensitive_rcpt_survey}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{sensitive_rcpt_survey_dist}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{sensitive_rcpt_survey_dir}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{sensitive_rcpt_survey_depth}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})
				]
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleAddStgtblpress: function (oEvent) {
			var oTable = oEvent.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_strgplan", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						//required: true,
						//editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{strat_num}",
						visible: false,
						//required: true,
						//editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{strat_created_on}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{type}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{status}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{contact}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{zcomment}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})
				]
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleAddConsVtblPress: function (oEvnt) {
			var oTable = oEvnt.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_conscont", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{cntct_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{role}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{company}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{name}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{phone}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{email}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{vendor_level}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})

				]
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleAddReglTbl: function (oEvnt) {
			var oTable = oEvnt.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_regperm", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{prmt_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{permit_number}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{permit_type}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{permit_exists}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{start_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{exp_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{renewal_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{link}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})
				]
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleAddclaimTbl: function (oEvnt) {
			this.getView().byId("idSmartFormClaimsInfo").bindElement("/zops_i_site_claims(site_num='',claim_num='')");
			var oTable = oEvnt.getSource().getParent().getParent();
			var oModel = this.getOwnerComponent().getModel();
			//adding lineitem level  to the binding context
			var otblContext = oModel.createEntry("/zops_i_site_claims", {});
			var oListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{site_num}",
						visible: false,
						// required: true,
						// editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_num}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_type}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_name}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_status}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_outcome}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_out_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_ini_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{claim_cls_date}",
						required: true,
						editable: true,
						innerControlsCreated: function (evt) {
							evt.getSource().setEditable(true);
						}.bind(this)
					})
				],
				type: "Navigation",
				press: function (evt) {
					this.onPressCliamNo(evt);
				}.bind(this)
			});
			oListItem.setBindingContext(otblContext);
			oTable._oTable.addItem(oListItem);
		},
		handleDeleteButtonPressed: function (oEvent) {
			var oTbl = oEvent.getSource().getParent().getParent().getTable();
			var oItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
			if (oItems.length === 0) {
				sap.m.MessageBox.warning("Please select atleast one item to delete");
			}
			for (var i = 0; i < oItems.length; i++) {
				var oselCtx = oTbl.removeItem(oItems[i]);
			}
		},
		onPressEmailSubMit: function (oEvent) {
			var that = this;
			var oButton = oEvent.getSource();
			var oModel = this.getOwnerComponent().getModel();
			var oViewModel = this.getView().getModel("LocalModel");
			var vcntx = this.getView().getBindingContext().getObject();
			var obj = vcntx;
			var oSitenum = obj.site_num;
			var oBkursPay = obj.bukrs_payment;
			var oBukrsLaibilty = obj.bukrs_liability;
			var oKostlLiblty = obj.kostl_liability;
			var oProjectname = obj.project_name;
			var oMandatory = [];
			if (!oSitenum || !oBkursPay || !oBukrsLaibilty || !oKostlLiblty || !obj.bukrs_expense || !obj.kostl_expense ||
				!obj.curr || !obj.sys_type || !oProjectname) {
				if (!oSitenum) {
					oViewModel.setProperty("/oVSSiteNo", "Error");
					var objs = {
						"ErrorText": "Please enter valid Site Number value"
					};
					oMandatory.push(objs);
				}
				if (!oBkursPay) {
					// oViewModel.setProperty("/oVSPCC", "Error");
					var obj = {
						"ErrorText": "Please enter valid Payment Company Code value"
					};
					oMandatory.push(obj);
				}
				if (!oBukrsLaibilty) {
					// oViewModel.setProperty("/oVSLiaCompy", "Error");
					var obj1 = {
						"ErrorText": "Please enter valid Liability Company Code value"
					};
					oMandatory.push(obj1);
				}
				if (!oKostlLiblty) {
					// oViewModel.setProperty("/oVSLCCenter", "Error");
					var obj2 = {
						"ErrorText": "Please enter valid Liability Cost Center value"
					};
					oMandatory.push(obj2);
				}
				if (!obj.bukrs_expense) {
					// oViewModel.setProperty("/oVSECC", "Error");
					var obj3 = {
						"ErrorText": "Please enter valid Expense Company Code value"
					};
					oMandatory.push(obj3);
				}
				if (!obj.kostl_expense) {
					// oViewModel.setProperty("/oVSECCenter", "Error");
					var obj4 = {
						"ErrorText": "Please enter valid Expense Cost Center value"
					};
					oMandatory.push(obj4);
				}
				// if (!obj.curr) {
				// 	oViewModel.setProperty("/oVSCurrency", "Error");
				// }
				if (!obj.sys_type) {
					// oViewModel.setProperty("/oVSPlanType", "Error");
					var obj5 = {
						"ErrorText": "Please enter valid System Type value"
					};
					oMandatory.push(obj5);
				}
				if (!oProjectname) {
					oViewModel.setProperty("/oVSProjectName", "Error");
					var obj6 = {
						"ErrorText": "Please enter valid Project Name value"
					};
					oMandatory.push(obj6);
				}
				var ovalidationModel = new sap.ui.model.json.JSONModel();
				var oresults = {
					"res": oMandatory
				};
				ovalidationModel.setData(oresults);
				this.getView().setModel(ovalidationModel, "VMsgModel");
				if (!this._ValdDialog) {
					this._ValdDialog = sap.ui.xmlfragment("com.p66.sitewb.ZOPS_E211_SITEWB.fragments.ValidationMessage", this);
					this.getView().addDependent(this._ValdDialog);
				}
				this._ValdDialog.open();
				return;
			}
			var oContext = oModel.createEntry("/zops_i_site_mail", {
				properties: {
					site_num: vcntx.site_num,
					p66_interest: vcntx.p66_interest,
					region_mgr_uname: "",
					mailids: "",
					addcomments: ""
				}
			});
			if (!this._oDialog) {
				Fragment.load({
					name: "com.p66.sitewb.ZOPS_E211_SITEWB.fragments.submitbtnpopup",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this._oDialog.setBindingContext(oContext);
					this.getView().addDependent(this._oDialog);
					this._oDialog.open();
				}.bind(this));
			} else {
				this._oDialog.setBindingContext(oContext);
				this.getView().addDependent(this._oDialog);
				this._oDialog.open();
			}
			/*		var that = this;
					//this.getView().byId("idSmartForm4").bindElement("/zops_i_site_mail");
					//this.getView().byId("idSmartForm4").bindElement("/zops_i_site_mail");
					var oButton = oEvent.getSource();
					var oModel = this.getOwnerComponent().getModel();
					var oViewModel = this.getView().getModel("LocalModel");
					var vcntx = this.getView().getBindingContext().getObject();
					var obj = vcntx;
					var oSitenum = obj.site_num;
					var oBkursPay = obj.bukrs_payment;
					var oBukrsLaibilty = obj.bukrs_liability;
					var oKostlLiblty = obj.kostl_liability;
					var oProjectname = obj.project_name;
					var oMandatory = [];
					if (!oSitenum || !oBkursPay || !oBukrsLaibilty || !oKostlLiblty || !obj.bukrs_expense || !obj.kostl_expense ||
						!obj.curr || !obj.sys_type || !oProjectname) {
						if (!oSitenum) {
							oViewModel.setProperty("/oVSSiteNo", "Error");
							var objs = {
								"ErrorText": "Please enter valid Site Number value"
							};
							oMandatory.push(objs);
						}
						if (!oBkursPay) {
							// oViewModel.setProperty("/oVSPCC", "Error");
							var obj = {
								"ErrorText": "Please enter valid Payment Company Code value"
							};
							oMandatory.push(obj);
						}
						if (!oBukrsLaibilty) {
							// oViewModel.setProperty("/oVSLiaCompy", "Error");
							var obj1 = {
								"ErrorText": "Please enter valid Liability Company Code value"
							};
							oMandatory.push(obj1);
						}
						if (!oKostlLiblty) {
							// oViewModel.setProperty("/oVSLCCenter", "Error");
							var obj2 = {
								"ErrorText": "Please enter valid Liability Cost Center value"
							};
							oMandatory.push(obj2);
						}
						if (!obj.bukrs_expense) {
							// oViewModel.setProperty("/oVSECC", "Error");
							var obj3 = {
								"ErrorText": "Please enter valid Expense Company Code value"
							};
							oMandatory.push(obj3);
						}
						if (!obj.kostl_expense) {
							// oViewModel.setProperty("/oVSECCenter", "Error");
							var obj4 = {
								"ErrorText": "Please enter valid Expense Cost Center value"
							};
							oMandatory.push(obj4);
						}
						// if (!obj.curr) {
						// 	oViewModel.setProperty("/oVSCurrency", "Error");
						// }
						if (!obj.sys_type) {
							// oViewModel.setProperty("/oVSPlanType", "Error");
							var obj5 = {
								"ErrorText": "Please enter valid System Type value"
							};
							oMandatory.push(obj5);
						}
						if (!oProjectname) {
							oViewModel.setProperty("/oVSProjectName", "Error");
							var obj6 = {
								"ErrorText": "Please enter valid Project Name value"
							};
							oMandatory.push(obj6);
						}
						var ovalidationModel = new sap.ui.model.json.JSONModel();
						var oresults = {
							"res": oMandatory
						};
						ovalidationModel.setData(oresults);
						this.getView().setModel(ovalidationModel, "VMsgModel");
						if (!this._ValdDialog) {
							this._ValdDialog = sap.ui.xmlfragment("com.p66.sitewb.ZOPS_E211_SITEWB.fragments.ValidationMessage", this);
							this.getView().addDependent(this._ValdDialog);
						}
						this._ValdDialog.open();
						return;
					}

					var oContext = oModel.createEntry("/zops_i_site_mail", {
						properties: {
							site_num: vcntx.site_num,
							p66_interest: vcntx.p66_interest,
							region_mgr_uname: "",
							mailids: "",
							addcomments: ""
						}
					});
					if (!this._oDialog) {
						Fragment.load({
							name: "com.p66.sitewb.ZOPS_E211_SITEWB.fragments.submitbtnpopup",
							controller: this
						}).then(function (oDialog) {
							this._oDialog = oDialog;
							this._oDialog.setBindingContext(oContext);
							this.getView().addDependent(this._oDialog);
							this._oDialog.open();
						}.bind(this));
					} else {
						this._oDialog.setBindingContext(oContext);
						this.getView().addDependent(this._oDialog);
						this._oDialog.open();
					}*/
		},
		handleValueHelp: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment("com.p66.sitewb.ZOPS_E211_SITEWB.fragments.TabSection.UserName", this);
				this.getView().addDependent(this._valueHelpDialog);
			}
			// open value help dialog filtered by the input value
			this._valueHelpDialog.open();

		},
		onPressAddRecipient: function (oEvent) {
			//	var tValue = this.byId(this.inputId);
			//	alert(tValue.getValue());	
			var userid;
			var emailid = sap.ui.getCore().getElementById("idf4user").getValue();

			//uList.add(emailid, emailid);
			var oMultiInput1 = sap.ui.getCore().getElementById("idinput");
			uList.push(new Token({
				text: emailid,
				key: emailid
			}));
			oMultiInput1.setTokens(uList);

			// add validator
			oMultiInput1.addValidator(function (args) {
				var text = args.text;

				return new Token({
					key: text,
					text: text
				});
			});

			//sap.ui.getCore().getElementById("idinput").setValue(userid);
		},
		onChangeValue: function (oEvent) {
			var a = oEvent.getSource().getId();
		},
		_handleValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new sap.ui.model.Filter(
				"bname",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_handleValueHelpClose: function (evt) {
			var oselt = sap.ui.getCore().byId("idf4user");
			var oSelectedItem = evt.getParameter("selectedItem");

			//var omodel = this.getView().getModel("LocalModel");
			if (oSelectedItem) {
				var ovalue = oSelectedItem.getProperty("title");
				oselt.setValue(ovalue);
				// var userInput = this.byId(this.inputId);
				// userInput.setValue(oSelectedItem.getTitle());
				//omodel.setProperty("/oUserNameIp", oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},
		onSendEmailPress: function (evt) {
			var oViewModel = this.getView().getModel("LocalModel");
			var oModel = this.getOwnerComponent().getModel();
			var vcntx = this.getView().getBindingContext().getObject();
			var userID = "";
			for (var i = 0; i < uList.length; i++) {
				userID += uList[i].mProperties.text + ";";

			}
			var opayload = {
				"site_num": vcntx.site_num,
				"project_name": vcntx.project_name,
				"addr": vcntx.addr,
				"city": vcntx.city,
				"state": vcntx.state,
				"county": vcntx.county,
				"pstlz": vcntx.pstlz,
				"kokrs": vcntx.kokrs,
				"bukrs_payment": vcntx.bukrs_payment,
				"bukrs_liability": vcntx.bukrs_liability,
				"kostl_liability": vcntx.kostl_liability,
				"bukrs_expense": vcntx.bukrs_expense,
				"kostl_expense": vcntx.kostl_expense,
				"bus_unit": vcntx.site_num_bu,
				"site_mgr_pernr": vcntx.site_mgr_pernr,
				"pm_comments": vcntx.pm_comments,
				"status": vcntx.status,
				"p66_interest": vcntx.p66_interest,
				"region_mgr_uname": "",
				"mailids": userID,
				"addcomments": ""
			};
			var that = this;
			oModel.create("/zops_i_site_mail", opayload, {
				success: function (odata, response) {
					var smsg = odata.retmsg;
					sap.m.MessageToast.show(smsg);
					that._oDialog.close();
					oViewModel.setProperty("/enSubmit", false);
				},
				error: function (error) {

				}
			});

		},
		onPressClose: function (evt) {
			var oformlemts = evt.getSource().getParent().getContent()[0].getItems()[0].getGroups()[0].mAggregations.formElements;
			oformlemts[0].mAggregations.fields[0].mAggregations.items[0].mProperties.value = "";
			oformlemts[3].mAggregations.fields[0].mProperties.value = "";
			var otokens = oformlemts[1].mAggregations.fields[0].mAggregations.tokenizer.mAggregations.tokens;
			for (var i = 0; i < otokens.length; i++) {
				otokens[0].setProperty("text", "");
				otokens[0].setKey("");
			}
			this._oDialog.close();
		},

		onPressDeltBtn: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var opath = this.sPath;
			var that = this;
			oModel.remove(opath, {
				success: function (odata, response) {
					var smg = response.headers.msg;
					// var smg = "Site deleted successfully";
					sap.m.MessageBox.success(smg, {
						title: "Success", // default
						onClose: function (oaction) {
							that.onNavBackPress();
						}
					});
					// sap.m.MessageBox.success("Site is successfully deleted");
					//debugger;
				},
				error: function (error) {
					//debugger;
				}
			});
		},
		onPressCliamNo: function (evt) {
			if (evt) {
				var oTblCntx = evt.getSource().getBindingContext();
				var obj = oTblCntx.getObject();
				var oFormId = this.getView().byId("idSmartFormClaimsInfo");
				var oclaimno = oTblCntx.getObject().claim_num;
				var osite_num = this.ositeNo;
				var afilter = [];
				if (oclaimno === undefined) {
					oclaimno = "";
				}
				if (osite_num === undefined) {
					osite_num = "";
				}
				//console.log("osite_num" +osite_num +""+"oclaimno" +oclaimno);
				this.getView().byId("idSmartFormClaimsInfo").bindElement("/zops_i_site_claims(site_num='" + osite_num + "',claim_num='" + oclaimno +
					"')");
			}
		},
		onUpdateClamisTbl: function (evt) {
				var tbl = evt.getSource(),
					oitems = tbl.getItems();
				if (oitems.length !== 0) {
					oitems[0].setSelected(true);
					var oFormId = this.getView().byId("idSmartFormClaimsInfo");
					var oclaimno = oitems[0].getBindingContext().getObject().claim_num;
					var osite_num = this.ositeNo;
					//console.log("osite_num" +osite_num +""+"oclaimno" +oclaimno);
					oFormId.bindElement("/zops_i_site_claims(site_num='" + osite_num + "',claim_num='" + oclaimno + "')");
				}
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.p66.sitewb.ZOPS_E211_SITEWB.view.SiteInfoView
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.p66.sitewb.ZOPS_E211_SITEWB.view.SiteInfoView
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.p66.sitewb.ZOPS_E211_SITEWB.view.SiteInfoView
		 */
		//	onExit: function() {
		//
		//	}

	});

});