sap.ui.define([
	"checkoutin/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"checkoutin/model/formatter",
	'sap/m/MessageToast',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, formatter, MessageToast, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("checkoutin.controller.Worklist", {

		formatter: formatter,
		globalFilter: [],
		_oTableSearchState: [],
		onInit: function() {
			var oView = this.getView();
			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.setSelectedKey("AllDraftBill");
			this.sKey = "AllDraftBill";
			var oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				AllDraftBills: 0,
				CheckedOut: 0,
				ToBeCheckedout: 0,
				countAll: 0,
				Comments: "",
				NewComments: "",
				addCmtEnable: false,
				saveButton: false,
				isRefresh: true,
				sSTK: "AllDraftBill"
			});
			this.setModel(oViewModel, "worklistView");
			/// comment Model 
			var comModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/zprs_bill_edit_srv/");
			this.setModel(comModel, "comModel");
			// Create an object of filters
			this._mFilters = {
				"AllDraftBills": [],
				"CheckedOut": [new sap.ui.model.Filter("Checkoutby", "NE", " ")],
				"ToBeCheckedout": [new sap.ui.model.Filter("Checkoutby", "EQ", " ")],
				"DRAFTBILL": []
			};
			this.aFilter = [];
			this.aSearchFilter = [];
			this.oCountModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV/");
			this.getTabCount();
			this.initBindingEventHandler();
			var sTbl = this.getView().byId("idDraftTable");
			sTbl.setIgnoredFields("Bname,Cname,Comments,Newcomments,Action,Tab");
		},

		onExcelButtonpress: function() {
			var idTable = this.byId("idDraftTable");
			var s = idTable._getRowBinding();
			var u = s.getDownloadUrl("xlsx") +
				"&$select=Vbeln,Pspid,Post1,Kunnr,Name1,Office,Werksname,Pernr,Bname,Zzmcurr,Mma,Zzmatgrp,Zzgrpbill,NetwrFee,NetwrSc,NetwrHc,Netwr,Waers,Checkoutby,Checkoutat,Checkinby,Checkinat,Stext";
			window.open(u);
		},
		handleColFilter: function(oEvt) {
			if (oEvt.getParameter("value") === "") {
				return;
			}
			this.initBindingEventHandler();
		},
		initBindingEventHandler: function() {
			var that = this;
			var lModel = this.getView().getModel("worklistView");
			var oTable = this.getTable();
			var pasetModle = this.getOwnerComponent().getModel();
			pasetModle.attachBatchRequestSent(function(evt) {
				oTable.setNoData(this.oBusyIndicator);
			});
			pasetModle.attachBatchRequestCompleted(function(evt) {
				lModel.setProperty("/isRefresh", false);
				oTable.setNoData(null);
				var oBinding = oTable.getBinding("rows");
				//oTable.setNoData(null); //Use default again ("No Data" in case no data is available)
				oBinding.detachChange();
				oBinding.attachChange(function() {
					if (that.sKey === "AllDraftBill") {
						that.getView().byId("idAllDraftsIconTab").setCount(oBinding.getLength());
					} else if (that.sKey === "CheckOut") {
						that.getView().byId("idCheckOutIconTab").setCount(oBinding.getLength());
					} else if (that.sKey === "ToBeCheckOut") {
						that.getView().byId("idTobeCheckedOutIconTab").setCount(oBinding.getLength());
					}
					if (oBinding.getLength() === 0) {
						var NoDBMsg = that.getResourceBundle().getText("NoDBFoundMsg");
						oTable.setNoData(NoDBMsg);
					} else {
						var LoadDB = that.getResourceBundle().getText("LoadingDraftBill");
						oTable.setNoData(LoadDB);
					}
					// Jan 19 2017 BG
					var aColumns = oTable.getColumns();
					$.each(aColumns, function(i, aCol) {
						aCol.setFiltered(aCol.isFilterableByMenu());
						aCol.setFilterValue("");
					});
					// Jan 19 2017 BG
					// that.getView().byId("table").setVisibleRowCount(6); // Set the visible row count of table to total no. of records
				}.bind(this));
			});

		},
		getTable: function() {
			return this.getView().byId("table");
		},
		updateRecords: function() {
			var oTable = this.byId("table");
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV/DBListSet");
			oModel.attachRequestCompleted(oModel.getData(), this.setTableLimit, this);
			oTable.setModel(oModel).bindRows("/d/results");
		},
		setTableLimit: function(evt) {
			var oTable = this.getView().byId("table");
			if (evt.getSource().getData() &&
				evt.getSource().getData().d &&
				evt.getSource().getData().d.results &&
				evt.getSource().getData().d.results.length > 0) {
				// tbl.setVisibleRowCount(evt.getSource().getData().d.results.length);
				evt.getSource().setSizeLimit(evt.getSource().getData().d.results.length);
			}
			if (evt.getSource().getData().d.results.length === 0) {
				var NoDBMsg = this.getResourceBundle().getText("NoDBFoundMsg");
				oTable.getNoData().setText(NoDBMsg);
			} else {
				var LoadDB = this.getResourceBundle().getText("LoadingDraftBill");
				oTable.getNoData().setText(LoadDB);
			}
			// evt.getSource().setEnableBusyIndicator(false);
		},
		onBusyStateIndicator: function(evt) {
			var msg = this.getResourceBundle().getText("LoadMsgState");
			MessageToast.show(msg);
		},
		onQuickFilter: function(oEvent) {
			this.resetFilters(oEvent);
			this.restControl();
			this.sKey = oEvent.getParameter("selectedKey");
			var lModel = this.getView().getModel("worklistView");
			lModel.setProperty("/sSTK", this.sKey);
			this.resetFilters(oEvent);
			this.applyFilter();
			this.getTable().setSelectionMode(this.sKey === "AllDraftBill" ? "None" : "MultiToggle");
			lModel.setProperty("/addCmtEnable", this.sKey !== "AllDraftBill");
			lModel.setProperty("/saveButton", this.sKey !== "AllDraftBill");
		},
		checkFilterandApply: function() {

		},
		onColumnFilter: function(oEvent) {
			var c = oEvent.getParameter("column");
			if (c.getFilterValue().length === 0) {
				var tbl = this.getTable(),
					oBinding = tbl.getBinding('rows');
				oBinding.filter(this.globalFilter, "Application");
			}
		},
		applyFilter: function() {
			var tbl = this.getTable(),
				oBinding = tbl.getBinding('rows'),
				oViewModel = this.getModel("worklistView");
			if (oViewModel.getProperty("/isRefresh")) {
				this.getTabCount();
				tbl.getModel().refresh();
			}
			oBinding.filter(this.globalFilter);
		},
		setFilterTab: function(sKey) {
			var oViewModel = this.getModel("worklistView");
			var tbl = this.getView().byId("table");
			var oBinding = tbl.getBinding('rows');
			var allFilter = [];
			switch (sKey) {
				case "AllDraftBill":
					//tbl.setSelectionMode("None");
					oViewModel.setProperty('/addCmtEnable', false);
					this.getView().byId("idCheckOutButton").setVisible(false);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idCheckInButton").setVisible(false);
					this.getView().byId("idAddComment").setVisible(false);
					this.getView().byId("idSaveButton").setVisible(false);
					this.getView().byId("idStatus").setVisible(false);
					this.getView().byId("idCheckOutBy").setVisible(false);
					this.getView().byId("idCheckOutAt").setVisible(false);
					this.getView().byId("idCheckInBy").setVisible(false);
					this.getView().byId("idCheckInAt").setVisible(false);
					break;
				case "CheckOut":
					allFilter = [new sap.ui.model.Filter("Tab", "EQ", "O")];

					allFilter = allFilter.concat(this.aFilter);
					//tbl.setSelectionMode("MultiToggle");

					oViewModel.setProperty('/addCmtEnable', true);
					this.getView().byId("idCheckInButton").setVisible(true);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idAddComment").setVisible(true);
					this.getView().byId("idSaveButton").setVisible(true);
					this.getView().byId("idStatus").setVisible(true);
					this.getView().byId("idCheckOutBy").setVisible(true);
					this.getView().byId("idCheckOutAt").setVisible(true);

					this.getView().byId("idCheckInBy").setVisible(false);
					this.getView().byId("idCheckInAt").setVisible(false);
					this.getView().byId("idCheckOutButton").setVisible(false);

					break;
				case "ToBeCheckOut":
					allFilter = [new sap.ui.model.Filter("Tab", "EQ", "I")];
					//tbl.setSelectionMode("MultiToggle");

					oViewModel.setProperty('/addCmtEnable', true);
					this.getView().byId("idCheckOutButton").setVisible(true);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idCheckInBy").setVisible(true);
					this.getView().byId("idCheckInAt").setVisible(true);
					this.getView().byId("idAddComment").setVisible(true);
					this.getView().byId("idSaveButton").setVisible(true);
					this.getView().byId("idStatus").setVisible(true);

					this.getView().byId("idCheckInButton").setVisible(false);
					this.getView().byId("idCheckOutBy").setVisible(false);
					this.getView().byId("idCheckOutAt").setVisible(false);
					break;
			}
			this.restControl();
			if (oViewModel.getProperty("/isRefresh")) {
				tbl.getModel().refresh();
			} else {
				oBinding.filter(allFilter);
			}
		},
		handleCheckInOut: function(evt) {
			var s = evt.getSource();
			s.setEnabled(false);

			var delayInvk = (function(that) {
				return function() {
					that.onCheckInOut(s);
				};
			})(this);
			jQuery.sap.delayedCall(100, this, delayInvk);
		},
		// checkout and checkin  functionaltiy
		onCheckInOut: function(s) {
			//Changed by Hansapriya 
			var oTable = this.getView().byId("table"),
				cInOut = s.data().ActionCode;
			var oSelectedRows = oTable.getSelectedIndices();
			var lModel = this.getView().getModel("worklistView");
			if (oSelectedRows.length === 0) {
				var sMsg = this.getResourceBundle().getText("sMsgs");
				sap.m.MessageToast.show(sMsg);
				s.setEnabled(true);
				return;
			}
			this.getView().byId("table").setBusy(true);

			// if (evt.getSource().getText() === this.getResourceBundle().getText("Check-In")) {
			// 	cInOut = "CIN";
			// }
			// if (evt.getSource().getText() === this.getResourceBundle().getText("Check-Out")) {
			// 	cInOut = "COUT";
			// }
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV");
			var batchChanges = [];
			$.each(oTable.getSelectedIndices(), function(i, o) {
				//Changed by Hansapriya
				var ctx = oTable.getContextByIndex(o);
				var oSelectedBillDraft = {
					Vbeln: ctx.getProperty("Vbeln"),
					Action: cInOut,
					Newcomments: ctx.getProperty("Newcomments")
				};
				//Changed by Hansapriya 17/11/16, to avoid save of same comment multiple times,on click of save btn several times
				var m = ctx.getModel();
				m.setProperty(ctx.getPath() + "/Newcomments", "");
				batchChanges.push(oModel.createBatchOperation("/DBListSet", "POST", oSelectedBillDraft));
			});
			oModel.addBatchChangeOperations(batchChanges);
			//submit changes and refresh the table and display message&nbsp;\&nbsp;
			oModel.setUseBatch(true);
			var that = this;
			oModel.submitBatch(function(data) {
					var isSuccess = false;
					var errorData = {};
					errorData.results = [];
					var receivedData = data.__batchResponses[0].__changeResponses;
					//Changed by Hansapriya
					$.each(oTable.getSelectedIndices(), function(inx, o) {
						var sobj = oTable.getContextByIndex(o).getObject();
						var a = receivedData.filter(function(obj) {
							return obj.data.Vbeln === sobj.Vbeln;
						});
						//Changed by Hansapriya 30/11/2016 view btn color change
						var ctx = oTable.getContextByIndex(o);
						var m = ctx.getModel(ctx.getPath());
						m.setProperty(ctx.getPath() + "/Comments", "newComments");
						if (a.length === 1) {
							m.setProperty(ctx.getPath() + "/Iserror", a[0].data.Iserror);
							m.setProperty(ctx.getPath() + "/Message", a[0].data.Message);
							if (a[0].data.Iserror === "S") {
								isSuccess = true;
							}
						}
					});
					if (isSuccess) {
						lModel.setProperty("/isRefresh", true);
						//that.getTabCount();
						//Changed by Hansapriya 30/11/16,BM-414 Message toast on successful table load.
						that.onBusyStateIndicator();
					}
					oTable.setBusy(false);
					s.setEnabled(true);
				},
				function(oErr) {
					oTable.setBusy(false);
					s.setEnabled(true);
				});
		},
		setCellProperty: function(cells, fieldName, resp) {
			$.each(cells, function(i, cell) {
				if (cell.data().fieldName && cell.data().fieldName === "status") {
					var iSource = formatter.SeTStatusIcon(resp.Iserror);
					var color = formatter.SeTStatusIconColor(resp.Iserror);
					cell.setSrc(iSource);
					cell.setColor(color);
					cell.setTooltip(resp.Message);
				}
			});
		},
		onSearch: function(oEvent) {
			var sQuery = oEvent.getParameter("query");
			var tFilter = [];
			if (this.sKey === "CheckOut") {
				tFilter.push(new sap.ui.model.Filter("Tab", "EQ", "O"));
			}
			if (this.sKey === "ToBeCheckOut") {
				tFilter.push(new sap.ui.model.Filter("Tab", "EQ", "I"));
			}
			if (sQuery) {
				tFilter.push(new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Bname", sap.ui.model.FilterOperator.Contains, sQuery)
					],
					false));
			}
			this.getTable().getBinding("rows").filter(tFilter);
		},
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			var tbl = this.getView().byId("table");
			//this.initBindingEventHandler();
			tbl.getBinding("rows").filter(oTableSearchState);
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState && oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
			// this.onUpdateFinished();
		},
		restControl: function() {
			var lModel = this.getView().getModel("worklistView");
			this.aFilter = [];
			this.aSearchFilter = [];
			this.globalFilter = [];
			this.messageRest();
			this.byId("searchField").setValue("");
			this.byId("searchField").fireSearch();
			var tbl = this.getTable(),
				oBinding = tbl.getBinding('rows');
			oBinding.aApplicationFilters = [];
			/*	lModel.setProperty("/addCmtEnable", false);
				lModel.setProperty("/saveButton", false);
				if (this.sKey !== "AllDraftBill") {
					lModel.setProperty("/addCmtEnable", true);
					lModel.setProperty("/saveButton", true);
				}*/
			// TO DO: clear all column filter values
		},
		messageRest: function() {
			var tbl = this.getView().byId("table");
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var ctx = tbl.getContextByIndex(o);
				var m = ctx.getModel(ctx.getPath());
				m.setProperty(ctx.getPath() + "/Iserror", "");
				m.setProperty(ctx.getPath() + "/Message", "");
			});
			tbl.clearSelection();
		},
		resetFilters: function(oEvt) {
			switch (this.sKey) {
				case "AllDraftBill":
					this.globalFilter = [];
					break;
				case "CheckOut":
					this.globalFilter = [new sap.ui.model.Filter("Tab", "EQ", "O")];
					break;
				case "ToBeCheckOut":
					this.globalFilter = [new sap.ui.model.Filter("Tab", "EQ", "I")];
					break;
			}
		},
		getTabCount: function(evt) {
			var oViewModel = this.getModel("worklistView"),
				that = this,
				oModel = this.oCountModel,
				sKeyArray = ["CheckedOut", "ToBeCheckedout", "AllDraftBills"],
				c1Filter = this._mFilters[sKeyArray[0]].length > 0 ? this._mFilters[sKeyArray[0]] : [],
				c2Filter = this._mFilters[sKeyArray[1]].length > 0 ? this._mFilters[sKeyArray[1]] : [],
				c3Filter = this._mFilters[sKeyArray[2]].length > 0 ? this._mFilters[sKeyArray[2]] : [];

			if (!oViewModel.getProperty("/isRefresh")) {
				return;
			}
			if ((this.aSearchFilter && this.aSearchFilter.length > 0) || (this.aFilter && this.aFilter.length > 0)) {
				if (this.aFilter.length > 0) {
					c1Filter = c1Filter.concat(this.aFilter);
					c2Filter = c2Filter.concat(this.aFilter);
					c3Filter = c3Filter.concat(this.aFilter);
				}
				if (this.aSearchFilter && this.aSearchFilter.length > 0) {
					c1Filter = c1Filter.concat(this.aSearchFilter);
					c2Filter = c2Filter.concat(this.aSearchFilter);
					c3Filter = c3Filter.concat(this.aSearchFilter);
				}
				c1Filter = [new Filter(c1Filter, true)];
				c2Filter = [new Filter(c2Filter, true)];
				c3Filter = [new Filter(c3Filter, true)];
			} else {
				c1Filter = this._mFilters[sKeyArray[0]];
				c2Filter = this._mFilters[sKeyArray[1]];
				c3Filter = this._mFilters[sKeyArray[2]];
			}
			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[0], response.body);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c1Filter
			});
			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[1], response.body);
					//	oTbl.setBusy(false);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c2Filter
			});
			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[2], response.body);
					//	oTbl.setBusy(false);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c3Filter
			});

		},
		onRefreshButtonpress: function(oEvt) {
			var oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/isRefresh", true);
			this.restControl();
			this.resetFilters(oEvt);
			this.getTabCount(oEvt);
			this.getTable().getModel().refresh();
		},

		setCommentVisibility: function(s, index) {
			return; // this need to be fixed yet
			if (index !== undefined) {
				if (s.getContextByIndex(index).getObject().addButton === undefined)
					s.getContextByIndex(index).getObject().addButton = ""; // Set some value to the field to enabling add button
				else s.getContextByIndex(index).getObject().addButton = undefined; // Set no value to field for disabling add button
				// var cmtCell = s.getRows()[index].getCells()[16];
				// cmtCell.getContent()[1].setEnabled(!cmtCell.getContent()[1].getEnabled());
			} else {
				if (s.getBinding() && s.getBinding().aIndices) {
					var iIndex = s.getBinding().aIndices;
					for (var i = 0; i < iIndex.length; i++) {
						if (s.getContextByIndex(i).getObject().addButton === undefined)
							s.getContextByIndex(i).getObject().addButton = ""; // Set some value to the field to enabling add button
						else s.getContextByIndex(i).getObject().addButton = undefined; // Set no value to field for disabling add button
					}
				}
			}
		},
		/// ON comment filed QickView 
		showQuickView: function(oEvt) {
			var src = oEvt.getSource();
			var caller = src.data().caller;
			var fragPath = "checkoutin.fragments.Comment";
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			worklistData.caller = caller;
			if (caller !== "multi") {
				var obj = src.getBindingContext().getObject();
				worklistData.NewComments = obj.Newcomments;
			} else {
				worklistData.NewComments = "";
			}
			worklistModel.setData(worklistData);
			worklistModel.refresh();
			if (!this.oQuick) {
				this.oQuick = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.oQuick);
			}
			this.oQuick.setBindingContext(src.getBindingContext());
			this.oQuick.openBy(oEvt.getSource());
		},
		//displayComment of quick view 
		disPlayComment: function(oEvt) {
			var src = oEvt.getSource();

			var fragPath = "checkoutin.fragments.DisplayComment";
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			var obj = src.getBindingContext().getObject();
			worklistData.Comments = obj.Comments;

			worklistModel.setData(worklistData);
			worklistModel.refresh();
			if (!this.displayCmt) {
				this.displayCmt = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.displayCmt);
			}
			var comList = sap.ui.getCore().byId("commentsList");
			var binding = comList.getBinding("items");
			var filters = [];
			filters.push(new Filter("Area", FilterOperator.EQ, "W1"));
			filters.push(new Filter("Vbeln", FilterOperator.EQ, obj.Vbeln));
			binding.filter(filters);
			this.displayCmt.openBy(oEvt.getSource());
		},
		handlCommentClose: function(oEvt) {
			this.displayCmt.close();
		},
		handleCommentAdd: function(oEvent) {
			var tbl = this.getView().byId('table');
			var src = oEvent.getSource();
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			if (worklistData.caller === "multi") {
				//Changed by Hansapriya 17/11/2016
				// $.each(tbl.getSelectedContexts(), function(i, o) {
				// 	var OData = o.getObject();
				$.each(tbl.getSelectedIndices(), function(i, o) {
					var oCtxt = tbl.getContextByIndex(o);
					//var OData = oCtxt.getObject();
					// OData.Newcomments = worklistData.NewComments;
					// var m = oCtxt.getModel(oCtxt.getPath());
					// m.setProperty(oCtxt.getPath() + "/Comments", OData.NewComments);
					var m = oCtxt.getModel(oCtxt.getPath());
					m.setProperty(oCtxt.getPath() + "/Newcomments", worklistData.NewComments);
				});
			} else {
				// var obj = src.getBindingContext().getObject();
				// obj.Newcomments = worklistData.NewComments;
				var oCtxt = src.getBindingContext();
				var m = oCtxt.getModel(oCtxt.getPath());
				m.setProperty(oCtxt.getPath() + "/Newcomments", worklistData.NewComments);

			}
			this.oQuick.close();

		},

		onPress: function(oEvent) {
			var s = oEvent.getSource(),
				rowIndex = oEvent.getParameter("rowIndex"),
				selectAll = oEvent.getParameter("selectAll"),
				that = this;
			if (selectAll) {
				$.each(s.getSelectedIndices(), function(i, index) {
					that.setCommentVisibility(s, index);
				});
			} else if (rowIndex >= 0) {
				that.setCommentVisibility(s, rowIndex);
			} else {
				that.setCommentVisibility(s, undefined);
			}
		},
		onNavBack: function() {
			history.go(-1);
		},
		// Switch to My WorkList Appilcation
		switchApp: function(oEvent) {
			//Changed by Hansapriya. 25/10/2016
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.toExternal({
				target: {
					semanticObject: "ZPRS_MY_WKLIST",
					action: "display"
				}
			});
		},
		// navigation to handle press link on draft bill Status.
		handleAuditTrailReport: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject();
			var oHref = "#ZPRS_WF_DA-display&/" + oObj.Vbeln;
			oSelItem.setHref(oHref);
		},
		// navigation to bill edit application 
		onPressBill: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject(),
				billerUrl;

			billerUrl = "/sap/bc/ui5_ui5/sap/zprs_bedit/index.html#/main/" + oObj.Vbeln;
			sap.m.URLHelper.redirect(billerUrl, true);

		}

	});
});