jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		// numberUnit : function (sValue) {
		// 	if (!sValue) {
		// 		return "";
		// 	}
		// 	return parseFloat(sValue).toFixed(2);
		// }

		convertDate: function(sBool) {
			return sBool;
			if (sBool) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});

				// var sJsonDate = "/Date(1402166783294)/";
				var sNumber = sBool.replace(/[^0-9]+/g, '');
				var iNumber = sNumber * 1; //trick seventeen  
				var oDate = new Date(iNumber);
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(oDate.getTime() + TZOffsetMs));
				return dateStr;

			}
		},
		SeTStatusIcon: function(isError) {
			if (isError === "S") {
				return "sap-icon://message-success";
			} else if (isError === "E") {
				return "sap-icon://message-error";
			} else if (isError === "" || isError === null || isError === undefined) {
				return "";
			}
		},
		SeTStatusIconColor: function(isError) {
			if (isError === "S") {
				return "Green";
			} else if (isError === "E") { 
				return "Red";
			}
		},
		SeTIconToolTip: function(isError) {
			if (isError === "S") {
					return this.getResourceBundle().getText("CheckoutMsg");
				// return "Checkout Successfull";
			} else if (isError === "E") {
				return "Error";
			} else if (isError === "" || isError === null || isError === undefined) {
				return "";
			}
		},
		toggleButtonColor: function(sComments) {
			// if (sComments === null || sComments === undefined || sComments === "" || sComments === " ")
			// 	return sap.m.ButtonType.Default;
			// else return sap.m.ButtonType.Emphasized;
			if (sComments && sComments.length > 0) {
				return sap.m.ButtonType.Emphasized;
			}
			// else if(nComments && nComments.length > 0 ){
			// 	return sap.m.ButtonType.Emphasized;
			// 			}
			return sap.m.ButtonType.Default;
		},

		enableAddButton: function(sComments) {
			if (sComments === undefined) return false;
			// else if(sComments !== "") return true;
			else return true;
		},
		//Changed by Hansapriya, 02/12/16 BM-712
		convertTimestamp:  function(date, time) {//function(oDate, oTime) {
							var dt = date.split("T");
							var c = time.slice(2, 4) + ":" + time.slice(5, 7) + ":" + time.slice(8, 10);
							var fine = dt[0].concat("T" + c);
							var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
													style: "medium",UTC:true
												});
							var fdt = new Date(fine);
							var TZOffsetMs = fdt.getTimezoneOffset() * 60 * 1000;
							var dateStr = dateFormat.format(new Date(fine));
							return dateStr;
			/*var sDate = oDate.split("T");
			var sTime = oTime.slice(2, 4) + ":" + oTime.slice(5, 7) + ":" + oTime.slice(8, 10);
			var sTimestamp = sDate[0].concat("," + " " + sTime);
			return sTimestamp;*/
		},
		currentFields:function(key){
			if(key === "AllDraftBill"){
				return false;
			}
			return true;
		},
		checkInFields:function(key){
			if(key === "ToBeCheckOut"){
				return true;
			}
			return false;
		},
		checkOutFields:function(key){
			if(key === "CheckOut"){
				return true;
			}
			return false;
		}
	};

});