sap.ui.define([], function() {
	"use strict";
	return {
		_loadExcelJSONData: function() {
			var obj = {
				"Matterk": "",
				"Workingofficek": "",
				"Barcode": "",
				"Locationcode": "",
				"Personaldata": "",
				"Partnerauthreq": "",
				"Description": "",
				"Destructiondue": null,
				"Status": "",
				"Statusdate": null,
				"Createdbycname": "",
				"Createdat": null,
				"Matter": "",
				"Workingoffice": "",
				"Statusdesc": "",
				"Locationdesc": "",
				"Locationname": "",
				"Locatointype": "",
				"Clientk": "",
				"Client": "",
				"Matterstatus": ""
			};
			return obj;
		}
	};
});