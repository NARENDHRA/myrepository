jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	] , function () {
		"use strict";
		return {
			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			editableformatter:function(value){
				if(value){
					return false;
				}
				else{
					return true;
				}
			},
			formatDate: function(iValue) {
			var value1;
			if (!iValue) {
				return null;
			} else {
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
					pattern: "YYYY-MM-dd"
				});
				value1 = oDateFormat.format(iValue);
				var dateVal = value1 + "T00:00:00";
				return dateVal;
			}
		}

		};

	}
);