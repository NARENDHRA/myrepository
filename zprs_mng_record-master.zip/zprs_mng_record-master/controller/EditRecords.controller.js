sap.ui.define([
	"managerecrds/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, MessageBox) {
	"use strict";
	return BaseController.extend("managerecrds.controller.EditRecords", {
		onInit: function() {
			var AddMulRec = new JSONModel({});
			this.setModel(AddMulRec, "AddMulRec");
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("edit").attachPatternMatched(this._onEditMatched, this);
		},
		_onEditMatched: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			oModel.resetChanges();
			var oEditModel = sap.ui.getCore().getModel("EditModel"),
				that = this;
			var oTable = this.getView().byId("EditLineItemsSmartTable").getTable();
			oTable.removeAllItems();
			$.each(oEditModel, function(i, val) {
				var items = that.oTemplateMultidEdit();
				items.setBindingContext(val);
				oTable.addItem(items);
			});

			//Code: Handling fiori launchpad nav back button
			/*---Starts Here---*/
			this.fBackButton = sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction;
			sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction = function() {
				// window.history.go(-1);
				this.onBackButtonPressed();
			}.bind(this);
			/*---Ends Here---*/
		},
		onSaveEdit: function(oEvnt) {
			var that, oModel, oTable, oItems, isValid, smg, eMsg;
			oModel = this.getModel();
			smg = this._oResourceBundle.getText("successMsg");
			eMsg = this._oResourceBundle.getText("errorMsg");
			// dateValMsg = this._oResourceBundle.getText("dateValMsg"),
			oTable = this.getView().byId("EditLineItemsSmartTable");
			oItems = oTable.getTable().getItems();
			isValid = false;
			that = this;
			// $.each(oItems, function(i, val) {
			// 	// var oDestDate = oItems[0].getBindingContext().getProperty("Destructiondue");
			// 	// var oCurrDate = new Date();
			// 	// if (oDestDate < oCurrDate) {
			// 	// 	MessageBox.error(dateValMsg);
			// 	// } else {
			// 	isValid = true;
			// 	// }
			// });
			// if (isValid) {
			if (!$.isEmptyObject(oModel.getPendingChanges())) {
				oModel.submitChanges({
					groupId: "changes",
					success: function(odata) {
						var oEmsg = odata.__batchResponses[0].message;
						//errors occured
						if (oEmsg) {
							var ores = odata.__batchResponses[0].response.body;
							var data = jQuery.parseJSON(ores);
							var errordetaisl = data.error.innererror.errordetails;
							if (errordetaisl.length) {
								$.each(errordetaisl, function(i, cntx) {
									var ostr = cntx.propertyref;
									that.resColVal = ostr.split("/")[1];
									var otrag = cntx.target;
									var resArry = otrag.split("|");
									that.resMatter = resArry[0];
									that.resOffice = resArry[1];
									$.each(oItems, function(i, obj) {
										var matterNo = obj.getBindingContext().getObject().Matterk;
										var officeNo = obj.getBindingContext().getObject().Workingofficek;
										if (that.resMatter === matterNo && that.resOffice === officeNo) {
											var oTabRowCells = oItems[i].getCells();
											$.each(oTabRowCells, function(c, val) {
												if (c !== 2 && c !== 4 &&  c !==7) {
													var oPath = oTabRowCells[c]._oValueBind.path;
												}
												if (that.resColVal === oPath) {
													oTabRowCells[c].setValueState("Error");
												}

											});
										}

									});
								});
								that.applyResp(errordetaisl);
							}
						}
						//If no errors occured 
						else {
							var dialog = new sap.m.Dialog({
								title: "Success",
								type: "Message",
								state: "Success",
								content: new sap.m.Text({
									text: smg
								}),
								beginButton: new sap.m.Button({
									text: "OK",
									press: function() {
										that.getRouter().navTo("worklist", true);
										dialog.close();
									}
								}),
								endButton: new sap.m.Button({
									text: "Cancel",
									press: function() {
										oTable.getTable().removeAllItems();
										dialog.close();
									}
								})
							});
							dialog.open();
						}
					}.bind(this),
					error: function() {}
				});
			} else {
				MessageBox.warning(eMsg);
			}
			// }
		},
		applyResp: function(results) {
			this.getView().getModel("AddMulRec").setProperty("/ErrorList", results);
			if (!this.errorList) {
				this.errorList = sap.ui.xmlfragment(this.getView().getId(), "managerecrds.fragments.ErrorList",
					this);
				this.getView().addDependent(this.errorList);
			}
			this.errorList.openBy(this.getView().byId("isEditSave"));
		},
			oncancelPress: function() {
			var msg, oModel, oTable, oBindingItems;
			msg = this._oResourceBundle.getText("BackBtnMsg");
			oModel = this.getOwnerComponent().getModel();
			oTable = this.getView().byId("EditLineItemsSmartTable");
			oBindingItems = oTable.getTable().getItems();
			if (oBindingItems.length === 0) {
				window.history.go(-1);
			}
			if (oBindingItems.length > 0) {
				MessageBox.warning(
					msg, {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								oTable.getTable().removeAllItems();
								window.history.go(-1);
							}
						}
					}
				);
			}
		}

	});

});