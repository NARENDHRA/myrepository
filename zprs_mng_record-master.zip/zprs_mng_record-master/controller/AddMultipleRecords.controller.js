jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
	"managerecrds/controller/BaseController",
	"managerecrds/model/JsonData",
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet"
], function(BaseController, JsonData, JSONModel, MessageBox, MessageToast, Spreadsheet) {
	"use strict";
	return BaseController.extend("managerecrds.controller.AddMultipleRecords", {
		JsonData: JsonData,
		onInit: function() {
			var AddMulRec = new JSONModel({
				isSaveBtnEnable: false
			});
			this.setModel(AddMulRec, "AddMulRec");
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oViewModel = this.getView().getModel("AddMulRec");
			oViewModel.setProperty("/isSaveBtnEnable", false);
			//Code: Handling fiori launchpad nav back button
			/*---Starts Here---*/
			this.fBackButton = sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction;
			sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction = function() {
				// window.history.go(-1);
				this.onBackButtonPressed();
			}.bind(this);
			/*---Ends Here---*/
			var oModel = this.getOwnerComponent().getModel();
			oModel.resetChanges();
			var oTable = this.getView().byId("addNewLineItem").getTable();
			oTable.removeAllItems();
		},
		onAddRowPress: function() {
			var that = this,
				oTable, items, oViewModel, oContext;
			oViewModel = this.getView().getModel("AddMulRec");
			oContext = this.getView().getModel().createEntry("/Recordsworklists", {
				properties: {
					"Useraction": "CREATE"
				}
			});
			oTable = that.getView().byId("addNewLineItem").getTable();
			items = that.oTemplateMultiAdd();
			items.setBindingContext(oContext);
			oTable.addItem(items);
			oViewModel.setProperty("/isSaveBtnEnable", true);
		},
		//Delete Row
		onDeleteRowPress: function(oEvent) {
			var oTable = oEvent.getSource(),
				oModel = this.getModel(),
				oContext = oEvent.getParameter("listItem"),
				sPath = oContext.getBindingContextPath(),
				oDelMsg = this._oResourceBundle.getText("delMsg");
			sap.m.MessageBox.show(oDelMsg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirm",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function(oAction) {
					if (oAction === "YES") {
						oTable.removeItem(oContext);
						oModel.resetChanges([sPath]);
					}
				}.bind(this)
			});
		},
		//End Delete
		//Excel data add to table
		handleValueChange: function(oEvnt) {
			var oFileUpId = this.byId("fileUpload"),
				domRef = oFileUpId.getFocusDomRef(),
				file = domRef.files[0];
			oFileUpId.clear();
			this._import(file);
		},
		_creatobjPy: function(Data) {
			var oMod = this.getView().getModel(),
				excelData = [],
				that = this,
				oViewModel = this.getView().getModel("AddMulRec");
			//Excel Header set
			for (var k = 0; k < Data.length; k++) {
				var data = Data[k],
					oExcelJson = this.JsonData._loadExcelJSONData();
				oExcelJson.Matterk = data["Matter Number"] ? data["Matter Number"].trim() : "",
					oExcelJson.Workingofficek = data["Working Office"] ? data["Working Office"].trim() : "",
					oExcelJson.Barcode = data.Barcode ? data.Barcode.trim() : "",
					oExcelJson.Locationcode = data["Location Code"] ? data["Location Code"].trim() : "",
					oExcelJson.Personaldata = data["Personal Data"],
					oExcelJson.Partnerauthreq = data["Partner Auth. Reqd"],
					oExcelJson.Description = data["Record Description"] ? data["Record Description"].trim() : null,
					oExcelJson.Destructiondue = data["Destruction Due Date"] ? data["Destruction Due Date"].trim() : null,
					oExcelJson.Status = data["Record Status"] ? data["Record Status"].trim() : "",
					oExcelJson.Statusdate = data["Status Date"] ? data["Status Date"].trim() : null,
					oExcelJson.Createdbycname = data["Created By"] ? data["Created By"].trim() : "",
					oExcelJson.Createdat = data["Created On"] ? data["Created On"].trim() : null,
					// oExcelJson.Changedby = data["Changed By"] ? data["Changed By"].trim() : "",
					// oExcelJson.Changedat = data["Changed On"] ? data["Changed On"].trim() : null,
					oExcelJson.Matter = data["Matter Description"] ? data["Matter Description"].trim() : "",
					oExcelJson.Workingoffice = data["Working Office"] ? data["Working Office"].trim() : "",
					oExcelJson.Statusdesc = data["Record Status Desc"] ? data["Record Status Desc"].trim() : "",
					oExcelJson.Locationdesc = data["Location Description"] ? data["Location Description"].trim() : "",
					oExcelJson.Locationname = data["Location Name"] ? data["Location Name"].trim() : "",
					oExcelJson.Locatointype = data["Location Type"] ? data["Location Type"].trim() : "",
					oExcelJson.Clientk = data.Client ? data.Client.trim() : "",
					oExcelJson.Client = data["Client Name"] ? data["Client Name"].trim() : "",
					oExcelJson.Matterstatus = data["Matter Status Description"] ? data["Matter Status Description"].trim() : "";

				if (oExcelJson.Createdat) {
					oExcelJson.Createdat = new Date(oExcelJson.Createdat);
				}
				if (oExcelJson.Destructiondue) {
					oExcelJson.Destructiondue = new Date(oExcelJson.Destructiondue);
				}
				if (oExcelJson.Statusdate) {
					oExcelJson.Statusdate = new Date(oExcelJson.Statusdate);
				}
				if (oExcelJson.Changedat) {
					oExcelJson.Changedat = new Date(oExcelJson.Changedat);
				}
				excelData.push(oExcelJson);
			}

			//End Excel header
			var oTable = that.getView().byId("addNewLineItem").getTable();
			$.each(excelData, function(i, val) {
				val.Useraction = "CREATE";
				var oContext = oMod.createEntry("/Recordsworklists", {
					properties: val
				});
				var items = that.oTemplateMultiAdd();
				items.setBindingContext(oContext);
				oTable.addItem(items);

			});
			oViewModel.setProperty("/isSaveBtnEnable", true);
		},

		//handle MultiLine items save
		onSaveMutiRecPress: function() {
			var oModel, oTable, oItems, reqFieldsmsg, isValidate, createSucMsg, wmsg;
			reqFieldsmsg = this._oResourceBundle.getText("ReqFieldsMsg");
			wmsg = this._oResourceBundle.getText("WMSg");
			createSucMsg = this._oResourceBundle.getText("createSucMsg");
			isValidate = true;
			oModel = this.getModel();
			oTable = this.getView().byId("addNewLineItem").getTable();
			oItems = oTable.getItems();
			if (oItems.length === 0) {
				MessageBox.error(wmsg);
				return;
			}
			//Looping for validation 
			$.each(oItems, function(i, obj) {
				var oTabRowCells = oItems[i].getCells();
				$.each(oTabRowCells, function(c, val) {
					if (c !== 2 && c !== 8 && c !== 9) {
						var oCell = oTabRowCells[c]._oValueBind.path;
						if (oCell) {
							if ((oCell === "Matterk") || (oCell === "Workingofficek") || (oCell === "Barcode") || (oCell === "Createdat") || (oCell ===
									"Status")) {
								var oCellValue = oTabRowCells[c].getValue();
								if (oCellValue === "") {
									oTabRowCells[c].setValueState("Error");
									isValidate = false;
								}
							}
						}
					} else {
						var oCellValue = oTabRowCells[c].getValue();
						if (oCellValue === "") {
							oTabRowCells[c].setValueState("Error");
							isValidate = false;
						}
					}

				});
			});
			//End Looping for validation
			if (!isValidate) {
				MessageBox.error(
					reqFieldsmsg);
				return;
			}
			var that = this;
			var mParameters = {
				"groupId": "changes",
				success: function(odata) {
					var oEmsg = odata.__batchResponses[0].message;
					if (oEmsg) {
						var ores = odata.__batchResponses[0].response.body;
						var data = jQuery.parseJSON(ores);
						var errordetaisl = data.error.innererror.errordetails;
						if (errordetaisl.length) {
							$.each(errordetaisl, function(i, cntx) {
								var ostr = cntx.propertyref;
								that.resColVal = ostr.split("/")[1];
								var otrag = cntx.target;
								var resArry = otrag.split("|");
								that.resMatter = resArry[0];
								that.resOffice = resArry[1];
								$.each(oItems, function(i, obj) {
									var matterNo = obj.getBindingContext().getObject().Matterk;
									var officeNo = obj.getBindingContext().getObject().Workingofficek;
									if (that.resMatter === matterNo && that.resOffice === officeNo) {
										var oTabRowCells = oItems[i].getCells();
										$.each(oTabRowCells, function(c, val) {
											if (c !== 2 && c !== 8 && c !== 9) {
												var oPath = oTabRowCells[c]._oValueBind.path;
											}
											if (that.resColVal === oPath) {
												oTabRowCells[c].setValueState("Error");
											} else {
												if (c === 9) {
													if (that.resColVal === "Destructiondue") {
														oTabRowCells[c].setValueState("Error");
													}
												}

											}
										});
									}

								});
							});
							that.applyResp(errordetaisl);
						}

					} else {
						var dialog = new sap.m.Dialog({
							title: 'Success',
							type: 'Message',
							state: 'Success',
							content: new sap.m.Text({
								text: createSucMsg
							}),
							beginButton: new sap.m.Button({
								text: 'OK',
								press: function() {
									that.getRouter().navTo("worklist", true);
									dialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text: 'Continue',
								press: function() {
									oTable.removeAllItems();
									dialog.close();
								}
							})
						});
						dialog.open();
					}
				},
				error: function(error) {}
			};
			oModel.submitChanges(mParameters);
		},
		applyResp: function(results) {
			this.getView().getModel("AddMulRec").setProperty("/ErrorList", results);
			if (!this.errorList) {
				this.errorList = sap.ui.xmlfragment(this.getView().getId(), "managerecrds.fragments.ErrorList",
					this);
				this.getView().addDependent(this.errorList);
			}
			this.errorList.openBy(this.getView().byId("isSaveRecords"));
		},
		oncancelPress: function() {
			var msg, oModel, oTable, oBindingItems;
			msg = this._oResourceBundle.getText("BackBtnMsg");
			oModel = this.getOwnerComponent().getModel();
			oTable = this.getView().byId("addNewLineItem");
			oBindingItems = oTable.getTable().getItems();
			if (oBindingItems.length === 0) {
				window.history.go(-1);
			}
			if (oBindingItems.length > 0) {
				MessageBox.warning(
					msg, {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								oTable.getTable().removeAllItems();
								window.history.go(-1);
							}
						}
					}
				);
			}
		},
		//Excel download from client side
		createColumnConfig: function() {
			var i18nLabel = this.getView().getModel("i18n").getResourceBundle();

			return [{
				label: i18nLabel.getText("MtrNum"),
				property: "Matterk",
				type: 'number'
			}, {
				label: i18nLabel.getText("WorkingOff"),
				property: "Workingofficek",
				type: 'string'
			}, {
				label: i18nLabel.getText("Barcode"),
				property: "Barcode",
				type: 'string'
			}, {
				label: i18nLabel.getText("LocCode"),
				property: "Locationcode",
				type: 'number',
				scale: 3
			}, {
				label: i18nLabel.getText("PersonalData"),
				property: "Personaldata",
				type: 'boolean',
				trueValue: 'YES',
				falseValue: 'NO'
			}, {
				label: i18nLabel.getText("PartnerAuthReqd"),
				property: "Partnerauthreq",
				type: 'boolean',
				trueValue: 'YES',
				falseValue: 'NO'
			}, {
				label: i18nLabel.getText("RecordStatus"),
				property: "Status",
				type: 'number',
				scale: 3
			}, {
				label: i18nLabel.getText("Description"),
				property: "Description",
				type: 'string'
			}, {
				label: i18nLabel.getText("CreatedDate"),
				property: "Createdat",
				type: 'date'
			}, {
				label: i18nLabel.getText("DestructionDueDate"),
				property: "Destructiondue",
				type: 'date'
			}];
		},
		onExportDownload: function(oEvnt) {
			var aCols, oSettings, oSheet, oExcelJson = [];
			oExcelJson.push(this.JsonData._loadExcelJSONData());
			aCols = this.createColumnConfig();
			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: oExcelJson
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function() {
					MessageToast.show('Spreadsheet export has finished');
				})
				.finally(function() {
					oSheet.destroy();
				});
		}

	});

});