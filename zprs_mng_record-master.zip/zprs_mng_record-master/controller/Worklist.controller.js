jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
	"managerecrds/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"managerecrds/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/SearchField"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox, SearchField) {
	"use strict";
	return BaseController.extend("managerecrds.controller.Worklist", {
		formatter: formatter,
		_smartFilterBar: null,
		onInit: function() {

			this._smartFilterBar = this.getView().byId("ManageRecFilterBar");
			var jsRMModel = new JSONModel({
				BCPrintBtn: false,
				isEditable: false,
				isToggleEditable: true,
				isMarkArcEnabled: false,
				isReqRetEnabled: false,
				isMarkRetEnabled: false,
				isMarkForDestEnabled: false,
				isMarkasDestEnabled: false,
				isEditEnabled: false,
				isUndoEnabled: false,
				btnActionText: ""

			});
			this.setModel(jsRMModel, "RMView");
			// this.getView().byId("ManageRecFilterBar").setFilterBarExpanded(true);
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			//Code: Handling fiori launchpad nav back button
			/*---Starts Here---*/
			this.fBackButton = sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction;
			sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction = function() {
				// window.history.go(-1);
				this.onBackButtonPressed();
			}.bind(this);
			/*---Ends Here---*/
			this.getRouter().getRoute("worklist").attachPatternMatched(this._onworklistMatched, this);

		},
		_onworklistMatched: function(oEvnt) {
			var oTable = this.getView().byId("LineItemsSmartTable").getTable();
			oTable.clearSelection();
			this.getView().byId("LineItemsSmartTable").rebindTable();
		},
		onAssignedFiltersChanged: function(oEvent) {
			var oStatusText = this.getView().byId("statusText");
			if (oStatusText && this._smartFilterBar) {
				var sText = this._smartFilterBar.retrieveFiltersWithValuesAsText();

				oStatusText.setText(sText);
			}
		},
		//Handle After Barcode  Scan Finished
		onBarCodeScannFinished: function() {
			var oSmartFilterBar, oKey;
			oSmartFilterBar = this.getView().byId("ManageRecFilterBar");
			oKey = oSmartFilterBar.getControlByKey("Barcode");
			this.oKey = oKey;
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					oKey.setValue(mResult.text);
				},
				function(err) {

				},
				function(mParams) {
					oKey.setValue(mParams.newValue);
				}
			);
		},
		//Row Selection change and validation for same status
		onSelectionRow: function(oEvt) {
			var oTable = this.getView().byId("table"),
				oSel = oTable.getSelectedIndices(),
				oSelIndLength = oSel.length,
				oViewModel = this.getView().getModel("RMView"),
				ostatusmsg = this._oResourceBundle.getText("statusMsg"),
				oCntx,
				oStatus,
				oFlage = false,
				oldstatus = '';
			//Handle if selected Rows 
			if (oSelIndLength) {
				$.each(oSel, function(i, val) {
					oCntx = oTable.getContextByIndex(val);
					oStatus = oCntx.getProperty("Status");
					//validation status
					if (oldstatus !== oStatus && i !== 0) {
						oFlage = true;
					}
					oldstatus = oStatus;
				});
				if (oFlage) {
					MessageBox.warning(ostatusmsg);
					oViewModel.setProperty("/isMarkArcEnabled", false);
					oViewModel.setProperty("/isReqRetEnabled", false);
					oViewModel.setProperty("/isMarkRetEnabled", false);
					oViewModel.setProperty("/isMarkForDestEnabled", false);
					oViewModel.setProperty("/isMarkasDestEnabled", false);
					// oViewModel.setProperty("/", true);
					oViewModel.setProperty("/isEditEnabled", false);
					oViewModel.setProperty("/isUndoEnabled", false);
				}
				//end validation for status
				//Handle action buttons based on Record status With as same started
				else {
					switch (oldstatus) {
						case "001":
							oViewModel.setProperty("/isReqRetEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", false);
							oViewModel.setProperty("/isMarkArcEnabled", true);
							oViewModel.setProperty("/isMarkForDestEnabled", true);
							oViewModel.setProperty("/isUndoEnabled", true);
							oViewModel.setProperty("/isEditEnabled", true);
							break;
						case "002":
							oViewModel.setProperty("/isMarkArcEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", false);
							oViewModel.setProperty("/isMarkForDestEnabled", true);
							oViewModel.setProperty("/isReqRetEnabled", true);
							oViewModel.setProperty("/isUndoEnabled", true);
							oViewModel.setProperty("/isEditEnabled", true);
							break;
						case "003":
							oViewModel.setProperty("/isMarkArcEnabled", false);
							oViewModel.setProperty("/isReqRetEnabled", false);
							oViewModel.setProperty("/isMarkForDestEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", true);
							oViewModel.setProperty("/isUndoEnabled", true);
							oViewModel.setProperty("/isEditEnabled", true);
							break;
						case "004":
							oViewModel.setProperty("/isReqRetEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", false);
							oViewModel.setProperty("/isMarkArcEnabled", true);
							oViewModel.setProperty("/isMarkForDestEnabled", true);
							oViewModel.setProperty("/isUndoEnabled", true);
							oViewModel.setProperty("/isEditEnabled", true);
							break;
						case "005":
							oViewModel.setProperty("/isMarkArcEnabled", false);
							oViewModel.setProperty("/isReqRetEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", false);
							oViewModel.setProperty("/isMarkForDestEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", false);
							// oViewModel.setProperty("/", true);
							oViewModel.setProperty("/isEditEnabled", false);
							// oViewModel.setProperty("/isUndoEnabled", true);
							break;
						case "006":
							oViewModel.setProperty("/isMarkArcEnabled", false);
							oViewModel.setProperty("/isReqRetEnabled", false);
							oViewModel.setProperty("/isMarkRetEnabled", false);
							oViewModel.setProperty("/isMarkasDestEnabled", true);
							oViewModel.setProperty("/isMarkForDestEnabled", false);
							// oViewModel.setProperty("/isUndoEnabled", true);
							oViewModel.setProperty("/isEditEnabled", false);
							break;
						default:

					}
				}
			}
			//Handle if no selected rows available
			else {
				oViewModel.setProperty("/isMarkArcEnabled", false);
				oViewModel.setProperty("/isReqRetEnabled", false);
				oViewModel.setProperty("/isMarkRetEnabled", false);
				oViewModel.setProperty("/isMarkForDestEnabled", false);
				oViewModel.setProperty("/isMarkasDestEnabled", false);
				// oViewModel.setProperty("/", true);
				oViewModel.setProperty("/isEditEnabled", false);
				oViewModel.setProperty("/isUndoEnabled", false);
			}
		},
		onPressAddMultipleRows: function(oEvnt) {
			this.getRouter().navTo("object");
		},
		//Handle on Location code 
		onLocationCodeChanges: function(oEvent) {
			var src = oEvent.getSource();
			this.m = src.getBindingContext().getModel();
			this.p = src.getBindingContext().sPath;
			this.v = src.getValue();
		},
		//Handle User Action 
		onPressAction: function(oEvnt) {
			this.oAction = oEvnt.getSource().data("Action");
			var oActionDesc = oEvnt.getSource().data("ActionDesc");
			this.getModel("RMView").setProperty("/btnActionText", oActionDesc);
			//Handle to open a dialog to select location code
			if (this.oAction === "FIA01" || this.oAction === "FIA02" || this.oAction === "FIA03") {
				var oContext;
				oContext = this.getOwnerComponent().getModel().createEntry("/Recordsworklists", {});
				if (!this.locationcode) {
					this.locationcode = sap.ui.xmlfragment(this.getView().getId(), "managerecrds.fragments.LocationCode",
						this);
					this.getView().addDependent(this.locationcode);
				}
				this.locationcode.setBindingContext(oContext);
				this.locationcode.open();
			} else {
				this.onSaveAction();
			}
		},
		onCloseAction: function(oEvnt) {
			this.locationcode.close();
		},
		//Save User action 
		onSaveAction: function(evt) {
			var oMatterArray = [],
				oWofcArray = [],
				oBarcodeArray = [],
				// oLocaCodeArray = [],
				context1,
				otab = this.getView().byId("LineItemsSmartTable"),
				tbl = otab.getTable(),
				oUserAction = this.oAction,
				oDataModel = this.getOwnerComponent().getModel(),
				smg = this._oResourceBundle.getText("successMsg"),
				oLocationCodeVal = this.v,
				oLocval;
			$.each(tbl.getSelectedIndices(), function(i, index) {
				context1 = tbl.getContextByIndex(index);
				oMatterArray.push(context1.getProperty("Matterk"));
				oWofcArray.push(context1.getProperty("Workingofficek"));
				oBarcodeArray.push(context1.getProperty("Barcode"));
				// oLocaCodeArray.push(context1.getProperty("Locationcode"));
			});
			oLocval = oLocationCodeVal ? oLocationCodeVal : "";
			var oUrlParams = {
				Useraction: oUserAction,
				Matterk: oMatterArray,
				Workingofficek: oWofcArray,
				Barcode: oBarcodeArray,
				Locationcode: oLocval
			};
			var that = this;
			oDataModel.callFunction("/Rwstatuschange", {
				urlParameters: oUrlParams,
				success: function(oData) {
					otab.rebindTable();
					MessageBox.success(smg);
					that.v = "";
					that.locationcode.close();
				},
				error: function(error) {
					that.locationcode.close();
				}
			});

		},
		//Edit the Table selected Rows
		onEditPress: function(oEvnt) {
			var oTable = this.getView().byId("LineItemsSmartTable").getTable(),
				oSelectedIndices = oTable.getSelectedIndices(),
				oSelCntx, oCntx = [];
			$.each(oSelectedIndices, function(i, val) {
				oSelCntx = oTable.getContextByIndex(val);
				oCntx.push(oSelCntx);
			});
			sap.ui.getCore().setModel(oCntx, "EditModel");
			this.getRouter().navTo("edit");
		},
		onfilter: function(e) {
				// var sfilterProp = e.getParameter('column').getProperty('filterProperty');
				// if (sfilterProp === "Personaldata" || sfilterProp === "Partnerauthreq") {
				// 	e.bCancelBubble = true;
				// 	e.bPreventDefault = true;
				// 	var partnerCol = this.getView().byId("partnerauthreqColumn");
				// 	var personalCol = this.getView().byId("personalDataColumn");
				// 	var arr = [];
				// 	$.each([partnerCol, personalCol], function(index, column) {
				// 		if (column.getMenu().getItems().length > 0) {
				// 			var val = column.getMenu().getItems()[2].getValue();
				// 			var sVal = val === 'Yes' ? true : e.getParameter('value') === 'No' ? false : '';
				// 			if (sVal !== '') {
				// 				var oFilter = new sap.ui.model.Filter(column.getProperty('filterProperty'), "EQ", sVal);
				// 				arr.push(oFilter);
				// 				column.setFiltered(true);
				// 			} else {
				// 				column.setFiltered(false);
				// 			}
				// 		}
				// 	});
				// 	if (arr.length > 0) {
				// 		// var oFilter = new sap.ui.model.Filter(sfilterProp, "EQ", sVal);
				// 		e.getSource().getBinding('rows').filter(arr);
				// 	}
				// }
			}
			// onBeforeExport: function(oEvnt) {
			// 	var Name = oEvnt.mParameters.exportSettings.fileName = "Manage Records",
			// 		oColumns = oEvnt.mParameters.exportSettings.workbook.columns;
			// 	$.each(oColumns, function(i, obj) {
			// 		if((obj.property === "Personaldata") ||(obj.property === "Partnerauthreq")){
			// 			obj.type = "string";
			// 		}
			// 	});

		// }
	});
});