sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageBox'
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("managerecrds.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},
		//handle line items add to table

		oTemplateMultiAdd: function() {
			var items = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Matterk}",
						editable: true,
						change: function(oEvnt) {
							this.onFieldValueChage(oEvnt);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Workingofficek}",
						editable: true,
						change: function(oEvnt) {
							this.onFieldValueChage(oEvnt);
						}.bind(this)
					}),
					new sap.m.Input({
						value: "{Barcode}",
						editable: true,
						liveChange: function(oEvent) {
							this.onBarCodeScannFinished(oEvent);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Locationcode}",
						editable: true,
						change: function(oEvnt) {
							this.onFieldValueChage(oEvnt);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Personaldata}",
						editable: true
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnerauthreq}",
						editable: true
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Status}",
						editable: true,
						change: function(oEvnt) {
							this.onFieldValueChage(oEvnt);
						}.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Description}",
						editable: true
					}),
					new sap.m.DatePicker({
						value: {
							path: 'Createdat',
							type: 'sap.ui.model.type.Date',
							formatOptions: {
								displayFormat: "medium",
								strictParsing: true
							}
						},
						change: function(oEvnt) {
							this.onDateValueChage(oEvnt);
						}.bind(this)

					}), new sap.m.DatePicker({
						value: {
							path: 'Destructiondue',
							type: 'sap.ui.model.type.Date',
							formatOptions: {
								displayFormat: "medium",
								strictParsing: true
							}
						},
						change: function(oEvnt) {
							this.onDateValueChage(oEvnt);
						}.bind(this)

					})
				]
			});
			return items;
		},
		onFieldValueChage: function(evt) {
			var source = evt.getSource();
			source.setValueState("None");
		},
		onDateValueChage: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				oNewValue = new Date(value),
				oCntx = evt.getSource().getBindingContext(),
				sPath = oCntx.getPath(),
				oMatterInModel = oCntx.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, oNewValue);
			source.setValueState("None");
		},
		// handle Edit template 
		oTemplateMultidEdit: function() {
			var items = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Matterk}",
						editable: false
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Workingofficek}",
						editable: false
					}),
					new sap.m.Input({
						value: "{Barcode}",
						editable: true
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Status}",
						editable: false
					}),
					new sap.m.Text({
						text: {
							path: 'Createdat',
							type: 'sap.ui.model.type.Date',
							formatOptions: {
								style: 'long'
							}
						}
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Locationcode}",
						editable: true
					}),

					new sap.ui.comp.smartfield.SmartField({
						value: "{Description}",
						editable: true
					}),

					new sap.m.DatePicker({
						value: {
							path: 'Destructiondue',
							type: 'sap.ui.model.type.Date',
							formatOptions: {
								displayFormat: "medium",
								strictParsing: true
							}
						},
						change: function(oEvnt) {
							this.onDateValueChage(oEvnt);
						}.bind(this)
					})
				]
			});
			return items;
		},
		onBarCodeScannFinished: function(oEvent) {
			var source = oEvent.getSource();
			source.setValueState("None");
			var oTabModel = this.getView().getModel();
			this.sPath = oEvent.getSource().getBindingContext().sPath;
			var oBarcode = oTabModel.getProperty(this.sPath + "/Barcode");
			var that = this;
			if(sap.ui.Device.system.desktop){
				return;
			}
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					if (oBarcode) {
						MessageBox.warning(
							"Are you sure you want to override the existing Barcode", {
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								onClose: function(sAction) {
									if (sAction === "OK") {
										oTabModel.setProperty(that.sPath + "/Barcode", mResult.text);
									}
								}
							}
						);
					} else {
						oTabModel.setProperty(that.sPath + "/Barcode", mResult.text);
					}

				},
				function(err) {

				},
				function(mParams) {
					oTabModel.setProperty(that.sPath + "/Barcode", mParams.newValue);

				}
			);
		},
		onBackButtonPressed: function() {
			var msg = this._oResourceBundle.getText("BackBtnMsg");
			var fnOnBack = jQuery.proxy(function() {
				window.history.back();
				sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction = this.fBackButton;
			}, this);

			var fnOnClose = jQuery.proxy(function(oAction) {
				if (oAction === "OK") {
					this.getModel().resetChanges();
					fnOnBack();
				}
			}, this);
			//Show warning if changes have been done, but the document was neither posted nor saved as draft
			if (!$.isEmptyObject(this.getModel().getPendingChanges())) {
				MessageBox.show(msg, MessageBox.Icon.WARNING,
					"Warning", [MessageBox.Action.OK, MessageBox.Action.CANCEL], fnOnClose);
			} else {
				fnOnBack();
			}
		},
		_import: function(file) {
			var excelErrMsg = this._oResourceBundle.getText("excelErrMsg");
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}

					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show(excelErrMsg, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
						if (sheetData[0]["Matter Number"] === undefined && sheetData[0]["Working Office"]=== undefined && sheetData[0].Barcode === undefined &&
						sheetData[0]["Location Code"] === undefined && sheetData[0]["Personal Data"] === undefined && sheetData[0]["Partner Auth. Reqd"] === undefined &&
						sheetData[0]["Record Description"] === undefined && sheetData[0]["Destruction Due Date"] === undefined && sheetData[0]["Record Status"] === undefined && 
						sheetData[0]["Status Date"] === undefined && sheetData[0]["Created By"] === undefined && sheetData[0]["Created On"] === undefined && 
						sheetData[0]["Changed By"] === undefined && sheetData[0]["Changed On"] === undefined && sheetData[0]["Matter Description"] === undefined && 
						sheetData[0]["Working Office"] === undefined && sheetData[0]["Record Status Desc"] === undefined && sheetData[0]["Location Description"] === undefined &&
						sheetData[0]["Location Name"] === undefined && sheetData[0]["Location Type"] === undefined && sheetData[0].Client === undefined && sheetData[0]["Client Name"] === undefined && sheetData[0]["Matter Status Description"] === undefined) {
						sap.m.MessageBox.show(excelErrMsg, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					that._creatobjPy(sheetData);

				};
				reader.readAsArrayBuffer(file);
			}
		}

	});

});