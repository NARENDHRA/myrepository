/*global location history */
sap.ui.define([
	"fgtttwb_TT/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"fgtttwb_TT/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/UploadCollectionParameter",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, UploadCollectionParameter, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("fgtttwb_TT.controller.TrackingWB", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel;
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				userComments: "",
				UpdateComments: "",
				ReopenBtn: false,
				SaveBtn: true,
				CancelBtn: true,
				isVisFeedinput: true,
				isVisUploadEnble: true,
				userText: sap.ushell.Container.getUser().getId(),
				menuItems: [{
					"title": "Tracking Tickets",
					"icon": "sap-icon://my-view"
				}, {
					"title": "My Tickets",
					"icon": "sap-icon://time-entry-request"
				}, {
					"title": "My Group Tickets",
					"icon": "sap-icon://activity-individual"
				}, {
					"title": "Create Ticket",
					"icon": "sap-icon://add-activity-2"
				}]

			});
			this.setModel(oViewModel, "worklistView");
			this._setToggleButtonTooltip(!sap.ui.Device.system.desktop);
			this.getOwnerComponent().getModel().setDefaultBindingMode("TwoWay");
			this.AttachmentNewArray = [];

		},

		onItemSelect: function(evt) {
			var oView = this.getView();
			var oNavId = this.getView().byId("NavPageContainerId");
			var oSelItemtxt = evt.getParameter("item").getProperty("text");
			var oModel = this.getOwnerComponent().getModel();
			var oTKUpdate = oView.byId("UpdateTicketID");
			var oSection = oTKUpdate.getSections()[1];
			oTKUpdate.setSelectedSection(oSection);
			if (oSelItemtxt === "Tracking Tickets") {
				oNavId.to(oView.byId("TrackingTicketsId"));
			} else if (oSelItemtxt === "My Tickets") {
				var oMyTicketTblId = this.getView().byId("smartTable_MyTicketsBId");
				oNavId.to(oView.byId("MyTicketsId"));
				oMyTicketTblId.rebindTable(true);
			} else if (oSelItemtxt === "Create Ticket") {
				var oContextTicktes = oModel.createEntry("/TrackingtoolSet", {});
				var c = oContextTicktes.getModel();
				oNavId.to(oView.byId("CreateTicketsId"));
				this.getView().byId("smartForm").setBindingContext(oContextTicktes);
			} else if (oSelItemtxt === "My Group Tickets") {
				oNavId.to(oView.byId("MyGropedTickets"));
			}
		},
		onBeforeRebindTableMtTickets: function(evt) {
			var oParmsFilter = evt.getParameter("bindingParams").filters;
			oParmsFilter.push(new Filter("Createdby", FilterOperator.EQ, "Naresh"));
		},
		onSideNavButtonPress: function() {
			var viewId = this.getView().getId();
			var toolPage = sap.ui.getCore().byId(viewId + "--toolPage");
			var sideExpanded = toolPage.getSideExpanded();

			this._setToggleButtonTooltip(sideExpanded);

			toolPage.setSideExpanded(!toolPage.getSideExpanded());
		},
		_setToggleButtonTooltip: function(bLarge) {
			var toggleButton = this.getView().byId('sideNavigationToggleButton');
			if (bLarge) {
				toggleButton.setTooltip('Large Size Navigation');
			} else {
				toggleButton.setTooltip('Small Size Navigation');
			}
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Project")
			});
		},
		onCreateTicket: function(evt) {
			var tooltocommentArry = [],
				oModel = this.getOwnerComponent().getModel();
			var oForm = this.getView().byId("smartForm");
			var oLocalModel = this.getView().getModel("worklistView");
			var octnxObj = oForm.getBindingContext().getObject();
			var oUserComments = oLocalModel.getProperty("/userComments");
			var oUpAtth = this.getView().byId("UploadCollection");
			var oitems = oUpAtth.getItems();
			var oFrmCh = oForm.check();
			if (oFrmCh.length > 0) {
				var vsmg = "Fill in all the required fields";
				MessageBox.error(vsmg);
				return;
			}
			if (!octnxObj.Ticketnum) {
				var otkno = "0000000000";
			}
			// for (var i = 0; i < oitems.length; i++) {
			// 	var oFilename = oitems[i].getProperty("fileName");
			// 	var obj = {
			// 		"Ticketnum": octnxObj.Ticketnum,
			// 		"Filename": oFilename
			// 	};
			// 	tooltoattachmentsArry.push(obj);
			// }
			this.getView().setBusy(true);
			if (oUserComments) {
				var uComObj = {
					"Ticketnum": otkno,
					"Comments": oUserComments
				};
				tooltocommentArry.push(uComObj);
			}
			if (tooltocommentArry.length > 0) {
				octnxObj["tooltocomment"] = tooltocommentArry;
			}
			if (this.AttachmentNewArray.length > 0) {
				octnxObj["tooltoattachments"] = this.AttachmentNewArray;
			}
			octnxObj.Ticketnum = otkno;
			var oPayLoad = octnxObj;
			delete(oPayLoad.__metadata);
			var that = this;
			oModel.create("/TrackingtoolSet", oPayLoad, {
				success: function(odata, response) {
					that.getView().setBusy(false);
					oUpAtth.removeAllItems();
					oLocalModel.setProperty("/userComments", " ");
					var oMsg = odata.Ticketnum + " " + odata.Message;
					MessageBox.success(oMsg, {
						onClose: function(oAction) {
							var oContextTicktes = oModel.createEntry("/TrackingtoolSet", {});
							that.getView().byId("smartForm").setBindingContext(oContextTicktes);
						}
					});
					that.AttachmentNewArray = [];
				},
				error: function(error) {
					that.getView().setBusy(false);
				}
			});
		},
		onChangeCreateMode: function(oEvent) {
			var oUploadCollection = oEvent.getSource(),
				oTicketNum;
			this.oUploadCollection = oUploadCollection;
			var oId = oUploadCollection.getId();
			var oCreateFrmId = this.getView().byId("smartForm");
			var oUpdFrmId = this.getView().byId("TicketchangeFromID");
			if (oId === "__xmlview0--UploadCollectionViewId") {
				oTicketNum = oUpdFrmId.getBindingContext().getObject().Ticketnum;
			} else {
				oTicketNum = oCreateFrmId.getBindingContext().getObject().Ticketnum;
			}
			if (!oTicketNum) {
				oTicketNum = "0000000000";
			}
			// oUploadCollection.setUploadUrl("/sap/opu/odata/SAP/ZTT_TRACKING_TOOL_SRV/attachmentSet(this.oTicketNum)");
			// Header Token
			// var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
			// 	name: "x-csrf-token",
			// 	value: oUploadCollection.getModel().getSecurityToken()
			// });
			// oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var oParameter = oEvent.getParameter("files"),
				that = this,
				sFileName = oParameter[0].name;
			//To Read filecontent
			var fileData = new Blob([oParameter[0]]);
			var buf = function getBuffer(resolve) {
				var reader = new FileReader();
				reader.readAsBinaryString(fileData);
				reader.onload = function() {
					var arrayBuffer = reader.result;
					resolve(arrayBuffer);
				};
			};
			var promise = new Promise(buf);
			// Wait for promise to be resolved, or log error.
			promise.then(function(data) {
				// Here you can pass the bytes to another function.
				var bData = btoa(data);
				var fileObj = {
					"Ticketnum": oTicketNum,
					"Filename": sFileName,
					"Xstring": bData

				};
				that.AttachmentNewArray.push(fileObj);
			}).catch(function(err) {});
		},
		onStartUploadTicketUpdate: function(evt) {
			var oUploadCollection = this.getView().byId("UploadCollectionViewId");
			// var coFiles = oUploadCollection.getItems().length;
			// // var uploadInfo = cFiles + " file(s)";
			// if (coFiles > 0) {
			// 	oUploadCollection.upload();
			// }

		},
		onFileTypeChange: function(oEvent) {
			this.getView().byId("UploadCollection").setFileType(oEvent.getSource().getSelectedKeys());
		},
		onStartUpload: function() {
			var oUploadCollection = this.getView().byId("UploadCollection");
			var cFiles = oUploadCollection.getItems().length;
			// var uploadInfo = cFiles + " file(s)";
			if (cFiles > 0) {
				oUploadCollection.upload();
			}
		},
		// onBeforeUploadStartsUpdateTicket: function(evt) {
		// 	var oCustomerHeaderSlug = new UploadCollectionParameter({
		// 		name: "slug",
		// 		value: this.oTicketNum + "|" + evt.getParameter("fileName")
		// 	});
		// 	evt.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		// },
		// onBeforeUploadStarts: function(oEvent) {
		// 	// Header Slug
		// 	var oCustomerHeaderSlug = new UploadCollectionParameter({
		// 		name: "slug",
		// 		value: oEvent.getParameter("fileName")
		// 	});
		// 	oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		// },
		onPressTicketItemNavigation: function(evt) {
			var oView = this.getView();
			var oUpdatetickId = oView.byId("UpdateTicketID");
			var oViewModel = this.getView().getModel("worklistView");
			// oUpdatetickId.setSelectedSection("Section1Id");
			oUpdatetickId.setSelectedSection("__xmlview0--Section1Id");
			var oAttachModel = new sap.ui.model.json.JSONModel();
			var oModel = this.getOwnerComponent().getModel();
			var oNavId = oView.byId("NavPageContainerId");
			var OlistCommId = oView.byId("ListCommentViewId");
			var ofeedList = oView.byId("feedListConId");
			var oTTUPdateFormId = oView.byId("TicketchangeFromID");
			var oAttachmentsViewID = oView.byId("UploadCollectionViewId");
			var oAttchItemsId = oView.byId("oupCollId");
			var sPath = evt.getSource().getBindingContext().getPath();
			var oCntx = evt.getSource().getBindingContext();
			this.oTicketNum = evt.getSource().getBindingContext().getObject().Ticketnum;
			var oStatus = oCntx.getObject().Status;
			if (oStatus === "RESOLVED" || oStatus === "ON-HOLD") {
				oViewModel.setProperty("/ReopenBtn", true);
				oViewModel.setProperty("/CancelBtn", false);
				oViewModel.setProperty("/SaveBtn", false);
				oViewModel.setProperty("/isVisUploadEnble", false); 
				oViewModel.setProperty("/isVisFeedinput", false);
				oTTUPdateFormId.setCheckButton(false);
			} else {
				oViewModel.setProperty("/ReopenBtn", false);
				oViewModel.setProperty("/CancelBtn", true);
				oViewModel.setProperty("/SaveBtn", true);
				oViewModel.setProperty("/isVisUploadEnble", true);
				oViewModel.setProperty("/isVisFeedinput", true);
				oTTUPdateFormId.setCheckButton(true);
			}
			var oCommPath = sPath + "/tooltocomment";
			var oAttachPath = sPath + "/tooltoattachments";
			oNavId.to(oView.byId("UpdateTicketID"));
			oTTUPdateFormId.setBindingContext(oCntx);
			// oTTUPdateFormId.bindElement({
			// 	path: sPath
			// });
			// OlistCommId.bindItems({
			// 	path: oCommPath,
			// 	template: ofeedList,
			// 	templateShareable: true
			// });
			OlistCommId.bindItems({
				path: oCommPath,
				template: new sap.m.FeedListItem({
					senderActive: false,
					sender: "{Usrid}",

					timestamp: {
						parts: [{
							path: "Zdate"
						}, {
							path: "Ztime"
						}],
						formatter: function(date, time) {
							var fine = date;
							var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
								style: "medium",
								UTC: true
							});
							var fdt = new Date(fine);
							var dateStr = dateFormat.format(new Date(fdt));
							return dateStr;
							//	return fine;
						}
					},
					text: "{Comments}"
				})
			});
			// var that = this;
			// var oCommentModel = new sap.ui.model.json.JSONModel();
			// oModel.read(oCommPath, {
			// 	success: function(odata, response) {
			// 		// var data = odata.results;
			// 		oCommentModel.setData(odata);
			// 		OlistCommId.setModel(oCommentModel, "CommentModel");
			// 	},
			// 	error: function(error) {

			// 	}
			// });
			// oModel.read(oAttachPath, {
			// 	success: function(odata, response) {
			// 		var data = odata.results;
			// 		oAttachModel.setData(data);
			// 		oAttachmentsViewID.setModel(oAttachModel, "AttachModel");
			// 	},
			// 	error: function(error) {}
			// });
			oAttachmentsViewID.bindAggregation("items", {
				path: oAttachPath,
				template: new sap.m.UploadCollectionItem({
					documentId: "{Filenum}",
					fileName: "{Filename}",
					visibleDelete: false,
					visibleEdit: false,
					url: "/sap/opu/odata/sap/ZTT_TRACKING_TOOL_SRV/attach_downloadSet(Ticketnum='{Ticketnum}',Filenum={Filenum})/$value",
					enableEdit: false,
					enableDelete: false,
					thumbnailUrl: ""
				})
			});

		},
		onPressNavBackItems: function(evt) {
			var oView = this.getView(),
				oTKUpdate = oView.byId("UpdateTicketID");
			var oNavId = oView.byId("NavPageContainerId");
			// oNavId.to(oView.byId("TrackingTicketsId"));
			oView.byId("TicketchangeFromID").unbindElement();
			var oSection = oTKUpdate.getSections()[1];
			oTKUpdate.setSelectedSection(oSection);
			var that = this;
			this.oModel = oView.getModel();
			if (!$.isEmptyObject(that.oModel.getPendingChanges())) {
				MessageBox.warning("By proceeding navigation all unsaved changes for Update Ticket details will be lost", {
					actions: ["Proceed", MessageBox.Action.CANCEL],
					emphasizedAction: "Proceed",
					title: "UnSaved Data Warning",
					onClose: function(sAction) {
						if (sAction === "Proceed") {
							that.oModel.resetChanges();
							oNavId.to(oView.byId("TrackingTicketsId"));
						}
					}
				});
			} else {
				oNavId.to(oView.byId("TrackingTicketsId"));
			}

		},
		onPostComments: function(evt) {
			var oUserModel = this.getOwnerComponent().getModel();
			var oUserComment = evt.getParameter("value");
			var otickNum = this.oTicketNum;
			var oListComments = this.getView().byId("ListCommentViewId");
			var oObjParm = {
				"Ticketnum": otickNum,
				"Comments": oUserComment
			};
			var that = this;
			oUserModel.create("/commentsSet", oObjParm, {
				success: function(odata, response) {
					oUserComment = "";
					var osmg = "Comments are updated to this ticket no." + otickNum;
					sap.m.MessageToast.show(osmg);
					oListComments.getModel().refresh();

				}
			});
		},
		onPressCancle: function(evt) {
			this.oModel = this.getView().getModel();
			var that = this;
			if (!$.isEmptyObject(that.oModel.getPendingChanges())) {
				MessageBox.warning("By proceeding all unsaved changes for Update Ticket details will be lost", {
					actions: ["Proceed", MessageBox.Action.CANCEL],
					emphasizedAction: "Proceed",
					title: "UnSaved Data Warning",
					onClose: function(sAction) {

						if (sAction === "Proceed") {
							that.oModel.resetChanges();
						}
					}
				});
			}
		},
		onUpdateTicket: function(evt) {
			var oAttchId = this.getView().byId("UploadCollectionViewId");
			var oModel = this.getOwnerComponent().getModel();
			var oFormupdate = this.oTCFormId = this.getView().byId("TicketchangeFromID");
			// var oLocalModel = this.getView().getModel("worklistView");
			var octnxObj = oFormupdate.getBindingContext().getObject();
			// var oUpAtth = this.getView().byId("UploadCollectionViewId");
			// var oitems = oUpAtth.getItems();
			this.oLocalModel = this.getView().getModel("worklistView");
			var oAttachModel = new sap.ui.model.json.JSONModel();
			delete(octnxObj.__metadata);
			var oBtnText = evt.getSource().getProperty("text");
			if (oBtnText === "Re-Open") {
				if (octnxObj.Status !== "RESOLVED" && octnxObj.Status !== "ON-HOLD") {
					MessageToast.show("Ticket can re-open only for Resloved and On-Hold Status", {
						duration: 3000
					});
					return;
				}
			}

			if (oBtnText === "Re-Open") {
				octnxObj.Action = "RO";
			} else {
				octnxObj.Action = "UD";
			}

			if (oFormupdate.getModel().getPendingChanges() || this.AttachmentNewArray.length > 0) {
				if (this.AttachmentNewArray.length > 0) {
					octnxObj["tooltoattachments"] = this.AttachmentNewArray;
				}
				var that = this;
				that.getView().setBusy(true);
				oModel.create("/TrackingtoolSet", octnxObj, {
					success: function(odata, response) {
						var oMsg = odata.Ticketnum + " " + odata.Message;
						var oAtthData = odata.tooltoattachments.results;
						MessageBox.success(oMsg);
						that.AttachmentNewArray = [];
						// var oDataAtch = oAttchId.getModel("AttachModel").getData();
						// oAttchId.getModel("AttachModel").setData([]);
						// // oAttchId.getModel("AttachModel").setData((odata.tooltoattachments.results));
						// // oAttchId.getModel("AttachModel").refresh();
						// var model = oAttchId.getModel("AttachModel"),
						// 	results = oDataAtch.unshift(odata.tooltoattachments.results);

						// // results.push(objArray);
						// model.setProperty("/", results);
						oAttchId.getModel().refresh();
						var oStatus = that.oTCFormId.getBindingContext().getObject().Status;
						if (oStatus === "RESOLVED" || oStatus === "ON-HOLD") {
							that.oLocalModel.setProperty("/ReopenBtn", true);
							that.oLocalModel.setProperty("/CancelBtn", false);
							that.oLocalModel.setProperty("/SaveBtn", false);
						} else {
							that.oLocalModel.setProperty("/ReopenBtn", false);
							that.oLocalModel.setProperty("/CancelBtn", true);
							that.oLocalModel.setProperty("/SaveBtn", true);
						}

						that.getView().setBusy(false);
					},
					error: function(error) {
						that.getView().setBusy(false);
					}
				});
			}

		}

	});
});