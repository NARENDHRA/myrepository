sap.ui.define([
	"sap/m/Text"
], function(Text) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		StatusText: function(stxt) {
			if (stxt === "CANCELLED") {
				return "Error";
			} else if (stxt === "NEW") {
				return "None";
			} else if (stxt === "IN-PROG") {
				return "Warning";
			} else if (stxt === "RESOLVED") {
				return "Success";
			} else if (stxt === "ON-HOLD") {
				return "Warning";
			}
		},
	
		btnPriortyText: function(Priorty) {
			if (Priorty === "001") {
				return "Critical";
			} else if (Priorty === "002") {
				return "High";
			} else if (Priorty === "003") {
				return "Medium";
			} else if (Priorty === "004") {
				return "Low";
			}
		},
		textState: function(s) {
			if (s === "001") {
				return "Error";
			} else if (s === "002") {
				return "Error";
			} else if (s === "003") {
				return "Warning";
			} else if (s === "004") {
				return "None";
			}
		},
		statuseditable:function(stst){
			debugger;
		}
		
	};

});