jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
cmimyinbox.model.DownloadTableData = {
	onDataExport: sap.m.Table.prototype.exportData || function(oModel, sPath, text, a, fileName) {
		var array = [],
			removeHtmlTags = function(ctnt) {
				if (ctnt) {
					var span = document.createElement('span');
					span.innerHTML = ctnt;
					ctnt = span.textContent || span.innerText;
					return ctnt.trim();
				} else {
					return ctnt;
				}
			};
		for (var i = 0; i < text.length; i++) {
			var obj;
			if (a[i] === "Terms") {

				obj = {
					name: text[i],
					template: {
						content: {
							parts: [a[i]],
							formatter: removeHtmlTags
						}
					}
				};

			} else {

				obj = {
					name: text[i],
					template: {
						content: "{" + a[i] + "}"
					}
				};

			}

			array.push(obj);
		}
		var oExport = new sap.ui.core.util.Export({
			exportType: new sap.ui.core.util.ExportTypeCSV({
				separatorChar: ","
			}),
			// Pass in the model created above
			models: oModel,
			// binding information for the rows aggregation
			rows: {
				path: sPath
			},
			// column definitions with column name and binding info for the content
			columns: array
		});
		// download exported file
		oExport.saveFile(fileName);
	}
};