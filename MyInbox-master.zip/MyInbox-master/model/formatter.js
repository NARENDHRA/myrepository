jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},

		formatSearchString: function(sValue) {
			if (sValue) {
				var a = JSON.parse(sValue),
					searchTerms = "";
				var aItems = a.Searchtermline.items;
				$.each(aItems, function(i, items) {
					if (i === 0) {
						searchTerms = items;
					} else {
						searchTerms = searchTerms + "," + items;
					}
				});
			}
			return searchTerms;
		},

		formatingTerms: function(sValue) {
			var sString = $.parseHTML(sValue),
				b, c, d;
			$.each(sString, function(i, value1) {
				if (i === 0) {
					b = value1.innerText;
					c = b.toString();
					d = c.slice(0, 50) + "...";
				}
			});
			return d;
		},

		formatTermsString: function(sValue) {
			if (sValue) {
				return $(sValue).getEncodedText();
			}
		},

		formatRequestType: function(sValue) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			switch (sValue) {
				case "NCNM":
					return resourceBundle.getText("txtNCNM");
				case "ECNM":
					return resourceBundle.getText("txtECNM");
				case "CA":
					return resourceBundle.getText("txtCA");
				case "MA":
					return resourceBundle.getText("txtMA");
				default:
					return sValue;
			}
		},

		removeTags: function(sValue) {
			if (sValue) {
				return sValue.replace(/<div[^>]*>|<\/div>/gi, "");
			}
		}

	};

});