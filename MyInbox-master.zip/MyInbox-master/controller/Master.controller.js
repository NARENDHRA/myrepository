/*global history */
sap.ui.define([
	"cmimyinbox/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"cmimyinbox/model/formatter"
], function(BaseController, JSONModel, History, Sorter, Filter, FilterOperator, GroupHeaderListItem, Device, formatter) {
	"use strict";

	return BaseController.extend("cmimyinbox.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {
			//check the selected view
			//test comment
			this._sView = "conflicts";
			this._noObjectFlag = false;
			this._tabChangeFlag = true;
			this.updateFlag = true;
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			var sPrevMatch = this.getRouter().getRoute("master")._oRouter._oRouter._prevMatchedRequest;
			if (sPrevMatch) {
				var uri = decodeURIComponent(sPrevMatch).split("/");
				this._sView = uri[1];
			}

			// Control state model
			this._oList = this.byId("listCMI");
			this._oListMyRequest = this.byId("listMyRequest");
			this._oListConflict = this.byId("listConflict");

			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			if (this._sView === "cmi") {
				this._onInitEvents(this._oList);
			} else if (this._sView === "myRequest") {
				this._onInitEvents(this._oListMyRequest);
			} else if (this._sView === "conflicts") {
				this._onInitEvents(this._oListConflict);
			}
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
		},

		_onInitEvents: function(oList) {
			var oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			//sap.ui.core.BusyIndicator.show();
			this.setModel(oViewModel, "masterView");
			oViewModel.setProperty("/viewSelectedKey", this._sView);
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});
		},

		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */
		_onMasterMatched: function() {
			this.updateFlag = false;
			this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
				function() {
					if (this._sView === "cmi") {
						this._onSelectionViewChange(this._oList);
					} else if (this._sView === "myRequest") {
						this._onSelectionViewChange(this._oListMyRequest);
					} else if (this._sView === "conflicts") {
						this._onSelectionConflictsViewChange(this._oListConflict);
					}
					//this._onSelectionConflictsViewChange(this._oListConflict);
				}.bind(this),
				function(mParams) {
					if (mParams.error) {
						return;
					}
					this.getRouter().getTargets().display("detailNoObjectsAvailable");
				}.bind(this)
			);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));

			if (this.updateFlag) {
				this.updateFlag = false;
				if (this._sView === "cmi" && oEvent.oSource.getId().search("listCMI") > 1) {
					this._onSelectionViewChange(this._oList);
				} else if (this._sView === "myRequest" && oEvent.oSource.getId().search("listMyRequest") > 1) {
					this._onSelectionViewChange(this._oListMyRequest);
				} else if (this._sView === "conflicts" && oEvent.oSource.getId().search("listConflict") > 1) {
					this._onSelectionConflictsViewChange(this._oListConflict);
				}
			}
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");
			var oBindingInfo;
			if (this._sView === "cmi") {
				oBindingInfo = this._oList.getBindingInfo("items");
			} else if (this._sView === "myRequest") {
				oBindingInfo = this._oListMyRequest.getBindingInfo("items");
			} else if (this._sView === "conflicts") {
				oBindingInfo = this._oListConflict.getBinding("items");
			}

			if (!oBindingInfo.parameters) {
				oBindingInfo.parameters = {};
			}
			if (!oBindingInfo.parameters.custom) {
				oBindingInfo.parameters.custom = {};
			}
			oBindingInfo.parameters.custom.search = sQuery;

			if (this._sView === "cmi") {
				this._oList.bindItems(oBindingInfo);
			} else if (this._sView === "myRequest") {
				this._oListMyRequest.bindItems(oBindingInfo);
			} else if (this._sView === "conflicts") {
				var aFilters;
				if (sQuery) {
					aFilters = new Filter("Searchname", FilterOperator.Contains, sQuery);
				} else {
					aFilters = [];
				}
				oBindingInfo.filter(aFilters, "Application");
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oList.getBinding("items").refresh();
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		onConflictsSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			this._showConflictsDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function() {
			return new JSONModel({
				viewSelectedKey: "cmi",
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Name",
				groupBy: "None"
			});
		},

		onSelect: function(oEvent) {
			this.oGlobalBusyDialog.open();
			var sKey = oEvent.getParameter("key"),
				bValCMI = (sKey === "cmi") ? true : false,
				bValMyRequest = (sKey === "myRequest") ? true : false,
				bValConflicts = (sKey === "conflicts") ? true : false;

			this._tabChangeFlag = true;
			if (bValCMI) {
				this._sView = "cmi";
				this._onSelectionViewChange(this._oList);
			}
			if (bValMyRequest) {
				this._sView = "myRequest";
				this._onSelectionViewChange(this._oListMyRequest);
			}
			if (bValConflicts) {
				this._sView = "conflicts";
				this._onSelectionConflictsViewChange(this._oListConflict);
			}
		},

		_onSelectionViewChange: function(oListSelect) {
			if (sap.ui.getCore().getModel("apprRej").getProperty("/oApproveReject")) {
				this._showDetail(oListSelect.getItems()[0]);
				oListSelect.setSelectedItem(oListSelect.getItems()[0]);
				sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
			} else if (oListSelect.getSelectedItem()) {
				this._showDetail(oListSelect.getSelectedItem());
			} else {
				this._showDetail(oListSelect.getItems()[0]);
				oListSelect.setSelectedItem(oListSelect.getItems()[0]);
			}
		},

		_onSelectionConflictsViewChange: function(oListSelect) {
			if (oListSelect.getSelectedItem()) {
				this._showConflictsDetail(oListSelect.getSelectedItem());
			} else {
				this._showConflictsDetail(oListSelect.getItems()[0]);
				oListSelect.setSelectedItem(oListSelect.getItems()[0]);
			}
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones an additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			if (oItem) {
				var uri = this._sView + "/" + oItem.getBindingContext().getProperty("Cmino") + "/" + oItem.getBindingContext().getProperty(
						"Cmirequesttype") + "/" + oItem.getBindingContext().getProperty(
						"Clientk") + "/" + oItem.getBindingContext().getProperty("Witype"),
					sPath = encodeURIComponent(uri);
				if (this._noObjectFlag) {
					this._noObjectFlag = false;
					this.getRouter().navTo("object", {
						//dummy parameters
						objectId: sPath + "%2F"
					}, bReplace);
					this._showDetail(oItem);
				} else {
					if (this._tabChangeFlag) {
						this._tabChangeFlag = false;
						this.getRouter().navTo("object", {
							//dummy parameters
							objectId: sPath + "%2F"
						}, bReplace);
						this._showDetail(oItem);
					} else {
						this.getRouter().navTo("object", {
							objectId: sPath
						}, bReplace);
						this.oGlobalBusyDialog.close();
					}
				}
			} else {
				this._noObjectFlag = true;
				this.getRouter().getTargets().display("detailNoObjectsAvailable");
				this.oGlobalBusyDialog.close();
			}
		},

		_showConflictsDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			if (oItem) {
				var uri = this._sView + "/" + oItem.getBindingContext("ConflictsService").getProperty("Searchid"),
					sPath = encodeURIComponent(uri);
				if (this._noObjectFlag) {
					this._noObjectFlag = false;
					this.getRouter().navTo("object", {
						//dummy parameters
						objectId: sPath + "%2F"
					}, bReplace);
					this._showConflictsDetail(oItem);
				} else {
					if (this._tabChangeFlag) {
						this._tabChangeFlag = false;
						this.getRouter().navTo("object", {
							objectId: sPath + "%2F"
						}, bReplace);
						jQuery.sap.delayedCall(1000, this, function() {
							this._showConflictsDetail(oItem);
						}.bind(this));
					} else {
						this.getRouter().navTo("object", {
							objectId: sPath
						}, bReplace);
						this.oGlobalBusyDialog.close();
					}
				}
			} else {
				this._noObjectFlag = true;
				this.getRouter().getTargets().display("detailNoObjectsAvailable");
				this.oGlobalBusyDialog.close();
			}
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		onPressNewRequest: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRS_CMI_NEWREQ",
					action: "display&/MyInbox/NewRequest"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onPressNewConflict: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRS_CMI_CONFLS",
					action: "search"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onFilterPress: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("cmimyinbox.fragments.StatusFilterDialog", this);
			}
			// toggle compact style
			//	jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},

		handleConfirm: function(oEvent) {
			var oView = this.getView();
			var oList = oView.byId("listMyRequest");

			var mParams = oEvent.getParameters();
			var oBinding = oList.getBinding("items");

			// apply sorter to binding
			var sPath;
			var bDescending;
			var aSorters = [];
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				aSorters.push(new Sorter(sPath, bDescending));
			}
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding.sort(aSorters);

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("|");
				var sPath = aSplit[0];
				var sOperator = "EQ";
				var sValue1 = aSplit[1];
				var oFilter = new Filter(sPath, sOperator, sValue1);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);

			// update filter bar
			oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			oView.byId("vsdFilterLabel").setText(mParams.filterString);
		}

	});

});