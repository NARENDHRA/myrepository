/*global location */
sap.ui.define([
	"cmimyinbox/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"cmimyinbox/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/table/TablePersoController",
	"cmimyinbox/model/PersoService",
	"cmimyinbox/model/DownloadTableData"
], function(BaseController, JSONModel, MessageToast, DateFormat, formatter, MessageBox, TablePersoController, PersoService,
	DownloadTableData) {
	"use strict";

	return BaseController.extend("cmimyinbox.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			var oFooterButtonModel = new JSONModel({
				visibleTerms: false,
				visibleConflicts: false,
				TermsTableRowCount: 0,
				ConflictsTableRowCount: 0,
				CSTableRowCount: 0
			});
			this.setModel(oFooterButtonModel, "cmiTab");

			var oCoreModel = new JSONModel();
			sap.ui.getCore().setModel(oCoreModel, "apprRej");
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var aURI = decodeURIComponent(oEvent.getParameter("arguments").objectId).split("/"),
				sView = aURI[0],
				that = this,
				sEntitySet, sCmino, sClientk, sWitype, sCmirequesttype;

			this.sView = aURI[0];
			this.cmino = aURI[1];

			sap.ui.core.BusyIndicator.show();
			switch (sView) {
				case "cmi":
					sCmino = aURI[1];
					sCmirequesttype = aURI[2];
					sClientk = aURI[3];
					sWitype = aURI[4];
					if (!sCmirequesttype) {
						sap.ui.core.BusyIndicator.hide();
						that.getRouter().navTo("master",{},true);
						return;
					}
					this._showFormFragment("CMIView");
					sEntitySet = "Worklistheaders"; //EntitySet binded to the cmi master view
					this._oModel = this.getOwnerComponent().getModel();
					this.setModel(null);
					this.setModel(this._oModel, "oCMIService");

					this._oModel.read("/Worklistheaders(Cmino='" + sCmino + "',Cmirequesttype='" + sCmirequesttype + "',Clientk='" + sClientk +
						"',Witype='" + sWitype + "')", {
							urlParameters: {
								"$expand": "Review,Terms,Conflicts,Comments"
							},
							success: function(oData) {
								if (!oData.Review) {
									that.getModel("cmiTab").setProperty("/reviewVisible", false);
								} else {
									that.getModel("cmiTab").setProperty("/reviewVisible", true);
								}
								if (!oData.Terms) {
									that.getModel("cmiTab").setProperty("/termsVisible", false);
								} else {
									if (oData.Terms.results.length === 0) {
										that.getModel("cmiTab").setProperty("/termsVisible", false);
									} else {
										that.getModel("cmiTab").setProperty("/termsVisible", true);
									}
								}
								if (!oData.Conflicts) {
									that.getModel("cmiTab").setProperty("/conflictsVisible", false);
								} else {
									if (oData.Conflicts.results.length === 0) {
										that.getModel("cmiTab").setProperty("/conflictsVisible", false);
									} else {
										that.getModel("cmiTab").setProperty("/conflictsVisible", true);
									}
								}
								sap.ui.core.BusyIndicator.hide();
								that.onPressNavigate();
								that.byId("idTermsTable").setVisibleRowCount(oData.Terms.results.length);
								that.byId("idTermsTable").clearSelection();
								that.getModel("cmiTab").setProperty("/TermsTableRowCount", oData.Terms.results.length);
								that.byId("idConflictsCMITable").setVisibleRowCount(oData.Conflicts.results.length);
								that.byId("idConflictsCMITable").clearSelection();
								that.getModel("cmiTab").setProperty("/ConflictsTableRowCount", oData.Conflicts.results.length);
							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
							}
						});

					this.getModel().metadataLoaded().then(function() {
						var sObjectPath = this.getModel().createKey(sEntitySet, {
							Cmino: sCmino,
							Cmirequesttype: sCmirequesttype,
							Clientk: sClientk,
							Witype: sWitype
						});
						this._bindView("/" + sObjectPath + "|Terms,Review,Comments,Conflicts,Cmidetail|oCMIService");

						this.oTermsTablePath = "/" + sObjectPath + "/Terms";
						this.oCMIConflictsTablePath = "/" + sObjectPath + "/Conflicts";
					}.bind(this));

					this._oTTPC = new TablePersoController({
						table: this.getView().byId("idTermsTable"),
						componentName: "cmimyinbox",
						persoService: PersoService
					});
					this._oCCMITPC = new TablePersoController({
						table: this.getView().byId("idConflictsCMITable"),
						componentName: "cmimyinbox",
						persoService: PersoService
					});

					break;
				case "myRequest":
					sCmino = aURI[1];
					sCmirequesttype = aURI[2];
					sClientk = aURI[3];
					sWitype = aURI[4];
					if (!sCmirequesttype) {
						sap.ui.core.BusyIndicator.hide();
						that.getRouter().navTo("master",{},true);
						return;
					}
					this._showFormFragment("MyRequestView");
					sEntitySet = "Worklistheaders"; //EntitySet binded to the cmi master view
					this._oModel = this.getOwnerComponent().getModel();
					this.setModel(null);
					this.setModel(this._oModel, "oCMIService");

					this.getModel().metadataLoaded().then(function() {
						var sObjectPath = this.getModel().createKey(sEntitySet, {
							Cmino: sCmino,
							Cmirequesttype: sCmirequesttype,
							Clientk: sClientk,
							Witype: sWitype
						});
						this._bindView("/" + sObjectPath + "|Cmidetail,Comments|oCMIService");
					}.bind(this));
					sap.ui.core.BusyIndicator.hide();
					break;
				case "conflicts":
					var sObjectId = aURI[1];
					this._oModel = this.getOwnerComponent().getModel("ConflictsService");
					sEntitySet = "Searchheaders";
					this.setModel(null);
					this.setModel(this._oModel, "oConflictsService");
					var sObjectPath = this.getModel("oConflictsService").createKey(sEntitySet, {
						Searchid: sObjectId
					});

					this.getModel("ConflictsService").metadataLoaded().then(function() {
						this._showFormFragment("ConflictsView");
						this._bindView("/" + sObjectPath + "|Results|oConflictsService");
						jQuery.sap.delayedCall(1000, this, function() {
							var oBinding = this.getView().byId("idConflictsTable").getBinding("rows");
							if (oBinding) {
								this.getModel("cmiTab").setProperty("/CSTableRowCount", oBinding.iLength);
							}
						}.bind(this));
					}.bind(this));

					this.oConflictsTablePath = "/" + sObjectPath + "/Results";

					this._oCTPC = new TablePersoController({
						table: this.getView().byId("idConflictsTable"),
						componentName: "cmimyinbox",
						persoService: PersoService
					});
					sap.ui.core.BusyIndicator.hide();
					break;
			}
		},

		onTermsPersoButtonPressed: function() {
			this._oTTPC.openDialog();
		},

		onConflictsCMIPersoButtonPressed: function() {
			this._oCCMITPC.openDialog();
		},

		onConflictsPersoButtonPressed: function() {
			this._oCTPC.openDialog();
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var sObj = sObjectPath.split("|"),
				sPath = sObj[0],
				sExp = sObj[1],
				sService = sObj[2];

			this.getView().bindElement({
				path: sPath,
				model: sService,
				parameters: {
					expand: sExp
				},
				events: {
					//change: this._onBindingChange.bind(this),
					dataRequested: function() {
						sap.ui.core.BusyIndicator.show();
					},
					dataReceived: function() {
						sap.ui.core.BusyIndicator.hide();
					}
				}
			});
			//this.getView().getElementBinding(sService).refresh(true);
		},

		getTable: function() {
			var oTable = this.getView().byId("MyWBDetailSTable");
			return oTable.getTable();
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				sModelName;

			if (this.sView === "myRequest" || this.sView === "cmi") {
				sModelName = "oCMIService";
			} else {
				sModelName = "oConflictsService";
			}
			var oElementBinding = oView.getElementBinding(sModelName);
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath();
			this.getOwnerComponent().oListSelector.selectAListItem(sPath, sModelName);
		},

		_formFragments: {},

		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "cmimyinbox.fragments." + sFragmentName, this);
			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},

		onCloseUploadDialog: function() {
			this._oDialog.close();
		},

		onPressNavigate: function() {
			var sSelectedSection = this.getView().getContent()[0].getContent()[0].getContent()[0].getSelectedSection(),
				oSections = this.getView().getContent()[0].getContent()[0].getContent()[0],
				sSelectedTab;
			for (var i = 0; i < oSections.getSections().length; i++) {
				if (oSections.getSections()[i].sId === sSelectedSection) {
					sSelectedTab = oSections.getSections()[i].getSubSections()[0].data("subSection");
				}
			}

			if (sSelectedTab === "review") {
				this.byId("idBtnApprove").setText("Approve Request");
				this.byId("idBtnReject").setText("Reject Request");
			} else if (sSelectedTab === "terms") {
				this.byId("idBtnApprove").setText("Approve Terms");
				this.byId("idBtnReject").setText("Reject Terms");
			} else if (sSelectedTab === "conflicts") {
				this.byId("idBtnApprove").setText("Approve Conflicts");
				this.byId("idBtnReject").setText("Reject Conflicts");
			}
		},

		onPressApprove: function() {
			var sSelectedSection = this.getView().getContent()[0].getContent()[0].getContent()[0].getSelectedSection(),
				oSections = this.getView().getContent()[0].getContent()[0].getContent()[0],
				sSelectedTab;
			for (var i = 0; i < oSections.getSections().length; i++) {
				if (oSections.getSections()[i].sId === sSelectedSection) {
					sSelectedTab = oSections.getSections()[i].getSubSections()[0].data("subSection");
				}
			}
			var oModel = this._oModel,
				batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel(oModel.sServiceUrl),
				oPayload = {},
				that = this;

			sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", true);

			if (sSelectedTab === "review") {
				var oBinding = this.getView().getBindingContext("oCMIService").getObject();
				var Wiid = this.getView().byId("txtIdWiid").getText();

				oPayload = {
					"Cmino": oBinding.Cmino,
					"Wiid": Wiid,
					"Action": "APPR"
				};
				batchChanges.push(batchModel.createBatchOperation("/Cmireviews ", "POST", oPayload));
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Request Approved", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			} else if (sSelectedTab === "terms") {
				var oTable = this.getView().byId("idTermsTable"),
					aResults = this.getTableSelectedData(oTable);

				if (aResults.length === 0) {
					MessageBox.information(
						"Please select one or more Terms from table", {}
					);
				}
				
				if(oSections._getVisibleSections().length > 1) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				} else if(oTable.getRows().length !== aResults.length) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				}
				
				if(sap.ui.getCore().getModel("apprRej").getProperty("/oApproveReject")) {
					that.getOwnerComponent().getModel().refresh();
				}

				$.each(aResults, function(j, oRowData) {
					oPayload = {
						"Cmino": oRowData.Cmino,
						"Wiid": oRowData.Wiid,
						"Action": "APPR"
					};
					batchChanges.push(batchModel.createBatchOperation("/Clientterms ", "POST", oPayload));
				});
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Terms Approved", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			} else if (sSelectedTab === "conflicts") {
				var oTableConf = this.getView().byId("idConflictsCMITable"),
					aResultsConf = this.getTableSelectedData(oTableConf);

				if (aResultsConf.length === 0) {
					MessageBox.information(
						"Please select one or more Conflicts from table", {}
					);
				}
				
				if(oSections._getVisibleSections().length > 1) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				} else if(oTableConf.getRows().length !== aResultsConf.length) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				}
				
				if(sap.ui.getCore().getModel("apprRej").getProperty("/oApproveReject")) {
					that.getOwnerComponent().getModel().refresh();
				}

				$.each(aResultsConf, function(j, oRowData) {
					oPayload = {
						"Cmino": oRowData.Cmino,
						"Wiid": oRowData.Wiid,
						"Action": "APPR"
					};
					batchChanges.push(batchModel.createBatchOperation("/Cmiconflicts ", "POST", oPayload));
				});
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Conflicts Approved", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			}
		},

		onPressReject: function() {
			var sSelectedSection = this.getView().getContent()[0].getContent()[0].getContent()[0].getSelectedSection(),
				oSections = this.getView().getContent()[0].getContent()[0].getContent()[0],
				sSelectedTab;
			for (var i = 0; i < oSections.getSections().length; i++) {
				if (oSections.getSections()[i].sId === sSelectedSection) {
					sSelectedTab = oSections.getSections()[i].getSubSections()[0].data("subSection");
				}
			}
			var oModel = this._oModel,
				batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel(oModel.sServiceUrl),
				oPayload = {},
				that = this;

			sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", true);

			if (sSelectedTab === "review") {
				var oBinding = this.getView().getBindingContext("oCMIService").getObject(),
					Wiid = this.getView().byId("txtIdWiid").getText();

				oPayload = {
					"Cmino": oBinding.Cmino,
					"Wiid": Wiid,
					"Action": "DCLN"
				};
				batchChanges.push(batchModel.createBatchOperation("/Cmireviews ", "POST", oPayload));
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Request Rejected", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			} else if (sSelectedTab === "terms") {
				var oTable = this.getView().byId("idTermsTable"),
					aResults = this.getTableSelectedData(oTable);

				if (aResults.length === 0) {
					MessageBox.information(
						"Please select one or more Terms from table", {}
					);
				}
				
				if(oSections._getVisibleSections().length > 1) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				} else if(oTable.getRows().length !== aResults.length) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				}
				
				if(sap.ui.getCore().getModel("apprRej").getProperty("/oApproveReject")) {
					that.getOwnerComponent().getModel().refresh();
				}

				$.each(aResults, function(j, oRowData) {
					oPayload = {
						"Cmino": oRowData.Cmino,
						"Wiid": oRowData.Wiid,
						"Action": "DCLN"
					};
					batchChanges.push(batchModel.createBatchOperation("/Clientterms ", "POST", oPayload));
				});
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Terms Rejected", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			} else if (sSelectedTab === "conflicts") {
				var oTableConf = this.getView().byId("idConflictsCMITable"),
					aResultsConf = this.getTableSelectedData(oTableConf);

				if (aResultsConf.length === 0) {
					MessageBox.information(
						"Please select one or more Conflicts from table", {}
					);
				}
				
				if(oSections._getVisibleSections().length > 1) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				} else if(oTableConf.getRows().length !== aResultsConf.length) {
					sap.ui.getCore().getModel("apprRej").setProperty("/oApproveReject", false);
				}
				
				if(sap.ui.getCore().getModel("apprRej").getProperty("/oApproveReject")) {
					that.getOwnerComponent().getModel().refresh();
				}

				$.each(aResultsConf, function(j, oRowData) {
					oPayload = {
						"Cmino": oRowData.Cmino,
						"Wiid": oRowData.Wiid,
						"Action": "DCLN"
					};
					batchChanges.push(batchModel.createBatchOperation("/Cmiconflicts ", "POST", oPayload));
				});
				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);
				batchModel.submitBatch(function() {
					MessageBox.success("Conflicts Rejected", {});
					//that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				}, function(oError) {
					MessageBox.error(oError.message, {});
				});
			}
		},

		getTableSelectedData: function(oTable) {
			var aResults = [];

			if (oTable) {
				var aIndices = oTable.getSelectedIndices();
				jQuery.each(aIndices, function(i, index) {
					var oRow = oTable.getRows()[index];
					var obj = oRow.getBindingContext("oCMIService").getObject();
					if (obj.hasOwnProperty("__metadata")) {
						delete obj.__metadata;
					}
					aResults.push(obj);
				});
			}
			return aResults;
		},

		onPressReview: function() {
			var oBinding = this.getView().getBindingContext("oCMIService").getObject();
			this._navigation(oBinding);
		},

		_navigation: function(oBinding) {
			var sObject, action, sTab;
			if (oBinding.Matterk === "") {
				oBinding.Matterk = 0;
			}
			if (oBinding.Clientk === "") {
				oBinding.Clientk = 0;
			}
			if (this.sView === "cmi") {
				sTab = "review";
			} else {
				sTab = this.sView;
			}
			if (oBinding.Cmirequesttype === "CA") {
				sObject = "ZPRS_CMI_AMENDN";
				action = "display&/" + "MyInbox/CA" + "/" + sTab + "/" + oBinding.Cmino + "/" + oBinding.Clientk;
				this._CrossApplicationNavigation(sObject, action);
			}
			if (oBinding.Cmirequesttype === "MA") {
				sObject = "ZPRS_CMI_AMENDN";
				action = "display&/" + "MyInbox/MA" + "/" + sTab + "/" + oBinding.Cmino + "/" + oBinding.Matterk;
				this._CrossApplicationNavigation(sObject, action);
			}

			if (oBinding.Cmirequesttype === "NCNM") {
				sObject = "ZPRS_CMI_NEWREQ";
				action = "display&/" + "MyInbox/NCNM" + "/" + sTab + "/" + oBinding.Cmino;
				this._CrossApplicationNavigation(sObject, action);
			}
			if (oBinding.Cmirequesttype === "ECNM") {
				sObject = "ZPRS_CMI_NEWREQ";
				action = "display&/" + "MyInbox/ECNM" + "/" + sTab + "/" + oBinding.Cmino;
				this._CrossApplicationNavigation(sObject, action);
			}
		},

		onPressConflicts: function() {
			var sSearchId = this.getView().getBindingContext("oConflictsService").getProperty("Searchid");
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRS_CMI_CONFLS",
					action: "search"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash + "&/" + sSearchId
				}
			});
		},

		onPostComment: function(oEvent) {
			var sSelectedSection = this.getView().getContent()[0].getContent()[0].getContent()[0].getSelectedSection(),
				oSections = this.getView().getContent()[0].getContent()[0].getContent()[0],
				sSelectedTab,
				that = this;
			for (var i = 0; i < oSections.getSections().length; i++) {
				if (oSections.getSections()[i].sId === sSelectedSection) {
					sSelectedTab = oSections.getSections()[i].getSubSections()[0].data("subSection");
				}
			}

			var sTab;
			if (sSelectedTab === "review") {
				sTab = "R";
			} else if (sSelectedTab === "terms") {
				sTab = "T";
			} else if (sSelectedTab === "conflicts") {
				sTab = "C";
			}

			var sCmino = this.getView().getBindingContext("oCMIService").getObject().Cmino;
			var sComment = oEvent.getParameter("value");
			var oEntry = {
				Cmino: sCmino,
				UserComment: sComment + "|" + sTab
			};
			var oModel = this.getModel();
			oModel.create("/Wfcomments", oEntry, {
				success: function(oData) {
					that.getOwnerComponent().getModel().refresh();
					that.getRouter().navTo("master",{},true);
				},
				error: function(oError) {

				}
			});

			//update model
			/*var oModel = this.getView().getModel("oCMIService");
			var aEntries = oModel.getData();
			aEntries.unshift(oEntry);
			oModel.setData(aEntries);*/
		},

		onPressRequest: function() {
			var oBinding = this.getView().getBindingContext("oCMIService").getObject();
			this._navigation(oBinding);
		},

		_CrossApplicationNavigation: function(sObject, action) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sObject,
					action: action
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onConflictsExcelDownloadPress: function() {
			var oTable = this.getView().byId("idConflictsTable");
			var sModel = oTable.getBindingInfo("rows").model;
			var sPath = this.oConflictsTablePath;
			var oModel = this.getView().getModel(sModel);
			var a = [];
			var text = [];
			if (oTable.getRows().length > 0) {
				for (var j = 0; j < oTable.getColumns().length; j++) {
					var colPath = oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path;
					for (var i = 0; i < oTable.getRows()[0].getCells().length; i++) {
						if (oTable.getRows()[0].getCells()[i].getBindingInfo("text").parts[0].path === colPath) {
							a.push(oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path);
							text.push(oTable.getColumns()[j].getLabel().getText());
						}
					}
				}
				DownloadTableData.onDataExport(oModel, sPath, text, a, "Conflicts Search");
			}
		},

		onTermsExcelDownloadPress: function() {
			var oTable = this.getView().byId("idTermsTable");
			var sModel = oTable.getBindingInfo("rows").model;
			var sPath = this.oTermsTablePath;
			var oModel = this.getView().getModel(sModel);
			var a = [];
			var text = [];
			if (oTable.getRows().length > 0) {
				for (var j = 0; j < oTable.getColumns().length; j++) {
					var colPath;
					if (oTable.getColumns()[j].getTemplate().getBindingInfo("text")) {
						colPath = oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path;
					} else {
						colPath = oTable.getColumns()[j].getTemplate().getBindingInfo("value").parts[0].path;
					}
					for (var i = 0; i < oTable.getRows()[0].getCells().length; i++) {
						if (oTable.getRows()[0].getCells()[i].getBindingInfo("text")) {
							if (oTable.getRows()[0].getCells()[i].getBindingInfo("text").parts[0].path === colPath) {
								a.push(oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path);
								text.push(oTable.getColumns()[j].getLabel().getText());
							}
						} else {
							if (oTable.getRows()[0].getCells()[i].getBindingInfo("value").parts[0].path === colPath) {
								a.push(oTable.getColumns()[j].getTemplate().getBindingInfo("value").parts[0].path);
								text.push(oTable.getColumns()[j].getLabel().getText());
							}
						}
					}
				}
				DownloadTableData.onDataExport(oModel, sPath, text, a, "Terms");
			}
		},

		onConflictsCMIExcelDownloadPress: function() {
			var oTable = this.getView().byId("idConflictsCMITable");
			var sPath = this.oCMIConflictsTablePath;
			var sModel = oTable.getBindingInfo("rows").model;
			var oModel = this.getView().getModel(sModel);
			var a = [];
			var text = [];
			if (oTable.getRows().length > 0) {
				for (var j = 0; j < oTable.getColumns().length; j++) {
					var colPath = oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path;
					for (var i = 0; i < oTable.getRows()[0].getCells().length; i++) {
						if (oTable.getRows()[0].getCells()[i].getBindingInfo("text").parts[0].path === colPath) {
							a.push(oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path);
							text.push(oTable.getColumns()[j].getLabel().getText());
						}
					}
				}
				DownloadTableData.onDataExport(oModel, sPath, text, a, "Conflicts");
			}
		},

		onPressLinkStatus: function(Event) {
			sap.ui.core.BusyIndicator.show();
			var source = Event.getSource(),
				oModel = this.getModel("ConflictsReviewService"),
				filters = [new sap.ui.model.Filter("Cmino", "EQ", this.cmino)],
				sPath = "/Cmihistorydetails";
			var JsonModel = new JSONModel();
			oModel.read(sPath, {
				filters: filters,
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();
					JsonModel.setData(oData.results);
					this._onPressFragment(source, oData.results);
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		onCloseProcessDialog: function() {
			this._oDialog.close();
		},

		_onPressFragment: function(source, data) {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cmimyinbox.fragments.ProcessFlow", this);
			    this.getView().addDependent(this._oDialog);
			}
			var idProcessFlow = this.byId("processflow");
			idProcessFlow.setZoomLevel("Two");
			idProcessFlow.setWheelZoomable(false);

			// idProcessFlow.destroyLanes();
			//   idProcessFlow.destroyNodes();
			var nodes = [],
				lanes = [],
				nodeObj, lineObj;
			$.each(data, (function(i, item) {
				nodeObj = {
					"id": i + 1,
					"Cmino": item.Cmino,
					"title": item.Changedby,
					"lane": i,
					"children": [],
					"state": "",
					"stateText": item.Wfstat,
					"texts": [item.Changedtime]
				};
				if (i < data.length - 1) {
					nodeObj.children = [i + 2];
				}
				if (item.Wfstatk === "05") {
					nodeObj.state = "Neutral";
				}
				if (item.Wfstatk === "04") {
					nodeObj.state = "Critical";
				}
				if (item.Wfstatk === "01") {
					nodeObj.state = "Negative";
				}
				if (item.Wfstatk === "02") {
					nodeObj.state = "Positive";
				}
				if (item.Wfstatk === "03") {
					nodeObj.state = "PlannedNegative";
				}
				lineObj = {
					"id": i,
					"icon": "sap-icon://order-status",
					"label": item.Wfstat,
					"position": i
				};
				nodes.push(nodeObj);
				lanes.push(lineObj);
			}));
			var jsonData = {
				"nodes": nodes,
				"lanes": lanes
			};

			var JsonModel = new JSONModel();
			JsonModel.setData(jsonData);
			this._oDialog.setModel(JsonModel);
			idProcessFlow.updateModel(); // this will update the model
			this._oDialog.openBy(source);
			//this._oDialog.open();
		},

		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}
				if (this._formFragments[sPropertyName]) {
					this._formFragments[sPropertyName].destroy();
					this._formFragments[sPropertyName] = null;
				}
			}
		}

	});

});