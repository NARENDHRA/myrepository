/*global location */
sap.ui.define([
	"bcd_svms/ZSV_SVMDAPP/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"bcd_svms/ZSV_SVMDAPP/model/formatter"
], function (BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("bcd_svms.ZSV_SVMDAPP.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				isVisProcess: false,
				isVisSubmit: false,
				isVisReject: false,
				isVisCancel: false,
				isEnabledCancel: true,
				isnotesCount: 0,
				isVisCreateReqNew: true,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by Create Request button has been clicked
		 * @public
		 */
		onPressCreatNewReqst: function (evt) {
			var oReqId = this.oReqId;
			this.getOwnerComponent().getRouter().navTo("Createrequest", {
				objectId: oReqId
			}, true);
			// this.getOwnerComponent().getRouter().getTargets().display("Createrequest");
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function (oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");

			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.oReqId = sObjectId;
			var oListNoteId = this.getView().byId("ListNotesIdN");
			var oIconTbar = this.getView().byId("iconTabBarId");
			oIconTbar.setSelectedKey("SuppVDinfo");
			this.getModel().metadataLoaded().then(function () {
				var sObjectPath = this.getModel().createKey("ReqDetailSet", {
					Reqid: sObjectId
				});
				this._bindView("/" + sObjectPath);
				this._ListBinding(this.oReqId, oListNoteId);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function (sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");
			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

		},
		_ListBinding: function (reqid, olistNotes) {
			var spath = "/NotesSet";
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("Reqid", sap.ui.model.FilterOperator.EQ, reqid));
			olistNotes.bindItems({
				path: spath,
				filters: aFilter,
				template: new sap.m.FeedListItem({
					senderActive: false,
					sender: "{Username}",
					timestamp: {
						parts: [{
							path: "Crdate"
						}, {
							path: "Crtime"
						}],
						formatter: function (date, time) {
							var times = new Date(time.ms);
							var C = times.getUTCHours() + ":" + String(times.getUTCMinutes()).padStart(2, "0");
							var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
								style: "medium",
								UTC: true
							});
							var dateStr = dateFormat.format(date).split(",")[0];
							var fine = dateStr + " " + C;
							return fine;
						}
					},
					text: "{Znotes}",
					info: "{Userrole}"
				})
			});
		},
		onPostNotes: function (evt) {
			var oListNotesId = this.getView().byId("ListNotesIdN");
			var oUserNotes = evt.getParameter("value");
			var oModel = this.getOwnerComponent().getModel();
			var objParm = {
				"Appid": "ZHY_APP_SVMD",
				"Reqid": this.oReqId,
				"Znotes": oUserNotes
			};
			var that = this;
			oModel.create("/NotesSet", objParm, {
				success: function (data) {
					sap.m.MessageToast.show("Successfully uploaded the Notes");
					oListNotesId.getModel().refresh();
				},
				error: function (error) {
					sap.m.MessageToast.show("Error While Post the Notes");
				}
			});
		},
		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Reqid,
				sObjectName = oObject.Reqid,
				oViewModel = this.getModel("detailView");
			var oReqStatus = oObject.Reqstatus;
			var oRole = oObject.Role;
			var oLockedBy = oObject.Lockedby;
			var oErname = oObject.Ernam;
			this._oButtonVisbility(oReqStatus, oViewModel, oRole, oLockedBy, oErname);

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		_oButtonVisbility: function (status, viewmodel, Role, lockedby, ername) {
			// isVisProcess: false,
			// isVisSubmit: false,
			// isVisReject: false,
			// isVisCancel: false,
			// isFeedInput 
			var oCurrentUser = new sap.ushell.services.UserInfo().getId();
			if (lockedby === "") {
				if ((status === "PROCESSED") || (status === "REJECTED") || (status === "CANCELLED")) {
					viewmodel.setProperty("/isVisProcess", false);
					viewmodel.setProperty("/isVisReject", false);
					viewmodel.setProperty("/isVisCancel", false);
					viewmodel.setProperty("/isVisCreateReqNew", true);
					viewmodel.setProperty("/isFeedInput", false);
				} else {
					if (Role === "Processor") {
						viewmodel.setProperty("/isFeedInput", true);
						viewmodel.setProperty("/isVisProcess", true);
						viewmodel.setProperty("/isVisReject", true);
						viewmodel.setProperty("/isVisCancel", false);
						viewmodel.setProperty("/isVisCreateReqNew", true);
					} else if (Role === "Requestor") {
						viewmodel.setProperty("/isFeedInput", true);
						viewmodel.setProperty("/isVisProcess", false);
						viewmodel.setProperty("/isVisReject", false);
						viewmodel.setProperty("/isVisCreateReqNew", true);
						if (oCurrentUser === ername) {
							viewmodel.setProperty("/isVisCancel", true);
						} else {
							viewmodel.setProperty("/isVisCancel", false);
						}
						// viewmodel.setProperty("/isVisSubmit", true);
					} else {
						viewmodel.setProperty("/isVisProcess", false);
						viewmodel.setProperty("/isVisReject", false);
						viewmodel.setProperty("/isVisCancel", false);
						viewmodel.setProperty("/isFeedInput", false);
						viewmodel.setProperty("/isVisCreateReqNew", false);
					}
				}
				// var oCancleBtnVis = viewmodel.getProperty("/isVisCancel");
				if (status === "SUBMIT") {
					// if (oCancleBtnVis) {
					viewmodel.setProperty("/isEnabledCancel", true);
					// }
				} else if (status === "SUBMITTED") {
					// if (oCancleBtnVis) {
					viewmodel.setProperty("/isEnabledCancel", true);
					// }
				}
			} else {
				var smg = this.getResourceBundle().getText("lockedMsg") + " " + lockedby;
				viewmodel.setProperty("/isVisProcess", false);
				viewmodel.setProperty("/isVisReject", false);
				viewmodel.setProperty("/isVisCancel", false);
				viewmodel.setProperty("/isVisCreateReqNew", true);
				viewmodel.setProperty("/isFeedInput", false);
				sap.m.MessageBox.warning(smg);
			}
		},
		onPressSubProRejCncl: function (evt) {
			var oAction = evt.getSource().getAggregation("customData")[0].getValue();
			this.oReqtyp = "";
			var msg = "",
				oActionTitle = "";
			var oModel = this.getOwnerComponent().getModel();
			var oCntx = this.getView().getBindingContext();
			this.ObjParms = oCntx.getObject();
			delete(this.ObjParms.__metadata);
			switch (oAction) {
			case "Submited":
				oActionTitle = "Submit";
				this.oReqtyp = "SUBMITTED";
				msg = "Are you sure you want to submited this request?";
				break;
			case "Process":
				oActionTitle = "Process";
				this.oReqtyp = "PROCESSED";
				msg = "Are you sure you want to process this request?";
				break;
			case "Reject":
				oActionTitle = "Reject";
				this.oReqtyp = "REJECTED";
				msg = "Are you sure you want to reject this request?";
				break;
			case "CancelRej":
				oActionTitle = "Cancel";
				this.oReqtyp = "CANCELLED";
				msg = "Are you sure you want to cancel this request?";
			}
			this.ObjParms.Reqtyp = this.oReqtyp;
			var that = this;
			sap.m.MessageBox.warning(msg, {
				title: oActionTitle,
				actions: [sap.m.MessageBox.Action.OK,
					sap.m.MessageBox.Action.CANCEL
				],
				// emphasizedAction: sap.m.MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === "OK") {
						that._updateReqStatusfn(that.ObjParms, that.oReqtyp);
					}
				}
			});

		},
		_updateReqStatusfn: function (obj, reqType) {
			var oModel = oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSV_SVMD_SRV", {
				json: true
			});
			var that = this;
			oModel.create("/ReqDetailSet", obj, {
				success: function (odata) {
					var SMessage = "Successfully update the Request Status";
					sap.m.MessageToast.show(SMessage);
					that.getView().getModel().refresh();
					var oReqStatus = odata.Reqstatus;
					var oViewModel = that.getView().getModel("detailView");
					var oRole = odata.Role;
					var oLockedBy = odata.Lockedby;
					that._oButtonVisbility(oReqStatus, oViewModel, oRole, oLockedBy);
				},
				error: function (error) {
					sap.m.MessageToast.show("Error while updating the request status");
				}
			});
		},
		onUpdateCommestLists: function (evt) {
			var oModel = this.getView().getModel("detailView");
			var tot = evt.getParameter("total");
			oModel.setProperty("/isnotesCount", tot);
		},

		_onMetadataLoaded: function () {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList");
			// iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			// oLineItemTable.attachEventOnce("updateFinished", function () {
			// 	// Restore original busy indicator delay for line item table
			// 	// oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			// });

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});