sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/BusyDialog"
], function (Controller, History, Filter, FilterOperator, MessageBox, BusyDialog) {
	"use strict";

	return Controller.extend("bcd_svms.ZSV_SVMDAPP.controller.Createrequest", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf bcd_svms.ZSV_SVMDAPP.view.Createrequest
		 */
		onInit: function () {
			this.busydialog = new BusyDialog();
			this.busydialog.open();
			var oCreateModel = new sap.ui.model.json.JSONModel({
				venderVal: "",
				isSaveBtn: false,
				newNotes: "",
				sucerrorlist: []
			});
			var oVCModel = new sap.ui.model.json.JSONModel({
				iVVendorNo: "",
				iVVendrorName: "",
				iVCompany: "",
				iVCompanyname: "",
				iCVendorNo: "",
				iCVendorName: "",
				iCCompany: "",
				iCCompanyName: ""
			});
			this.oVendorNo = "";
			this.oVendorName1 = "";
			this.getView().setModel(oCreateModel, "localModel");
			this.getView().setModel(oVCModel, "oVCModel");
			this.getOwnerComponent().getRouter().getRoute("Createrequest").attachPatternMatched(this._onObjectMatched, this);
			// this.getView().getModel().setDefaultBindingMode("OneWay");
			var otbl = this.getView().byId("reqTableId");
			var oItemsl = otbl.getItems();
			if (oItemsl.length > 0) {
				otbl.removeAllItems();
			}
		},
		_onObjectMatched: function (evt) {
			// this.oTrgetname = evt.getParameters().arguments.Trgetname;
			this.soId = evt.getParameters().arguments.objectId;
			this._oCreateMode();
			this.oVendorNo = "";
			this.oVendorName = "";
			this.oSameVedorcheck = false;
			//default rowAdding
			this.onPressAddRow();
		},
		_oCreateMode: function (evt) {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			this.getView().getModel().setDefaultBindingMode("TwoWay");
			oModel.metadataLoaded().then(function () {
				that.busydialog.close();
				var oContextRequestdetail = oModel.createEntry("/ReqDetailSet", {});
				var c = oContextRequestdetail.getModel();
				c.setProperty(oContextRequestdetail.getPath() + "/Name1", "");
				that.getView().setBindingContext(oContextRequestdetail);
			});
		},
		onPressNavback: function () {
			// var oHistory = History.getInstance();
			// var sPreviousHash = oHistory.getPreviousHash();

			// if (sPreviousHash !== undefined) {
			// 	window.history.go(-1);
			// } else {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oSObjectId = this.soId;
			var oTbl = this.getView().byId("reqTableId");
			var oItems = oTbl.getItems();
			if (oItems.length > 0) {
				oTbl.removeAllItems();
			}
			if (this.soId === "C") {
				this.getOwnerComponent().getRouter().navTo("master", {}, true);
			} else {
				this.getOwnerComponent().getRouter().navTo("object", {
					"objectId": this.soId
				}, true);
			}
			this.getView().setBusy(false);
			// if (this.oTrgetname === "DetailPageToCrtReq") {
			// 	this.getOwnerComponent().getRouter().navTo("object", {
			// 		objectId: oSObjectId
			// 	}, true);
			// } else {
			// 	this.getOwnerComponent().getRouter().navTo("NoSelection", true);
			// }
			// DetailPageToCrtReq
			// // }
			// if (window.location.href.search("MasterDataSet") !== -1) {
			// 	this.getOwnerComponent().getRouter().getTargets().display("object");
			// } else {
			// 	this.getOwnerComponent().getRouter().getTargets().display("NoSelection");
			// }
		},
		onPressAddRow: function (evt) {
			var oViewModel = this.getView().getModel("localModel");
			// var src = evt.getSource();
			var oTbl = this.getView().byId("reqTableId");
			this.isValidate = false;
			if (oTbl.getItems().length > 0) {
				var oItems = oTbl.getItems();
				this._oMandatoryCheckforAddRow(oItems);
				if (this.isValidate) {
					sap.m.MessageBox.error("Please provide all required fileds");
					return;
				}
			}
			var oContext = this._createTableItemContext();
			var items = this._oTempletMultiadditems();
			items.setBindingContext(oContext);
			oTbl.addItem(items);
			oViewModel.setProperty("/isSaveBtn", true);
		},
		_oMandatoryCheckforAddRow: function (oItems) {
			var that = this;
			for (var i = 0; i < oItems.length; i++) {
				var oTblCells = oItems[i].getCells();
				$.each(oTblCells, function (c, Val) {
					var svalue = oTblCells[c].mBindingInfos.value;
					if (svalue !== undefined) {
						// var oVal = oTblCells[c].getProperty("value");
						var oSpath = oTblCells[c].getBindingInfo("value").binding.sPath;
						// if (oSpath === "Bukrs")) {
						if ((oSpath === "Supplier") || (oSpath === "Name1") || (oSpath === "Butxt")) {
							var oVal = oTblCells[c].getProperty("value");
							if (!oVal) {
								oTblCells[c].setValueState("Error");
								that.isValidate = true;
							}
						}
						// }
					}
				});
			}
		},
		_createTableItemContext: function () {
			var vendorNo, VendorName, oSupplierNo, oBillBackInd;
			var oTbl = this.getView().byId("reqTableId");
			var oModel = this.getOwnerComponent().getModel();
			// var oViewContext = this.getView().getBindingContext().getObject();
			var oItems = oTbl.getItems();
			if (oItems.length === 1) {
				var oName1 = oItems[0].getBindingContext().getObject().Name1;
				this.oVendorName = oName1;
			}
			if (oItems.length === 0) {
				this.oBillBackInd = false;
			}
			if (this.oSupplierItem) {
				if (oItems.length > 0) {
					oSupplierNo = this.oSupplierItem;
				} else {
					oSupplierNo = "";
				}
			} else {
				oSupplierNo = "";
			}
			if (this.oVendorNo) {
				if (oItems.length > 0) {
					vendorNo = this.oVendorNo;
				} else {
					vendorNo = "";
				}
			} else {
				vendorNo = "";
			}
			if (this.oVendorName) {
				if (oItems.length > 0) {
					VendorName = this.oVendorName;
				} else {
					VendorName = "";
				}
			} else {
				VendorName = "";
			}
			if (this.oBillBackInd) {
				oBillBackInd = true;
			} else {
				oBillBackInd = false;
			}
			var oContext = oModel.createEntry("/ReqDetailSet", {
				properties: {
					"Appid": "ZHY_APP_SVMD",
					"Reqid": "SVMD00",
					"Reqtyp": "New",
					"Supplier": oSupplierNo,
					"Lifnr": vendorNo,
					"Name1": VendorName,
					"Bukrs": "",
					"Butxt": "",
					"Billbackindicator": oBillBackInd,
					"Remark": ""
				}
			});
			return oContext;
		},
		_oTempletMultiadditems: function () {
			var obtnDel;
			var oTbl = this.getView().byId("reqTableId");
			if (oTbl.getItems().length === 0) {
				obtnDel = false;
			} else {
				obtnDel = true;
			}

			var that = this;
			var items = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Supplier}",
						maxLength: 10,
						type: "Number",
						change: function (evt) {
							that._handleChangeSupplier(evt);
						},
						liveChange: function (evt) {
							that._handlelivechangeChangeSupplier(evt);
						}
					}),
					new sap.m.Input({
						value: "{Name1}",
						description: "{Lifnr}",
						fieldWidth: "76%",
						showSuggestion: true,
						showValueHelp: true,
						// suggestionItemSelected: function (evt) {
						// 	that._handleSuggestVendor1122(evt);
						// },
						valueHelpRequest: function (oEvent) {
							that._handleVendorValueHelp112(oEvent);
						},
						change: function (evt) {
							that._handleChangeVendor11(evt);
						}
					}),
					// .bindAggregation("suggestionItems", {
					// 	path: "/VendorHelpSet",
					// 	template: new sap.ui.core.ListItem({
					// 		text: "{Name1}",
					// 		key: "{Lifnr}",
					// 		additionalText: "{Lifnr}"
					// 	})
					// }),
					new sap.m.Input({
						value: "{Butxt}",
						description: "{Bukrs}",
						fieldWidth: "76%",
						showSuggestion: true,
						showValueHelp: true,
						// suggest: function (evt) {
						// 	var oEvent = evt;
						// 	that._handleCompanySuggest(oEvent);
						// },
						valueHelpRequest: function (oEvent) {
								that._handleCompanyf4Help(oEvent);
							}
							// suggestionItemSelected: function (evt) {
							// 	that.onChangeCompanyCode(evt);
							// },
							// change: function (evt) {
							// 	that._handleChangeCompanyCode(evt);
							// }
					}),
					// .bindAggregation("suggestionItems", {
					// 	path: "/CompanycodHelpSet",
					// 	template: new sap.ui.core.ListItem({
					// 		text: "{Butxt}",
					// 		key: "{Bukrs}",
					// 		additionalText: "{Bukrs}"
					// 	})
					// }),
					new sap.m.Switch({
						state: {
							path: 'Billbackindicator',
							formatter: function (ind) {
								if (ind) {
									return true;
								} else {
									return false;
								}
							}
						},
						customTextOn: "Yes",
						customTextOff: "No",
						change: function (evt) {
							that._oChangeBillBackInd(evt);
						}
					}),
					new sap.m.Button({
						icon: "sap-icon://comment",
						press: function (evt) {
							that._handlePopOverbtn(evt);
						}
					}),
					new sap.m.Button({
						icon: "sap-icon://sys-cancel-2",
						enabled: obtnDel,
						press: function (evt) {
							that._handledeleteRow(evt);
						}
					})
				]
			});
			return items;
		},
		_onChangeVendorName: function (evt) {
			// debugger;
			var Src, Val = "",
				ocntx, oModel, sPath;
			Src = evt.getSource();
			Val = Src.getValue();
			ocntx = Src.getBindingContext();
			oModel = ocntx.getModel();
			sPath = ocntx.getPath();
			var TblCntx = Src.getParent().getBindingContext();
			var TblModel = TblCntx.getModel();
			var TblPath = TblCntx.getPath();
			if (Val) {
				if (!this.oVendorNo) {
					if (Src.getParent().getParent().getItems().length === 1) {
						this.oVendorNo = Val;
					}
					oModel.setProperty(sPath + "/Name1", Val);
				}
				if (this.oVendorNo !== Val) {
					if (Src.getParent().getParent().getItems().length > 1) {
						sap.m.MessageBox.warning("A request can only be for same vendor");
						oModel.setProperty(sPath + "/Butxt", "");
						oModel.setProperty(sPath + "/Bukrs", "");
					} else {
						oModel.setProperty(sPath + "/Butxt", "");
						oModel.setProperty(sPath + "/Bukrs", "");
						this.oVendorNo = Val;
						// this.oVendorName1 = oName1;
					}
				}
			} else {
				oModel.setProperty(sPath + "/Name1", "");
				oModel.setProperty(sPath + "/Lifnr", "");
				oModel.setProperty(sPath + "/Butxt", "");
				oModel.setProperty(sPath + "/Bukrs", "");
			}
			if (Src.getValueState() === "Error") {
				Src.setValueState("None");
			}
		},
		_onChangeCompanyCode: function (evt) {
			var Src, Val = "",
				ocntx, oModel, sPath;
			Src = evt.getSource();
			Val = Src.getValue();
			ocntx = Src.getBindingContext();
			oModel = ocntx.getModel();
			sPath = ocntx.getPath();
			var TblCntx1 = Src.getParent().getBindingContext();
			var TblModel1 = TblCntx1.getModel();
			var TblPath1 = TblCntx1.getPath();
			var oTbl = Src.getParent().getParent(),
				oBukrs = Val,
				oLifnr = TblCntx1.getObject().Lifnr;
			if (Val) {
				oModel.setProperty(sPath + "/Bukrs", Val);
				Src.setValueState("None");
				this._supplierMappingCheck(oBukrs, oLifnr, oTbl);
			} else {
				oModel.setProperty(sPath + "/Butxt", "");
				// oModel.setProperty(sPath + "/Bukrs", "");
				TblModel1.setProperty(TblPath1 + "/Bukrs", "");
			}
			if (Src.getValueState() === "Error") {
				Src.setValueState("None");
			}
		},

		//Warning Message for Supplier mappingTable with vendor and companycode.
		_oMappigSuppWarning: function (oMppSupAction, oLFB1CheckInd) {
			// if (oMppSupAction === false) {
			// 	var vMesg = "A mapping for this combination of this Vendor and Company Code already exists";
			// 	sap.m.MessageBox.warning(vMesg);
			// }
			// if (oLFB1CheckInd === false) {
			// 	var vMesg = "Combination of this Vendor and Company Code does not exists in LFB1";
			// 	sap.m.MessageBox.warning(vMesg);
			// }
		},
		_handledeleteRow: function (evt) {
			if (evt) {
				var oListItem, oTable;
				oListItem = evt.getSource().getParent();
				oTable = evt.getSource().getParent().getParent();
				// var sMg = this.getResourceBundle().getText("deleteMsg");
				var sMg = "Are you sure you want to delete this row?";
				sap.m.MessageBox.warning(sMg, {
					title: "warning", // default
					actions: [sap.m.MessageBox.Action.OK,
						sap.m.MessageBox.Action.CANCEL
					],
					// emphasizedAction: sap.m.MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							oTable.removeItem(oListItem);
						}
					}
				});
			}
		},
		_handlePopOverbtn: function (evt) {
			if (evt) {
				var oButton = evt.getSource();
				this.oCommentSrc = oButton;
				var fragname = "bcd_svms.ZSV_SVMDAPP.fragments.comments";
				if (!this._oPopover) {
					// Fragment.load({
					// 	name: "bcd_svms.ZSV_SVMDAPP.fragments.comments",
					// 	controller: this
					// }).then(function (oPopover) {
					// 	this._oPopover = oPopover;
					// 	this.getView().addDependent(this._oPopover);
					// 	// this._oPopover.bindElement("/ProductCollection/0");
					// 	this._oPopover.openBy(oButton);
					// }.bind(this));
					this._oPopover = sap.ui.xmlfragment(fragname, this);
					this.getView().addDependent(this._oPopover);
					this._oPopover.openBy(oButton);
				} else {
					this._oPopover.openBy(oButton);
				}
			}
		},

		handleNotesAddClose: function (evt) {
			var oLocalModel = this.getView().getModel("localModel");
			var oVal = oLocalModel.getProperty("/newNotes");
			var oCntx = this.oCommentSrc.getParent().getBindingContext();
			var m = oCntx.getModel();
			var sPath = oCntx.getPath();
			if (oVal) {
				m.setProperty(sPath + "/Remark", oVal);
			}
			oLocalModel.setProperty("/newNotes", "");
			this._oPopover.close();
		},
		_oChangeBillBackInd: function (evt) {
			var Src, Selected, ocntx, oBillbaIndModel, sPath;
			this.oBillBackInd = false;
			Src = evt.getSource();
			Selected = Src.getState();
			ocntx = Src.getBindingContext();
			oBillbaIndModel = ocntx.getModel();
			sPath = ocntx.getPath();
			if (Selected) {
				this.oBillBackInd = true;
				oBillbaIndModel.setProperty(sPath + "/" + "Billbackindicator", "X");
			} else {
				this.oBillBackInd = false;
				oBillbaIndModel.setProperty(sPath + "/" + "Billbackindicator", "");
			}
		},
		onChangeNotes: function (evt) {
			// var Src, oval, ocntx, oNotesModel, sPath;
			// Src = evt.getSource();
			// oval = Src.getValue();
			// ocntx = Src.getBindingContext();
			// oNotesModels = ocntx.getModel();
			// sPath = ocntx.getPath();
			// oNotesModels.setProperty(sPath + "/" + "Remark", oval);
		},
		onChangeCompanyCode: function (evt) {
			var Src = evt.getSource();
			// var oButxt = evt.getParameters().selectedItem.getText();
			if (evt.getParameters().selectedItem !== null) {
				var oBkurs = evt.getParameters().selectedItem.getKey();
			}
			if (Src.getValue()) {
				Src.setDescription(oBkurs);
			} else {
				Src.setDescription("");
			}
		},
		_handleSuggestVendor: function (evt) {
			var Src = evt.getSource();
			var oName1 = evt.getParameters().selectedItem.getText();
			if (Src.getValue()) {
				var olifnrs = evt.getParameters().selectedItem.getKey();
				Src.setDescription(olifnrs);
			} else {
				Src.setDescription("");
			}
		},
		_handleChangeSupplier: function (evt) {
			this.oSupplierItem = evt.getSource().getValue();
			var oState = evt.getSource().getValueState();
			if (oState === "Error") {
				evt.getSource().setValueState("None");
			}
		},
		_handlelivechangeChangeSupplier: function (evt) {
			var a = evt.getParameter("value");
			var src = evt.getSource();
			if (a.length > 10) {
				src.setValueState("Error");
				src.setValueStateText("Maximum 10 digits only allowed");
				src.setValue("");
			} else {
				src.setValueState("None");
			}
		},
		_handleChangeVendor: function (evt) {
			var oVal = evt.getSource().getValue();
			var oState = evt.getSource().getValueState();
			if (oState === "Error") {
				evt.getSource().setValueState("None");
			}
			if (!oVal) {
				evt.getSource().setValue("");
				evt.getSource().setDescription("");
			}
		},

		onPressSubReqst: function (evt) {
			var oTbl, src, oModel, vMessage, oItems;
			src = evt.getSource();
			// oModel = this.getOwnerComponent().getModel();
			oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSV_SVMD_SRV", {
				json: true
			});
			oTbl = this.getView().byId("reqTableId");
			oItems = oTbl.getItems();

			if (oItems.length === 0) {
				vMessage = "Please add atleast one line item before save request";
				sap.m.MessageBox.warning(vMessage);
				return;
			}
			this.isValidate = false;
			if (oItems.length === 1) {
				this._oMandatoryCheckforAddRow(oItems);
				if (this.isValidate) {
					sap.m.MessageBox.error("Please provide all required fileds");
					return;
				}
			}
			var batchChanges = [];
			$.each(oItems, function (i, oIndex) {
				var oId = "SVMD00" + i;
				var cntx = oItems[i].getBindingContext();
				var obj = cntx.getObject();
				obj.Reqid = oId;
				if (obj.Billbackindicator) {
					obj.Billbackindicator = "X";
				} else {
					obj.Billbackindicator = "";
				}
				var oSlectedItems = {
					Appid: obj.Appid,
					Reqid: obj.Reqid,
					Reqtyp: obj.Reqtyp,
					Supplier: obj.Supplier,
					Lifnr: obj.Lifnr,
					Name1: obj.Name1,
					Bukrs: obj.Bukrs,
					Butxt: obj.Butxt,
					Billbackindicator: obj.Billbackindicator,
					Remark: obj.Remark.trim()
				};
				delete(obj.__metadata);
				batchChanges.push(oModel.createBatchOperation("/ReqDetailSet", "Post", oSlectedItems));
			});
			oModel.addBatchChangeOperations(batchChanges);
			oModel.setUseBatch(true);
			// var mParameters = {
			// 	"groupId": "changes",
			// 	success: function (odata, response) {
			// 		// debugger;
			// 	},
			// 	error: function (error) {
			// 		// debugger;
			// 	}
			// };
			// oModel.submitChanges(mParameters);
			oTbl.setBusy(true);
			this.oTblCrt = oTbl;
			this.oErrorList = [];
			var that = this;
			oModel.submitBatch(function (odata) {
					// debugger;
					var ochangesresp = odata.__batchResponses[0].__changeResponses;
					that.getView().getModel().refresh();
					// var oResourceModel = that.getResourceBundle();
					var viewref = that;
					that.SucessPopUpViewfn(ochangesresp, viewref);
					if (that.oErrorList.length === 0) {
						that.oTblCrt.removeAllItems();
					} else {
						//add table items with error state records;
						var oErrorArray = that.oErrorList;
						var oTblRef = that.oTblCrt;
						that.oTblCrt.removeAllItems();
						that._addErrorRequesttoTable(oErrorArray, oTblRef, that);
					}
					oTbl.setBusy(false);
				},
				function (error) {
					// debugger;
					oTbl.setBusy(false);
				});
		},
		SucessPopUpViewfn: function (resp, that) {
			var oArry = [];
			// var smg1R = oResourceModel.getText("Requesttxt");
			// var smg1CS = oResourceModel.getText("createTxt");
			for (var i = 0; i < resp.length; i++) {
				var data = resp[i].data;
				if (data.Msgtyp !== "E") {
					var msg = "Request" + " " + data.Reqid + " " + "created Succesfully";
					delete(data.__metadata);
					data.Msg = msg;
				} else {
					that.oErrorList.push(data);
				}
				oArry.push(data);
			}
			that.getView().getModel("localModel").setProperty("/sucerrorlist", oArry);
			var vFragment = "bcd_svms.ZSV_SVMDAPP.fragments.SucessErrPopUp";
			if (!that.succerrPopup) {
				that.succerrPopup = sap.ui.xmlfragment(that.getView().getId(), vFragment, that);
				that.getView().addDependent(that.succerrPopup);
			}
			that.succerrPopup.openBy(that.getView().byId("SaveRequestId"));

		},
		onPressCancleReqst: function (evt) {
			var that = this;
			var msg = "Changes will be lost. Are you sure you want to leave this page?";
			var oTbl = that.getView().byId("reqTableId");
			var oModel = that.getOwnerComponent().getModel();
			var oBindingItems = oTbl.getItems();
			that.getView().setBusy(true);
			if (oBindingItems.length === 0) {
				// window.history.go(-1);
				that.onPressNavback();
			}
			if (oBindingItems.length > 0) {
				sap.m.MessageBox.warning(msg, {
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) {
						if (sAction === "OK") {
							oModel.resetChanges();
							// oTbl.removeAllItems();
							// window.history.go(-1);
							that.onPressNavback();
						} else {
							that.getView().setBusy(false);
						}
					}
				});
			}
		},
		/**sss
		 *  A check should be done if a combination of the Vendor and Company Code already exists in ZHY_MA_SUPPL_VND
		 * @memberOf bcd_svms.ZSV_SVMDAPP.view.Createrequest
		 */
		_supplierMappingCheck: function (Bukrs, lifnr, tbl, VDCCSrc) {
			this.oSuppMapplingInd = false;
			this.oLfb1TblInd = false;
			var oModel = this.getOwnerComponent().getModel();
			// var oItemSelObj = tbl.getObject();
			var suppMappFilter = [];
			var oBukrs = Bukrs;
			var oVendor = lifnr;
			suppMappFilter.push(new Filter("Bukrs", FilterOperator.EQ, oBukrs));
			suppMappFilter.push(new Filter("Vendor", FilterOperator.EQ, oVendor));
			var that = this;
			tbl.setBusy(true);
			oModel.read("/SupplierDetSet", {
				filters: suppMappFilter,
				success: function (odata) {
					var oRes = odata.results;
					var vMesg1 = "A mapping for this combination of Vendor and Company Code already exists";
					// var vMesg2 = "Combination of this Vendor and Company Code does not exists in LFB1";
					if (oRes.length > 0) {
						// if the vendor has a value lfb1, it means user can create the request.
						// if (oRes[0].Vendor !== "LFB1") {
						// 	that.oLfb1TblInd = true;
						// }
						if (oRes[0].Bukrs !== "") {
							that.oSuppMapplingInd = true;
						}
					}
					// if ((that.oLfb1TblInd === true) && (that.oSuppMapplingInd === true)) {
					// 	var smg = vMesg1 + " and " + vMesg2;
					// 	sap.m.MessageBox.warning(smg);
					// } else {
					// if (that.oLfb1TblInd === true) {
					// 	sap.m.MessageBox.warning(vMesg2);
					// }
					if (that.oSuppMapplingInd === true) {
						var ocntx = VDCCSrc.getBindingContext();
						var oCntModel = ocntx.getModel();
						var sPath = ocntx.getPath();
						oCntModel.setProperty(sPath + "/Bukrs", "");
						oCntModel.setProperty(sPath + "/Butxt", "");
						sap.m.MessageBox.warning(vMesg1);
					}
					// }
					tbl.setBusy(false);
				},
				error: function (error) {
					tbl.setBusy(false);
				}
			});
		},
		_addErrorRequesttoTable: function (erroraryData, tbl, t) {
			var oModel = t.getOwnerComponent().getModel();
			var oTable = tbl;
			var oBillInd;
			for (var i = 0; i < erroraryData.length; i++) {
				var oData = erroraryData[i];
				if (oData.Billbackindicator === "X") {
					oBillInd = true;
				} else {
					oBillInd = false;
				}
				var objParmss = {
					"Appid": oData.Appid,
					"Reqid": oData.Reqid,
					"Reqtyp": oData.Reqtyp,
					"Supplier": oData.Supplier,
					"Lifnr": oData.Lifnr,
					"Name1": oData.Name1,
					"Bukrs": oData.Bukrs,
					"Butxt": oData.Butxt,
					"Billbackindicator": oBillInd,
					"Remark": oData.Remark
				};
				var ocontxt = oModel.createEntry("/ReqDetailSet", {
					properties: objParmss
				});
				var items = this._oTempletMultiadditems();
				items.setBindingContext(ocontxt);
				oTable.addItem(items);
			}
		},
		// New Custom F4 help same like has smart field annotation.
		_handleVendorValueHelp112: function (evt) {
			var oVModelF4 = this.getView().getModel("oVCModel");
			var src = evt.getSource();
			var Tbl = evt.getSource().getParent().getParent();
			Tbl.setBusy(true);
			var sInputValue = evt.getSource().getValue();
			var sInputDes = evt.getSource().getDescription();
			this.inputId = evt.getSource().getId();
			this.oVendorIDSrc18 = src;
			// create value help dialog
			if (!this._VendorvalueHelpDialog) {
				this._VendorvalueHelpDialog = sap.ui.xmlfragment(
					"bcd_svms.ZSV_SVMDAPP.fragments.vendorf4",
					this
				);
				this.getView().addDependent(this._VendorvalueHelpDialog);
				Tbl.setBusy(false);
			}
			// create a filter for the binding
			if (sInputValue) {
				Tbl.setBusy(false);
				var aFilter = [];
				if (this.oVendorNo) {
					if (Tbl.getItems().length > 1) {
						oVModelF4.setProperty("/iVVendorNo", this.oVendorNo);
						aFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, this.oVendorNo));
					} else {
						oVModelF4.setProperty("/iVVendorNo", sInputDes);
						aFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sInputDes));
					}
				}
				if (this.oVendorName) {
					if (Tbl.getItems().length > 1) {
						oVModelF4.setProperty("/iVVendrorName", this.oVendorName);
						aFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, this.oVendorName));
					} else {
						oVModelF4.setProperty("/iVVendrorName", sInputValue);
						aFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sInputValue));
					}
				}
				this._VendorvalueHelpDialog.getContent()[2].bindRows({
					path: "/VDCCF4helpSet",
					filters: aFilter
				});
			} else {
				this._VendorvalueHelpDialog.getContent()[2].bindRows({
					path: "/VDCCF4helpSet",
					filters: []
				});
				Tbl.setBusy(false);
				oVModelF4.setProperty("/iVVendorNo", "");
				oVModelF4.setProperty("/iVVendrorName", "");
				oVModelF4.setProperty("/iVCompany", "");
				oVModelF4.setProperty("/iVCompanyname", "");
			}
			// open value help dialog with out filtered by the input value
			this._VendorvalueHelpDialog.open();
		},
		onPressClose: function (evt) {
			this._VendorvalueHelpDialog.close();
		},
		onbeforeOpen: function (evt) {
			this.getView().setBusy(true);
		},
		onafterOpen: function (evt) {
			this.getView().setBusy(false);
		},
		onPressClearInputs: function (evt) {
			var oVModel = this.getView().getModel("oVCModel");
			oVModel.setProperty("/iVVendorNo", "");
			oVModel.setProperty("/iVVendrorName", "");
			oVModel.setProperty("/iVCompany", "");
			oVModel.setProperty("/iVCompanyname", "");
		},
		onPressGoVendor: function (evt) {
			var sID = evt.getId(),
				Tbl;
			var aFilter = [];
			var oVModelF4 = this.getView().getModel("oVCModel");
			if (this.oVendorNo) {
				oVModelF4.getProperty("/iVVendorNo", this.oVendorNo);
			}
			if (this.oVendorName) {
				oVModelF4.getProperty("/iVVendrorName", this.oVendorName);
			}
			var oVendorNo = oVModelF4.getProperty("/iVVendorNo"),
				oVendorName = oVModelF4.getProperty("/iVVendrorName"),
				oComapany = oVModelF4.getProperty("/iVCompany"),
				oCompanyName = oVModelF4.getProperty("/iVCompanyname");
			if (sID === "press") {
				Tbl = evt.getSource().getParent().getParent().getContent()[2];
			} else if (sID === "submit") {
				Tbl = evt.getSource().getParent().getParent().getParent().getParent().getContent()[2];
			}
			if (oVendorNo) {
				aFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, oVendorNo));
			}
			if (oVendorName) {
				aFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, oVendorName));
			}
			if (oComapany) {
				aFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, oComapany));
			}
			if (oCompanyName) {
				aFilter.push(new sap.ui.model.Filter("Butxt", sap.ui.model.FilterOperator.Contains, oCompanyName));
			}
			// oBinding.filter(aFilter);
			Tbl.bindRows({
				path: "/VDCCF4helpSet",
				filters: aFilter
			});
		},
		onRowSelectionChangeV: function (evt) {
			this.oCompanyCode = "";
			this.oCompanyCodeName = "";
			this.oSameVedorcheck = false;
			var inputSrcVendor = this.oVendorIDSrc18;
			var omainTbl = inputSrcVendor.getParent().getParent();
			var srcList = evt.getParameter("listItem") || evt.getSource();
			var index = srcList.getSelectedIndex();
			var oCntx = evt.getParameter("rowContext");
			var oTbl = inputSrcVendor.getParent().getParent();
			if (oCntx !== null) {
				var obj = oCntx.getObject();
				var oLifnr = obj.Lifnr,
					oName1 = obj.Name1,
					oBukrs = obj.Bukrs,
					oButxt = obj.Butxt;
				if (!this.oVendorNo) {
					this.oVendorNo = oLifnr;
				}
				if (!this.oVendorName) {
					this.oVendorName = oName1;
				}
				this.oCompanyCode = oBukrs;
				this.oCompanyCodeName = oButxt;
				if (omainTbl.getItems().length > 1) {
					if (this.oVendorNo !== this.oVendorNoNewValue) {
						this.oSameVedorcheck = true;
						inputSrcVendor.setValue(this.oVendorName);
						inputSrcVendor.setDescription(this.oVendorNo);
					}
				} else {
					this.oVendorName = oName1;
					this.oVendorNo = oLifnr;
					omainTbl.getItems()[0].getCells()[2].setValue(oButxt);
					omainTbl.getItems()[0].getCells()[2].setDescription(oBukrs);
					omainTbl.getItems()[0].getCells()[2].setValueState("None");
					this._supplierMappingCheck(oBukrs, oLifnr, oTbl, inputSrcVendor);
					this.oSameVedorcheck = false;
					inputSrcVendor.setValue(oName1);
					inputSrcVendor.setDescription(oLifnr);
				}
				this._VendorvalueHelpDialog.close();
				if (inputSrcVendor.getValueState() === "Error") {
					inputSrcVendor.setValueState("None");
				}
				if (this.oSameVedorcheck) {
					sap.m.MessageBox.warning("A request can only be for same vendor");
				}
			}
		},
		// onAftercloseVendorDialog: function (evt) {
		// 	if (this.oSameVedorcheck) {
		// 		sap.m.MessageBox.warning("A request can only be for same vendor");
		// 	}
		// },
		_handleChangeVendor11: function (evt) {
			// debugger;
		},
		_handleCompanyf4Help: function (evt) {
			var oCModelF4 = this.getView().getModel("oVCModel");
			var src = evt.getSource();
			var Tbl = evt.getSource().getParent().getParent();
			Tbl.setBusy(true);
			var sCompInputValue = evt.getSource().getValue();
			this.inputCompantId = evt.getSource().getId();
			this.oCompanyIDSrc18 = src;
			oCModelF4.setProperty("/iCVendorNo", this.oVendorNo);
			oCModelF4.setProperty("/iCVendorName", this.oVendorName);
			// create value help dialog
			if (!this._ComapnyvalueHelpDialog) {
				this._ComapnyvalueHelpDialog = sap.ui.xmlfragment(
					"bcd_svms.ZSV_SVMDAPP.fragments.companyf4",
					this
				);
				this.getView().addDependent(this._ComapnyvalueHelpDialog);
				Tbl.setBusy(false);
			}
			// create a filter for the binding
			if (sCompInputValue) {
				var aFilter = [];
				if (this.oVendorNo) {
					aFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, this.oVendorNo));
				}
				if (this.oVendorName) {
					aFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, this.oVendorName));
				}
				this._ComapnyvalueHelpDialog.getContent()[2].bindRows({
					path: "/VDCCF4helpSet",
					filters: aFilter
				});
				Tbl.setBusy(false);
			} else {
				var aFilter = [];
				if (this.oVendorNo) {
					aFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, this.oVendorNo));
				}
				if (this.oVendorName) {
					aFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, this.oVendorName));
				}
				this._ComapnyvalueHelpDialog.getContent()[2].bindRows({
					path: "/VDCCF4helpSet",
					filters: aFilter
				});
				Tbl.setBusy(false);
			}
			// open value help dialog with out filtered by the input value
			this._ComapnyvalueHelpDialog.open();
		},
		onPressCompanyClose: function (evt) {
			this._ComapnyvalueHelpDialog.close();
		},
		onPressGoCompany: function (evt) {
			var TblCC,
				sIDC = evt.getId();
			var acFilter = [];
			var oCModelF4 = this.getView().getModel("oVCModel");
			var oCVendorNo = oCModelF4.getProperty("/iCVendorNo"),
				oCVendorName = oCModelF4.getProperty("/iCVendorName"),
				oCComapany = oCModelF4.getProperty("/iCCompany"),
				oCCompanyName = oCModelF4.getProperty("/iCCompanyName");
			// var Tbl = this.oVendorIDSrc18.getParent().getParent();
			// var TblCC = evt.getSource().getParent().getParent().getContent()[2];
			if (sIDC === "press") {
				TblCC = evt.getSource().getParent().getParent().getContent()[2];
			} else if (sIDC === "submit") {
				TblCC = evt.getSource().getParent().getParent().getParent().getParent().getContent()[2];
			}
			if (oCVendorNo) {
				acFilter.push(new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, oCVendorNo));
			}
			if (oCVendorName) {
				acFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, oCVendorName));
			}
			if (oCComapany) {
				acFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, oCComapany));
			}
			if (oCCompanyName) {
				acFilter.push(new sap.ui.model.Filter("Butxt", sap.ui.model.FilterOperator.Contains, oCCompanyName));
			}
			// oBinding.filter(aFilter);
			TblCC.bindRows({
				path: "/VDCCF4helpSet",
				filters: acFilter
			});
		},
		onPressClearInputsCompny: function (evt) {
			var oCModel = this.getView().getModel("oVCModel");
			oCModel.setProperty("/iCCompany", "");
			oCModel.setProperty("/iCCompanyName", "");

		},
		onRowSelectionChangeCC: function (evt) {
			var inputSrcCompany = this.oCompanyIDSrc18;
			var oTbl = inputSrcCompany.getParent().getParent();
			var srcList = evt.getParameter("listItem") || evt.getSource();
			// var index = srcList.getSelectedIndex();
			var oCntx = evt.getParameter("rowContext");
			if (oCntx !== null) {
				var obj = oCntx.getObject();
				var oLifnr = obj.Lifnr,
					oName1 = obj.Name1,
					oBukrs = obj.Bukrs,
					oButxt = obj.Butxt;

				this._ComapnyvalueHelpDialog.close();
				if (inputSrcCompany.getValueState() === "Error") {
					inputSrcCompany.setValueState("None");
				}
				this._supplierMappingCheck(oBukrs, oLifnr, oTbl, inputSrcCompany);
				if (this.oSuppMapplingInd === true) {
					inputSrcCompany.setValue("");
					inputSrcCompany.setDescription("");
				} else {
					inputSrcCompany.setValue(oButxt);
					inputSrcCompany.setDescription(oBukrs);
				}

			}
		},
		// //This event is fired when user presses the Enter key on the input. 
		// and it will featch the respective vendor from LfB1 table
		onSubmitVendorVF4: function (evt) {
			var e = evt;
			this.onPressGoVendor(e);
		},
		onSubmitCompanyCF4: function (evt) {
			var cc = evt;
			this.onPressGoCompany(cc);
		}

		/**sss
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf bcd_svms.ZSV_SVMDAPP.view.Createrequest
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf bcd_svms.ZSV_SVMDAPP.view.Createrequest
		 */
		// onAfterRendering: function () {
		// 	var a = "s";
		// 	debugger;

		// },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf bcd_svms.ZSV_SVMDAPP.view.Createrequest
		 */
		//	onExit: function() {
		//
		//	}

	});

});