sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		BtnVisbility: function (status) {
			var st;
			if (status === "PROCESSED") {
				st = false;
			} else if (status === "SUBMITTED") {
				st = true;
			} else if (status === "REJECTED") {
				st = false;
			} else if (status === "CANCELLED") {
				st = false;
			}
			return st;
		},
		iconstate: function (msgType) {
			if (msgType === "E") {
				return "red";
			} else {
				return "green";
			}
		},
		NoteTimestamp: function (date, time) {
			// var dt = date.split("T");
			// var c = time.slice(2, 4) + ":" + time.slice(5, 7) + ":" + time.slice(8, 10);
			// var fine = dt[0].concat("T" + C);
			// var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			// 	style: "medium",
			// 	UTC: true
			// });
			// var fdt = new Date(fine);
			// var TZOffSetMs = fdt.getTimezoneOffSet() * 60 * 1000;
			// var dateStr = dateFormat.format(new Date(fine));
			// return datestr;
		},
		BillBackIndState: function (ind) {
			if (ind) {
				return true;
			} else {
				return false;
			}
		},
		Reqstatusfomatter: function (status) {
			var oState;
			if (status === "PROCESSED") {
				oState = "Success";

			} else if (status === "SUBMITTED") {
				oState = "Warning";
			} else if (status === "REJECTED") {
				oState = "Error";
			} else if (status === "CANCELLED") {
				oState = "Error";
			}
			return oState;
		},
		dateformatter: function (date) {
			if (date) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd.MM.yyyy",
					UTC: true
				});
				var finaldate = dateFormat.format(date);
			}
			return finaldate;
		}
	};

});