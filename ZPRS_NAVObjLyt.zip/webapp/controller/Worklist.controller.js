/*global location history */
sap.ui.define([
	"testnavobjcmi/ZPRS_NAVObjLyt/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"testnavobjcmi/ZPRS_NAVObjLyt/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("testnavobjcmi.ZPRS_NAVObjLyt.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay;

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			this._dataBinding();
		},
		_dataBinding: function() {
			var oModel = this.getOwnerComponent().getModel();
			// this.getModel("generalSettings").setProperty("/Cmino", args.Cmino);
			var that = this;
			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: "",
					Matterk: "",
					Clientk: "20001180",
					Cmirequesttype: "CA"
				});
				that._bindView("/" + sObjectPath);
			});
			// Cmihdrs(Cmirequesttype='CA',Cmino='',Clientk='20001180',Matterk='')

		},
		_bindView: function(sObjectPath) {
			//var oModel = this.getOwnerComponent().getModel();
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						this.getView().setBusy(true);
					}.bind(this),
					dataReceived: function(data) {
						this.getView().setBusy(false);

					}.bind(this)
				}
			});
		},
		onpressaddContact: function(oEvent) {
			this._addoreditContact();
		},
		_addoreditContact: function(oContactctx) {
			var oContactContext = oContactctx;
			if (!this._oContact) {
				this._oContact = sap.ui.xmlfragment(this.getView().getId(), "testnavobjcmi.ZPRS_NAVObjLyt.fragment.ContactEntryForm",
					this);
				this.getView().addDependent(this._oContact);
			}
			if (!oContactContext) {
				// this._oContact.data("bType", "Create");
				// var oClient = this.getBindingContextbyId("idClientDetails");
				// oClient = oClient.getObject();
				var oContactContext = this._createContexts("/Cmiclntcontacts", {
					Cmino: "",
					Clientk: "",
					Client: "",
					Partnertype: "CEC"
				});
			}
			this._oContact.setBindingContext(oContactContext);
			this._oContact.open();
		},
		// create context
		_createContexts: function(sPath, oClientObject) {
			var oModel = this.getModel(),
				oContext = oModel.createEntry(sPath, {
					properties: oClientObject
				});
			return oContext;
		},
		onContactEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditContact(oContext);
		},
		closeContact: function() {
			this._oContact.close();
		},
		onPressSubmitContact: function() {
			var oModel = this.getModel();
					oModel.submitChanges({
				success: function(res) {
					this._oContact.close();
					//	this.getView().byId("cmiamendmentnew.idClientContact.table_").getBinding("items").refersh(true);
					//	that._deleteContexts(that.getBindingContextbyId("cmiamendmentnew.clientContact.form_"));
				}.bind(this),
				error: function(res) {
					this._oContact.close();

				}.bind(this)
			});
		}

	});
});