/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/Worklist",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/Object",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/NotFound",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/Browser",
	"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "testnavobjcmi.ZPRS_NAVObjLyt.view."
	});

	sap.ui.require([
		"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/WorklistJourney",
		"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/ObjectJourney",
		"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/NavigationJourney",
		"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/NotFoundJourney",
		"testnavobjcmi/ZPRS_NAVObjLyt/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});