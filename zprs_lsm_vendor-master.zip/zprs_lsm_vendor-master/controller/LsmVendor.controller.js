sap.ui.define([
	"lsmvendor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmvendor/model/formatter"
], function(BaseController, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("lsmvendor.controller.LsmVendor", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf vendor.view.TKRate
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay;
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				pending: 0,
				inProcess: 0,
				approved: 0,
				rejected: 0,
				holdBudget: 0,
				paid: 0,
				payApprove: 0,
				invStatus: true,
				payStatus: true,
				paystatMes: true,
				filetype: true,
				currencyColm: true,
				invCurrency: true,
				Status: true,
				fileuploadBtn: true,
				attachUpload: false

			});
			this.setModel(oViewModel, "worklistView");
			var oButtonMod = new JSONModel({
				MainTabBtn: true,
				ManageBudgetBtn: false,
				commonButtons: false,
				TableVisibleFields: true,
				AccuralButtons: false
			});
			this.setModel(oButtonMod, "oButtonMod");

			var oInitialModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VENDOR_LAWFIRMS_SRV/");
			this.setModel(oInitialModel, "oInitialModel");
			var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			this.setModel(VMatterModel, "VMatterModel");
			var LSWModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV/");
			this.setModel(LSWModel, "LSWModel");
			var LUploadModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VENDOR_SRV/");
			this.setModel(LUploadModel, "LUploadModel");
			this._mFilters = {
				"pending": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "01")],
				"inProcess": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "04")],
				"approved": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "02")],
				"rejected": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "03")],
				"holdBudget": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "05")],
				"paid": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "01")],
				"payApprove": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "02")]

			};
			// 	var oTable = this.getView().byId("smartTable");
			// oTable.attachEventOnce("updateFinished", function() {
			// 	// Restore original busy indicator delay for worklist's table
			// 	oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			// });
		},
		onDisPlayAttachment: function(evt) {
			var LSWModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV"),
				sObj = evt.getSource().getBindingContext().getObject(),
				invoiceNo = sObj.ZzinvoiceNumber;
			var servUri = LSWModel.sServiceUrl;
			var sRead = "/PrintInvoiceCollection(Vbeln='" + invoiceNo + "')" + "/$value";
			var mainUri = servUri + sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");
		},
		onItemSelction: function(evt) {

			var oViewModel = this.getView().getModel("worklistView");
			var oTable = this.getView().byId("MyWorkBenchSmartTable");
			var tbl = oTable.getTable();
			var oItem = tbl.getSelectedItems();
			if (oItem.length > 1 || oItem.length === 0) {
				oViewModel.setProperty("/attachUpload", false);
			} else {
				oViewModel.setProperty("/attachUpload", true);
			}
		},
		// Attachments upload.
		onChangeUploadAttch: function(evt) {
			var oTable = this.getView().byId("MyWorkBenchSmartTable");
			var tbl = oTable.getTable();
			var obj = tbl.getSelectedContexts()[0].getObject();
			var invNo = obj.ZzinvoiceNumber;
			// // debugger;
			// var oItems = tbl.getSelectedItems();
			// if (oItems.length === 1) {
			var oFile = evt.getParameter("files");
			var sFileName = oFile[0].name;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV");
			var oToken = oModel.getSecurityToken();
			var oUpload = evt.getSource();
			oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: oToken
			}));
			oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: invNo + "|" + sFileName
			}));
			oUpload.upload();
			// } else {
			// 	oUpload.clear();
			// 	var smg = "Select one lineitem fro Add Attachment";
			// 	sap.m.MessageBox.show(smg, {
			// 		icon: sap.m.MessageBox.Icon.INFORMATION,
			// 		title: "My message box title",
			// 		actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			// 		onClose: function(oAction) {}
			// 	});

			// }
		},
		handleUploadAttach: function(evt) {
			var oUpload = evt.getSource();
			oUpload.clear();
		},
		onBeforeRebindTable: function(oEvent) {
			var SegmentKey = this.getView().byId("idIconTabBarNoIcons").getSelectedKey();
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];
			if (SegmentKey === "06") {
				aFilter.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, "01"));
			} else if (SegmentKey === "07") {
				aFilter.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, "02"));
			} else {
				aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			}

			mBindingParams.filters = aFilter;

		},
		ManagebudgetDataReceived: function(oEvent) {
			var oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/currencyColm", false);

		},
		handleDataReceived: function(oEvent) {
			var oSource = oEvent.getSource(),
				// oViewMod = this.getModel("oButtonMod"),
				// oTbl = oSource.getTable(),
				key = this.getView().byId("idIconTabBarNoIcons").getSelectedKey(),
				oViewModel = this.getModel("worklistView");

			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/pending", oData);
				},
				filters: this._mFilters.pending
			});

			// read the count for the unitsInStock filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/inProcess", oData);
				},
				filters: this._mFilters.inProcess
			});

			// read the count for the outOfStock filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/approved", oData);
				},
				filters: this._mFilters.approved
			});

			// read the count for the shortage filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/rejected", oData);
				},
				filters: this._mFilters.rejected
			});
			// read the count for the shortage filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/holdBudget", oData);
				},
				filters: this._mFilters.holdBudget
			});
			// read the count for the shortage filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/paid", oData);
				},
				filters: this._mFilters.paid
			});
			// read the count for the shortage filter
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/payApprove", oData);
				},
				filters: this._mFilters.payApprove
			});
			// rows = oTbl.getBinding().getLength();

			// var oViewModel = this.getModel("worklistView");
			if (key === "06" || key === "07") {
				oViewModel.setProperty("/invStatus", false);
				oViewModel.setProperty("/payStatus", true);
				oViewModel.setProperty("/paystatMes", false);
				oViewModel.setProperty("/filetype", false);
				oViewModel.setProperty("/invCurrency", false);

			} else {
				oViewModel.setProperty("/invStatus", true);
				oViewModel.setProperty("/payStatus", false);
				oViewModel.setProperty("/paystatMes", false);
				oViewModel.setProperty("/filetype", false);
				oViewModel.setProperty("/invCurrency", false);
			}

		},
		onselectList: function(oevn) {
			var aFilter = [],
				// t = this.getView().byId("idManageBudgetTable"),
				oTable = this.getView().byId("MyWorkBenchSmartTable"),
				oTab = oTable.getTable(),
				cntx = oTab.getBinding("items"),
				SegmentKey = oevn.getParameters().key,
				oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", true);
			oViewModel.setProperty("/paystatMes", true);
			oViewModel.setProperty("/filetype", true);
			// 			cntx.aApplicationFilters = null;
			if (SegmentKey === "06") {
				aFilter.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, "01"));

			} else if (SegmentKey === "07") {
				aFilter.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, "02"));

			} else {
				aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));

			}

			cntx.filter(aFilter, "Application");

		},

		getTable: function() {
			var oblock = this.getView().byId("MainTableSubSection").getBlocks()[0],
				oTable = oblock.byId("MyWorkBenchSmartTable");
			return oTable.getTable();
		},
		getBMTable: function() {
			var oblock = this.getView().byId("ManageBudgetSubSection").getBlocks()[0],
				oTable = oblock.byId("ManageBudgetSmartTable");
			return oTable.getTable();
		},
		getAcuralTable: function() {
			var oblock = this.getView().byId("AccrualsSubSection").getBlocks()[0],
				oTable = oblock.byId("AccrualsSmartTable");
			return oTable.getTable();
		},
		getExChangeTable: function() {
			var oblock = this.getView().byId("ExRateSubSection").getBlocks()[0],
				oTable = oblock.byId("idExRateTable");
			return oTable.getTable();
		},

		onSectionNav: function(oEvent) {
			var that = this,
				itemKey = oEvent.mParameters.section.getTitle();
			var oInitialModel = this.getModel("oInitialModel"),
				VMatterModel = this.getModel("VMatterModel"),
				LSWModel = this.getModel("LSWModel"),
				oViewModel = this.getView().getModel("worklistView"),
				IconTab = this.getModel("oButtonMod");

			if (itemKey === "My Workbench") {
				var oSmartTable = that.getTable().getParent();
				var MFlag = oSmartTable.getEnableAutoBinding();
				if (!MFlag) {
					that.getView().byId("MainTableSubSection").setModel(oInitialModel);
				}
				IconTab.setProperty("/MainTabBtn", true);
				IconTab.setProperty("/ManageBudgetBtn", false);
				IconTab.setProperty("/commonButtons", false);
				IconTab.setProperty("/AccuralButtons", false);
				oViewModel.setProperty("/fileuploadBtn", true);

			}
			if (itemKey === "Manage Budget") {
				var oSmartMBTable = that.getBMTable().getParent();
				var MBFlag = oSmartMBTable.getEnableAutoBinding();
				// Excel upload row data
				var that = this;
				that.ojsonModel = new JSONModel();
				VMatterModel.read("BudgetDetailSet", {
					success: function(odata) {
						that.ojsonModel.setData(odata);
						that.getView().byId("ManageBudgetSubSection").setModel(that.ojsonModel, "ojsonModel");
					},
					error: function() {}
				});
				// if (!MBFlag) {
				// 	oSmartMBTable.setEnableAutoBinding(true);

				// 	that.getView().byId("ManageBudgetSubSection").setModel(VMatterModel);
				// 	// oSmartMBTable.attachDataReceived(this._hideColumns, this);
				// 	oSmartMBTable.rebindTable();

				// }
				oViewModel.setProperty("/fileuploadBtn", false);
				IconTab.setProperty("/MainTabBtn", false);
				IconTab.setProperty("/ManageBudgetBtn", true);
				IconTab.setProperty("/commonButtons", true);
				IconTab.setProperty("/AccuralButtons", false);

			}

			if (itemKey === "Accruals") {

				var oSmartAccTable = that.getAcuralTable().getParent();
				var AccFlag = oSmartAccTable.getEnableAutoBinding();
				if (!AccFlag) {
					oSmartAccTable.setEnableAutoBinding(true);

					that.getView().byId("AccrualsSubSection").setModel(VMatterModel);
					oSmartAccTable.rebindTable();
				}

				IconTab.setProperty("/MainTabBtn", false);
				IconTab.setProperty("/ManageBudgetBtn", false);
				IconTab.setProperty("/commonButtons", false);
				IconTab.setProperty("/AccuralButtons", true);
				oViewModel.setProperty("/fileuploadBtn", false);
			}
			if (itemKey === "Exchange Rates") {

				var oSmartExRTable = that.getExChangeTable().getParent();
				var ExRFlag = oSmartExRTable.getEnableAutoBinding();
				if (!ExRFlag) {
					oSmartExRTable.setEnableAutoBinding(true);

					that.getView().byId("ExRateSubSection").setModel(LSWModel);
					oSmartExRTable.rebindTable();
				}
				oViewModel.setProperty("/fileuploadBtn", false);
				IconTab.setProperty("/MainTabBtn", false);
				IconTab.setProperty("/ManageBudgetBtn", false);
				IconTab.setProperty("/commonButtons", false);
				IconTab.setProperty("/AccuralButtons", false);
			}

		},
		// _hideColumns: function(evt) {
		// 	var oViewModel = this.getView().getModel("worklistView");
		// 	var oSmartTable = this.getView().byId("ManageBudgetSmartTable");
		// 	// var count = oSmartTable._getRowCount();
		// 	oViewModel.setProperty("/Status", false);
		// },
		onItemPress: function(oEvent) {
			this._showObject(oEvent.getSource());
		},
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				ZzinvoiceNumber: oItem.getBindingContext().getProperty("ZzinvoiceNumber"),
				Zzfiletype: oItem.getBindingContext().getProperty("Zzfiletype"),
				Zzseqnr: oItem.getBindingContext().getProperty("Zzseqnr")
			});
		},
		onTKPress: function() {
			this.getView().setBusy(true);
			this.getRouter().navTo("TKRate");
			this.getView().setBusy(false);
		},
		onPrintPress: function(oEvent) {
			var LSWModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV/"),
				oTab = this.getTable(),
				index = oTab.getSelectedItem(),
				cntx = index.getBindingContext(),
				Vbeln = cntx.getProperty("ZzinvoiceNumber");

			var servUri = LSWModel.sServiceUrl;
			var sRead = "/PrintInvoiceCollection(Vbeln='" + Vbeln + "')" + "/$value";

			var mainUri = servUri + sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");

		},
		onAccuralsSave: function() {
			var tbl = this.getAcuralTable(),
				sAccuralObj = [];

			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index),
					sObj = context1.getObject();
				// sAccuralObj.push(sObj);
				var sAccuralObj1 = {
					ClientId: sObj.ClientId,
					InvoiceDate: sObj.InvoiceDate,
					InvoiceNumber: sObj.InvoiceNumber,
					LawFirmMatterId: sObj.LawFirmMatterId,
					LineItemDescription: sObj.LineItemDescription,
					LineItemNumber: sObj.LineItemNumber,
					LineItemNumberOfUnits: sObj.LineItemNumberOfUnits,
					LineItemTotal: sObj.LineItemTotal,
					LineItemUnitCost: sObj.LineItemUnitCost,
					MatterName: sObj.MatterName,
					TimekeeperId: sObj.TimekeeperId,
					TimekeeperName: sObj.TimekeeperName,
					TransactionType: sObj.TransactionType
				};
				sAccuralObj.push(sAccuralObj1);
			});

			var oUrlParams = {
				Uname: "Extraj",
				ArecToUser: sAccuralObj

			};
			var AccuralModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/", {
				json: true
			});

			AccuralModel.create("/UserdataASet", oUrlParams, {
				success: function(oData, response) {
					var smg = oData.Message;

				},
				error: function() {

				}
			});

		},
		onBudgetSave: function() {
			var tbl = this.getBMTable();
			var oBukrsArray = [],
				oWerksArray = [],
				oPspidArray = [],
				oVendorArray = [],
				oStatusArray = [],
				oGjahrArray = [],
				oPosidArray = [],
				oHkontArray = [],
				oAmountArray = [],
				oRecordTypeArray = [],
				oCurrencyArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var obj = context1.getObject();
				oBukrsArray.push(obj.Bukrs);
				oWerksArray.push(obj.Werks);
				oPspidArray.push(obj.Pspid);
				oVendorArray.push(obj.Vendor);
				oStatusArray.push(obj.Status);
				oGjahrArray.push(obj.Gjahr);
				oPosidArray.push(obj.Posid);
				oHkontArray.push(obj.Hkont);
				oAmountArray.push(obj.Amount);
				oRecordTypeArray.push(obj.RecordType);
				oCurrencyArray.push(obj.Currency);
			});

			var oUrlParams = {
				Bukrs: oBukrsArray.join("|"),
				Werks: oWerksArray.join("|"),
				Pspid: oPspidArray.join("|"),
				Vendor: oVendorArray.join("|"),
				Status: oStatusArray.join("|"),
				Gjahr: oGjahrArray.join("|"),
				Posid: oPosidArray.join("|"),
				Hkont: oHkontArray.join("|"),
				Amount: oAmountArray.join("|"),
				RecordType: oRecordTypeArray.join("|"),
				Currency: oCurrencyArray.join("|")
			};
			var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// var VMatterModel = this.getModel("VMatterModel");
			VMatterModel.callFunction("/BudgetChange", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(tbl.getSelectedIndices(), function(i, o) {
						var oIserror = oData.results[0].Iserror;
						var oMsg = oData.results[0].Message;
						var ctx = tbl.getContextByIndex(o);
						var isErrorPath = ctx.getPath() + "/Iserror";
						var MessagePath = ctx.getPath() + "/Message";

						var model = ctx.getModel("ojsonModel");
						model.setProperty(MessagePath, oMsg);
						model.setProperty(isErrorPath, oIserror);

					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		// Excel Upload function
		handleUploadChange: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._importinvoice(file, action);

			}
		},
		// Excel Sheet read function method
		_importinvoice: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}

					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["Message type"] === undefined) {
							sheetData[i]["Message type"] = "";
						}
						if (sheetData[i]["Purchasing Doc"] === undefined) {
							sheetData[i]["Purchasing Doc"] = "";
						}
						if (sheetData[i]["Billing Date"] === undefined) {
							sheetData[i]["Billing Date"] = "";
						}
						if (sheetData[i]["Invoice Number"] === undefined) {
							sheetData[i]["Invoice Number"] = "";
						}
						if (sheetData[i]["Matter"] === undefined) {
							sheetData[i]["Matter"] = "";
						}
						if (sheetData[i]["Amount"] === undefined) {
							sheetData[i]["Amount"] = "";
						}
						if (sheetData[i]["Invoice Description"] === undefined) {
							sheetData[i]["Invoice Description"] = "";
						}
						if (sheetData[i]["Quantity"] === undefined) {
							sheetData[i]["Quantity"] = "";
						}
						if (sheetData[i]["Matter Name"] === undefined) {
							sheetData[i]["Matter Name"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["VendorNo"] === undefined) {
							sheetData[i]["VendorNo"] = "";
						}

					}
					that.creatObj(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		creatObj: function(newData, action) {
			var objArray = [],
				oMngBudget = this.getView().byId("MainTableSubSection").getBlocks()[0],
				oTable = oMngBudget.byId("MyWorkBenchSmartTable"),
				otbl = oTable.getTable();
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VENDOR_SRV");
			var batchChanges = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var Messagetype = data["Message type"].trim();
				var PurchasingDoc = data["Purchasing Doc"].trim();
				var BillingDate = new Date(data["Billing Date"].trim());
				var BillingDate = null;
				var InvoiceNumber = data["Invoice Number"].trim();
				var Matter = data["Matter"].trim();
				var Amount = data["Amount"].trim();
				var InvoiceDescription = data["Invoice Description"].trim();
				var Quantity = data["Quantity"].trim();
				var MatterName = data["Matter Name"].trim();
				var Currency = data["Currency"].trim();
				var oVendor = data["VendorNo"].trim();
				var obj = {
					"Type": Messagetype,
					"Zzebeln": PurchasingDoc,
					"ZzinvoiceDate": BillingDate,
					"ZzinvoiceNumber": InvoiceNumber,
					"ZzlawFirmMatterId": Matter,
					"ZzinvoiceTotal": Amount,
					"ZzinvoiceDescription": InvoiceDescription,
					"ZzlineItemNumberOfUnits": Quantity,
					"ZzmatterName": MatterName,
					"Zzwaerk": Currency,
					"ZzlawFirmNo": oVendor
				};

				if (Messagetype === "" && PurchasingDoc === "" && BillingDate === "" && InvoiceNumber === "" && Matter === "" && Amount === "" &&
					InvoiceDescription === "" && Quantity === "" && MatterName === "" && Currency === "") {
					continue;
				} else {
					// objArray.push(obj);
					otbl.setBusy(true);
					batchChanges.push(oModel.createBatchOperation("/AddInvoiceSet", "POST", obj));
				}
			}
			oModel.addBatchChangeOperations(batchChanges);
			//submit changes and refresh the table and display message&nbsp;\&nbsp;
			oModel.setUseBatch(true);
			oModel.submitBatch(function(oSuccess) {
				var smg = "Successfully Upload Invoice";
				sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
				otbl.getModel().refresh();
				otbl.setBusy(false);
			}, function(oError) {
				var sEmsg = "Error While Uploading";
				sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
				otbl.setBusy(false);
			});
		},
		//ManageBedugt Excel downLoad
		onExportExcelTrigger: function(evt) {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV");
			var sUrl = oModel.sServiceUrl + "/BudgetDetailSet?$format=xlsx";

			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},

		onBudgetRefresh: function(evt) {
			var oblock = this.getView().byId("ManageBudgetSubSection").getBlocks()[0];
			var tbl = oblock.byId("ManageBudgetSmartTable"),
				oTbl = tbl.getTable();
			$.each(oTbl.getSelectedIndices(), function(i, o) {
				var ctx = oTbl.getContextByIndex(o);
				var isErrorPath = ctx.getPath() + "/Iserror";
				var MessagePath = ctx.getPath() + "/Message";

				var model = ctx.getModel("ojsonModel");
				model.setProperty(MessagePath, "");
				model.setProperty(isErrorPath, "");

			});
			var oModel = oTbl.getModel();
			oModel.refresh();
			oTbl.clearSelection();
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
		// Excel upload Functn  
		handleUpload: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file, action);

			}
		},
		// Excel Sheet read function method
		_import: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}

					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["RecordType"] === undefined) {
							sheetData[i]["RecordType"] = "";
						}
						if (sheetData[i]["Vendor"] === undefined) {
							sheetData[i]["Vendor"] = "";
						}
						if (sheetData[i]["Vendor Name"] === undefined) {
							sheetData[i]["Vendor Name"] = "";
						}
						if (sheetData[i]["Compcode"] === undefined) {
							sheetData[i]["Compcode"] = "";
						}
						if (sheetData[i]["Office"] === undefined) {
							sheetData[i]["Office"] = "";
						}
						if (sheetData[i]["Status"] === undefined) {
							sheetData[i]["Status"] = "";
						}
						if (sheetData[i]["Fiscal Year"] === undefined) {
							sheetData[i]["Fiscal Year"] = "";
						}
						if (sheetData[i]["GL Account"] === undefined) {
							sheetData[i]["GL Account"] = "";
						}
						if (sheetData[i]["Amount"] === undefined) {
							sheetData[i]["Amount"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["Matter Phase"] === undefined) {
							sheetData[i]["Matter Phase"] = "";
						}

					}
					that.abd(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		abd: function(newData, action) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var RecordType = data["RecordType"].trim();
				var Vendor = data["Vendor"].trim();
				var VendorName = data["Vendor Name"].trim();
				var Compcode = data["Compcode"].trim();
				var Office = data["Office"].trim();
				var Matter = data["Matter"].trim();
				var MatterName = data["Matter Name"].trim();
				var Status = data["Status"].trim();
				var FiscalYear = data["Fiscal Year"].trim();
				var GLAccount = data["GL Account"].trim();
				var Amount = data["Amount"].trim();
				var Currency = data["Currency"].trim();
				var MatterPhase = data["Matter Phase"].trim();

				var obj = {
					"RecordType": RecordType,
					"Vendor": Vendor,
					"Name1": VendorName,
					"Bukrs": Compcode,
					"Werks": Office,
					"Pspid": Matter,
					"Post1": MatterName,
					"StatusText": Status,
					"Gjahr": FiscalYear,
					"Hkont": GLAccount,
					"Amount": Amount,
					"Konwa": Currency,
					"Posid": MatterPhase
				};

				if (RecordType === "" && Vendor === "" && VendorName === "" && Compcode === "" && Office === "" && Matter === "" &&
					MatterName === "" && Status === "" && FiscalYear === "" && GLAccount === "" && Amount === "" && Currency === "" && MatterPhase ===
					"") {
					continue;
				} else {
					objArray.push(obj);
				}
			}
			var model = this.getView().getModel("ojsonModel"),
				results = model.getData().results;
			// results.push(objArray);
			this.getModel("ojsonModel").setProperty("/results", objArray.concat(results));

		},
		handleUploadManage: function(evt) {
			var a = 10;
			debugger;
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf vendor.view.TKRate
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf vendor.view.TKRate
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf vendor.view.TKRate
		 */
		//	onExit: function() {
		//
		//	}

	});

});