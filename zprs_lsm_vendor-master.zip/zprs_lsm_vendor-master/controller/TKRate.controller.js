sap.ui.define([
	"lsmvendor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmvendor/model/formatter"
], function(BaseController, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("lsmvendor.controller.TKRate", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf vendor.view.TKRate
		 */
		onInit: function() {
			var oView = this.getView(),
				MasterDetModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_MS_SRV/");
			this.excelmodel = MasterDetModel;
			oView.setModel(MasterDetModel);
		},
		onUpdateFinished: function(oEvent) {
			var list = oEvent.getSource();
			if (list.getItems().length > 0) {
				//list.removeSelections(true);
				var selItem;
				if (list.getSelectedItems().length > 0) {
					selItem = list.getSelectedItems()[0];
				} else {
					selItem = list.getItems()[0];
				}
				list.setSelectedItem(selItem);
				this._showDetail(selItem || oEvent.getSource());
				// this.setVisibility();
				//	this.onItemSelect(oEvent)
			} else {
				// this.getRouter().getTargets().display("notFound");
			}
		},
		getTable: function() {
			var oTable = this.getView().byId("idTKTable");
			return oTable.getTable();
		},
		_showDetail: function(oItem) {
			// oItem.focus();
			// var bReplace = !Device.system.phone,
			// 	urlParams = [];
			var cntx = oItem.getBindingContextPath(),
				Rpath = cntx + "/CrecupdSet",
				oModel = this.getView().getModel();
			this.sPath = Rpath;
			var oMDLocal = new sap.ui.model.json.JSONModel();
			var otbl = this.getView().byId("idTKTable");
			var tbl = otbl.getTable();
			var that = this;
			tbl.setBusy(true);
			oModel.read(Rpath, {

				success: function(data, response) {
					oMDLocal.setData({
						modelData: data.results
					});
					var oTable = that.getTable();
					oTable.setModel(oMDLocal);
					// oTable.setSelectionMode("None");
					oTable.bindRows("/modelData");
					tbl.setBusy(false);
				},
				error: function(oError) {
					tbl.setBusy(false);
				}

			});

		},
		onExportExcelTimeKepeer: function(evt) {
			var sUrl = this.excelmodel.sServiceUrl + this.sPath + "?$format=xlsx";
			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		onItemSelect: function(oEvent) {
			var tbl = this.getView().byId("list"),
				li = oEvent.getParameter("listItem") || oEvent.getSource();

			if (li.getSelected() === true || oEvent.getSource() instanceof sap.m.ObjectListItem) {
				this._showDetail(li);
			} else if (li.getSelected() === false) {
				var oList = this.getView().byId("list");
				if (oList.getSelectedItems().length !== 0) {
					this._showDetail(oList.getSelectedItems()[0]);
				} else {
					// this.getRouter().getTargets().display("notFound");
				}
			}

		},
		onTKRateSave: function(oEvt) {
			var otbl = this.getView().byId("idTKTable"),
				tbl = otbl.getTable(),
				sTKObj = [];

			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index),
					sObj = context1.getObject();
				// sTKObj.push(sObj);
				var sTKRObj1 = {
					Action: "UPL",
					Datab: sObj.Datab,
					Datbi: sObj.Datbi,
					Kbetr: sObj.Kbetr,
					Kmein: sObj.Kmein,
					Konwa: sObj.Konwa,
					Kpein: sObj.Kpein,
					Kunnr: sObj.Kunnr,
					Name1: sObj.Name1,
					Pernr: sObj.Pernr,
					Post1: sObj.Post1,
					Pspid: sObj.Pspid,
					Sname: sObj.Sname,
					Status: sObj.Status
				};
				sTKObj.push(sTKRObj1);
			});

			var oUrlParams = {
				Uname: "Extraj",
				CrecToUser: sTKObj

			};
			var TKRateModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/", {
				json: true
			});

			TKRateModel.create("/UserdataASet", oUrlParams, {
				success: function(oData) {
					var smg = oData.Message;

				},
				error: function() {

				}
			});
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("LsmVendor", {}, true);
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf vendor.view.TKRate
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf vendor.view.TKRate
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf vendor.view.TKRate
		 */
		//	onExit: function() {
		//
		//	}

	});

});