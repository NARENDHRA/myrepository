/*global location*/
sap.ui.define([
	"lsmvendor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmvendor/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("lsmvendor.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					Title: ""
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			// iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			// this.getOwnerComponent().getModel().metadataLoaded().then(function () {
			// 		// Restore original busy indicator delay for the object view
			// oViewModel.setProperty("/delay", iOriginalBusyDelay);
			// 	}
			// );
			// this.byId("smartTableDetail").attachBeforeRebindTable(this.onBeforeRebindTable, this);
		},
		getTable: function() {
			var oTable = this.getView().byId("smartTableDetail");
			return oTable.getTable();
		},
		_onObjectMatched: function(oEvent) {
			var ZzinvoiceNumberID = oEvent.getParameter("arguments").ZzinvoiceNumber,
				ZzfiletypeId = oEvent.getParameter("arguments").Zzfiletype,
				ZzseqnrId = oEvent.getParameter("arguments").Zzseqnr;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("InvHeaderSet", {
					ZzinvoiceNumber: ZzinvoiceNumberID,
					Zzfiletype: ZzfiletypeId,
					Zzseqnr: ZzseqnrId
				});

				this._bindTable("/" + sObjectPath + "/InvHeaderToDetail");
			}.bind(this));
		},

		_bindTable: function(sObjectPath) {
			this.sPath = sObjectPath;
			var oDataModel = this.getModel(),
				oViewMod = this.getModel("objectView"),
				oTable = this.getTable();
			oViewMod.setProperty("/busy", false);
			// var that = this;
			var oModelLocal = new sap.ui.model.json.JSONModel();
			oDataModel.read(sObjectPath,

				{

					success: function(data, response) {
						// oModelLocal.setData(data);
						// that.setModel(oModelLocal, "oModelLocal");
						oModelLocal.setData({
							modelData: data.results
						});
						var vTitle = data.results[0].Zzphase + " - " + data.results[0].ZzphaseName + " , " + data.results[0].ZzinvoiceNumber;
						oViewMod.setProperty("/Title", vTitle);
						oTable.setModel(oModelLocal);
						oTable.setSelectionMode("None");
						oTable.bindRows("/modelData");
						oTable.setBusy(false);

					},
					error: function(oError) {

					}

				}
			);
		},
		onExportExcelTrigger: function(evt) {
			var oModel = this.getOwnerComponent().getModel();
			var sUrl = oModel.sServiceUrl + this.sPath + "?$format=xlsx";

			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		onBeforeRebindTable: function(oEvent) {
			// var SegmentKey = this.getView().byId("idIconTabBarNoIcons").getSelectedKey();
			// var mBindingParams = oEvent.getParameter("bindingParams");
			// var aFilter = [];
			var tbPath = this.sObjectPath + "/InvHeaderToDetail";
			var oTable = this.byId("smartTableDetail");
			oTable.getEntitySet();
			oTable.setTableBindingPath(tbPath);
			oTable.rebindTable();

			// aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			// mBindingParams.filters = aFilter;

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("LsmVendor", {}, true);
			}
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							// oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			// var oResourceBundle = this.getResourceBundle(),
			// 	oObject = oView.getBindingContext().getObject(),
			// 	sObjectId = oObject.ZzinvoiceNumberID,
			// 	sObjectName = oObject.ZzfiletypeId;

			// // Everything went fine.
			oViewModel.setProperty("/busy", false);
			// oViewModel.setProperty("/shareSendEmailSubject",
			// oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			// oViewModel.setProperty("/shareSendEmailMessage",
			// oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		}

	});

});