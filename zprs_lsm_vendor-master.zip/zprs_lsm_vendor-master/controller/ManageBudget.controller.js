sap.ui.define([
	"lsmvendor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmvendor/model/formatter"
], function(BaseController, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("lsmvendor.controller.ManageBudget", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf vendor.view.TKRate
		 */
		onInit: function() {
			
			// 	var oViewModel = new JSONModel({
			// 	worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
			// 	saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
			// 	shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
			// 	shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
			// 	shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
			// 	tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
			// 	tableBusyDelay: 0
			// });
			// this.setModel(oViewModel, "worklistView");
			
			var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// this.setModel(VMatterModel, "VMatterModel");
			this.getView().setModel(VMatterModel);
		},
		onBeforeRebindTable: function(oEvent) {
			var SegmentKey = this.getView().byId("idIconTabBarNoIcons").getSelectedKey();
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			mBindingParams.filters = aFilter;

		},
		onselectList: function(oevn) {
			var aFilter = [],
				oTab = this.getTable(),
				cntx = oTab.getBinding("items"),
				SegmentKey = oevn.getParameters().key;
			// 			cntx.aApplicationFilters = null;
			if (SegmentKey === "06") {
				aFilter.push(new sap.ui.model.Filter("ZzpaystatMes", sap.ui.model.FilterOperator.EQ, "01"));
			} else if (SegmentKey === "07") {
				aFilter.push(new sap.ui.model.Filter("ZzpaystatMes", sap.ui.model.FilterOperator.EQ, "02"));
			} else {
				aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			}

			cntx.filter(aFilter, "Application");
		},

		getTable: function() {
			var oTable = this.getView().byId("smartTable");
			return oTable.getTable();
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf vendor.view.TKRate
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf vendor.view.TKRate
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf vendor.view.TKRate
		 */
		//	onExit: function() {
		//
		//	}

	});

});