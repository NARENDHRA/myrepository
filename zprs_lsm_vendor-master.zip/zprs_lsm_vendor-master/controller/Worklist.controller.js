sap.ui.define([
	"lsmvendor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"lsmvendor/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("lsmvendor.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {

			var oViewMod = new sap.ui.model.json.JSONModel({
				MainTable: true,
				ManageBudget: false,
				TKRate: false,
				Accruals: false,
				ExRate: false
			});
			this.setModel(oViewMod, "TabSwitchMod");

			var oButtonMod = new JSONModel({
				MainTabBtn: true,
				ManageBudgetBtn: false,
				commonButtons: false,
				TableVisibleFields: true,
				AccuralButtons: false
			});
			this.setModel(oButtonMod, "oButtonMod");
			var oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			this.getRouter().getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);

			this.sideKey = "";

			// // Make sure, busy indication is showing immediately so there is no
			// // break after the busy indication for loading the view's meta data is
			// // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			// oTable.attachEventOnce("updateFinished", function(){
			// 	// Restore original busy indicator delay for worklist's table
			// 	oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			// });

			var sideNavigation = this.getView().byId('sideNavigation');
			//var expanded = !sideNavigation.getExpanded();
			sideNavigation.setExpanded(false);
			// 	var oView = this.getView();
			// oView.byId("samplePanel").addContent(
			// 	sap.ui.xmlfragment("vendor.fragments.MainTabTable", this));

			// this.getView().byId("smartTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);

			// this.sampleMethod(this.sKey);	

			var oInitialModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VENDOR_LAWFIRMS_SRV/");
			this.setModel(oInitialModel, "oInitialModel");
			var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			this.setModel(VMatterModel, "VMatterModel");
			var LSWModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV/");
			this.setModel(LSWModel, "LSWModel");
			var LUploadModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VENDOR_SRV/");
			this.setModel(LUploadModel, "LUploadModel");
		},
		_onObjectMatched: function(evt) {
			var a = this.sideKey;

			if (a === "TKRate") {

				//this.getView().setModel(this.oDataModel1);
				var MainTable = "MainTable";
				this.setCurrentTab(MainTable);
			}
		},
		handleUploadInvoice: function(oEvent) {

			var osrc = oEvent.getSource(),
				fileName = osrc.getValue(),
				oUploadMod = this.getModel("LUploadModel");

			osrc.setUploadUrl("/sap/opu/odata/SAP/ZPRS_LSW_VENDOR_SRV/UploadInvoiceCollection");
			// Header Token
			var oCustomerHeaderToken = new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: osrc.getModel().getSecurityToken()
			});
			osrc.addHeaderParameter(oCustomerHeaderToken);

		},
		onuploadStart: function(oEvent) {
			var oTab = this.getTable(),
				index = oTab.getSelectedItem(),
				cntx = index.getBindingContext(),
				Vbeln = cntx.getProperty("ZzinvoiceNumber");
			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: Vbeln + oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onuploadProgress: function(oEvent) {
			var osrc = oEvent.getSource();
		},
		uploadComplete: function(oEvent) {
			var atthModel;
			atthModel = this.getView().getModel();
			atthModel.refresh();

		},
		onAccuralsSave: function(){
				var otbl = this.getView().byId("idAccrualsTable"),
				tbl = otbl.getTable(),
				sAccuralObj = [];
				
				$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index),
				sObj = context1.getObject();
				// sAccuralObj.push(sObj);
			var	sAccuralObj1 = {
					ClientId : sObj.ClientId,
InvoiceDate: sObj.InvoiceDate,
InvoiceNumber : sObj.InvoiceNumber,
LawFirmMatterId :sObj. LawFirmMatterId,
LineItemDescription : sObj.LineItemDescription,
LineItemNumber :  sObj.LineItemNumber,
LineItemNumberOfUnits : sObj.LineItemNumberOfUnits,
LineItemTotal : sObj.LineItemTotal,
LineItemUnitCost : sObj.LineItemUnitCost,
MatterName : sObj.MatterName,
TimekeeperId : sObj.TimekeeperId,
TimekeeperName : sObj.TimekeeperName,
TransactionType : sObj.TransactionType
				};
				sAccuralObj.push(sAccuralObj1);
			});

			var oUrlParams = {
					Uname: "Extraj",
					ArecToUser: sAccuralObj
				
			};
				var AccuralModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/",{json:true});

			AccuralModel.create("/UserdataASet", oUrlParams,  {
    success: function(oData, response) {
     var smg = oData.Message;
       
    },
    error: function() {
     
    }
			});
			
		},
		onBudgetSave: function() {
			var otbl = this.getView().byId("idManageBudgetTable"),
				tbl = otbl.getTable();
			var oBukrsArray = [],
				oWerksArray = [],
				oPspidArray = [],
				oVendorArray = [],
				oStatusArray = [],
				oGjahrArray = [],
				oPosidArray = [],
				oHkontArray = [],
				oAmountArray = [],
				oRecordTypeArray = [],
				oCurrencyArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var obj = context1.getObject();
				oBukrsArray.push(obj.Bukrs);
				oWerksArray.push(obj.Werks);
				oPspidArray.push(obj.Pspid);
				oVendorArray.push(obj.Vendor);
				oStatusArray.push(obj.Status);
				oGjahrArray.push(obj.Gjahr);
				oPosidArray.push(obj.Posid);
				oHkontArray.push(obj.Hkont);
				oAmountArray.push(obj.Amount);
				oRecordTypeArray.push(obj.RecordType);
				oCurrencyArray.push(obj.Currency);
			});

			var oUrlParams = {
				Bukrs: oBukrsArray.join("|"),
				Werks: oWerksArray.join("|"),
				Pspid: oPspidArray.join("|"),
				Vendor: oVendorArray.join("|"),
				Status: oStatusArray.join("|"),
				Gjahr: oGjahrArray.join("|"),
				Posid: oPosidArray.join("|"),
				Hkont: oHkontArray.join("|"),
				Amount: oAmountArray.join("|"),
				RecordType: oRecordTypeArray.join("|"),
				Currency: oCurrencyArray.join("|")
			};
		var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// var VMatterModel = this.getModel("VMatterModel");
			VMatterModel.callFunction("/BudgetChange", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
						$.each(tbl.getSelectedIndices(), function(i, o) {

						var ctx = tbl.getContextByIndex(o);
						var isErrorPath = ctx.getPath() + "/Iserror";
						var MessagePath = ctx.getPath() + "/Message";

						var model = ctx.getModel();
						model.setProperty(MessagePath, oData.Message);

						model.setProperty(isErrorPath, oData.IsError);

					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		onBeforeRebindTable: function(oEvent) {
			var SegmentKey = this.getView().byId("idIconTabBarNoIcons").getSelectedKey();
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			mBindingParams.filters = aFilter;

		},
		handleDataReceived: function(oEvent) {
			var oSource = oEvent.getSource(),
				oViewMod = this.getModel("oButtonMod"),
				oTbl = oSource.getTable();
			// rows = oTbl.getBinding().getLength();

			oViewMod.setProperty("/TableVisibleFields", false);
		},

		onselectList: function(oevn) {
			var aFilter = [],
				oTab = this.getTable(),
				cntx = oTab.getBinding("items"),
				SegmentKey = oevn.getParameters().key;
			// 			cntx.aApplicationFilters = null;
			if (SegmentKey === "06") {
				aFilter.push(new sap.ui.model.Filter("ZzpaystatMes", sap.ui.model.FilterOperator.EQ, "01"));
			} else if (SegmentKey === "07") {
				aFilter.push(new sap.ui.model.Filter("ZzpaystatMes", sap.ui.model.FilterOperator.EQ, "02"));
			} else {
				aFilter.push(new sap.ui.model.Filter("ZzinvStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			}

			cntx.filter(aFilter, "Application");
		},

		getTable: function() {
			var oTable = this.getView().byId("smartTable");
			return oTable.getTable();
		},
		onItemPress: function(oEvent) {
			this._showObject(oEvent.getSource());
		},
		_pressNavigationListSelect: function(oItem) {
			var that = this,
				oView = this.getView();
			var itemKey = oItem.getParameter("item").getKey();
			this.sideKey = itemKey;
			this.setCurrentTab(itemKey);

			// switch (itemKey) {
			// 	case "MainTable":
			// 		this.getModel();
			// 		this.MainTabFields();
			// 		break;
			// 	case "ManageBudget":
			// 		that.getView().setModel(VMatterModel);
			// 		// var ManageBudgetTable = this.getView().byId("ManageBudgetTable");
			// 		// ManageBudgetTable.setModel(VMatterModel);
			// 		this.onManageBudget();

			// 		break;
			// 	case "TKRate":
			// 		// this.getView().setModel(VMatterModel);
			// 		// this.TimeKeeperRate();
			// 		that.getRouter().navTo("TKRate", {}, true);

			// 		break;
			// 	case "Accruals":
			// 		that.getView().setModel(VMatterModel);
			// 		this.AccrualsTab();

			// 		break;
			// 	case "ExRate":
			// 		that.getView().setModel(LSWModel);
			// 		// this.ExRateTab();

			// 		break;
			// }
			var oInitialModel = this.getModel("oInitialModel"),
				VMatterModel = this.getModel("VMatterModel"),
				LSWModel = this.getModel("LSWModel");
			if (itemKey === "MainTable") {
				that.getView().setModel(oInitialModel);
				this.MainTabFields();
			}
			if (itemKey === "ManageBudget") {
				
				that.getView().setModel(VMatterModel);
               var a =  that.getView().byId("idManageBudgetTable");
               a.setHeight("440px");
				this.onManageBudget();
			}
			if (itemKey === "TKRate") {
				// 	var opage = this.getView().byId("VendorPageId");
				// 	opage.removeAllContent();
				// 	opage.addContent(
				// sap.ui.xmlfragment("vendor.fragments.TimeKeeper_Rate", this));
				this.getRouter().navTo("TKRate", true);
			}
			if (itemKey === "Accruals") {
				that.getView().setModel(VMatterModel);
				this.AccrualsTab();
			}
			if (itemKey === "ExRate") {
				that.getView().setModel(LSWModel);
				this.ExRateTab();
			}
			// this.sampleMethod(sKey);

		},
		setCurrentTab: function(SelKey) {
			var jkey = this.getModel("TabSwitchMod");
			$.each(jkey.getData(), function(pn, v) {
				if (pn === SelKey) {
					jkey.setProperty("/" + pn, true);
				} else {
					jkey.setProperty("/" + pn, false);
				}

			});
		},
		MainTabFields: function() {
			var IconTab = this.getModel("oButtonMod");
			IconTab.setProperty("/MainTabBtn", true);
			IconTab.setProperty("/ManageBudgetBtn", false);
			IconTab.setProperty("/commonButtons", false);
			IconTab.setProperty("/AccuralButtons", false);
		},
		onManageBudget: function() {
			var IconTab = this.getModel("oButtonMod");
			IconTab.setProperty("/MainTabBtn", false);
			IconTab.setProperty("/ManageBudgetBtn", true);
			IconTab.setProperty("/commonButtons", true);
			IconTab.setProperty("/AccuralButtons", false);

		},
		TimeKeeperRate: function() {
			// var IconTab = this.getModel("oButtonMod");
			// IconTab.setProperty("/MainTabBtn", false);
			// IconTab.setProperty("/ManageBudgetBtn", false);
			// IconTab.setProperty("/commonButtons", true);
			this.getRouter().navTo("TKRate");
		},
		AccrualsTab: function() {
			var IconTab = this.getModel("oButtonMod");
			IconTab.setProperty("/MainTabBtn", false);
			IconTab.setProperty("/ManageBudgetBtn", false);
			IconTab.setProperty("/commonButtons", false);
			IconTab.setProperty("/AccuralButtons", true);
		},
		ExRateTab: function() {
			var IconTab = this.getModel("oButtonMod");
			IconTab.setProperty("/MainTabBtn", false);
			IconTab.setProperty("/ManageBudgetBtn", false);
			IconTab.setProperty("/commonButtons", false);
			IconTab.setProperty("/AccuralButtons", false);
			
		},
		onPrintPress: function(oEvent) {
			var LSWModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_SRV/"),
				oTab = this.getTable(),
				index = oTab.getSelectedItem(),
				cntx = index.getBindingContext(),
				Vbeln = cntx.getProperty("ZzinvoiceNumber");

			var servUri = LSWModel.sServiceUrl;
			var sRead = "/PrintInvoiceCollection(Vbeln='" + Vbeln + "')" + "/$value";

			var mainUri = servUri + sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");

		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Ernam", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				ZzinvoiceNumber: oItem.getBindingContext().getProperty("ZzinvoiceNumber"),
				Zzfiletype: oItem.getBindingContext().getProperty("Zzfiletype"),
				Zzseqnr: oItem.getBindingContext().getProperty("Zzseqnr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});