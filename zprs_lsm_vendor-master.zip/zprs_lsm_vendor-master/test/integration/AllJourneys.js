jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"vendor/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"vendor/test/integration/pages/Worklist",
		"vendor/test/integration/pages/Object",
		"vendor/test/integration/pages/NotFound",
		"vendor/test/integration/pages/Browser",
		"vendor/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "vendor.view."
	});

	sap.ui.require([
		"vendor/test/integration/WorklistJourney",
		"vendor/test/integration/ObjectJourney",
		"vendor/test/integration/NavigationJourney",
		"vendor/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});