jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	"sap/ui/core/format/NumberFormat",
	"sap/ui/unified/Currency"
], function(NumberFormat,Currency) {
	"use strict";
	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(val, cur) {
				var sVal = "";
				if(val === undefined){
					val = "";
				}
				if (val !== "") {
					val = parseFloat(parseFloat(val).toFixed(2));
					sVal = val;
					if (val && cur) {
						var oCurr = new sap.ui.unified.Currency({
							value: val,
							currency: cur
						});
						sVal = oCurr.getFormattedValue();
					}
				}
				return sVal;
			
	/*		if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);*/
		},
		validate: function(value) {
			if (value) {
				return value;
			} else {
				return "";
			}
		},
		formatDate: function(iValue) {
			var value1;
			if (!iValue) {
				return null;
			} else {
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
					pattern: "YYYY-MM-dd"
				});
				value1 = oDateFormat.format(iValue);
				var dateVal = value1 + "T00:00:00";
				return dateVal;
			}
		},

		concateValue: function(val1, val2) {
			if (val1 && val2) {
				var val = val1 + val2;
				return val.toString();
			}
		},

		currencyFormatter: function(val, cur) {
			//var oNumberFormat = NumberFormat.getCurrencyInstance();
			//debugger
			var sVal = "";
			if (val !== "") {
				val = parseFloat(val);
				sVal = val;
				if (val && cur) {
					var oCurr = new Currency({
						value: val,
						currency: cur
					});
					sVal = oCurr.getFormattedValue();
				}
			}

			return sVal;
		}

	};

});