sap.ui.define([
	"trusttmm/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trusttmm/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict"; 

	return BaseController.extend("trusttmm.controller.PaymentMultMatter", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			//	window.that= this;
			this._formFragments = {};
			var that = this;
			that.office = this.getView().byId("idOffice");

			var oViewModel = new JSONModel({
				PayerName: true,
				Vender: false,
				BankCode: true,
				ReferenceNumber: true,
				BankCodeReq: false,
				ReferenceNumberReq: false,
				PayerNameReq: false,
				venderReq: false,
				AddressForm: false,
				bankAccNum: [],
				bAccNum: "",
				totalAmount: "",
				currency: "",
				bankDescription: "",
				bankAccNo: false,
				addBtn: false,
				MatterTbl: false,
				AmtTbl: false

			});
			this.setModel(oViewModel, "jsonViewMod");

			if (!this.oOutputComp) {
				this.oOutputComp = sap.ui.getCore().createComponent({
					name: "fgt.trustdispdoc.control.comp.outputitems"
				});
			}
			this._showFormFragment("TrustPaymentMultipleMatter");
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/Trustpayments", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/Office", "");
				c.setProperty(oContextClients.getPath() + "/OfficeT", "");
				c.setProperty(oContextClients.getPath() + "/Matter", "");
				c.setProperty(oContextClients.getPath() + "/PostDate", null);
				c.setProperty(oContextClients.getPath() + "/TBankAccNo", "");
				c.setProperty(oContextClients.getPath() + "/PayType", "");
				c.setProperty(oContextClients.getPath() + "/PayMethod", "");
				c.setProperty(oContextClients.getPath() + "/PayerName", "");
				c.setProperty(oContextClients.getPath() + "/Vender", "");
				c.setProperty(oContextClients.getPath() + "/Amount", "");
				c.setProperty(oContextClients.getPath() + "/Currency", "");
				c.setProperty(oContextClients.getPath() + "/AuthorisedBy", "");
				c.setProperty(oContextClients.getPath() + "/AuthorisedByT", "");
				c.setProperty(oContextClients.getPath() + "/BranchCode", "");
				c.setProperty(oContextClients.getPath() + "/RefDocNo", "");

				c.setProperty(oContextClients.getPath() + "/Street", "");
				c.setProperty(oContextClients.getPath() + "/PoBox", "");
				c.setProperty(oContextClients.getPath() + "/City", "");
				c.setProperty(oContextClients.getPath() + "/Country", "");
				c.setProperty(oContextClients.getPath() + "/PoBoxCode", "");
				c.setProperty(oContextClients.getPath() + "/PostalCode", "");

				//	c.setProperty(oContextClients.getPath() + "/Matter", "");
				that.getView().setBindingContext(oContextClients);
			});
			//	this.handleBackAccNo();
		},

		handleChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),

				sPath = this.getView().getBindingContext().sPath;
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			this.handleonValueInput(evt);
		},

		handleDate: function(evt) {

			var source = evt.getSource();
			var path = source.getBindingPath("dateValue"),
				value = source.getDateValue(),
				sPath = this.getView().getBindingContext().sPath;
			if (!evt.getParameter("valid")) {
				source.setDateValue();
				this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, null);
				this.handleonValueInput(evt);
				return;
			}
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			this.handleonValueInput(evt);
		},

		onChangePayType: function(oEvent) {
			var source = oEvent.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				model = this.getView().getBindingContext().getModel(),
				sPath = this.getView().getBindingContext().sPath;
			model.setProperty(sPath + "/" + path, value);
			this.handleonValueInput(oEvent);
			//	var vPayType = oEvent.getSource().getValue();
			var viewModel = this.getModel("jsonViewMod");
			if (value === "C") {
				viewModel.setProperty("/PayerName", false);
				viewModel.setProperty("/venderReq", false);
				model.setProperty(sPath + "/Vender", "");
				model.setProperty(sPath + "/PayerName", "");
				viewModel.setProperty("/AddressForm", false);
				viewModel.setProperty("/PayerNameReq", false);
				this.clearPayerNameField();
				viewModel.setProperty("/Vender", false);
			}
			if (value === "M") {
				if (this.getView().getBindingContext().getObject().PayMethod === "1" || this.getView().getBindingContext().getObject().PayMethod ===
					"2") {
					viewModel.setProperty("/AddressForm", true);
				}
				viewModel.setProperty("/PayerName", true);
				viewModel.setProperty("/PayerNameReq", true);
				viewModel.setProperty("/venderReq", true);
				viewModel.setProperty("/Vender", true);
				//	model.setProperty(sPath + "/Vender", "8000000000");

			}
		},

		clearPayerNameField: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				//jsonModel = this.getView().getModel("jsonViewMod"),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/Street", "");
			oModel.setProperty(sPath + "/PoBox", "");
			oModel.setProperty(sPath + "/City", "");
			oModel.setProperty(sPath + "/Country", "");
			oModel.setProperty(sPath + "/PoBoxCode", "");
			oModel.setProperty(sPath + "/PostalCode", "");
		},

		onPayMethod: function(oEvent) {
			var source = oEvent.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = this.getView().getBindingContext().sPath;
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var oModel = this.getView().getBindingContext().getModel();
			this.handleonValueInput(oEvent);
			var viewModel = this.getModel("jsonViewMod");
			if (value === "1") {
				if (viewModel.getProperty("/PayerName") === true) {
					//	viewModel.setProperty("/PayerNameReq", true);
					viewModel.setProperty("/AddressForm", true);
				}
				viewModel.setProperty("/BankCode", false);
				viewModel.setProperty("/ReferenceNumber", false);
				oModel.setProperty(sPath + "/" + "BranchCode", "");
				oModel.setProperty(sPath + "/" + "RefDocNo", "");
				viewModel.setProperty("/BankCodeReq", false);
				viewModel.setProperty("/ReferenceNumberReq", false);
				this.handledNoneError1();
			}
			if (value === "2") {
				if (viewModel.getProperty("/PayerName") === true) {
					//	viewModel.setProperty("/PayerNameReq", true);
					viewModel.setProperty("/AddressForm", true);
				}
				viewModel.setProperty("/BankCode", false);
				viewModel.setProperty("/ReferenceNumber", false);
				oModel.setProperty(sPath + "/" + "BranchCode", "");
				oModel.setProperty(sPath + "/" + "RefDocNo", "");
				viewModel.setProperty("/BankCodeReq", false);
				viewModel.setProperty("/ReferenceNumberReq", false);
				this.handledNoneError1();
			}
			if (value === "3") {
				oModel.setProperty(sPath + "/" + "BranchCode", "");
				viewModel.setProperty("/BankCode", false);
				viewModel.setProperty("/ReferenceNumber", true);
				//	viewModel.setProperty("/PayerNameReq", false);
				viewModel.setProperty("/BankCodeReq", false);
				viewModel.setProperty("/ReferenceNumberReq", true);
				viewModel.setProperty("/AddressForm", false);
				this.clearPayerNameField();
				this.handledNoneError1();
			}
			if (value === "4") {
				viewModel.setProperty("/BankCode", true);
				viewModel.setProperty("/ReferenceNumber", true);
				//	viewModel.setProperty("/PayerNameReq", false);
				viewModel.setProperty("/BankCodeReq", true);
				viewModel.setProperty("/ReferenceNumberReq", true);
				viewModel.setProperty("/AddressForm", false);
				this.clearPayerNameField();
				this.handledNoneError1();
			}
		},

		onUpdateOfficeValue: function(evt) {
			var oChangeValues = evt.getParameter("changes");
			var sPath = this.getView().getBindingContext().sPath;
			var oTable = this.getView().byId("tblPaymentMM"),

				aItems = oTable.getItems();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/Office", oChangeValues.Office);
			if (oChangeValues.hasOwnProperty("Office")) {
				oTable.getBindingContext().getModel().setProperty(sPath + "/Office", oChangeValues.Office);
				if (oChangeValues.Office.length > 0 && aItems.length === 0) {
					this.onAddRowItemMatter();
				}
			}
			//  return Office;
		},
		onChangeOffice: function(evt) {
			var oTable = this.getView().byId("tblPaymentMM"),
				viewModel = this.getView().getModel("jsonViewMod");
			this.handleonValueInput(evt);
			oTable.removeAllItems();
			this.clearValue();
			var source = evt.getSource(),
				sPath = this.getView().getBindingContext().sPath,
				path = source.getBindingPath("value"),
				value = source.getValue();

			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);

			var oMatter = oTable.getBindingContext().getModel(),
				sMPath = oTable.getBindingContext().sPath;

			oMatter.setProperty(sMPath + "/" + path, value);
			if (value) {
				source.setValueState("None");
				viewModel.setProperty("/MatterTbl", true);
				viewModel.setProperty("/addBtn", true);
				//	this.onAddRowItemMatter();
			} else {
				viewModel.setProperty("/addBtn", false);
			}

			/*	var tabOffice,	that = this;
				var aItems = oTable.getItems();
				if (aItems.length > 0) {
					aItems.forEach(function(item) {
						tabOffice = item.getBindingContext().getObject().Matter;
					});
				}
				if (tabOffice !== "" && tabOffice !== undefined) {
					sap.m.MessageBox.show("All data will be clear", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "WARNING",
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CLOSE],
						onClose: function(oAction) {
							if (oAction === "OK") {
								oTable.removeAllItems();
								that.onAddRowItemMatter();
								that.clearValue();
							}
						}
					});

				} else {
					oTable.removeAllItems();
					this.onAddRowItemMatter();
					this.clearValue();
				}*/

		},

		onClearAvailableBal: function() {
			var s = this.getView().byId("tblPaymentMM");
			var aPath = s.getBindingContext().getPath();
			var Model = s.getBindingContext().getModel();
			var items = s.getItems();
			for (var i = 0; i < items.length; i++) {

				//var tbl = this.getView().byId("tblPaymentMM"),
				//	m = this.getView().byId("tblPaymentMM").getBindingContext().getModel();

				Model.setProperty(items[i].getBindingContext().getPath() + "/AvilMattBal", "");
				Model.setProperty(items[i].getBindingContext().getPath() + "/TotMattBal", "");
			}
			//	Model.setProperty(aPath + "/AvilMattBal", "");
			//	Model.setProperty(aPath + "/TotMattBal", "");
		},

		onChangeMatterTblRow: function(evt) {
			var that = this;
			var sPath1, oModel1, bDuplicateVal = false;
			var jsonModel = that.getView().getModel("jsonViewMod");
			jsonModel.setProperty("/bankAccNo", true);
			var oTable = this.getView().byId("tblPaymentMM"),
				items = oTable.getItems();

			//	var a=evt.getParameter()
			if (evt) {
				var s = evt.getSource();
				var aPath = s.getBindingContext().getPath();
				var Model = s.getBindingContext().getModel();

				if (s.getValue().length > 0) {
					s.setValueState("None");
				} else {
					s.setValueState("Error");
				}
				if (items.length > 1) {
					jQuery.each(items, function(i, oItem) {
						if (oItem.getBindingContext().getObject().Matter === evt.getParameter("value")) {
							bDuplicateVal = true;
						}
					});
				}

				if (bDuplicateVal) {
					//oSource.getAggregation("_content").setSelectionItem();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.warning(
						"The selected Matter already exist in the list", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					var oContext = this._createTableItemContext();
					s.getParent().setBindingContext(oContext);
					return;
				}
				Model.setProperty(aPath + "/Matter", evt.getParameter("value"));

			}
			oModel1 = this.getView().getBindingContext().getModel();
			sPath1 = this.getView().getBindingContext().sPath;
			var office = oModel1.getProperty(sPath1 + "/Office");
			var BankArr = [];
			jsonModel.setProperty("/bankAccNum", []);

			if (items.length === 0) {
				jsonModel.setProperty("/bankAccNum", []);
				jsonModel.setProperty("/currency", "");
				jsonModel.setProperty("/bankDescription", "");

				jsonModel.setProperty("/bankAccNo", false);
				jsonModel.setProperty("/totalAmount", "");
				//jsonModel.setProperty("/bAccNum", "");
				return;
			}
			var arrayMatter = "";
			var filters = new Array();
			var ctx;
			for (var i = 0; i < items.length; i++) {

				if (!ctx) {
					ctx = items[i].getBindingContext().getObject().Matter;
				} else {
					ctx += "," + items[i].getBindingContext().getObject().Matter;
				}

			}

			var filterByName = new sap.ui.model.Filter("MatterStr", sap.ui.model.FilterOperator.EQ, ctx);
			var filterOffice = new sap.ui.model.Filter("Office", sap.ui.model.FilterOperator.EQ, office);
			filters.push(filterOffice);
			filters.push(filterByName);
			var oModel = this.getOwnerComponent().getModel();
			sap.ui.core.BusyIndicator.show();
			//	var BankArr = [];
			oModel.read("/MatterAccNumS", {
				filters: filters,
				success: function(oData, oResp) {
					sap.ui.core.BusyIndicator.hide();

					var aRes = oData.results;
					jsonModel.setProperty("/bankAccNum", oData.results);
					if (aRes.length === 1) {
						jsonModel.setProperty("/currency", oData.results[0].Currency);
						jsonModel.setProperty("/bankDescription", oData.results[0].AccDesc);
						jsonModel.setProperty("/bAccNum", oData.results[0].TBankAccNo);
						that.handleChangeAccNO(oData.results[0].TBankAccNo);
					} else {
						jsonModel.setProperty("/bAccNum", "");
						jsonModel.setProperty("/currency", "");
						jsonModel.setProperty("/bankDescription", "");

						that.onClearAvailableBal();

					}

				}

			});

		},

		onChangeAccNo: function(evt) {

			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var SorcAccNum = this.getView().getBindingContext().getModel().getProperty(sPath + "/" + path, value);
			this.handleChangeAccNO(SorcAccNum);
			this.handleBackAccNo();

		},
		handleChangeAccNO: function(bankAccNo) {
			sap.ui.core.BusyIndicator.show();
			//var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			//var path = source.getBindingPath("value");
			//var value = source.getValue();
			//this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			//var SorcAccNum = this.getView().getBindingContext().getModel().getProperty(sPath + "/" + path, value);
			var SorcAccNum = bankAccNo;
			//this.getView().byId("cmbBankAcc").getModel("bankAccJsonModel");
			var oModel = this.getOwnerComponent().getModel(),
				oView = this.getView().byId("tblPaymentMM"),
				ctx = oView.getBindingContext(),
				matter,
				that = this,
				data = ctx.getObject();
			var oModel1 = this.getView().getBindingContext().getModel();
			var sPath1 = this.getView().getBindingContext().sPath;
			var Office = oModel1.getProperty(sPath1 + "/Office");
			var items = oView.getItems(),
				callBacks = [],
				entityType, readPath, batchrequest = [],
				rModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_TRUST_PAYMENTS_SRV/");
			rModel.setUseBatch(true);

			for (var i = 0; i < items.length; i++) {
				matter = items[i].getBindingContext().getObject().Matter;
				var sPath1 = "/TrustAccBalanceS(Office='" + Office + "',Matter='" + matter + "',TBankAccNo='" + SorcAccNum +
					"')";

				var tbl = this.getView().byId("tblPaymentMM"),
					m = this.getView().byId("tblPaymentMM").getBindingContext().getModel();
				callBacks["R_" + i] = function(oData, cbIndex) {
					sap.ui.core.BusyIndicator.hide();
					var i1 = tbl.getItems()[cbIndex];
					m.setProperty(i1.getBindingContext().getPath() + "/AvilMattBal", oData.AvlBalnace);
					m.setProperty(i1.getBindingContext().getPath() + "/TotMattBal", oData.TotBalnace);

				};
				var filters = [new sap.ui.model.Filter("Office", sap.ui.model.FilterOperator.EQ, data.Office),
					new sap.ui.model.Filter("Matter", sap.ui.model.FilterOperator.EQ, matter),
					new sap.ui.model.Filter("TBankAccNo", sap.ui.model.FilterOperator.EQ, SorcAccNum)
				];
				entityType = oModel.oMetadata._getEntityTypeByPath("/TrustAccBalanceS");
				//	readPath = "/TrustAccBalanceS?" + sap.ui.model.odata.ODataUtils.createFilterParams(filters, oModel.oMetadata, entityType);
				batchrequest.push(rModel.createBatchOperation(sPath1, "GET"));
			}

			// make a batch call
			rModel.addBatchReadOperations(batchrequest);
			rModel.submitBatch(
				function(r) {
					//var callEntity;
					$.each(r.__batchResponses, function(respi, br) {
						if (br && br.data) {
							//callEntity = br.data.__metadata.title;
							callBacks["R_" + respi](br.data, respi);
						}
					});
				},
				function(e) {

				},
				true);

		},
		count: function(s1, letter) {
			return (s1.match(RegExp(letter, 'g')) || []).length;
		},

		findAndReplace: function(string, target, replacement) {
			var i = 0,
				length = string.length;
			for (i; i < length; i++) {
				var count1 = this.count(string, '\\.');
				if (count1 > 1) {
					string = string.replace(target, replacement);
				}
			}
			return string;
		},
		handleTotalAmount: function(evt) {
			var that = this,
				oTable = this.getView().byId("tblPaymentMM");
			var s = evt.getSource();
			if (s.getValue().length > 0) {
				s.setValueState("None");
			} else {
				s.setValueState("Error");
			}
			var aPath = s.getBindingContext().getPath();
			var Model = s.getBindingContext().getModel();
			Model.setProperty(aPath + "/Amt", evt.getParameter("value"));
			var tot = 0,
				vAmount = evt.getParameter("value");
			var validAmount = /^[1-9][0-9,]*\.?[0-9,]{0,2}$/;
			if (vAmount) {
				if (vAmount.startsWith("-")) {
					evt.getSource().setValue("");
					evt.getSource().setValueState("Error");
					return;
				}
				if (vAmount.match(validAmount)) {
					evt.getSource().setValueState("None");
				} else {
					//vAmount = findAndReplace(vAmount, ".", "");
					vAmount = vAmount.substring(0, vAmount.length - 1);
					evt.getSource().setValue(vAmount);
					//oEvent.getSource().setValueState("Error");
				}
			} else {
				evt.getSource().setValueState("Error");
			}
			for (var i = 0; i < oTable.getItems().length; i++) {
				var am = oTable.getItems()[i].getBindingContext().getObject().AvilMattBal;
				var Amt = oTable.getItems()[i].getBindingContext().getObject().Amt;
				if (!Amt) {
					Amt = 0;
					return;
				}
				if (am !== "") {
					if (Amt <= parseInt(am)) {} else {

						sap.m.MessageBox.show("Amount should be less than Available Amount", {
							icon: sap.m.MessageBox.Icon.WARNING,
							title: "WARNING",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {
								//	that.getView().getModel("jsonViewMod").setProperty("/totalAmount", "");
								Model.setProperty(aPath + "/Amt", "");
							}
						});
					}
				}

				tot = parseFloat(tot) + parseFloat(Amt);
				tot = parseFloat(tot);

			}
			tot = tot.toFixed(2);
			this.getView().getModel("jsonViewMod").setProperty("/totalAmount", tot);
		},

		handleChangeTbl: function(evt) {

			var s = evt.getSource();
			var aPath = s.getBindingContext().getPath();
			var Model = s.getBindingContext().getModel();
			Model.setProperty(aPath + "/ResonPay", evt.getParameter("value"));
			this.handleonValueInput(evt);
		},

		_createTableItemContext: function() {
			var oModel = this.getOwnerComponent().getModel();
			var viewContext = this.getView().getBindingContext().getObject();
			var oContext = oModel.createEntry("/Trustpaymatters", {
				properties: {
					"Office": viewContext.Office,
					"OfficeT": viewContext.OfficeT,
					"Matter": "",
					"MatterTxt": "",
					"Amt": "",
					"ResonPay": "",
					"AvilMattBal": "",
					"TotMattBal": "",
					"Client": "",
					"ClientT": ""
				}
			});

			return oContext;
		},
		onAddRowItemMatter: function() {
			var that = this,
				oContext = this._createTableItemContext();

			var oTable = this.getView().byId("tblPaymentMM");
			var items = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Matter}",
						change: that.onChangeMatterTblRow.bind(that),
						enabled: "{jsonViewMod>/MatterTbl}"
					}),
					new sap.m.Text({
						text: "{MatterTxt}"
					}),
					new sap.m.Input({
						value: "{Amt}",
						type: "Number",
						textAlign: "Right",
						liveChange: that.handleTotalAmount.bind(that)
					}),

					new sap.ui.comp.smartfield.SmartField({
						maxLength: 50,
						width: "100%",
						rows: 1,
						value: "{ResonPay}",
						change: that.handleChangeTbl.bind(that)
					}),
					new sap.m.Text({
						text: {
							parts: [{
								path: 'AvilMattBal'
							}, {
								path: 'jsonViewMod>/currency'
							}],
							formatter: formatter.numberUnit
						}

					}),
					new sap.m.Text({
						text: {
							parts: [{
								path: 'TotMattBal'
							}, {
								path: 'jsonViewMod>/currency'
							}],
							formatter: formatter.numberUnit
						}

					}),
					new sap.m.Text({
						text: "{jsonViewMod>/currency}"
					}),

					new sap.m.Text({
						text: "{Client}"
					}),
					new sap.m.Text({
						text: "{ClientT}"
					})

				]
			});
			items.setBindingContext(oContext);
			oTable.addItem(items);
			// }
		},

		onPressSave: function() {
			var bVal = this._handleValidation();
			var bVal1 = this.handleAmountValid();
			if (!bVal) {
				return;
			}
			//sap.ui.core.BusyIndicator.show();
			var oView = this.getView(),
				createpayload,
				ctx = oView.getBindingContext(),
				that = this,
				data = ctx.getObject();
			var oModel = this.getOwnerComponent().getModel();
			var sPath = oView.getBindingContext().sPath;
			var oTable = this.getView().byId("tblPaymentMM");
			var TrustpaymatterSet = [];
			var aItems = oTable.getItems();
			var pFlag = true;
			if (aItems.length > 0) {
				aItems.forEach(function(item) {
					var tabOffice = item.getBindingContext().getObject().Office;
					TrustpaymatterSet.push({
						"Office": item.getBindingContext().getObject().Office,
						"Matter": item.getBindingContext().getObject().Matter,
						//	"MatterTxt": item.getBindingContext().getObject().MatterTxt,
						"Amt": item.getBindingContext().getObject().Amt,
						"ResonPay": item.getBindingContext().getObject().ResonPay,
						"TotMattBal": item.getBindingContext().getObject().TotMattBal,
						"AvilMattBal": item.getBindingContext().getObject().AvilMattBal,
						"Client": item.getBindingContext().getObject().Client
							//	"ClientT": item.getBindingContext().getObject().ClientT
					});
					if (item.getBindingContext().getObject().TotMattBal !== "") {
						if (item.getBindingContext().getObject().TotMattBal <= 0) {
							pFlag = false;
							sap.m.MessageBox.show("Available Amount is less than zero, cannot save record", {
								icon: sap.m.MessageBox.Icon.WARNING,
								title: "WARNING",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									return;
								}
							});
						}
					}
				});
			}

			var viewModel = this.getModel("jsonViewMod");
			var Office = formatter.validate(data.Office);
			var OfficeT = formatter.validate(data.OfficeT);
			var PostDate = formatter.formatDate(data.PostDate);
			//	var TBankAccNo = formatter.validate(data.TBankAccNo);
			//	var TBankAccNo = this.getView().byId("cmbBankAcc").getSelectedKey();
			var TBankAccNo = viewModel.getProperty("/bAccNum");
			var PayType = formatter.validate(data.PayType);
			var PayMethod = formatter.validate(data.PayMethod);

			var PayerName = formatter.validate(data.PayerName);
			var Vender = formatter.validate(data.Vender);
			var Amount = viewModel.getProperty("/totalAmount");
			Amount = Amount.toString();
			var Currency = viewModel.getProperty("/currency");
			var CurrencyT = formatter.validate(data.CurrencyT);
			var AuthorisedBy = formatter.validate(data.AuthorisedBy);
			var AuthorisedByT = formatter.validate(data.AuthorisedByT);
			var RefDocNo = formatter.validate(data.RefDocNo);
			var BranchCode = formatter.validate(data.BranchCode);

			var Street = formatter.validate(data.Street);
			var PoBox = formatter.validate(data.PoBox);
			var City = formatter.validate(data.City);
			var Country = formatter.validate(data.Country);
			var PoBoxCode = formatter.validate(data.PoBoxCode);
			var PostalCode = formatter.validate(data.PostalCode);

			createpayload = {
				"Office": Office,
				"OfficeT": OfficeT,
				"PostDate": PostDate,
				"TBankAccNo": TBankAccNo,
				"PayType": PayType,
				"PayMethod": PayMethod,
				"PayerName": PayerName,
				"Vender": Vender,
				"Amount": Amount,
				"Currency": Currency,
				"CurrencyT": CurrencyT,
				"AuthorisedBy": AuthorisedBy,
				"AuthorisedByT": AuthorisedByT,
				"RefDocNo": RefDocNo,
				"BranchCode": BranchCode,
				"Street": Street,
				"PoBox": PoBox,
				"City": City,
				"Country": Country,
				"PoBoxCode": PoBoxCode,
				"PostalCode": PostalCode,

				"TrustpaymatterSet": TrustpaymatterSet
			};
			/*	if (data.Office !== "" && PostDate !== "" && data.PayType !== "" && TBankAccNo !== "" && data.PayMethod !== "" && Amount !== "" &&
					Currency !==
					"" && AuthorisedBy !== "") {*/
			if (pFlag && aItems.length) {
				//	that.saveRecord();

				oModel.create("/Trustpayments", createpayload, {
					success: function(oData, oResp) {
						//sap.ui.core.BusyIndicator.hide();
						//	sap.ui.core.BusyIndicator.hide();
						var sflag = oData.ReturnTyp;
						var msg = oData.ReturnMsg;
						if (sflag === "S") {
							that.onMessageSuccessDialog(oData);
							//	sap.m.MessageToast.show(msg);
							/*	sap.m.MessageBox.show(msg, {
									icon: sap.m.MessageBox.Icon.SUCCESS,
									title: "Success",
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										oModel.setProperty(sPath + "/" + "Office", "");
										oModel.setProperty(sPath + "/" + "OfficeT", "");

										viewModel.setProperty("/addBtn", false);
										that.clearValue();
										oTable.removeAllItems();
									}
								});*/
						} else {
							//sap.m.MessageToast.show(msg);

							sap.m.MessageBox.show(msg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									//	oModel.setProperty(sPath + "/" + "Office", "");
									//	that.clearValue();
								}
							});

						}
					},
					error: function(oErr) {
						sap.ui.core.BusyIndicator.hide();
						//	sap.ui.core.BusyIndicator.hide();
						var oResp = JSON.parse(oErr.responseText);
						if (oResp.error.innererror.errordetails.length > 0) {
							this.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
						}
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							//var respError = that.converttoJson(result);
							//stop showing standar popup
							this.applyResp(jQuery.parseJSON(result));
						}
					}.bind(this)

				});
			}
			/*	} else {
					//sap.m.MessageToast.show("Please fill all required fields");
					sap.m.MessageBox.show("Please fill all required fields", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "WARNING",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {

						}
					});
				}*/
		},

		onMessageSuccessDialog: function(oResp) {
			var that = this;

			var oTable = this.getView().byId("tblPaymentMM");
			var dialog = new sap.m.Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: oResp.ReturnMsg
				}),
				buttons: [
					new sap.m.Button({
						text: "Display Document",
						press: function() {
							dialog.close();
							that._displayForm("display", oResp);
						}
					}),
					new sap.m.Button({
						text: "OK",
						press: function() {
							that.ClearOffice();
							that.clearValue();
							oTable.removeAllItems();
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		_displayForm: function(sKey, oResp) {
			var oModel = this.getOwnerComponent().getModel(),
				oViewModel = this.getModel("jsonViewMod");

			if (oResp) {
				oViewModel.setProperty("/display", oResp);
			}

			var oContent = oViewModel.getProperty("/display");
			if (sKey === "display") {
				this._showFormFragment("TrustPaymentDisplay");
				//oViewModel.setProperty("/documentTitle","Document " + oContent.Belnr);
				this.oOutputComp.invokeDocDisp(oContent.Gjahr, oContent.Belnr, oContent.Bukrs);
				this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
			}
		},
		ClearOffice: function() {
			var oView = this.getView(),
				viewModel = this.getModel("jsonViewMod"),
				oModel = this.getOwnerComponent().getModel(),
				sPath = oView.getBindingContext().sPath;

			oModel.setProperty(sPath + "/" + "Office", "");
			oModel.setProperty(sPath + "/" + "OfficeT", "");

			viewModel.setProperty("/addBtn", false);
		},
		clearValue: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				jsonModel = this.getView().getModel("jsonViewMod"),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/" + "Matter", "");
			oModel.setProperty(sPath + "/" + "PostDate", null);
			oModel.setProperty(sPath + "/" + "PayType", "");
			oModel.setProperty(sPath + "/" + "PayMethod", "");
			oModel.setProperty(sPath + "/" + "PayerName", "");
			oModel.setProperty(sPath + "/" + "Vender", "");
			oModel.setProperty(sPath + "/" + "Amount", "");
			//	oModel.setProperty(sPath + "/" + "Currency", "");
			jsonModel.setProperty("/currency", "");
			jsonModel.setProperty("/bankDescription", "");
			jsonModel.setProperty("/totalAmount", "");
			jsonModel.setProperty("/bAccNum", "");
			jsonModel.setProperty("/bankAccNum", []);
			oModel.setProperty(sPath + "/" + "AuthorisedBy", "");
			oModel.setProperty(sPath + "/" + "AuthorisedByT", "");
			oModel.setProperty(sPath + "/" + "BranchCode", "");
			oModel.setProperty(sPath + "/" + "RefDocNo", "");
			oModel.setProperty(sPath + "/Street", "");
			oModel.setProperty(sPath + "/PoBox", "");
			oModel.setProperty(sPath + "/City", "");
			oModel.setProperty(sPath + "/Country", "");
			oModel.setProperty(sPath + "/PoBoxCode", "");
			oModel.setProperty(sPath + "/PostalCode", "");
			jsonModel.setProperty("/MatterTbl", true);
			//jsonModel.setProperty("/addBtn", true);
			/*var BankArr = [];
			var bankAccJsonModel = new JSONModel(BankArr);
			this.getView().byId("cmbBankAcc").setModel(bankAccJsonModel, "bankAccJsonModel");*/
		},
		handleDeleteMatter: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem");
			oTable.removeItem(oItmSel);
			this.onChangeMatterTblRow();
			this.onClearAvailableBal();

			var totAmt = this.getView().getModel("jsonViewMod").getProperty("/totalAmount"),
				sAmt;
			if (totAmt !== "" && sAmt === undefined) {
				sAmt = parseInt(oItmSel.getBindingContext().getObject().Amt, 10);
				if (isNaN(sAmt)) {
					sAmt = 0;
				}
				totAmt = parseFloat(totAmt - sAmt);
				totAmt = parseFloat(totAmt).toFixed(2);
			}
			this.getView().getModel("jsonViewMod").setProperty("/totalAmount", totAmt);
		},

		_handleValidation: function() {

			var oView = this.getView();
			var oViewModel = this.getView().getModel("jsonViewMod");
			var aInputs = [
				oView.byId("idOffice"),
				oView.byId("idPostDate"),
				oView.byId("idPayType"),
				oView.byId("idPayMethod"),
				oView.byId("idbankAccNumInput"),
				oView.byId("idAuthorisedBy")
				//	oView.byId("idBranchCode"),
				//	oView.byId("idRefDocNo")

			];
			var addresInput = [
				oView.byId("idStreet"),
			//	oView.byId("idPoBox"),
				oView.byId("idCity"),
				oView.byId("idCountry"),
			//	oView.byId("idPoBoxCode"),
				oView.byId("idPostalCode")
			];

			var aInputsEna = [
				oView.byId("idPayerName"),
				oView.byId("idBranchCode"),
				oView.byId("idRefDocNo"),
				oView.byId("idVender")
			];
			var bValidationError = false;

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValue()) {
					oInput.setValueState("None");
					bValidationError = true;
				} else {
					oInput.setValueState("Error");
				}
			});

			jQuery.each(aInputsEna, function(i, oInput) {
				if (oInput.getEnabled() === true) {
					if (oInput.getValue()) {
						oInput.setValueState("None");
						bValidationError = true;
					} else {
						oInput.setValueState("Error");
					}
				} else {
					oInput.setValueState("None");
					bValidationError = true;
				}
			});

			if (oViewModel.getProperty("/AddressForm") === true) {
				jQuery.each(addresInput, function(i, oInput) {
					if (oInput.getValue()) {
						oInput.setValueState("None");
						bValidationError = true;
					} else {
						oInput.setValueState("Error");
					}
				});
			} else {
				jQuery.each(addresInput, function(i, oInput) {
					oInput.setValue(null);
					oInput.setValueState("None");
				});
			}

			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			jQuery.each(aInputsEna, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			jQuery.each(addresInput, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			if (bValidationError === true) {
				bValidationError = this.handleAmountValid();
			}
			if (bValidationError === true) {
				bValidationError = this.handledNoneError();
			}
			if (!bValidationError) {
				sap.m.MessageBox.alert("Please fill all required fields");
			}
			return bValidationError;
		},

		handleAmountValid: function() {
			var oTable = this.getView().byId("tblPaymentMM"),
				aItems = oTable.getItems(),
				bValidationError1 = false;

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 0 || index === 3) {
						if (oCell.getValue().length > 0) {
							bValidationError1 = true;
							oCell.setValueState("None");
						} else {
							oCell.setValueState("Error");
						}

					} else if (index === 2) {
						var validAmount = /^[1-9]\d*(\.\d{1,2})?$/,
							sVal = oCell.getValue();
						if (sVal.length > 0 && sVal.match(validAmount)) {
							bValidationError1 = true;
							oCell.setValueState("None");
						} else {
							oCell.setValueState("Error");
						}
					}
				});
			});

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 0 || index === 2 || index === 3) {
						if (oCell.getValueState() === "Error") {
							bValidationError1 = false;
						}
					}
				});
			});

			return bValidationError1;

		},

		handleonValueInput: function(evt) {
			var oSrc = evt.getSource();

			if (oSrc.getValue().length > 0) {
				oSrc.setValueState("None");
			} else {
				oSrc.setValueState("Error");
			}
		},

		/*	handleBackAccNo: function(evt) {
				var oSrc = this.getView().byId("cmbBankAcc");
				var viewModel = this.getModel("jsonViewMod");

				if (oSrc.getSelectedKey().length > 0) {
					oSrc.setValueState("None");
					//viewModel.setProperty("/AmtTbl", true);
				} else {
					oSrc.setValueState("Error");
					//	viewModel.setProperty("/AmtTbl", false);
				}
			},*/
		handledNoneError: function() {
			var oView = this.getView();
			var aInputs = [
				oView.byId("idPayerName"),
				oView.byId("idBranchCode"),
				oView.byId("idRefDocNo")
			];

			var bValidationError = false;
			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getEnabled() === true) {
					if (oInput.getValue()) {
						oInput.setValueState("None");
						bValidationError = true;
					} else {
						oInput.setValueState("Error");
					}
				} else {
					oInput.setValueState("None");
					bValidationError = true;
				}
			});

			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			return bValidationError;
		},
		onAuthorisedByChanged: function(evt) {
			var sOffice = evt.getParameter("changes");
			var oTable = this.getView().byId("tblPaymentMM"),
				viewModel = this.getModel("jsonViewMod"),
				oMatter = oTable.getBindingContext().getModel(),
				sMPath = oTable.getBindingContext().sPath;

			if (sOffice.hasOwnProperty("Office")) {
				if (sOffice.Office.length > 0 && oTable.getItems().length === 0) {
					this.onAddRowItemMatter();
					viewModel.setProperty("/MatterTbl", true);
					viewModel.setProperty("/addBtn", true);
					//oModel.setProperty(sPath + "/Office", );
				}
			}
		},

		// Bank Account Value help Code
		handleValueHelp: function(oEvent) {
			//	var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"trusttmm.fragments.F4BankAccNumber",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			/*this._valueHelpDialog.getBinding("items").filter([new Filter(
				"AccNum",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);*/

			// open value help dialog filtered by the input value
			//	this._valueHelpDialog.open(sInputValue);
			this._valueHelpDialog.open();
		},

		_handleValueHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"TBankAccNo",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts"),
				that = this;
			if (aContexts && aContexts.length) {
				var oInput = this.getView().byId(this.inputId),
					sAccNum = aContexts.map(function(oContext) {
						return oContext.getObject().TBankAccNo;
					}).join(", ");
				oInput.setValue(sAccNum);
				that.handleChangeAccNO(sAccNum);
				oInput.setValueState("None");
				var sCurrency = aContexts.map(function(oContext) {
					return oContext.getObject().Currency;
				}).join(", ");
				this.getView().getModel("jsonViewMod").setProperty("/currency", sCurrency);
				var sBankDesc = aContexts.map(function(oContext) {
					return oContext.getObject().AccDesc;
				}).join(", ");
				this.getView().getModel("jsonViewMod").setProperty("/bankDescription", sBankDesc);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		suggestionItemSelected: function(evt) {

			var oItem = evt.getParameter('selectedItem'),
				src = evt.getSource(),
				sKey = oItem ? oItem.getKey() : '',
				sCurrency = oItem ? oItem.data("currency") : '';

			src.setValue(sKey);
			this.getView().getModel("jsonViewMod").setProperty("/currency", sCurrency);
			src.setValueState("None");
		},

		onChangeAccNumber: function(oEvent) {
			var oSource = oEvent.getSource(),
				sInputValue = oSource.getValue(),
				oViewModel = this.getModel("jsonViewMod"),
				aBankAccNum = oViewModel.getProperty("/bankAccNum");

			function isExist(value) {
				return value.TBankAccNo === sInputValue;
			}

			if (aBankAccNum.length > 0) {
				var aFilterVal = aBankAccNum.filter(isExist);
				if (aFilterVal.length > 0) {
					oViewModel.setProperty("/currency", aFilterVal[0].Currency);
					oSource.setValueState("None");
				} else {
					oViewModel.setProperty("/currency", '');
					oSource.setValueState("Error");
				}
			}
		},

		handledNoneError1: function() {
			var oView = this.getView();
			var aInputs = [
				oView.byId("idPayerName"),
				oView.byId("idBranchCode"),
				oView.byId("idRefDocNo")
			];

			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getEnabled() === true) {
					if (oInput.getValue()) {
						oInput.setValueState("None");
						//bValidationError = true;
					}
				} else {
					oInput.setValueState("None");
					//bValidationError = true;
				}
			});

		},

		handleOnNewDoc: function() {
			var oTable = this.getView().byId("tblPaymentMM");
			this._showFormFragment("TrustPaymentMultipleMatter");
			this.ClearOffice();
			this.clearValue();
			oTable.removeAllItems();
		},

		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "trusttmm.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},

		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});