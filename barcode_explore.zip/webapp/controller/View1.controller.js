sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"app/barcode/libs/html2pdf",
	"app/barcode/libs/html2canvas.min",
	"app/barcode/libs/jspdf.debug"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("app.barcode.controller.View1", {
		onInit: function () {
			var oViewModel = new JSONModel({
				barcount: ""
			});
			this.getView().setModel(oViewModel, "viewModel");
		},

		onBack: function (evt) {
			var app = this.getView().byId("idAppControl");
			app.to(this.getView().byId("first"));
			this.getView().byId("idVBox").removeAllItems();
		},

		onGenerate: function (evt) {
			var count = this.getView().getModel("viewModel").getProperty("/barcount");
			var app = this.getView().byId("idAppControl");
			app.to(this.getView().byId("second"));
			if (count < 4) {
				var nearestNumber = 6;
			} else {
				var nearestNumber = Math.ceil(Number(count) / 3) * 3;
			}

			var vbox = this.getView().byId("idVBox");
			for (var i = 0; i < nearestNumber; i++) {
				if (i >= Number(count)) {
					if (i === 3) {
						vbox.insertItem(hbox, vbox.getItems().length);
						var hbox = new sap.m.HBox().addStyleClass("HBoxClass");
					}
					hbox.insertItem(new sap.m.VBox({
						width: "33.3%"
					}).addStyleClass("VBoxClass"), counter);
					counter++;

					continue;
				}
				if (i === 0 || i % 3 === 0) {
					var counter = 0;
					if (i !== 0)
						vbox.insertItem(hbox, vbox.getItems().length);
					var hbox = new sap.m.HBox().addStyleClass("HBoxClass");
				}

				var box = new sap.m.VBox({
					// class: "VBoxClass",
					width: "33.3%",
					items: [
						new sap.m.Text({
							// class: "barCode",
							text: "*113456789123456*"
						}).addStyleClass("barCode")
					]
				}).addStyleClass("VBoxClass");
				hbox.insertItem(box, counter);
				counter++;
			}
			vbox.insertItem(hbox, vbox.getItems().length);
		},

		generatePDF: function () {
			var element = document.getElementById(this.getView().getId() + '--idVBox');
			var options = {
				margin: 0.2,
				filename: "barcode",
				image: {
					type: 'jpeg',
					quality: 0.98
				},
				html2canvas: {
					scale: 4,
					dpi: 192,
					letterRendering: true,
					logging: true
				},
				jsPDF: {
					unit: 'in',
					format: 'letter',
					// orientation: 'portrait'
					orientation: 'landscape'
				}
			};
			html2pdf(element, options);
		}
	});
});