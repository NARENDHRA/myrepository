// jQuery.sap.includeScript("https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js");
// jQuery.sap.includeScript("https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js");
// jQuery.sap.includeScript("/libs/html2canvas.min.js");
// jQuery.sap.includeScript("app/barcode/webapp/libs/jspdf.debug.js");
// jQuery.sap.includeScript("app/barcode/webapp/libs/html2pdf.js");
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"app/barcode/model/models",
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("app.barcode.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});