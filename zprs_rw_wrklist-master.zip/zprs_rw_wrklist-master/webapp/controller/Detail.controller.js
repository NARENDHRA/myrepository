/*global location */
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	"fgt/rw/wrklist/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"fgt/rw/wrklist/model/formatter"
], function(BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("fgt.rw.wrklist.controller.Detail", {

		formatter: formatter,
		onInit: function() {
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				editable: true,
				duedate: null,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			this._oModel = this.getOwnerComponent().getModel();
			this._oModel.setDeferredGroups(["changes"]);
		},
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("RecordSummarySet", {
					Matterk: sObjectId
				});
				this.sObjectPath = sObjectPath;
				this._bindView("/" + sObjectPath + "/RecordSummaryToRecordHeader");
				this._bindRecordDetail("/" + sObjectPath);
			}.bind(this));
		},
		//Handle Detail Binding
		_bindRecordDetail: function(sObjectPath) {
			var AudittableLog = this.getView().byId("RdetailSmartTable");
			AudittableLog.rebindTable(true);
		},
		handlebeforeRecordDetail: function(oEvent) {
			var oSrc = oEvent.getSource();
			oSrc.setTableBindingPath("/" + this.sObjectPath + "/RecordSummaryToRecordDetails");
		},
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/busy", false);
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList");
			// iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			// oLineItemTable.attachEventOnce("updateFinished", function() {
			// 	// Restore original busy indicator delay for line item table
			// 	oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			// });

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onCreateinnrecontrol: function(evt) {
			evt.getSource().setEditable(true);
		},
		onChangeFlag: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				model = source.getBindingContext().getModel(),
				sPath = source.getBindingContext().sPath;
			model.setProperty(sPath + "/" + path, value);
		},
		onApproveDestruction: function(evt) {
			var tbl = this.getView().byId("RdetailSmartTable").getTable(),
				vFragment = "fgt.rw.wrklist.fragments.DistructiondueDate",
				oSelectedRows = tbl.getSelectedIndices(),
				errMsg = this._oResourceBundle.getText("errMsg");
			this._oAction = evt.getSource().getCustomData()[0].getValue();
			if (this._oAction === "P") {
				var oModel = this.getOwnerComponent().getModel();
				if ($.isEmptyObject(oModel.getPendingChanges())) {
					sap.m.MessageBox.warning(errMsg);
					return;
				}
			}

			if (this._oAction !== "A") {
				if (!this.__odailaogDueDate) {
					this.__odailaogDueDate = sap.ui.xmlfragment(vFragment, this);
					this.getView().addDependent(this.__odailaogDueDate);
				}
				this.__odailaogDueDate.open();
			} else {

				this.onPressOk();
			}
		},
		onPressOk: function(evt) {
			if (this.__odailaogDueDate !== undefined) {
				this.__odailaogDueDate.close();
			}
			var oAction = this._oAction;
			var oviewModel = this.getView().getModel("detailView");
			var tbl = this.getView().byId("RdetailSmartTable").getTable(),
				rows = tbl.getBinding("rows"),
				tblCntx = rows.getContexts(),
				ctxview = this.getView().getBindingContext(),
				aproveSucMsg = this._oResourceBundle.getText("aproveSucMsg"),
				desSucMsg = this._oResourceBundle.getText("desSucMsg");
			// var oSelectedRows = tbl.getSelectedIndices();
			var oMatterk = ctxview.getObject().Matterk;
			var DateValue1 = new Date(oviewModel.getProperty("/duedate").split("T")[0]);
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MM.dd.yyyy",
				UTC: true
			});
			var DateValue = dateFormat.format(DateValue1);
			var oModel = this.getOwnerComponent().getModel();
			$.each(tblCntx, function(j, oRowData) {
				var ctx = oRowData;
				if (ctx !== undefined) {
					var obj = ctx.getObject();
					var sPath = ctx.getPath();
					var oflag = ctx.getObject().Flag;
					var obj = ctx.getObject();
					if (oAction === "P") {
						oModel.setProperty(sPath + "/Destructionduen", new Date(DateValue));
						oModel.setProperty(sPath + "/Flag", oflag);
						oModel.setProperty(sPath + "/Matterk", oMatterk);
						oModel.setProperty(sPath + "/Action", oAction);
						obj.Flag = oflag;
					}
					if (oAction === "A" || oAction === "R") {
						if (oAction === "R") {
							oModel.setProperty(sPath + "/Destructionduen", new Date(DateValue));
						}
						oModel.setProperty(sPath + "/Flag", oflag);
						oModel.setProperty(sPath + "/Matterk", oMatterk);
						oModel.setProperty(sPath + "/Action", oAction);
						obj.Flag = oflag;

					}

				}
			});
			//	if (!$.isEmptyObject(oModel.getPendingChanges())) {
			var that = this;
			oModel.setDeferredGroups(["changes"]);
			oModel.submitChanges({
				groupId: "changes",
				success: function(oData, res) {
					oviewModel.setProperty("/duedate", null);
					if (oData.__batchResponses[0].__changeResponses !== undefined) {
						// if (oAction === "A") {
						// 	sap.m.MessageBox.show("Approve destruction of all items successfully posted");
						// }
						if (oAction === "P") {
							sap.m.MessageBox.show(aproveSucMsg);
						}
						if (oAction === "R") {
							sap.m.MessageBox.show(desSucMsg);
						}
						that._bindView("/" + that.sObjectPath + "/RecordSummaryToRecordHeader");
						that.getView().byId("RdetailSmartTable").rebindTable();
						that.getOwnerComponent().oListSelector._oList.getBinding('items').refresh(true);
						oModel.resetChanges();
					} else {
						var resData = oData.__batchResponses[0].response.body;
						var o = jQuery.parseJSON(resData);
						var mesgvalue = o.error.innererror.errordetails[0].message;
						sap.m.MessageBox.error(mesgvalue);
					}

				}.bind(this),
				error: function(error) {
					sap.m.MessageBox.show("error while posting the data");
					that.__odailaogDueDate.close();
				}
			
			});
			//	}

		},
		onCloseDialog: function(evt) {
			var oviewModel = this.getView().getModel("detailView");
			oviewModel.setProperty("/duedate", null);
			this.__odailaogDueDate.close();
		},
		onBeforeExport: function(evt) {
			var oMatter = this.getView().getBindingContext().getObject().Matterk;
			var oColumns = evt.mParameters.exportSettings.workbook.columns,
				df = new sap.ui.model.type.Date().getOutputPattern();
			$.each(oColumns, function(i, obj) {
				if ((obj.property === "Createdat") || (obj.property === "Destructiondue")) {
					obj.type = "date";
					obj.format = df.toLowerCase();
					obj.width = 18;
				}
			});
			// setting  FileName  Excel sheet.
			evt.mParameters.exportSettings.fileName = "Record Worklist(" + oMatter + ")";

		}

	});

});