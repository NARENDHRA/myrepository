jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"fgt/rw/wrklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"fgt/rw/wrklist/test/integration/pages/App",
	"fgt/rw/wrklist/test/integration/pages/Browser",
	"fgt/rw/wrklist/test/integration/pages/Master",
	"fgt/rw/wrklist/test/integration/pages/Detail",
	"fgt/rw/wrklist/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "fgt.rw.wrklist.view."
	});

	sap.ui.require([
		"fgt/rw/wrklist/test/integration/NavigationJourneyPhone",
		"fgt/rw/wrklist/test/integration/NotFoundJourneyPhone",
		"fgt/rw/wrklist/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});