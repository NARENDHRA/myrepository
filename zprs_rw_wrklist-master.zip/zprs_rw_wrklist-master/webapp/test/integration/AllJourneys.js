jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 RecordSummarySet in the list
// * All 3 RecordSummarySet have at least one RecordSummaryToRecordHeader

sap.ui.require([
	"sap/ui/test/Opa5",
	"fgt/rw/wrklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"fgt/rw/wrklist/test/integration/pages/App",
	"fgt/rw/wrklist/test/integration/pages/Browser",
	"fgt/rw/wrklist/test/integration/pages/Master",
	"fgt/rw/wrklist/test/integration/pages/Detail",
	"fgt/rw/wrklist/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "fgt.rw.wrklist.view."
	});

	sap.ui.require([
		"fgt/rw/wrklist/test/integration/MasterJourney",
		"fgt/rw/wrklist/test/integration/NavigationJourney",
		"fgt/rw/wrklist/test/integration/NotFoundJourney",
		"fgt/rw/wrklist/test/integration/BusyJourney",
		"fgt/rw/wrklist/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});