sap.ui.define([
	"cminewrequest/controller/BaseController",
	"sap/ui/table/TablePersoController",
	"cminewrequest/util/PersoService",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cminewrequest/model/formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"cminewrequest/util/xmlToJSON"
], function(BaseController, TablePersoController,PersoService,JSONModel, History, formatter, Filter, MessageToast) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView, oOPSideContentBtn;
	return BaseController.extend("cminewrequest.controller.NewMatter", {
		formatter: formatter,
		onInit: function() {
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.attachRoutePatternMatched(this.handleRouteMatched, this);
			var data = this._loadJSONData();
			var oOveriewDataModel1 = new sap.ui.model.json.JSONModel(data);
			this.getView().setModel(oOveriewDataModel1, "NRequestView");
			this.attachmentData();
			this.handleComments();
		},
		handleComments: function() {
			var commentList = new sap.ui.model.json.JSONModel({
				"CommentSet": []
			});
			this.getView().setModel(commentList, "CommentsModel");
			var that = this;
			this.WizardTitle = "Known Parties";
			//		this.validatedStep = false;
			var a = this.byId("NRWizardEC");
			var c = a._getProgressNavigator();
			var curr = 1;
			var old = undefined;
			//		var suppressEvent = true;
			//		var newStep = "";
			/*	a.onAfterRendering = function() {*/
			c.attachStepChanged(function(e) {
				curr = e.mParameters.current;
				old = e.mParameters.previous;
				var step = e.getSource().getStepTitles();
				that.WizardTitle = step[curr - 1];
				var cType = that.WizardTitle;
				//	that.onFilterComments(cType);

			}.bind(this));

			c._moveToStep = function(newStep, suppressEvent) {
				var stepCount = c.getStepCount(),
					oldStep = c.getCurrentStep();

				if (newStep > stepCount) {
					return c;
				}

				if (newStep > c._activeStep) {
					c._updateActiveStep(newStep);
				}
				c._updateCurrentStep(newStep, oldStep, suppressEvent);
				var curr = newStep;
				var old = oldStep;
				var step = c.getStepTitles();
				that.WizardTitle = step[curr - 1];
				var cType = that.WizardTitle;
				//	that.onFilterComments(cType);
			};
		},
		handleScroll: function() {
			jQuery.sap.delayedCall(200, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterNew").getDomRef().getBoundingClientRect().top;
				if (this.byId("idCommentsList").getDomRef()) {
					var barPositionTop = this.byId("idCommentsList").getDomRef().getBoundingClientRect().top;
					var scrollerHeight = window.innerHeight - barPositionTop - footerHeight - 30;
					this.byId("scrollContainer").setHeight(String(scrollerHeight + "px"));
				}
			}.bind(this));
		},
		onPostCommnets: function(evt) {
			// if (this.validatedStep) {
			// 	this.WizardTitle = "Client Details";
			// }
			var title = this.WizardTitle;
			var cType = "";
			if (title === "Client Details") {
				cType = "CC";
			} else if (title === "Known Parties") {
				cType = "KP";
			} else if (title === "Terms") {
				cType = "TE";
			} else if (title === "Client Service Directors") {
				cType = "LP";
			} else if (title === "Matter Details") {
				cType = "MD";
			} else {
				cType = "CO";
			}
			var text = evt.getParameter("value");
			var userId = this.getModel("worklistView").getProperty("/userId");
			var name = this.getModel("worklistView").getProperty("/userName");
			var obj = {
				Cmino: "",
				//	CommentType: cType,
				CommentType: "",
				Sequence: "",
				UserComment: text,
				Addedby: name,
				Addedbyk: userId,
				Addedon: new Date()
			};
			var oRemarks = this.getView().getModel("CommentsModel");
			var oRemarkData = oRemarks.getProperty("/CommentSet");
			oRemarkData.push(obj);
			oRemarks.setProperty("/CommentSet", oRemarkData);
			//	this.onFilterComments(cType);
			if (this._oCommentsForSteps) {
				this._oCommentsForSteps.close();
			}

		},
		next: function(evt) {
			console.log(1);
		},
		onFilterComments: function(val) {
			/*	if (this.validatedStep) {
					this.WizardTitle = "Client Details";
				}*/
			var title = this.WizardTitle;
			var cType = "";
			if (title === "Client Details") {
				cType = "CC";
			} else if (title === "Known Parties") {
				cType = "KP";
			} else if (title === "Terms") {
				cType = "TE";
			} else if (title === "Client Service Directors") {
				cType = "LP";
			} else if (title === "Matter Details") {
				cType = "MD";
			} else {
				cType = "CO";
			}
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("CommentType", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oList = this.getView().byId("idCommentsList");
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		handleRouteMatched: function(oEvent) {
			var oParameters = oEvent.getParameters();
			if(oParameters.name === "ExistClientNewMatterConflict"){
				var bCmino = $.isEmptyObject(oParameters.arguments);
				var data = oParameters.arguments;
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					ConsiData: []
				});
				this.getView().setModel(oJsonModel, "jsonConsiModel");
				var oJsonModel1 = new sap.ui.model.json.JSONModel();
				oJsonModel1.setData({
					RiskData: []
				});
				this.getView().setModel(oJsonModel1, "riskConsiModel");
				this.onDisplayClientApp(data);
			}
			else if ((oParameters.name !== "NewMatter" && oParameters.name !== "ExtClient")) {
				return;
			} else {
				var bCmino = $.isEmptyObject(oParameters.arguments);
				if (bCmino) {
					var data = {};
					data.Searchid = "";
					data.Cmino = "";
					this.onDisplayClientApp(data);
				} else {
					//
					oDynamicSideView = this.getView().byId("DynamicSideContentEC");
					window.that = this;
					this.dataBP();
					var oViewModel;
					var data = oParameters.arguments;
					var Cmino = data.Cmino;
					var clientk = data.Clientk;
					var bButton = data.bEditScreen;
					if (bButton === "0") {
						bButton = false;
					} else {
						bButton = true;
					}
					var inbox = data.bInbox;
					var rShow;
					if (inbox === "0") {
						inbox = false;
						rShow = true;
					} else {
						inbox = true;
						rShow = false;
					}
					oViewModel = new JSONModel({
						LbLMsgp: this.getResourceBundle().getText("LbLMsgp"),
						tableBusyDelay: 0,
						visbl: true,
						editable: false,
						altVisible: false,
						classfication: "",
						Role: "",
						enablePercent: bButton,
						Designation: "",
						Name: "",
						PopInDisplay: false,
						PopInDisplaycomments: false,
						conflictMsgVisible: false,
						selectCliVisible: false,
						submitEnable: false,
						expandClientDetails: true,
						Notes: "",
						viewDisplay: true,
						CmiId: Cmino,
						state: false,
						team: true,
						Astate: false,
						saveButton: false,
						submitButton: false,
						ExistState: true,
						clientFalse: false,
						PopOverClientEdit: true,
						btnEdit: false,
						btnDiplay: false,
						NMTitle: "",
						NMCNum: clientk,
						editScreen: bButton,
						EditCon: "",
						userId: sap.ushell.Container.getService("UserInfo").getUser().getId(),
						userName: sap.ushell.Container.getService("UserInfo").getUser().getFullName(),
						idisplayapprove: inbox,
						idisplayapprove01: rShow,
						idisplaySave: false,
						pageTitleReq: "Existing Client New Matter Review",
						Searchid:""
					});
					this.setModel(oViewModel, "worklistView");
					this.bindMandateField();
					this.getModel().metadataLoaded().then(function() {
						this._readOData(Cmino);
					}.bind(this));
					var aChange = ["FormDisplay354ALH", "FormChange354BD", "FormChange354MI", "FormChange354BF1",
						"FormChange354OD", "FormChange354BI", "FormChange354TD", "FormChange354ID", "FormDisplay354WO"
					];
					for (var i = 0; i < aChange.length; i++) {
						this.getView().byId(aChange[i]).setVisible(true);
					}
				}
			}
		},
		onDisplayClientApp: function(data) {
			oDynamicSideView = this.getView().byId("DynamicSideContentEC");
			window.that = this;
			this.dataBP();
			var oViewModel;
			oViewModel = new JSONModel({
				LbLMsgp: this.getResourceBundle().getText("LbLMsgp"),
				tableBusyDelay: 0,
				visbl: true,
				editable: false,
				altVisible: false,
				classfication: "",
				Role: "",
				enablePercent: true,
				Designation: "",
				Name: "",
				PopInDisplay: false,
				PopInDisplaycomments: false,
				conflictMsgVisible: false,
				selectCliVisible: false,
				submitEnable: false,
				expandClientDetails: true,
				Notes: "",
				team: false,
				viewDisplay: false,
				CmiId: data.Cmino,
				state: false,
				Astate: false,
				saveButton: false,
				submitButton: false,
				ExistState: true,
				clientFalse: false,
				PopOverClientEdit: true,
				btnEdit: false,
				btnDiplay: false,
				NMTitle: "",
				NMCNum: "",
				editScreen: true,
				EditCon: "",
				userId: sap.ushell.Container.getService("UserInfo").getUser().getId(),
				userName: sap.ushell.Container.getService("UserInfo").getUser().getFullName(),
				idisplayapprove: false,
				idisplayapprove01: false,
				idisplaySave: true,
				pageTitleReq: "Existing Client New Matter Request",
				Searchid: data.Searchid
			});
			this.setModel(oViewModel, "worklistView");
			this._onInitialize();
			//	this.displayCategoryData();
			this.CreateClient();

			this.bindMandateField();
			var aChange = ["FormDisplay354ALH", "FormChange354BD", "FormChange354MI", "FormChange354BF1",
				"FormChange354OD", "FormChange354BI", "FormChange354TD", "FormChange354ID", "FormDisplay354WO"
			];
			for (var i = 0; i < aChange.length; i++) {
				this.getView().byId(aChange[i]).setVisible(true);
			}
		},
		bindMandateField: function() {
			var oViewModel = new JSONModel({
				vClientName: "None",
				vClassification: "None",
				vAddress1: "None",
				vCity: "None",
				vState: "None",
				vZipCode: "None",
				vCountry: "None",
				vOffice: "None",
				vEmail: "None"
					//vContactName: "None",
					//vContactPhone: "None",
					//vContactEmail: "None"
			});
			this.setModel(oViewModel, "ErrorShow");
			var oViewMatterModel = new JSONModel({
				vMatterMN: "None",
				vMatterSA: "None",
				vMatterMMA: "None",
				vMatterMD: "None",
				vMatterPG: "None",
				vMatterO: "None",
				vMatterEF: "None"
			});
			this.setModel(oViewMatterModel, "ShowMatterError");
			var Altpayers = {
				"vAlternatepayer": "None",
				"vAltpayercityk": "None",
				"vAltpayeraddr1": "None",
				"vAltpayerstate": "None",
				"vAltpayerzip": "None",
				"vAltpayercountry": "None",
				"vAltpayerphone": "None"
			};
			var oViewAltModel = new JSONModel(Altpayers);
			this.setModel(oViewAltModel, "ShowAlterError");
		},
		CreateClient: function() {
			var idClient = this.byId("idClientDetailsNew");
			var idClientExt = this.byId("idClientDetails1");
			var idMatterInDetailsStep = this.byId("MatterInDetailsStep");
			this.getModel().metadataLoaded().then(function() {
				var qtc = this.getModel();
				var oContextClients = qtc.createEntry("/Cmiclients", {
					properties: this._loadJSONData().Clients
				});
				idClient.setBindingContext(oContextClients);
				var oContextEClients = qtc.createEntry("/Cmiclients", {
					properties: this._loadJSONData().Clients
				});
				idClientExt.setBindingContext(oContextEClients);
				var matter = this.byId("idMatterDetails");
				var oContextMatter = qtc.createEntry("/Cmimatters", {
					properties: this._loadJSONData().Matters
				});
				matter.setBindingContext(oContextMatter);
				/*var alter = this.byId("idAlterDetails");
				var oContextAlter = qtc.createEntry("/Cmialtpayers", {
					properties: this._loadJSONData().Altpayers
				});
				alter.setBindingContext(oContextAlter);*/

				var oContextMatterInDetail = qtc.createEntry("/Cmimatterdetails", {
					properties: this.handleMatterInDetails()
				});
				idMatterInDetailsStep.setBindingContext(oContextMatterInDetail);
				this.addWOOffice();
				this.onAddMatterBP();
				this.addAltPayer();
			}.bind(this));
		},
		displayEntries: function(data) {
			var qtc = this.getModel();
			var clientData = data.Clients.results.pop();
			var MatterData = data.Matters.results.pop();
			var MatterDetailsData = data.Matterdetails.results.pop();
			var oVModel = this.getModel("worklistView");
			if (clientData) {
				oVModel.setProperty("/NMTitle", clientData.Client);
			}
			/*		var idClient = this.byId("idClientDetailsNew");
						
						var oContextClients = qtc.createEntry("/Cmiclients", {
							properties: clientData
						});
						idClient.setBindingContext(oContextClients);
						*/
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
				//this._oPopover.bindElement("/ProductCollection/0");
				this.getView().addDependent(this._oPopover);
			}
			var idClientExt = this.byId("SimpFormClientEdit");
			var oContextEClients = qtc.createEntry("/Cmiclients", {
				properties: clientData
			});
			idClientExt.setBindingContext(oContextEClients);

			var matter = this.byId("idMatterDetails");
			var oContextMatter = qtc.createEntry("/Cmimatters", {
				properties: MatterData
			});
			matter.setBindingContext(oContextMatter);
			var idMatterInDetailsStep = this.byId("MatterInDetailsStep");
			var oContextMatterInDetail = qtc.createEntry("/Cmimatterdetails", {
				properties: MatterDetailsData
			});
			idMatterInDetailsStep.setBindingContext(oContextMatterInDetail);
		},
		handleDeleteComments: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oItmSel.getBindingContext("CommentsModel").getObject().Sequence;
			oTable.getModel("CommentsModel").getProperty("/CommentSet").splice(ind, 1);
			oTable.getModel("CommentsModel").refresh();
		},
		handleMatterInDetails: function() {
			var obj = {
				"Auth": "",
				"BillInstDate": "",
				"CheckNoLock": "",
				"Cmino": "",
				"Error": "",
				"Errormessage": "",
				"Etag": "",
				"Txjcd": "",
				"Txjcddesc": "",
				"Werks": "",
				"Werksdesc": "",
				"Zcontinue": "",
				"Zzactcodeset": "",
				"Zzactcodesetdesc": "",
				"ZzacsetValidfrom": null,
				"Zzaol": "",
				"Zzaoldesc": "",
				"Zzbillfreq": "",
				"Zzbillfreqdesc": "",
				"Zzbillinst": "",
				"Zzbillmthd": "",
				"Zzbillmthddesc": "",
				"Zzbillteam": "",
				"Zzbillteamdesc": "",
				"Zzbspras": "",
				"Zzbsprasdesc": "",
				"Zzcap": "0.00",
				"Zzcapctrl": "",
				"Zzcapcurr": "",
				"Zzcasecatcd": "",
				"Zzcasecatcddesc": "",
				"Zzclcasename": "",
				"Zzclcasenamedesc": "",
				"Zzclcasenbr": "",
				"Zzclcasenbrdesc": "",
				"Zzclntaol": "",
				"Zzclntaoldesc": "",
				"Zzclntbusarea": "",
				"Zzclntbusareadesc": "",
				"Zzclntccenter": "",
				"Zzclntccenterdesc": "",
				"Zzclntjursd": "",
				"Zzclntjursddesc": "",
				"Zzclntsrvcat": "",
				"Zzclntsrvcatdesc": "",
				"Zzclntstatus": "",
				"Zzclntstatusdesc": "",
				"Zzclntsubenty": "",
				"Zzclntsubentydesc": "",
				"Zzclntwrktype": "",
				"Zzclntwrktypedesc": "",
				"Zzcolco": "",
				"Zzcolcodesc": "",
				"Zzcompldate": null,
				"Zzcompletion": "0.00",
				"Zzcourtnum": "",
				"Zzcourtnumdesc": "",
				"Zzcstdtsumry": "",
				"Zzcstdtsumrydesc": "",
				"Zzdrftformat": "",
				"Zzdrftformatdesc": "",
				"Zzecost": "0.00",
				"Zzefees": "0.00",
				"Zzenttype": "",
				"Zzenttypedesc": "",
				"Zzetotal": "0.00",
				"Zzexpcodeset": "",
				"Zzexpcodesetdesc": "",
				"Zzfftcset": "",
				"Zzfftcsetdesc": "",
				"ZztcsetValidfrom": null,
				"Zzfnalformat": "",
				"Zzfnalformatdesc": "",
				"Zzgrpbill": "",
				"Zzgrpbilldesc": "",
				"Zzintver": "",
				"Zzintverdesc": "",
				"Zziob": "",
				"Zziobdesc": "",
				"Zzipanuyear": "",
				"Zzipappldate": null,
				"Zzipapplnum": "",
				"Zzipapplnumdesc": "",
				"Zzipjurisdcd": "",
				"Zzipjurisdcddesc": "",
				"Zzipponum": "",
				"Zzipponumdesc": "",
				"Zziprefrtypecd": "",
				"Zziprefrtypecddesc": "",
				"Zzipregdt": null,
				"Zzipregnum": "",
				"Zzipregnumdesc": "",
				"Zzipsort1": "",
				"Zzipsort1desc": "",
				"Zzipsort2": "",
				"Zzipsort2desc": "",
				"Zzipsort3": "",
				"Zzipsort3desc": "",
				"Zzipsort4": "",
				"Zzipsort4desc": "",
				"Zzipsort5": "",
				"Zzipsort5desc": "",
				"Zzmansp": "",
				"Zzmanspdesc": "",
				"Zzmatpageno": "",
				"Zzmatpagenodesc": "",
				"Zzmatremit": "",
				"Zzmatremitdesc": "",
				"Zzmatrptgrp": "",
				"Zzmatrptgrpdesc": "",
				"Zzmattercat": "",
				"Zzmattercatdesc": "",
				"Zzmattertype": "",
				"Zzmattertypedesc": "",
				"Zzmcurr": "",
				"Zzmcurrdesc": "",
				"Zzmonlau": "",
				"Zzmonlaudesc": "",
				"Zzmprgrp": "",
				"Zzmprgrpdesc": "",
				"Zznatureprocd": "",
				"Zznatureprocddesc": "",
				"Zzpassthru": "",
				"Zzpracticegroup": "",
				"Zzpracticegroupdesc": "",
				"Zzpriconf": "",
				"Zzpriconfdesc": "",
				"Zzsubindcode": "",
				"Zzsubindcodedesc": "",
				"Zzsumwo": "",
				"Zzsumwodesc": "",
				"Zzsyndlomat": "",
				"Zztaskcodeset": "",
				"Zztaskcodesetdesc": "",
				"Zztax": "",
				"Zztaxdesc": "",
				"Zztecharea": "",
				"Zztechareadesc": "",
				"Zztimeentryunit": "",
				"Zztimeentryunitdesc": "",
				"Zztksumry": "",
				"Zztksumrydesc": "",
				"Zztmdtl": "",
				"Zztmdtldesc": "",
				"Zzwipprovpercent": ""
			};
			return obj;
		},
		displayCategoryData: function() {
			//this.onCancelJCM();
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_ADMIN_TABS_SRV/");
			var oJsonModel = new sap.ui.model.json.JSONModel();
			//	oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);

			var conPath = "Busconsiderations?$filter=Questioncategoryk%20eq%20%27RQ%27";
			oModel.read(conPath, null, null, true, function(oData, oResponse) {
				oJsonModel.setData({
					ConsiData: oData.results
				});
				that.getView().setModel(oJsonModel, "jsonConsiModel");
			}, function(oResponse) {

			});
		},
		_loadJSONDataForClient: function(oData) {
			this._loadDataForKnownPartyDropDown();
			this._loadDataForMatterDetailDropDown();
			var aData = oData || this._loadJSONData();
			var oContact = {};
			// primary Contact
			if (aData.Clientcontacts.results) {
				aData.Clientcontacts.testContact = aData.Clientcontacts.results;
				var contact = aData.Clientcontacts.results.filter(function(sContact) {
					return sContact.Contacttype === "P";
				});
				oContact = contact.pop();
			}
			// Client Details
			if (aData.Clients.results) {
				var oClient = aData.Clients.results[0];
				//	var oAttach = aData.Clients;
				oClient.ClientDetail = oClient;
				oClient.ClientContact = oContact;
				aData.Clients.testClient = aData.Clients.results;
			}
			// Client Matters
			if (aData.Matters.results) {
				var oMatter = aData.Matters.results.pop();
				var that = this;
				aData.Matters.MatterDetail = oMatter;
				this.getModel().metadataLoaded().then(function() {
					var qtc = that.getModel();
					var matter = that.byId("idMatterDetails");
					var oContextMatter = qtc.createEntry("/Cmimatters", {
						properties: oMatter
					});
					matter.setBindingContext(oContextMatter);
				});
			}
			// Altpayers
			if (aData.Altpayers.results) {
				var oAltpayer = aData.Altpayers.results.pop();
				aData.Altpayers.AltpayersDetail = oAltpayer;
				this.getModel().metadataLoaded().then(function() {
					var qtc = that.getModel();
					var alter = that.byId("idAlterDetails");
					var oContextAlter = qtc.createEntry("/Cmialtpayers", {
						properties: oAltpayer
					});
					alter.setBindingContext(oContextAlter);
				});
			}
			return aData;
		},
		getBindingContextbyId: function(sId) {
			var oContext = this.getView().byId(sId).getBindingContext();
			return oContext;
		},
		onAlterChange: function(evt) {
			var selected = evt.getParameter("state"),
				model = this.getModel("worklistView");
			if (selected) {
				model.setProperty("/altVisible", selected);
			} else {
				model.setProperty("/altVisible", selected);
			}
		},
		changeMatterDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idMatterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
			this.getMatterValidated("ch");
		},
		getMatterValidated: function(e) {
			var that = this;
			var oMatterData = that.byId("idMatterDetails").getBindingContext().getObject();
			var sFlag = true;
			for (var key in oMatterData) {
				if (oMatterData.hasOwnProperty(key)) {
					if (key == "Quote" || key == "__metadata" || key == "Estimatedfees") {
						continue;
					}
					var oError = this.getModel("ShowMatterError");
					var Field = formatter.getMatterKeyField(key);
					if (oMatterData[key] == "") {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		onPressConflictSearch: function(oEvent, oView) {
			var aFilter = [];
			var Srchid = this.getModel("worklistView").getProperty("/Searchid");
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oConflictReport) {
				this._oConflictReport = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.ConfilctReport", this);
				oView.addDependent(this._oConflictReport);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oConflictReport);
				var oBusyDialog = new sap.m.BusyDialog();
				oBusyDialog.open();
				aFilter.push(new Filter("Searchid", "EQ", Srchid));
				var that = this;
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_CONFLICTS_SRV/");
				var oCSTableModel = new sap.ui.model.json.JSONModel();
				var oTable = that.getView().byId("ConflictSearchTableId");
				oTable.setModel(oCSTableModel, "csTableModel");
				oModel.read("/Searchresults", {
					filters: aFilter,
					success: function(oData) {
						oCSTableModel.setData(oData);
						that.setCount();
						oTable._handleRowCountModeAuto();
						oBusyDialog.close();
						that._oConflictReport.open();
					},
					error: function(oError) {
						sap.m.MessageBox.error(oError.message, {
							title: "Error",
							actions: [sap.m.MessageBox.Action.CLOSE]
						});
						oBusyDialog.close();
					}
				});
		},
		onCloseConflictsSearch: function() {
			this._oConflictReport.close();
		},
		setCount: function() {
			var oBinding = this.getView().byId("ConflictSearchTableId").getBinding("rows"),
				oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/tableCount", oBinding.iLength);
			if (oBinding.iLength === 0) {
				oViewModel.setProperty("/tableNoDataText", "No Data");
			}
		},

		onAlterMandatory: function(e) {
			var that = this;
			var oAlterData = that.byId("idAlterDetails").getBindingContext().getObject();
			var sFlag = true;
			for (var key in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key === "__metadata" || key === "Altpayeraddr1" || key === "Altpayeraddr2" || key === "Alternatepayer") {
						continue;
					}
					var oError = this.getModel("ShowAlterError");
					var Field = formatter.getAlterKeyField(key);
					if (oAlterData[key] === "") {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		changeClientDetailsNew: function(evt) {
			var data = this._loadJSONData();
			var oOveriewDataModel1 = new sap.ui.model.json.JSONModel(data);
			this.getView().setModel(oOveriewDataModel1, "NRequestView");
			var CFormId = this.getView().byId("SimpFormClient1");
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var oVModel = this.getModel("worklistView");
			oVModel.setProperty("/NMTitle", value);
			// set Value for Client Details Context
			var oClientContext = this.getBindingContextbyId("idClientDetails1");
			var sPath = oClientContext.getPath();
			var oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
			this.getModel("worklistView").setProperty("/submitEnable", true);
			jQuery.sap.delayedCall(400, this, function() {
				var oClientObj = this.getBindingContextbyId("idClientDetails1").getObject();
				var oModel = this.getView().getModel("NRequestView");
				oModel.setProperty("/ClientDetail", oClientObj);
				oModel.setProperty("/ClientContact", oClientObj);
				this.byId("KnownParties").setValidated(true);
				//				var Data = this.getView().getModel("NRequestView").getProperty("/Knownparties");
				//				this.bindKnownParties(Data);

			}.bind(this));
		},
		OnPressCDetails: function(oEvent) {
			var that = this;

			var oVModel = this.getModel("worklistView");
			var oClientObj = {};
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
				//this._oPopover.bindElement("/ProductCollection/0");
				this.getView().addDependent(this._oPopover);
			}
			var team = oVModel.getProperty("/team");
			if (!team) {
				//	oClientObj = this.getBindingContextbyId("idClientDetails1").getObject();
				var idClient = this.getView().byId("SimpFormClientEdit");
				var oModel = idClient.getBindingContext().getModel();
				var sPath = idClient.getBindingContext().getPath();
				oModel.setProperty(sPath + "/Client", oVModel.getProperty("/NMTitle"));
				oClientObj.Client = oVModel.getProperty("/NMTitle");
			}
			this._oPopover.openBy(oEvent.getSource());
		},
		handleClientEdit: function(oEvent) {
			var viewModel = this.getModel("worklistView");
			//viewModel.setProperty("/PopOverClientEdit", true);
			viewModel.setProperty("/btnDiplay", true);
			viewModel.setProperty("/clientFalse", true);
			viewModel.setProperty("/btnEdit", false);
		},

		handleClientDisplay: function(oEvent) {
			var viewModel = this.getModel("worklistView");
			// viewModel.setProperty("/PopOverClientDipl", true);
			viewModel.setProperty("/btnEdit", true);
			viewModel.setProperty("/clientFalse", false);
			viewModel.setProperty("/btnDiplay", false);
		},
		handleclose: function() {
			this._oPopover.close();
		},
		onAfterRendering: function() {
			//	sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
		},
		handleSideContentHide: function() {
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(false);
			}
			//oOPSideContentBtn.setVisible(true);
		},
		handleSCBtnPress: function(oEvent) {

			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					oEvent.getSource().setText("Hide Comments");
					this.handleScroll();
				} else {
					oEvent.getSource().setText("Show Comments");
				}
			}
			//oOPSideContentBtn.setVisible(false);
		},
		// changeClientDetails: function(evt) {
		// 	var source = evt.getSource();
		// 	var path = source.getBindingPath("value");
		// 	var value = source.getValue();
		// 	// set Value for Client Details Context
		// 	var oClientContext = this.getBindingContextbyId("idClientDetails");
		// 	var sPath = oClientContext.getPath();
		// 	var oClientModel = oClientContext.getModel();
		// 	oClientModel.setProperty(sPath + "/" + path, value);
		// 	jQuery.sap.delayedCall(400, this, function() {
		// 		var oClientObj = this.getBindingContextbyId("idClientDetails").getObject();
		// 		var oModel = this.getView().getModel("NRequestView");
		// 		oModel.setProperty("/ClientDetail", oClientObj);
		// 		oModel.setProperty("/ClientContact", oClientObj);
		// 		var Data = this.getView().getModel("NRequestView").getProperty("/Knownparties");
		// 		this.byId("KnownParties").setValidated(true);
		// 		this.bindKnownParties(Data);
		// 	}.bind(this));
		// },
		changeMatterCurrDetails: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			var unit = source.getUnitOfMeasure();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idMatterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/Estimatedfees", value);
			oMatterModel.setProperty(sPath + "/Estimatedfeecurr", unit);
			//	this.getMatterValidated("ch");
		},
		_loadDataForMatterDetailDropDown: function() {
			// Service Area
			var servicearea = {
				"ServiceAreaSet": [{
					"Serviceareak": "AF",
					"Servicearea": "Acquisition Finance"
				}, {
					"Serviceareak": "AL",
					"Servicearea": "Administrative Law"
				}, {
					"Serviceareak": "BAKF",
					"Servicearea": "Banking & Finace"
				}, {
					"Serviceareak": "CRL",
					"Servicearea": "Criminal Law"
				}, {
					"Serviceareak": "AQ",
					"Servicearea": "AF"
				}]
			};
			var serviceareaJSON = new sap.ui.model.json.JSONModel();
			serviceareaJSON.setData(servicearea);
			this.getView().setModel(serviceareaJSON, "serviceAreaData");

			// Matter Mgmt
			var mattermanagement = {
				"MatterManagementSet": [{
					"Mmak": "00122879",
					"Mma": "Curtis Powell"
				}, {
					"Mmak": "00125779",
					"Mma": "Marion Stephens"
				}, {
					"Mmak": "00221879",
					"Mma": "Adem Alexander"
				}, {
					"Mmak": "00125879",
					"Mma": "CONNOR RUSSEL"
				}]
			};
			var mattermanagementJSON = new sap.ui.model.json.JSONModel();
			mattermanagementJSON.setData(mattermanagement);
			this.getView().setModel(mattermanagementJSON, "matterManagementData");

			// matterMgmtOfficeData  MatterMgmtOfficeSet ; Mmoffice Mmofficek
			var mattermgntoffice = {
				"MatterMgmtOfficeSet": [{
					"Mmofficek": "GLB1",
					"Mmoffice": "Global"
				}, {
					"Mmofficek": "BOG1",
					"Mmoffice": "Bogota"
				}, {
					"Mmofficek": "CHI1",
					"Mmoffice": "Chivago"
				}, {
					"Mmofficek": "CAN1",
					"Mmoffice": "Canada"
				}, {
					"Mmofficek": "CAR1",
					"Mmoffice": "Caracas"
				}]
			};
			var mattermgntofficeJSON = new sap.ui.model.json.JSONModel();
			mattermgntofficeJSON.setData(mattermgntoffice);
			this.getView().setModel(mattermgntofficeJSON, "matterMgmtOfficeData");

			// practiceGroupData PracticeGroupSet ; Practicegroup Practicegroupk
			var practicegroup = {
				"PracticeGroupSet": [{
					"Practicegroupk": "IM",
					"Practicegroup": "Immigration"
				}, {
					"Practicegroupk": "TX",
					"Practicegroup": "TAX"
				}, {
					"Practicegroupk": "IS",
					"Practicegroup": "Insurance"
				}, {
					"Practicegroupk": "CM",
					"Practicegroup": "Capital Markets"
				}]
			};
			var practicegroupJSON = new sap.ui.model.json.JSONModel();
			practicegroupJSON.setData(practicegroup);
			this.getView().setModel(practicegroupJSON, "practiceGroupData");

			// STATE 
			var state = {
				"StateSet": [{
					"Statek": "1",
					"State": "5 U.S. (1 Cranch) 137 Marbury v. Madison"
				}, {
					"Statek": "2",
					"State": "17 U.S. (4 Wheat.) 316 McCulloch v. Maryland"
				}, {
					"Statek": "3",
					"State": "22 U.S. (9 Wheat.) 1 Gibbons v. Ogden"
				}, {
					"Statek": "4",
					"State": "60 U.S. (19 How.) 393 Dred Scott v. Sandford"
				}, {
					"Statek": "ON",
					"State": "Ontario"
				}]
			};
			var stateJSON = new sap.ui.model.json.JSONModel();
			stateJSON.setData(state);
			this.getView().setModel(stateJSON, "stateData");
			// Country
			var country = {
				"CountrySet": [{
					"Countryk": "US",
					"Country": "United States"
				}, {
					"Countryk": "GE",
					"Country": "Germany"
				}, {
					"Countryk": "CA",
					"Country": "Canada"
				}]
			};
			var countryJSON = new sap.ui.model.json.JSONModel();
			countryJSON.setData(country);
			this.getView().setModel(countryJSON, "countryData");
		},
		_loadDataForKnownPartyDropDown: function() {
			var roles = {
				"RoleSet": [{
					"Rolek": "1",
					"Role": "Client"
				}, {
					"Rolek": "A",
					"Role": "Adverse Party"
				}, {
					"Rolek": "3",
					"Role": "Related Party"
				}]
			};
			var roleJSON = new sap.ui.model.json.JSONModel();
			roleJSON.setData(roles);
			this.getView().setModel(roleJSON, "rolesData");

			var classifications = {
				"ClassificationSet": [{
					"Classificationk": "I",
					"Classification": "Individual"
				}, {
					"Classificationk": "O",
					"Classification": "Organization"
				}, {
					"Classificationk": "C",
					"Classification": "Collaboration"
				}]
			};

			var classificationJSON = new sap.ui.model.json.JSONModel();
			classificationJSON.setData(classifications);
			this.getView().setModel(classificationJSON, "classificationData");

			var designations = {
				"DesignationSet": [{
					"Designationk": "1",
					"Designation": "Adverse Family Member"
				}, {
					"Designationk": "2",
					"Designation": "Affiliate"
				}, {
					"Designationk": "3",
					"Designation": "Assignee"
				}, {
					"Designationk": "4",
					"Designation": "Beneficiary"
				}, {
					"Designationk": "B",
					"Designation": "Broker"
				}, {
					"Designationk": "6",
					"Designation": "Buyer"
				}, {
					"Designationk": "7",
					"Designation": "Child"
				}, {
					"Designationk": "8",
					"Designation": "Client's Family Member"
				}, {
					"Designationk": "9",
					"Designation": "Client's Other Business"
				}, {
					"Designationk": "10",
					"Designation": "Client's Partners"
				}, {
					"Designationk": "11",
					"Designation": "Co-Counsel"
				}, {
					"Designationk": "12",
					"Designation": "Co-Defendant"
				}, {
					"Designationk": "13",
					"Designation": "Co-Plaintiff"
				}, {
					"Designationk": "14",
					"Designation": "Creditor"
				}, {
					"Designationk": "15",
					"Designation": "Defendant"
				}, {
					"Designationk": "16",
					"Designation": "Devisee"
				}, {
					"Designationk": "17",
					"Designation": "Director"
				}, {
					"Designationk": "18",
					"Designation": "Employee"
				}, {
					"Designationk": "19",
					"Designation": "Employer"
				}, {
					"Designationk": "20",
					"Designation": "Expert Witness"
				}, {
					"Designationk": "21",
					"Designation": "Foreign Patent Agent"
				}]

			};
			var designationJSON = new sap.ui.model.json.JSONModel();
			designationJSON.setData(designations);
			this.getView().setModel(designationJSON, "designationData");
		},
		_readOData: function(CmiNo) {
			var _that = this;
			var oModel = this.getModel();
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var oOveriewDataModel = new sap.ui.model.json.JSONModel();
			var sObjectPath = oModel.createKey("Cmihdrs", {
				Cmino: CmiNo,
				Matterk:"",
				Clientk: "",
				Cmirequesttype: "ECNM"
			});
			var urlParams = {
				"$expand": "Comments,ConsiderationsN,Documents,Clients,Knownparties,Matters,Matterdetails,Offices,Altpayers"
			};
			oModel.read("/" + sObjectPath, {
				context: null,
				urlParameters: urlParams,
				async: true,
				filters: null,
				success: function(oData, oResponse) {
					//	_that.getModel("worklistView").setProperty("/userId", oResponse.data.Requestuserk);
					//	_that.getModel("worklistView").setProperty("/userName", oResponse.data.Requestuser);
					oBusy.close();
					var commentList = new sap.ui.model.json.JSONModel({
						"CommentSet": oData.Comments.results
					});
					_that.getView().setModel(commentList, "CommentsModel");
					//		_that.getModel("worklistView").setProperty("/CmiId", oResponse.data.Cmino);
					oOveriewDataModel.setData(oData);
					//		_that.getView().setModel(oOveriewDataModel, "NRequestView");
					var dataC = oData.ConsiderationsN,
						businessData = [],
						riskData = [];
					for (var j = 0; j < dataC.results.length; j++) {
						if (dataC.results[j].Attributetypek === "02") {
							riskData.push(dataC.results[j]);
						} else {
							businessData.push(dataC.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					oJsonBModel.setData({
						ConsiData: businessData
					});
					_that.getView().setModel(oJsonBModel, "jsonConsiModel");
					oJsonRModel.setData({
						RiskData: riskData
					});
					_that.getView().setModel(oJsonRModel, "riskConsiModel");
					_that.bindKnownParties(oData.Knownparties.results);
					_that.bindOffices(oData.Offices.results);
					_that.bindAlterData(oData.Altpayers.results);
					_that.displayEntries(oData);
					var data = oData.Documents.results;
					var aFileData = [];
					var host = window.location.host;
					var protocol = window.location.protocol;
					var urlprefix = protocol + "//" + host;
					var serviceUrl = _that.getModel().sServiceUrl;
					for (var i = 0; i < data.length; i++) {
						var obj = data[i];
						obj.url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
							"',Doctype='" + obj.Doctype +
							"')/$value";
						aFileData.push(obj);
					}
					var oJsonModel = new sap.ui.model.json.JSONModel({
						FileDataSet: aFileData
					});
					_that.getView().setModel(oJsonModel, "AttachmentModel");
				},
				error: function(oData) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						styleClass: "customPopBg",
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function() {
							//Action to be performed on close of message dialog
						}
					});
				}
			});
		},
		bindKnownParties: function(newData) {
			var idKnownParty = this.byId("idKnownParty");
			idKnownParty.destroyItems();
			for (var k = 0; k < newData.length; k++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: newData[k]
				});
				this.bindKnownTable(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.addKnownParties();
			}
			//	this.getModel("NRequestView").setProperty("/Knownparties", newData);
		},
		changeKnownDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			var oItem = source.getAggregation("_content").getSelectedItem();
			if (oItem) {
				var id, description, key,
					selData = oItem.getBindingContext().getObject();
				if (path === "Classification") {
					id = "Classificationk";
					description = "STEXT";
					key = "CLASSIFICATIONK";
				}
				if (path === "Role") {
					id = "Rolek";
					description = "STEXT";
					key = "ROLEK";
				}
				if (path === "Designation") {
					id = "Designationk";
					description = "STEXT";
					key = "DESIGNATIONK";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		addKnownParties: function(evt) {
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var objArray = [];
				var aKnownParties = that.getModel("NRequestView").getProperty("/Knownparties");
				var qtc = that.getModel();
				var obj = {
					"Cmino": "$000000001",
					"Designation": "",
					"Knownpartyseq": "",
					"Classification": "",
					"Rolek": "",
					"Designationk": "",
					"Classificationk": "",
					"Role": "",
					"Name": "",
					"Comments": "",
					"Hasconflict": ""
				};
				objArray.push(obj);
				var idKnownParty = that.byId("idKnownParty");
				if (idKnownParty.getItems().length === 0) {
					var clientObj = that.getView().byId("SimpFormClientEdit").getBindingContext().getObject();
					var objc = {
						Classification: clientObj.Classification,
						Classificationk: clientObj.Classificationk,
						Client: clientObj.Client
					};
					obj.Name = objc.Client;
					obj.Role = "Client";
					obj.Rolek = "01";
					obj.Classificationk = objc.Classificationk;
					obj.Classification = objc.Classification;
					obj.Designation = "Client's Family Memb";
					obj.Designationk = "08";
				}
				that.getModel("NRequestView").setProperty("/Knownparties", aKnownParties.concat(objArray));
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: obj
				});
				that.bindKnownTable(oContextKnownParties);
			});
		},
		bindKnownTable: function(oContextKnownParties) {

			var idKnownParty = this.byId("idKnownParty");
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				text: "Add",
				enabled: "{worklistView>/editScreen}",
				press: this.addKnownParties.bind(this)
			});
			//		var a= new sap.ui.comp.smartfield.Configuration({controlType:"dropDownList"}); addAggregation("configuration",a,false)
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Name}",
						editable: "{worklistView>/editScreen}",
						change: this.changeKnownDetails.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Classification}",
						editable: "{worklistView>/editScreen}",
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(a).attachInnerControlsCreated(function(e) {

					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Role}",
						editable: "{worklistView>/editScreen}",
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Designation}",
						editable: "{worklistView>/editScreen}",
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(c),
					new sap.m.Button({
						icon: "sap-icon://bell",
						type: "Reject",
						visible: {
							path: 'Hasconflict',
							formatter: formatter.myBooleanBDOD
						},
						press: this.onPressViewConfilt.bind(this)
					}),
					new sap.m.Button({
						icon: "sap-icon://message-popup",
						type: "{=${Comments} ? 'Emphasized':'Default'}",
						press: function(evt) {
							this.onPressComments(evt);
						}.bind(this)
					}),
					new sap.m.Button({
						icon: "sap-icon://attachment",
						type: "Default",
						press: this.addAttachments.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idKnownParty.addItem(oColumnListItem);
			this.upDateButtons(idKnownParty);
		},
		_loadJSONData: function() {
			var data = {
				Cmino: "",
				Requestuserk: "",
				Requestuser: "",
				Requesttime: "0",
				Cmirequesttype: "00",
				Changedbyk: "",
				Changedby: "",
				Changedtime: "0",
				BP: [],
				VAConflicts: [],
				Clients: {
					"Cmino": "$000000001",
					"Clientk": "",
					"Client": "",
					"Classificationk": "",
					"Classification": "",
					"Addr1": "",
					"Addr2": "",
					"City": "",
					"Statek": "",
					"State": "",
					"Zipcode": "",
					"Countryk": "",
					"Country": "",
					"Bofficek": "",
					"Boffice": "",
					"Email": "",
					"Nstandardterms": "",
					"Vkorg": "",
					"Vkorgdesc": ""
				},
				ClientDetail: {},
				ClientContact: {},
				Clientcontacts: [],
				Matters: {
					"Cmino": "$000000001",
					"Mattername": "",
					"Matter": "",
					"Serviceareak": "",
					"Servicearea": "",
					"Mmak": "",
					"Mma": "",
					"Matterlongtext": "",
					"Practicegroupk": "",
					"Practicegroup": "",
					"Mmofficek": "",
					"Mmoffice": "",
					"Quote": "",
					"Estimatedfees": "0.00",
					"Estimatedfeecurr": "",
					"Zzplsez": null,
					"Zzplfaz": null
				},
				Ocgs: [],
				Knownparties: [],
				Leadpartners: [],
				Considerations: [{
					"Cmino": "$000000001",
					"Considerationseq": "",
					"Considerationtype": "",
					"Consderationk": "",
					"Consideration": "",
					"Countryrequired": "",
					"Countryk": "",
					"Explainationrequired": "",
					"Explaination": ""
				}],
				Altpayers: {
					"Cmino": "$000000001",
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Partnertypedesc": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				},
				Altpayers1: [{
					"Cmino": "$000000001",
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Partnertypedesc": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				}]
			};
			return data;
		},
		_onInitialize: function() {
			var sParms = "", // this.getOwnerComponent().getComponentData().startupParameters,
				oViewModel = this.getView().getModel("worklistView"),
				aKnownParties;

			if (sParms.hasOwnProperty("appName")) {
				var sAppName = sParms.appName[0];

				//Cross App Handling
				var executeApp = {
					"Conflicts": function() {
						aKnownParties = JSON.parse(decodeURIComponent(decodeURI(sParms.conflictsData[0])));
						if (!(aKnownParties.length > 0)) {
							this.msgPopover();
							oViewModel.setProperty("/conflictMsgVisible", true);
							return;
						}
						this.getModel("worklistView").setProperty("/conflictRequest", aKnownParties);
						this.conflictRequestDialog();
						oViewModel.setProperty("/conflictMsgVisible", false);
					}.bind(this),

					"NewRequest": function() {
						var aClients = this._oModel.getProperty("/Clients"),
							index;
						aClients.forEach(function(o, i) {
							if (o.ClientID === sParms.ClientId[0]) {
								index = i;
							}
						});
						this.getView().bindElement("NRequestView>/Clients/" + index);
					}.bind(this)
				};
				executeApp[sAppName]();
			} else {
				this.msgPopover();
				oViewModel.setProperty("/conflictMsgVisible", true);
			}
		},
		attachmentData: function() {
			var oObj = [];
			var oJsonModel = new sap.ui.model.json.JSONModel({
				FileDataSet: oObj
			});
			this.getView().setModel(oJsonModel, "AttachmentModel");
			var oJsonKPModel = new sap.ui.model.json.JSONModel({
				KPDataSet: []
			});
			this.getView().setModel(oJsonKPModel, "KPModel");
		},
		onChange: function(oEvent) {
			var oModel = this.getView().getModel("AttachmentModel");
			var oData = oModel.getProperty("/FileDataSet");
			var files = oEvent.getParameter("files")[0];
			var obj = {
				"AttachmentNo": files.lastModified,
				"FileName": files.name,
				"MimeType": files.type,
				"url": "https://",
				"visibleDelete": true
			};
			oData.push(obj);
			oModel.refresh();
		},
		onPressViewConfilt: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oKnownParties) {
				this._oKnownParties = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.ViewConflicts", this);
				oView.addDependent(this._oKnownParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKnownParties);
			var that = this;
			var source = evt.getSource();
			var obj = source.getBindingContext().getObject();
			var cmino = this.getModel("worklistView").getProperty("/CmiId");
			var name = obj.Name;
			var aFilter = [new Filter("Cmino", sap.ui.model.FilterOperator.EQ, cmino), new Filter("Name", sap.ui.model.FilterOperator
				.EQ, name)];
			var filesPath = "/Cmigetconflicts";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					that.getModel("NRequestView").setProperty("/VAConflicts", oData.results);
					that._oKnownParties.open();
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		onClosevConflicts: function() {
			this._oKnownParties.close();
		},

		onExpandConflicts: function(oEvent) {
			var oSrc = oEvent.getSource(),
				sId = oSrc.getBindingContext("NRequestView").getProperty("ID"),
				aFilter = [new Filter("ClientID", "EQ", sId)],

				oTable = oSrc.getContent()[0],
				oTemplate = this.getView().byId("columnListItemTemplate");

			//if (oTable.data().isTableBound === "no") {
			oTable.bindItems({
				path: "NRequestView>/Conflicts",
				filters: aFilter,
				template: oTemplate
			});
			//	oTable.data().isTableBound = "yes";
			//	}
		},

		OnPressHeader: function() {
			// var a = this.byId("objHeaderId");
			// var n = a.getEditable();
			// a.setEditable(!n);
			var oView = this.getView().getModel("worklistView");
			var oPr = oView.getProperty("/editable");
			oView.setProperty("/editable", !oPr);

		},

		msgPopover: function() {
			if (!this._oNMatterReqest) {
				this._oNMatterReqest = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMReqestNew", this);
				this.getView().addDependent(this._oNMatterReqest);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oNMatterReqest);
			this._oNMatterReqest.open();
		},
		onNavToClient: function(oEvent) {
			// var oCtx = oEvent.getSource().getBindingContext();
			var oNavCon = this.getView().byId("navCon");
			var oDetailPage = this.getView().byId("detail1");
			oNavCon.to(oDetailPage);
			this.getModel("worklistView").setProperty("/submitEnable", true);
			this.getModel("worklistView").setProperty("/ExistState", true);

			// oDetailPage.bindElement(oCtx.getPath());
		},
		onNavToExtclient: function(oEvent) {
			// var oCtx = oEvent.getSource().getBindingContext();

			this.getModel("worklistView").setProperty("/ExistState", false);
			var oNavCon = this.getView().byId("navCon");
			var oDetailPage = this.getView().byId("detail");
			oNavCon.to(oDetailPage);
			// oDetailPage.bindElement(oCtx.getPath());
		},
		onNavBackEclient: function(oEvent) {
			var oNavCon = this.getView().byId("navCon");
			oNavCon.back();
			this.getModel("worklistView").setProperty("/submitEnable", false);
		},
		onNavBackclient: function(oEvent) {
			var oNavCon = this.getView().byId("navCon");
			oNavCon.back();
			this.getModel("worklistView").setProperty("/submitEnable", false);
		},

		/*onSubmitDialog: function() {
			var oViewModel = this.getModel("worklistView"),
				bCliSel = oViewModel.getProperty("/selectCliVisible"),
				oClient = this.getView().byId("CliSelID");

			if (bCliSel) {
				//Handle Client
				var oItem = oClient.getSelectedItem();
				if (oItem) {
					var sClientBindingContext = oItem.getBindingContext("NRequestView").sPath;
					this.getView().bindElement("NRequestView>" + sClientBindingContext);
					//	this.getView().bindElement("NRequestView>/Clientcontacts/results/0");
				} else {
					MessageToast.show("Client Not Found");
				}
			} else {
				this.getRouter().navTo("NewClientNewMatter", {}, true);
			}
			if (oItem) {
				oViewModel.setProperty("/viewDisplay", true);
				this._oNMatterReqest.close();
			}
		},*/
		onSubmitDialog: function() {
			var oViewModel = this.getModel("worklistView"),
				// bCliSel = oViewModel.getProperty("/state");
				bCliSel = oViewModel.getProperty("/ExistState");
			this.getView().byId("idClientDetailsNew");

			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			if (!bCliSel) {
				var oClientObj = this.getBindingContextbyId("idClientDetails1").getObject();
				if (!this._oPopover) {
					this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
					//this._oPopover.bindElement("/ProductCollection/0");
					this.getView().addDependent(this._oPopover);
				}
				var idClient = this.getView().byId("SimpFormClientEdit");
				this.getModel().metadataLoaded().then(function() {
					var qtc = this.getModel();
					var oContextClients = qtc.createEntry("/Cmiclients", {
						properties: oClientObj
					});
					idClient.setBindingContext(oContextClients);
				}.bind(this));
				oViewModel.setProperty("/viewDisplay", true);
				oViewModel.setProperty("/NMCNum", oClientObj.Clientk);
				this.addKnownParties();
				this._oNMatterReqest.close();
			} else {
				var cObj = this.getBindingContextbyId("idClientDetailsNew").getObject();
				if (!this.getContactsValidated(cObj)) {
					return;
				}
				var Email = cObj.Email;
				var oError = this.getModel("ErrorShow");
				oError.setProperty("/vEmail", "None");
				if (!validateEmail(Email)) {
					oError.setProperty("/vEmail", "Error");
					sap.m.MessageToast.show("Enter valid Email Id.");
					return;
				}
				this.getModel("TempModel").setData(cObj);
				var Srchid = this.getModel("worklistView").getProperty("/Searchid");
				var CmiId = this.getModel("worklistView").getProperty("/CmiId");
				if(Srchid===""){
				this.getRouter().navTo("NewClientNewMatter", null, true);
				}else{
					this.getRouter().navTo("NewClientNewMatterConflict",{Cmino:CmiId,Searchid:Srchid}, true);
				}
			}
		},
		onPersoButtonPressed: function() {
			this._oTPC = new TablePersoController({
				table: this.getView().byId("ConflictSearchTableId"),
				componentName: "cminewrequest",
				persoService: PersoService
			});
			this._oTPC.openDialog();
		},
		getContactsValidated: function(oClientData) {
			var sFlag = true;
			for (var key in oClientData) {
				if (oClientData.hasOwnProperty(key)) {
					if (key === "Addr2" || key === "Nstandardterms" || key === "__metadata") {
						continue;
					}
					var oError = this.getModel("ErrorShow");
					var Field = formatter.getKeyField(key);
					if (oClientData[key] === "") {
						if (Field) {
							oError.setProperty("/" + Field, "Error");
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		onCloseDialog: function(oEvent) {
			if (!oEvent.mParameters.origin) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.backToPreviousApp();
			}
		},
		addNewAltPayer: function() {
			if (!this._oAltPayer) {
				this._oAltPayer = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.AltPayer", this);
				this.getView().addDependent(this._oAltPayer);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAltPayer);
			this._oAltPayer.open();
		},
		beforeAltPayer: function() {
			this.addAltPayerDialog();
			var oAlterData = this.byId("idAlterDetails").getBindingContext().getObject();
			for (var key in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key === "__metadata") {
						continue;
					}
					var oError = this.getModel("ShowAlterError");
					var Field = formatter.getAlterKeyField(key);
					if (Field) {
						oError.setProperty("/" + Field, "None");
					}
				}
			}
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var keyI = oIconTabBarKey.split("--")[ln - 1];
			var idAltPayer = this.byId("idAlterDetails");
			var oContextAltPayer = idAltPayer.getBindingContext();
			var a = oContextAltPayer.getModel();
			if (keyI === "BP") {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			} else {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "PY");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "Payer");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "X");
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		addAltPayerDialog: function() {
			var qtc = this.getModel();
			var idAltPayer = this.byId("idAlterDetails");
			var oContextAltPayer = qtc.createEntry("/Cmialtpayers", {});
			var a = oContextAltPayer.getModel();
			a.setProperty(oContextAltPayer.getPath() + "/Alternatepayer", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayername", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr1", "");
			a.setProperty(oContextAltPayer.getPath() + "/Isnew", "X");
			a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerzip", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercityk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerperc", "0.00");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountryk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstate", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountry", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerphone", "");
			a.setProperty(oContextAltPayer.getPath() + "/Cmino", "$000000001");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerseq", "0001");
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var key = oIconTabBarKey.split("--")[ln - 1];
			if (key === "BP") {
				this.byId("idPayerSelect").setEnabled(true);
			} else {
				this.byId("idPayerSelect").setEnabled(false);
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		onCloseAltData: function() {
			this._oAltPayer.close();
		},
		onAddMatterBP: function() {
			var that = this;
			var objArray = [];
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "",
				"Altpayeraddr2": "",
				"Altpayercityk": "",
				"Altpayerperc": "0.00",
				"Partnertype": "",
				"Partnertypedesc": "",
				"Isnew": "",
				"IsMulti": "",
				"Altpayerphone": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			objArray.push(obj);
			var oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindMatterBPTable(oContextMatterBP);
		},
		bindMatterBPTable: function(oContextMatterBP, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var addButton = new sap.m.Button({
			//	text: "Add BP",
				icon: "sap-icon://add",
				enabled: "{worklistView>/editScreen}",
				press: this.onAddMatterBP.bind(this),
				type: "Emphasized"
			});
			var idBillPartenr = this.byId("FormChange354BP");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnertypedesc}",
						editable: bEdit,
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Alternatepayer}",
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'worklistView>/editScreen'
							}],
							formatter: formatter.checkStatus
						},
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedBP.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Altpayername}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextMatterBP);
			idBillPartenr.addItem(oColumnListItem);
			this.updateMatterBP(idBillPartenr);
		},
		updateMatterBP: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleDeleteBP: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormChange354BP");
			this._removeMatterBPCondition(oTable);
		},
		_removeMatterBPCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddMatterBP();
			}
			this.updateMatterBP(oTable);
		},
		changeBillPartnerDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			if (path === "Parvwdesc") {
				model.setProperty(sPath + "/Partnername", "");
				model.setProperty(sPath + "/Parnr", "");
				model.setProperty(sPath + "/Addr1", "");
				model.setProperty(sPath + "/Addr2", "");
				model.setProperty(sPath + "/Cityk", "");
				model.setProperty(sPath + "/Statek", "");
				model.setProperty(sPath + "/Countryk", "");

			}
			if (path === "Partnertypedesc") {
				model.setProperty(sPath + "/Alternatepayer", "");
				model.setProperty(sPath + "/Altpayername", "");
				model.setProperty(sPath + "/Altpayercountry", "");
				model.setProperty(sPath + "/Altpayeraddr1", "");
				model.setProperty(sPath + "/Altpayeraddr2", "");
				model.setProperty(sPath + "/Altpayercityk", "");
				model.setProperty(sPath + "/Altpayerstatek", "");
				model.setProperty(sPath + "/Altpayercountryk", "");
			}
		},
		onPressComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oEvt = evt.getSource();
			if (!this._oKPNotes) {
				this._oKPNotes = sap.ui.xmlfragment("cminewrequest.fragments.KPNotes", this);
				oView.addDependent(this._oKPNotes);
			}
			this._oKPNotes.setBindingContext(oEvt.getBindingContext());
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPNotes);
			this._oKPNotes.openBy(evt.getSource());
		},
		onMultiComment: function(evt) {
			var oEvt = evt.getSource();
			var sPath = this._oKPNotes.getBindingContext().sPath;
			var path = oEvt.getBindingPath("value");
			var value = oEvt.getValue();
			// set Value for Client Details Context
			var oMatterModel = oEvt.getBindingContext().getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
		},
		handleCommentAdd: function() {
			this._oKPNotes.close();
		},

		onPressIMparties: function(evt, oView) {
			//open the matter attachment
			if (!oView) {
				oView = this.getView();
			}

			if (!this._oKPImportParties) {
				this._oKPImportParties = sap.ui.xmlfragment("cminewrequest.fragments.CMIAttachment", this);
				oView.addDependent(this._oKPImportParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPImportParties);
			this._oKPImportParties.open();
		},
		onCloseAttchDailogDialog: function() {
			this._oKPImportParties.close();
		},

		onNavBack: function() {
			/*	var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
					history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: "#Shell-home"
						}
					});
				}*/
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: "#Shell-home"
				}
			});
		},

		onPressPopinDispBtn: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oViewMode = oView.getModel("worklistView");
			var flag = oViewMode.getProperty("/PopInDisplay");
			if (flag) {
				oViewMode.setProperty("/PopInDisplay", false);
			} else {
				oViewMode.setProperty("/PopInDisplay", true);
			}
		},
		onPressAddParty: function() {
			var oViewModel = this.getModel("worklistView"),
				odata = {
					Name: oViewModel.getProperty("/Name"),
					Rolek: oViewModel.getProperty("/Role"),
					Designation: oViewModel.getProperty("/Designation"),
					Classificationk: oViewModel.getProperty("/classfication")
				};
			var viewMod = this.getModel("NRequestView");
			var CCMod = viewMod.getProperty("/KnownParties");
			CCMod.push(odata);
			viewMod.refresh();
			oViewModel.setProperty("/Name", "");
			oViewModel.setProperty("/Role", "");
			oViewModel.setProperty("/Designation", "");
			oViewModel.setProperty("/classfication", "");
		},

		//below code added on 05/Jan/18
		onShowHideClientDetail: function(oEvent) {
			var bVal = oEvent.getParameter("pressed"),
				oViewModel = this.getModel("worklistView"),
				oWizard = this.getView().byId("NRWizardEC");

			if (!bVal) {
				oViewModel.setProperty("/expandClientDetails", true);
				oWizard.setHeight("75%");
			} else {
				oViewModel.setProperty("/expandClientDetails", false);
				oWizard.setHeight("91%");
			}
		},

		conflictRequestDialog: function() {
			if (!this._ConflictReqest) {
				this._ConflictReqest = sap.ui.xmlfragment("cminewrequest.fragments.NMConflictReqest", this);
				this.getView().addDependent(this._ConflictReqest);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._ConflictReqest);
			this._ConflictReqest.open();
		},

		handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleStep: function(evt) {
			var step = true;
			var model = this.getModel("worklistView");
			if (model.getProperty("/editScreen")) {
				if (!this.getModel("worklistView").getProperty("/CmiId")) {
					this.onStepSubmit(step);
				}
				if (evt.getParameter("index") === 2) {
					model.setProperty("/submitButton", true);
				}
			}
		},
		onStepSubmit: function() {
			var sPath = "/Cmihdrs";
			var oModel = this.getModel(),
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var clientData = {
				Cmino: "$000000001",
				Matterk:"$000000001",
				Clientk: this.getModel("worklistView").getProperty("/NMCNum"),
				Requesttime: "0",
				Cmirequesttype: "ECNM",
				Changedtime: "0",
				Clients: [this._readClientMatterDetails().clients],
				ConsiderationsN: []
			};
			var that = this;
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					that.getModel("worklistView").setProperty("/CmiId", oResponse.data.Cmino);
					//	that.getModel("worklistView").setProperty("/userId", oResponse.data.Requestuserk);
					//	that.getModel("worklistView").setProperty("/userName", oResponse.data.Requestuser);
					var dataC = oResponse.data.ConsiderationsN;
					var businessData = [],
						riskData = [];
					for (var j = 0; j < dataC.results.length; j++) {
						if (dataC.results[j].Attributetypek === "02") {
							riskData.push(dataC.results[j]);
						} else {
							businessData.push(dataC.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					if (dataC) {
						oJsonBModel.setData({
							ConsiData: businessData
						});
						that.getView().setModel(oJsonBModel, "jsonConsiModel");
						oJsonRModel.setData({
							RiskData: riskData
						});
						that.getView().setModel(oJsonRModel, "riskConsiModel");
					} else {
						oJsonBModel.setData({
							ConsiData: []
						});
						that.getView().setModel(oJsonBModel, "jsonConsiModel");
						oJsonRModel.setData({
							RiskData: []
						});
						that.getView().setModel(oJsonRModel, "riskConsiModel");
					}
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		handleConfirm: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var oModel = this._oModel,
				oClient = oModel.getProperty("/Clients")[0],
				aKnownParties = [];

			if (aContexts && aContexts.length) {
				var bValSetClient = true;
				aContexts.map(function(oContext) {
					var oClientObject = oContext.getObject();
					if (oClientObject.Role === "Client" && bValSetClient) {
						oClient.Name = oClientObject.Name;
						bValSetClient = false;
					} else {
						aKnownParties.push(oClientObject);
					}
				});
				this.getView().bindElement("NRequestView>/Clients/0");
				oModel.setProperty("/KnownParties", aKnownParties);
			}
			oModel.refresh();
			oEvent.getSource().getBinding("items").filter([]);
		},

		handleClose: function() {
			var oViewModel = this.getView().getModel("worklistView");
			this.msgPopover();
			oViewModel.setProperty("/conflictMsgVisible", true);
		},

		onSwitchRequest: function(oEvent) {
			var oState = oEvent.getParameter("state"),
				oViewModel = this.getModel("worklistView");

			if (oState) {
				this.getView().byId("CliSelID").setSelectedKey("");
				oViewModel.setProperty("/LbLMsgp", "Please click \"Submit\" to begin a Existing Client New Matter Request");
				oViewModel.setProperty("/selectCliVisible", false);
				oViewModel.setProperty("/submitEnable", true);
			} else {
				oViewModel.setProperty("/LbLMsgp", "Please click \"Submit\" to begin a New Client New Matter Request");
				oViewModel.setProperty("/selectCliVisible", false);
				oViewModel.setProperty("/submitEnable", true);
			}
		},

		onClientSelction: function(oEvent) {
			var oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/submitEnable", true);
		},

		//Excell Import
		handleUpload: function() {
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file);

			}
		},
		_import: function(file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					//	xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					if (sheetData[0].Name === undefined && sheetData[0].Notes === undefined && sheetData[0].Classification === undefined &&
						sheetData[0].Role === undefined && sheetData[0].Designation === undefined && sheetData[0].Classificationk === undefined &&
						sheetData[0].Rolek === undefined && sheetData[0].Designationk === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i].Classification === undefined) {
							sheetData[i].Classification = "";
						}
						if (sheetData[i].Role === undefined) {
							sheetData[i].Role = "";
						}
						if (sheetData[i].Designation === undefined) {
							sheetData[i].Designation = "";
						}
						if (sheetData[i].Classificationk === undefined) {
							sheetData[i].Classificationk = "";
						}
						if (sheetData[i].Rolek === undefined) {
							sheetData[i].Rolek = "";
						}
						if (sheetData[i].Designationk === undefined) {
							sheetData[i].Designationk = "";
						}
						if (sheetData[i].Name === undefined) {
							sheetData[i].Name = "";
						}
						if (sheetData[i].Notes === undefined) {
							sheetData[i].Notes = "";
						}
					}
					that.abd(sheetData);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		abd: function(newData) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var Designation = data.Designation.trim();
				var Name = data.Name.trim();
				var Notes = data.Notes.trim();
				var Classification = data.Classification.trim();
				var Role = data.Role.trim();
				var Classificationk = data.Classificationk.trim();
				var Rolek = data.Rolek.trim();
				var Designationk = data.Designationk.trim();
				var obj = {
					"Cmino": "$000000001",
					"Designation": Designation,
					"Knownpartyseq": "",
					"Classification": Classification,
					"Rolek": Rolek,
					"Designationk": Designationk,
					"Classificationk": Classificationk,
					"Role": Role,
					"Name": Name,
					"Comments": "",
					"Hasconflict": ""
						//"Notes": Notes,
						//"Action": "M"
				};
				if (Designation === "" && Name === "" && Role === "" && Classification) {
					continue;
				} else {
					objArray.push(obj);
					var qtc = this.getModel();
					var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
						properties: obj
					});
					this.bindKnownTable(oContextKnownParties);
				}
			}

			var aKnownParties = this.getModel("NRequestView").getProperty("/Knownparties");
			this.getModel("NRequestView").setProperty("/Knownparties", aKnownParties.concat(objArray));
		},
		changeAltDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idAlterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
			this.onAlterMandatory("ch");
		},
		onDeleteKnownParties: function(oEvent) {
			var aData = this.getModel("NRequestView").getProperty("/Knownparties/results"),
				oSrc = oEvent.getSource(),
				item = oEvent.getParameter("listItem"),
				index = oSrc.indexOfItem(item);
			aData.splice(index, 1);
			this.getModel("NRequestView").refresh();
		},
		updateFinishedTableResult: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sTotal = oEvent.getParameter("total");
			var oKwnPartiesModel = oSrc.getModel("NRequestView");
			for (var i = 0; i < sTotal; i++) {
				oKwnPartiesModel.setProperty("/Knownparties/results/" + i + "/Knownpartyseq", this.formatter.sequenceNumber(i + 1));
			}
		},
		onPresshandleWizard: function(evt) {
			if (evt.getSource().getPressed()) {
				evt.getSource().setText("Client Details");
				this.byId("NRWizard").setVisible(false);
			} else {
				evt.getSource().setText("Attachment / Comments");
				this.byId("NRWizard").setVisible(true);
			}
		},
		_readClientMatterDetails: function() {
			var CmiId = this.getModel("worklistView").getProperty("/CmiId"),
				matterData, AlterData,
				matterPath = this.getBindingContextbyId("idMatterDetails").sPath,
				matterModel = this.getBindingContextbyId("idMatterDetails").getModel();
			var clientPath = this.getBindingContextbyId("SimpFormClientEdit").sPath,
				clientModel = this.getBindingContextbyId("SimpFormClientEdit").getModel(),
				clientObj = clientModel.getProperty(clientPath);
			var clientData = {
				"Cmino": CmiId,
				"Clientk": clientObj.Clientk,
				"Client": clientObj.Client,
				"Classificationk": clientObj.Classificationk,
				"Classification": clientObj.Classification,
				"Addr1": clientObj.Addr1,
				"Addr2": clientObj.Addr2,
				"City": clientObj.City,
				"Statek": clientObj.Statek,
				"State": clientObj.State,
				"Zipcode": clientObj.Zipcode,
				"Countryk": clientObj.Countryk,
				"Country": clientObj.Country,
				"Bofficek": clientObj.Bofficek,
				"Boffice": clientObj.Boffice,
				"Email": clientObj.Email,
				"Nstandardterms": clientObj.Nstandardterms,
				"Vkorg": clientObj.Vkorg,
				"Vkorgdesc": clientObj.Vkorgdesc
			};
			matterModel.setProperty(matterPath + "/Cmino", CmiId);
			matterData = matterModel.getProperty(matterPath);

			/*var AlterPath = this.getBindingContextbyId("idAlterDetails").sPath,
				AlterModel = this.getBindingContextbyId("idAlterDetails").getModel();
			AlterModel.setProperty(AlterPath + "/Cmino", CmiId);
			AlterData = AlterModel.getProperty(AlterPath);
			delete(AlterData.__metadata);*/
			delete(matterData.__metadata);

			//  Detail Section Known parties
			var knowParty = this.byId("idKnownParty"),
				Knownparties = [];
			for (var i = 0; i < knowParty.getItems().length; i++) {
				var oItem = knowParty.getItems()[i];
				var sSequence = this.formatter.sequenceNumber(i + 1);
				var KnownPath = oItem.getBindingContext().sPath,
					KnownModel = oItem.getBindingContext().getModel();
				var obj = {
					"Cmino": CmiId,
					"Designation": KnownModel.getProperty(KnownPath + "/" + "Designation"),
					"Knownpartyseq": sSequence,
					"Classification": KnownModel.getProperty(KnownPath + "/" + "Classification"),
					"Rolek": KnownModel.getProperty(KnownPath + "/" + "Rolek"),
					"Designationk": KnownModel.getProperty(KnownPath + "/" + "Designationk"),
					"Classificationk": KnownModel.getProperty(KnownPath + "/" + "Classificationk"),
					"Role": KnownModel.getProperty(KnownPath + "/" + "Role"),
					"Name": KnownModel.getProperty(KnownPath + "/" + "Name"),
					"Comments": KnownModel.getProperty(KnownPath + "/" + "Comments"),
					"Hasconflict": KnownModel.getProperty(KnownPath + "/" + "Hasconflict")
				};
				Knownparties.push(obj);
			}
			var WOffice = this.byId("FormDisplay354WO"),
				aWOffice = [];
			for (var w = 0; w < WOffice.getItems().length; w++) {
				var oOItem = WOffice.getItems()[w];
				var OfficePath = oOItem.getBindingContext().sPath,
					OfficeModel = oOItem.getBindingContext().getModel();
				var wObj = {
					"Cmino": CmiId,
					"OfficeCode": OfficeModel.getProperty(OfficePath + "/" + "OfficeCode"),
					"OfficeName": OfficeModel.getProperty(OfficePath + "/" + "OfficeName"),
					"CompCode": OfficeModel.getProperty(OfficePath + "/" + "CompCode"),
					"CompanyName": OfficeModel.getProperty(OfficePath + "/" + "CompanyName"),
					"Country": OfficeModel.getProperty(OfficePath + "/" + "Country"),
					"CountryName": OfficeModel.getProperty(OfficePath + "/" + "CountryName")
				};
				aWOffice.push(wObj);
			}
			// Detail Working Office
			var idBFinance = this.byId("FormChange354BF1"),
				aBFinance = [];
			for (var b = 0; b < idBFinance.getItems().length; b++) {
				var oBItem = idBFinance.getItems()[b];
				var oBFinancePath = oBItem.getBindingContext().sPath,
					oBFinanceModel = oBItem.getBindingContext().getModel();
				var oBFinance = {
					"Cmino": CmiId,
					"Alternatepayer": oBFinanceModel.getProperty(oBFinancePath + "/" + "Alternatepayer"),
					//	"Altpayeraddr1": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					//	"Altpayeraddr2": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayercityk": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercityk"),
					"Altpayercountry": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercountry"),
					"Altpayercountryk": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercountryk"),
					"Altpayername": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayername"),
					"Partnertypedesc": oBFinanceModel.getProperty(oBFinancePath + "/" + "Partnertypedesc"),
					"Altpayerperc": (oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerperc") || "0.00"),
					"Altpayerseq": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerseq"),
					"Partnertype": oBFinanceModel.getProperty(oBFinancePath + "/" + "Partnertype"),
					"Isnew": oBFinanceModel.getProperty(oBFinancePath + "/" + "Isnew"),
					"IsMulti": oBFinanceModel.getProperty(oBFinancePath + "/" + "IsMulti"),
					"Altpayerstate": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerstate"),
					"Altpayerstatek": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerstatek"),
					"Altpayerzip": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerzip"),
					"Altpayeraddr1": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					"Altpayeraddr2": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayerphone": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerphone")
				};
				aBFinance.push(oBFinance);
			}
			var idMatterBPartner = this.byId("FormChange354BP");
			for (var mbp = 0; mbp < idMatterBPartner.getItems().length; mbp++) {
				var oMBPItem = idMatterBPartner.getItems()[mbp];
				var oMBPPath = oMBPItem.getBindingContext().sPath,
					oMBPModel = oMBPItem.getBindingContext().getModel();
				var oMBP = {
					"Cmino": CmiId,
					"Alternatepayer": oMBPModel.getProperty(oMBPPath + "/" + "Alternatepayer"),
					//	"Altpayeraddr1": oMBPModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					//	"Altpayeraddr2": oMBPModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayercityk": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercityk"),
					"Altpayercountry": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercountry"),
					"Altpayercountryk": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercountryk"),
					"Altpayername": oMBPModel.getProperty(oMBPPath + "/" + "Altpayername"),
					"Partnertypedesc": oMBPModel.getProperty(oMBPPath + "/" + "Partnertypedesc"),
					"Altpayerperc": (oMBPModel.getProperty(oMBPPath + "/" + "Altpayerperc") || "0.00"),
					"Altpayerseq": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerseq"),
					"Partnertype": oMBPModel.getProperty(oMBPPath + "/" + "Partnertype"),
					"Isnew": oMBPModel.getProperty(oMBPPath + "/" + "Isnew"),
					"IsMulti": oMBPModel.getProperty(oMBPPath + "/" + "IsMulti"),
					"Altpayerstate": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerstate"),
					"Altpayerstatek": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerstatek"),
					"Altpayerzip": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerzip"),
					"Altpayerphone": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerphone"),
					"Altpayeraddr1": oMBPModel.getProperty(oMBPPath + "/" + "Altpayeraddr1"),
					"Altpayeraddr2": oMBPModel.getProperty(oMBPPath + "/" + "Altpayeraddr2")
				};
				aBFinance.push(oMBP);
			}
			/*	var Alterswitch = this.byId("idAlterSwitch");
				if (Alterswitch.getState()) {
					aBFinance.push(AlterData);
				}*/
			for (var oBFS = 0; oBFS < aBFinance.length; oBFS++) {
				aBFinance[oBFS].Altpayerseq = this.formatter.sequenceNumber(oBFS + 1);
			}

			// Comments
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var oMatterIndetail = this.getBindingContextbyId("MatterInDetailsStep").getObject();
			delete(oMatterIndetail.__metadata);

			if (matterData.Zzplfaz != null && matterData.Zzplfaz !== "" && typeof(matterData.Zzplfaz) ===
				"string") {
				matterData.Zzplfaz = matterData.Zzplfaz + "T00:00:00";
			} else {
				if (matterData.Zzplfaz != null) {
					matterData.Zzplfaz = dateFormat.format(matterData.Zzplfaz) + "T00:00:00";
				} else {
					matterData.Zzplfaz = null;
				}
			}
			if (matterData.Zzplsez != null && matterData.Zzplsez !== "" && typeof(matterData.Zzplsez) ===
				"string") {
				matterData.Zzplsez = matterData.Zzplsez + "T00:00:00";
			} else {
				if (matterData.Zzplsez != null) {
					matterData.Zzplsez = dateFormat.format(matterData.Zzplsez) + "T00:00:00";
				} else {
					matterData.Zzplsez = null;
				}
			}
			if (oMatterIndetail.ZztcsetValidfrom != null && oMatterIndetail.ZztcsetValidfrom !== "" && typeof(oMatterIndetail.ZztcsetValidfrom) ===
				"string") {
				oMatterIndetail.ZztcsetValidfrom = oMatterIndetail.ZztcsetValidfrom + "T00:00:00";
			} else {
				if (oMatterIndetail.ZztcsetValidfrom != null) {
					oMatterIndetail.ZztcsetValidfrom = dateFormat.format(oMatterIndetail.ZztcsetValidfrom) + "T00:00:00";
				} else {
					oMatterIndetail.ZztcsetValidfrom = null;
				}
			}
			if (oMatterIndetail.Zzipappldate != null && oMatterIndetail.Zzipappldate !== "" && typeof(oMatterIndetail.Zzipappldate) ===
				"string") {
				oMatterIndetail.Zzipappldate = oMatterIndetail.Zzipappldate + "T00:00:00";
			} else {
				if (oMatterIndetail.Zzipappldate != null) {
					oMatterIndetail.Zzipappldate = dateFormat.format(oMatterIndetail.Zzipappldate) + "T00:00:00";
				} else {
					oMatterIndetail.Zzipappldate = null;
				}
			}
			if (oMatterIndetail.Zzipregdt != null && oMatterIndetail.Zzipregdt !== "" && typeof(oMatterIndetail.Zzipregdt) === "string") {
				oMatterIndetail.Zzipregdt = oMatterIndetail.Zzipregdt + "T00:00:00";
			} else {
				if (oMatterIndetail.Zzipregdt != null) {
					oMatterIndetail.Zzipregdt = dateFormat.format(oMatterIndetail.Zzipregdt) + "T00:00:00";
				} else {
					oMatterIndetail.Zzipregdt = null;
				}
			}
			if (oMatterIndetail.ZzacsetValidfrom != null && oMatterIndetail.ZzacsetValidfrom !== "" && typeof(oMatterIndetail.ZzacsetValidfrom) ===
				"string") {
				oMatterIndetail.ZzacsetValidfrom = oMatterIndetail.ZzacsetValidfrom + "T00:00:00";
			} else {
				if (oMatterIndetail.ZzacsetValidfrom != null) {
					oMatterIndetail.ZzacsetValidfrom = dateFormat.format(oMatterIndetail.ZzacsetValidfrom) + "T00:00:00";
				} else {
					oMatterIndetail.ZzacsetValidfrom = null;
				}
			}
			if (!oMatterIndetail.Zzefees) {
				oMatterIndetail.Zzefees = "0.00";
			}
			if (!oMatterIndetail.Zzecost) {
				oMatterIndetail.Zzecost = "0.00";
			}
			if (!oMatterIndetail.Zzetotal) {
				oMatterIndetail.Zzetotal = "0.00";
			}
			if (!oMatterIndetail.Zzcompletion) {
				oMatterIndetail.Zzcompletion = "0.00";
			}
			if (!oMatterIndetail.Zzcap) {
				oMatterIndetail.Zzcap = "0.00";
			}
			oMatterIndetail.Cmino = CmiId;
			var dateTimeFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddhhmmss"
			});
			var oSRemarks = this.getView().getModel("CommentsModel");
			var oSRemarkData = oSRemarks.getProperty("/CommentSet");
			var DataComments = [];
			for (var so = 0; so < oSRemarkData.length; so++) {
				var sSRSequence = this.formatter.sequenceNumber(so + 1);
				var oSRobj = {
					Cmino: CmiId,
					//	CommentType: oSRemarkData[so].CommentType,
					CommentType: "CI",
					Sequence: sSRSequence,
					UserComment: oSRemarkData[so].UserComment,
					Addedby: oSRemarkData[so].Addedby,
					Addedbyk: oSRemarkData[so].Addedbyk,
					// 	Addedon: this.formatter.dateFormat.format(oRemarkData[co].Addedon)
					Addedon: typeof(oSRemarkData[so].Addedon) === "string" ? oSRemarkData[so].Addedon : dateTimeFormat.format(oSRemarkData[so].Addedon)
				};
				DataComments.push(oSRobj);
			}
			// Display All details
			var clientMatterDetails = {
				matterData: matterData,
				Altpayers: aBFinance,
				Knownparties: Knownparties,
				clients: clientData,
				WOffice: aWOffice,
				MatterInDetail: oMatterIndetail,
				Comments: DataComments
			};
			return clientMatterDetails;
		},
		Onpresssave: function() {
			var sPath = "/Cmihdrs";
			var oModel = this.getModel();
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var CmiId = this.getModel("worklistView").getProperty("/CmiId");
			var ClientId = this.getModel("worklistView").getProperty("/NMCNum");
			var Srchid = this.getModel("worklistView").getProperty("/Searchid");
				var bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			var consiData = [];
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = CmiId;
				delete(bconsiData[c].__metadata);
			}
			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = CmiId;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);
			var clientData = {
				Cmino: CmiId,
				Searchid:Srchid,
				Clientk: ClientId,
				Requesttime: "0",
				Cmirequesttype: "ECNM",
				Changedtime: "0",
				Clients: [this._readClientMatterDetails().clients],
				Knownparties: this._readClientMatterDetails().Knownparties,
				Matters: [this._readClientMatterDetails().matterData],
				Matterdetails: [this._readClientMatterDetails().MatterInDetail],
				Offices: this._readClientMatterDetails().WOffice,
				Altpayers: this._readClientMatterDetails().Altpayers,
				Comments: this._readClientMatterDetails().Comments,
				ConsiderationsN: consiData
			};
			var that = this;
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var cmiNo = oResponse.data.Cmino;
						var dataC = oData.ConsiderationsN;
					var businessData = [],
						riskData = [];
				if(dataC){
					for (var j = 0; j < dataC.results.length; j++) {
						if (dataC.results[j].Attributetypek === "02") {
							riskData.push(dataC.results[j]);
						} else {
							businessData.push(dataC.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					oJsonBModel.setData({
						ConsiData: businessData
					});
					that.getView().setModel(oJsonBModel, "jsonConsiModel");
					oJsonRModel.setData({
						RiskData: riskData
					});
					that.getView().setModel(oJsonRModel, "riskConsiModel");
				}
					that.getModel("worklistView").setProperty("/CmiId", cmiNo);
					that.getModel("worklistView").setProperty("/EditCon", oResponse.data.Edit);
					var msg = "Client matter intake " + cmiNo + " has been created successfully,Do you want to continue?";
					sap.m.MessageBox.show(msg, {
						icon: "INFORMATION",
						title: "Information",
						//	actions: [sap.m.MessageBox.Action.OK],
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction == "YES") {

								//
							} else {
								that.onNavBack();
							}
							//	window.history.go(-1);
						}
					});

				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		OnpressSubmit: function() {
			/*			if (!this.getMatterValidated()) {
							this.byId("NRWizardEC").goToStep(this.byId("MatterDetail"));
							sap.m.MessageToast.show("Matter Details General Tab: Please fill mandatory fields.");
							return;
						}*/
			var sPath = "/Cmihdrs";
			var oModel = this.getModel();
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var CmiId = this.getModel("worklistView").getProperty("/CmiId");
			var ClientId = this.getModel("worklistView").getProperty("/NMCNum");
			var Srchid = this.getModel("worklistView").getProperty("/Searchid");
			var bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			var consiData = [];
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = CmiId;
				delete(bconsiData[c].__metadata);
			}
			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = CmiId;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);
			var clientData = {
				Action:"SUBM",
				Cmino: CmiId,
				Searchid:Srchid,
				Clientk: ClientId,
				Requesttime: "0",
				Cmirequesttype: "ECNM",
				Changedtime: "0",
				Clients: [this._readClientMatterDetails().clients],
				Knownparties: this._readClientMatterDetails().Knownparties,
				Matters: [this._readClientMatterDetails().matterData],
				Matterdetails: [this._readClientMatterDetails().MatterInDetail],
				Offices: this._readClientMatterDetails().WOffice,
				Altpayers: this._readClientMatterDetails().Altpayers,
				Comments: this._readClientMatterDetails().Comments,
				ConsiderationsN: consiData
			};
			var that = this;
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var cmiNo = oResponse.data.Cmino;
					var msg = "Client matter intake " + cmiNo + " has been Submitted successfully, Do you want to continue to edit?";
					sap.m.MessageBox.show(msg, {
						icon: "INFORMATION",
						title: "Information",
						//	actions: [sap.m.MessageBox.Action.OK],
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction == "YES") {
								//	that._createnewEntry();
								//that._readOData();// _readOData
								//	var oOveriewDataModel = new sap.ui.model.json.JSONModel(data);
								//	that.getView().setModel(oOveriewDataModel, "NRequestView");
								/*		var oViewModel;
										// Model used to manipulate control states
										oViewModel = new JSONModel({
											LbLMsgp: that.getResourceBundle().getText("LbLMsgp"),
											tableBusyDelay: 0,
											visbl: true,
											editable: false,
											altVisible: false,
											classfication: "",
											Role: "",
											Designation: "",
											Name: "",
											PopInDisplay: false,
											PopInDisplaycomments: false,
											conflictMsgVisible: false,
											selectCliVisible: false,
											submitEnable: false,
											expandClientDetails: true,
											Notes: "",
											viewDisplay: true,
											CmiId: "",
											state: false,
											Astate: false
										});
										that.setModel(oViewModel, "worklistView");*/
								//	that._onInitialize();
								//	that._readOData();
								//	that.WizardTitle = "Known Parties";
								//	that.onFilterComments(that.WizardTitle);
								that.byId("NRWizardEC").goToStep(that.byId("KnownParties"));
								that.byId("NRWizardEC").discardProgress(that.byId("KnownParties"));
							} else {
								that.onNavBack();
							}
							//	window.history.go(-1);
						}
					});

				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		onCancelSubmit: function() {
			/*	var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
					history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: "#Shell-home"
						}
					});
				}*/
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: "#Shell-home"
				}
			});
		},
		BusinessListFactory: function(sId, oContext) {
			var qType = oContext.getProperty("Questiontypek");
			var oControl = null;
			var mData = {
				selected: [],
				items: [{
					key: "0",
					text: "Answer 1"
				}, {
					key: "1",
					text: "Answer 2"
				}, {
					key: "2",
					text: "Answer 3"
				}, {
					key: "3",
					text: "Answer 4"
				}]
			};
			var oItemTemplate = new sap.ui.core.Item({
				key: "{key}",
				text: "{text}"
			});
			var oModel = new sap.ui.model.json.JSONModel(mData);
			oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'jsonConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchConsiChange.bind(this),
				enabled: "{worklistView>/editScreen}"
			});
			/*	switch (qType) {
					case "01":
						oControl = new sap.m.Switch({});
						break;
					case "02":
						oControl = new sap.m.MultiComboBox({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							},
							selectedKeys: {
								path: "/selected",
								template: "{selected}"
							}
						});
						oControl.setModel(oModel);
						break;
					case "03":
						oControl = new sap.m.Select({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							}
						});
						oControl.setModel(oModel);
						break;
					case "04":
						oControl = new sap.m.RangeSlider({
							width: "20rem",
							height: "3rem",
							min: 0,
							max: 30,
							range: [5, 20],
							enableTickmarks: true
								//	scale: new sap.m.ResponsiveScale({tickmarksBetweenLabels: 3})
						});
						break;
					default:
						oControl = new sap.m.Input({
							width: "12rem"
						});
				}*/
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'jsonConsiModel>QuestionText'}, {path: 'jsonConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		riskListFactory: function() {
			var oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'riskConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchRiskChange.bind(this),
				enabled: "{worklistView>/editScreen}"
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'riskConsiModel>QuestionText'}, {path: 'riskConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		handleSwitchRiskChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("riskConsiModel").getPath();
			var ConsiInModel = source.getBindingContext("riskConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		handleSwitchConsiChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("jsonConsiModel").getPath();
			var ConsiInModel = source.getBindingContext("jsonConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		updateMatterWOButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleWOPayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormDisplay354WO");
			this._removeMatterWOCondition(oTable);
		},
		_removeMatterWOCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addWOOffice();
			}
			this.updateMatterWOButtons(oTable);
		},
		bindOffices: function(newData) {
			var idOffice = this.byId("FormDisplay354WO");
			idOffice.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmimatteroffices", {
					properties: newData[o]
				});
				this.bindWOOffice(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.addWOOffice();
			}
		},
		addWOOffice: function() {
			var that = this;
			var objArray = [];
			var aKnownParties = that.getModel("NRequestView").getProperty("/Altpayers1");
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"OfficeCode": "",
				"OfficeName": "",
				"CompCode": "",
				"CompanyName": "",
				"Country": "",
				"CountryName": ""
			};
			objArray.push(obj);
			that.getModel("NRequestView").setProperty("/Altpayers1", aKnownParties.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmimatteroffices", {
				properties: obj
			});
			that.bindWOOffice(oContextKnownParties);
		},
		changeOfficeTableDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},

		bindWOOffice: function(oContextKnownParties) {
			var idKnownParty = this.byId("FormDisplay354WO");
			var model = this.getModel("worklistView");
			var bEdit = true;
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
			//	text: "Add WO",
				enabled: "{worklistView>/editScreen}",
				press: this.addWOOffice.bind(this),
				type: "Emphasized"
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{OfficeName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CompanyName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CountryName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(c),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idKnownParty.addItem(oColumnListItem);
			this.updateMatterWOButtons(idKnownParty);
		},
		businessUpdate: function(evt) {
			var evtr = evt.getSource();
			for (var i = 0; i < evtr.getItems().length; i++) {
				if (i % 2 === 0) {
					evtr.getItems()[i].addStyleClass("colorR");
				}

			}
		},
		bindAlterData: function(newData) {
			var idAlterPayer = this.byId("FormChange354BF1");
			idAlterPayer.destroyItems();
			var idMatterBP = this.byId("FormChange354BP");
			idMatterBP.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
					properties: newData[o]
				});
				if (newData[o].IsMulti === "X") {
					this.bindAlterTable(oContextKnownParties);
				} else {
					this.bindMatterBPTable(oContextKnownParties);
				}
			}
			if (idAlterPayer.getItems().length < 1) {
				this.addAltPayer();
			}
			if (idMatterBP.getItems().length < 1) {
				this.onAddMatterBP();
			}
		},
		changeBillPartnerDDDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			var oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Partnertypedesc") {
					id = "Partnertype";
					description = "VTEXT";
					key = "PARVW";
				}
				if (path === "Parvwdesc") {
					id = "Parvw";
					description = "VTEXT";
					key = "PARVW";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		bindAlterTable: function(oContextKnownParties, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var addButton = new sap.m.Button({
			//	text: "Add Payer",
				icon: "sap-icon://add",
				press: this.addAltPayer.bind(this),
				enabled: "{worklistView>/enablePercent}",
				tooltip: "{i18n>detailBFLabelTooltip1}",
				type: "Emphasized"
			});
			var idAlterPayer = this.byId("FormChange354BF1");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnertypedesc}",
						editable: false,
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeAltTableDetails.bind(this),
						value: "{Alternatepayer}",
						valueListChanged: this.valueListChangedBP.bind(this),
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'worklistView>/editScreen'
							}],
							formatter: formatter.checkStatus
						}
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeAltTableDetails.bind(this),
						value: "{Altpayername}",
						editable: false
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					new sap.m.Input({
						value: "{Altpayerperc}",
						enabled: "{worklistView>/editScreen}",
						liveChange: this.liveChangePercent.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idAlterPayer.addItem(oColumnListItem);
			this.updateAlterBtn(idAlterPayer);
		},
		updateAlterBtn: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleDeletePayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var total = 0.00;
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var idBFinance = this.byId("FormChange354BF1");
			for (var b = 0; b < idBFinance.getItems().length; b++) {
				var oBItem = idBFinance.getItems()[b];
				var oBFinancePath = oBItem.getBindingContext().sPath,
					oBFinanceModel = oBItem.getBindingContext().getModel();
				var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerperc");
				var oTVal = oFloatFormat.format(oTPercent);
				if (!oTVal) {
					oTVal = "0.00";
				}
				total = total + oFloatFormat.parse(oTVal);
			}
			var model = this.getModel("worklistView");
			if (total >= 100) {
				model.setProperty("/enablePercent", false);
			} else {
				model.setProperty("/enablePercent", true);
			}
			this._removeAlterCondition(idBFinance);
		},
		_removeAlterCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addAltPayer();
			}
			this.updateMatterBP(oTable);
		},
		changeAltTableDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		liveChangePercent: function(oEvent) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			var idBFinance = this.byId("FormChange354BF1");

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
			var total;

			function validTotalPercent() {
				total = 0.00;
				for (var b = 0; b < idBFinance.getItems().length; b++) {
					var oBItem = idBFinance.getItems()[b];
					var oBFinancePath = oBItem.getBindingContext().sPath,
						oBFinanceModel = oBItem.getBindingContext().getModel();
					var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + path);
					var oTVal = oFloatFormat.format(oTPercent);
					if (!oTVal) {
						oTVal = "0.00";
					}
					total = total + oFloatFormat.parse(oTVal);
				}
			}
			validTotalPercent();

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100 || total > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);
					validTotalPercent();
					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			var valPercent = oFloatFormat.format(oPhone);
			var model = this.getModel("worklistView");
			if (valPercent >= 100 || total >= 100) {
				model.setProperty("/enablePercent", false);
			} else {
				model.setProperty("/enablePercent", true);
			}
			//	vPhone = oFloatFormat.format(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		liveMatterPercent: function(oEvent) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);

					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		addBP: function() {
			var oViewNewModel = this.getModel("NRequestView"),
				aClientData = oViewNewModel.getProperty("/BP");
			var obj = {
				"Addrln": "",
				"Name1": "",
				"ParnrNew": "",
				"Parvw": "",
				"Update": true,
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Partnertypedesc": "",
				"Altpayeraddr1": "Payer",
				"Altpayeraddr2": "",
				"Altpayerphone": "",
				"Altpayercityk": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerperc": "0.00",
				"Partnertype": "",
				"Isnew": "",
				"IsMulti": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			aClientData.push(obj);
			oViewNewModel.refresh();
		},
		addNewBP: function() {
			this.addNewAltPayer();
		},
		handleSelectPartnerTypeBP: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("selectedKey");
			var value = source.getSelectedItem().getKey();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			/*	if (oSelKey === "SP") {
				sap.m.MessageToast.show("CLIENT can be selected only once.");
				oEvent.getSource().setSelectedKey("PY");
			}*/
			/*	var oSelKey = oEvent.getSource().getSelectedKey();
		
				var oTable = this.getView().byId("FormChange354BP");
				var oModel = oTable.getModel("NRequestView");
				var modelData = oModel.getData();
				var aTable = [];

				for (var i = 0; i < modelData.BP.length; i++) {
					var value = modelData.BP[i];
					aTable.push(value);
				}
				var PModel = this.getModel("partner");
				var PData = PModel.getProperty("/results");
				var bdata = this.getModel("NRequestView").getProperty("/BP");
				for (var p = 0; p < PData.length; p++) {
					PData[p].vis = true;
				}
				for (var d = 0; d < bdata.length; d++) {
					var key = bdata[d].Parvw;
					PData.filter(function(sData) {
						if (sData.Parvw) {
							if (sData.Parvw === key) {
								sData.vis = false;
							}
						}
					});
				}
				PData.filter(function(sData) {
					if (sData.Parvw) {
						if (sData.Parvw === oSelKey) {

							sData.vis = false;
						}
					}
				});
				PModel.refresh();*/
			/*	var iIndex = oEvent.getSource().getParent().getIndex();
				if (aTable[this._oTblPrtnrNmbrRowBPBP].Update !== "I") {
				  aTable[this._oTblPrtnrNmbrRowBPBP].Update = "U";
				}
				if (aTable[iIndex].Update !== "I") {
					aTable[iIndex].Update = "U";
				}
				oModel.setData({
					modelData: aTable
				});*/
		},
		dataBP: function() {
			var data = {
				"results": [{
					Parvw: "",
					Vtext: "",
					vis: true
				}, {
					Parvw: "SP",
					Vtext: "Sold-to party",
					vis: true
				}, {

					Parvw: "BP",
					Vtext: "Bill-to party",
					vis: true
				}, {

					Parvw: "PY",
					Vtext: "Payer",
					vis: true
				}, {

					Parvw: "SH",
					Vtext: "Ship-to party",
					vis: true
				}, {

					Parvw: "Z2",
					Vtext: "Client Bill Contact",
					vis: true
				}, {

					Parvw: "Z3",
					Vtext: "Alt Billing Address",
					vis: true
				}, {

					Parvw: "Z4",
					Vtext: "Alt Bill Contact",
					vis: true
				}, {

					Parvw: "ZE",
					Vtext: "Bill Approver",
					vis: true
				}, {

					Parvw: "ZL",
					Vtext: "Matter Lead Partner",
					vis: true
				}, {

					Parvw: "ZO",
					Vtext: "Bill Reviewer",
					vis: true
				}, {
					Parvw: "ZS",
					Vtext: "Signing Officer",
					vis: true
				}]
			};
			var oPartnerModel = new sap.ui.model.json.JSONModel();
			this.setModel(oPartnerModel, "partner");
			oPartnerModel.setData(data);
		},
		onSubmitAltData: function() {
			var qtc = this.getModel();
			var cObj = this.getBindingContextbyId("idAlterDetails").getObject();
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var key = oIconTabBarKey.split("--")[ln - 1];
			if (!this.onAlterMandatory()) {
				return;
			}
			if (key === "BP") {
				var oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
					properties: cObj
				});
				this.bindMatterBPTable(oContextMatterBP, "New");
			} else {
				var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
					properties: cObj
				});
				this.bindAlterTable(oContextKnownParties, "New");
			}

			this._oAltPayer.close();
		},
		changeInClientAdd: function(oEvent) {
			var src = oEvent.getSource();
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			var validPh = /^[0-9]{1,30}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
		},
		addAltPayer: function() {
			var that = this;
			var objArray = [];
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "",
				"Altpayeraddr2": "",
				"Altpayercityk": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerperc": "0.00",
				"Partnertype": "PY",
				"Partnertypedesc": "Payer",
				"Isnew": "",
				"IsMulti": "X",
				"Altpayerphone": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			objArray.push(obj);
			var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindAlterTable(oContextKnownParties, "Add");
		},
		handleDeleteKnownParties: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			var oTable = this.byId("idKnownParty");
			oItmSel.destroy();
			this._removeCondition(oTable);
		},
		_removeCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addKnownParties();
			}
			this.upDateButtons(oTable);
		},
		handleChangeNewClientDetails: function(evt) {

			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oClientContext = this.getBindingContextbyId("idClientDetailsNew");
			var sPath = oClientContext.getPath();
			var oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
			if (path === "Countryk") {
				oClientModel.setProperty(sPath + "/" + "Statek", "");
				oClientModel.setProperty(sPath + "/" + "State", "");
			}
			//	this.getContactsValidated(oClientContext.getObject());
		},
		handleChangeNewClientDetailsDD: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			var path = source.getBindingPath("value");
			var oControl = source.getAggregation("_content");
			var oMatterInContext = this.getBindingContextbyId("idClientDetailsNew");
			var oMatterInModel = oMatterInContext.getModel();
			var sPath = oMatterInContext.getPath();
			var id, description, key;
			if (path === "Classification") {
				id = "Classificationk";
				description = "STEXT";
				key = "CLASSIFICATIONK";
			}
			if (oControl) {
				var oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					var selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oMatterInModel.setProperty(sPath + "/" + path, selData[description]);
					oMatterInModel.setProperty(sPath + "/" + id, selData[key]);
					source.getAggregation("_content").setValue(selData[description]);
				} else {
					oMatterInModel.setProperty(sPath + "/" + path, value);
					oMatterInModel.setProperty(sPath + "/" + id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
			//		this.getContactsValidated("ch");
		},
		changeInMatterDetailsDD: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			var path = source.getBindingPath("value");
			var oControl = source.getAggregation("_content");
			var oMatterInContext = this.getBindingContextbyId("MatterInDetailsStep");
			var oMatterInModel = oMatterInContext.getModel();
			var sPath = oMatterInContext.getPath();
			var id, description, key;
			if (path === "Zzbillfreqdesc") {
				id = "Zzbillfreq";
				description = "ZZDESC";
				key = "ZZBILLFREQ";
			}
			if (path === "Zzbillmthddesc") {
				id = "Zzbillmthd";
				description = "ZZDESC";
				key = "ZZBILLMTHD";
			}
			if (path === "Zzmanspdesc") {
				id = "Zzmansp";
				description = "TEXT1";
				key = "MANSP";
			}
			if (path === "Zzmattertypedesc") {
				id = "Zzmattertype";
				description = "DESCRIPTION";
				key = "MATTERTYPE";
			}
			if (path === "Zzpracticegroupdesc") {
				id = "Zzpracticegroup";
				description = "ZZDESC";
				key = "ZZPGP";
			}

			if (path === "Classification") {
				id = "Classificationk";
				description = "STEXT";
				key = "CLASSIFICATIONK";
			}
			if (oControl) {
				var oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					var selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oMatterInModel.setProperty(sPath + "/" + path, selData[description]);
					oMatterInModel.setProperty(sPath + "/" + id, selData[key]);
					source.getAggregation("_content").setValue(selData[description]);
				} else {
					oMatterInModel.setProperty(sPath + "/" + path, value);
					oMatterInModel.setProperty(sPath + "/" + id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
		},
		upDateButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		valueListChangedBP: function(evt) {
			var that = this;
			var data = evt.getSource().getBindingContext().getObject();
			var source = evt.getSource();
			var model = source.getModel();
			var sPath = source.getBindingContext().getPath();

			var sPartnertype = data.Partnertype;
			var sAlternatepayer = data.Alternatepayer;
			var aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, sPartnertype), new Filter("Alternatepayer", sap.ui.model.FilterOperator
				.EQ, sAlternatepayer)];
			var filesPath = "/Cmialtpayers";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Altpayeraddr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Altpayeraddr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Altpayercityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Altpayerstatek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Altpayercountryk", obj.Altpayercountryk);

						}
					}

				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		//Documents Upload
		onDocumentClick: function(e) {
			var proto = window.location.protocol;
			var host = window.location.host;
			var k = this.byId("idAttachment").getSelectedKey();
			if (k === "CD" || k === "MD") {
				var service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmidocuments";
				this.byId(k).getContent()[0].setUploadUrl(service);
				this.fileattachmentFilter(this.byId(k).getContent()[0], k);
			}
			if (k === "CM") {
				this.handleScroll();
			}
		},

		onChangeDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var cmiNo = this.getModel("worklistView").getProperty("/CmiId");
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = this.byId("idAttachment").getSelectedKey();
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + clientk + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size + "|" + key
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [];
				var resText = xmlToJSON.parseString(response.responseRaw);
				var key = this.byId("idAttachment").getSelectedKey();
				var host = window.location.host;
				var protocol = window.location.protocol;
				var urlprefix = protocol + "//" + host;
				var serviceUrl = this.getModel().sServiceUrl;
				var clnt = this.getModel("worklistView").getProperty("/NMCNum");
				var url = "";
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": clnt,
					"Client": resText.entry[0].properties[0].Client[0]._text
				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
				this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", arr.concat(data));
				this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},

		fileattachmentFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId;
			var type = this.byId("idAttachment").getSelectedKey();
			var that = this;
			var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
			var Cmino = "";
			var Docseq = "";
			var Doctype = "";
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos && data[i].Doctype === type) {
					Cmino = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", data);
			var path = "/Cmidocuments(Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData, oResponse) {
					sap.m.MessageToast.show("Document deleted successfully.");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},
		onCreateClientMatter: function() {
			var oModel = this.getModel();
			var cmiId = this.getModel("worklistView").getProperty("/CmiId");
			var ClientId = this.getModel("worklistView").getProperty("/NMCNum");
			var that = this,
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			oModel.callFunction(
				"/CreateCmi", {
					method: "GET",
					urlParameters: {
						Cmino: cmiId,
						Clientk: ClientId,
						Requesttype: "ECNM"
					},
					success: function(oData, response) {
						oBusy.close();
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									sap.m.MessageToast.show(oData.results[0].Message);
								}
							} else {
								sap.m.MessageToast.show("");
							}
						} else {
							sap.m.MessageToast.show("");
						}

					},
					error: function(oError) {
						oBusy.close();
					}
				});

		},
		addAttachments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			this.seqno = evt.getSource().getBindingContext().getObject().Knownpartyseq;
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.KPUpload", this);
				oView.addDependent(this._attchParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._attchParties);
			this._attchParties.open();
		},
		onCloseKPDialog: function() {
			this._attchParties.close();
		},
		onChangeKPDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var cmiNo = this.getModel("worklistView").getProperty("/CmiId");
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = "KP";
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + clientk + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size + "|" + key + "|" +
					this.seqno
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteKPDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [];
				var resText = xmlToJSON.parseString(response.responseRaw);
				var key = "KP";
				var host = window.location.host;
				var protocol = window.location.protocol;
				var urlprefix = protocol + "//" + host;
				var serviceUrl = this.getModel().sServiceUrl;
				var url = "";
				var clnt = this.getModel("worklistView").getProperty("/NMCNum");
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": clnt,
					"Client": resText.entry[0].properties[0].Client[0]._text
				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("KPModel").getProperty("/KPDataSet");
				this.getView().getModel("KPModel").setProperty("/KPDataSet", arr.concat(data));
				this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentKPFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileKPDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId;
			var type = "KP";
			var data = this.getView().getModel("KPModel").getProperty("/KPDataSet");
			var Cmino = "";
			var Docseq = "";
			var Doctype = "";
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos && data[i].Doctype === type) {
					Cmino = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("KPModel").setProperty("/KPDataSet", data);
			var path = "/Cmidocuments(Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData) {
					sap.m.MessageToast.show("Document deleted successfully.");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		}

	});
});
myFormatter = {
	requiredQuestion: function(sValue1, sValue2) {
		if (sValue2 === "X") {
			this.addStyleClass("sapMLabelRequired");
			return " " + sValue1;
		} else {
			return " " + sValue1;
		}
	}
};