/* global myFormatter xmlToJSON PDFJS TextLayerBuilder CustomStyle getOutputScale*/
sap.ui.define([
	"cminewrequest/controller/BaseController",
	"sap/ui/table/TablePersoController",
	"cminewrequest/util/PersoService",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cminewrequest/model/formatter",
	"sap/m/GroupHeaderListItem",
	"sap/ui/model/Filter",
	"cminewrequest/util/xmlToJSON",
	"sap/ui/richtexteditor/RichTextEditor",
	"sap/suite/ui/commons/util/DateUtils"
], function(
	BaseController,
	TablePersoController,
	PersoService,
	JSONModel,
	History,
	formatter,
	GroupHeaderListItem,
	Filter,
	RTE,
	DateUtils
) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView, oOPSideContentBtn;
	return BaseController.extend("cminewrequest.controller.NewClientNewMatter", {
		formatter: formatter,
		onInit_oo: function() {
			oDynamicSideView = this.getView().byId("DynamicSideContent");
			//	oOPSideContentBtn = this.getView().byId("headerForTest").getSideContentButton();
		},

		handleSideContentHide: function() {
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(false);
			}
			//oOPSideContentBtn.setVisible(true);
		},
		handleSCBtnPress: function(oEvent) {
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {

					oEvent.getSource().setText("Hide Comments");
					this.handleScroll();
				} else {
					oEvent.getSource().setText("Show Comments");

				}
			}
			//oOPSideContentBtn.setVisible(false);
		},
		onInit: function() {
			this.onInit_oo();
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.attachRoutePatternMatched(this.handleRouteMatched, this);
			this.attachmentData();
		},
		onAfterRendering: function() {
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			jQuery.sap.delayedCall(2000, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterNew").getDomRef().getBoundingClientRect().top;
				var tablePositionTop = this.byId("NRWizard").getDomRef().getBoundingClientRect().top;
				var scrollHeight = window.innerHeight - tablePositionTop - footerHeight - 0;
				this.byId("NRWizard").setHeight(String(scrollHeight + "px"));
			}.bind(this));
		},
		handleScroll: function() {
			jQuery.sap.delayedCall(200, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterNew").getDomRef().getBoundingClientRect().top;
				if (this.byId("idCommentsList").getDomRef()) {
					var barPositionTop = this.byId("idCommentsList").getDomRef().getBoundingClientRect().top;
					var scrollerHeight = window.innerHeight - barPositionTop - footerHeight - 30;
					this.byId("scrollContainer").setHeight(String(scrollerHeight + "px"));
				}
			}.bind(this));
		},
		handleRouteMatched: function(oEvent) {
			var oParameters = oEvent.getParameters();
			if (oParameters.name === "NewClientNewMatterConflict") {
				var bCmino = $.isEmptyObject(oParameters.arguments);
				var data = oParameters.arguments;
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					ConsiData: []
				});
				this.getView().setModel(oJsonModel, "jsonConsiModel");
				var oJsonModel1 = new sap.ui.model.json.JSONModel();
				oJsonModel1.setData({
					RiskData: []
				});
				this.getView().setModel(oJsonModel1, "riskConsiModel");
				this.createNewRequest(data);
			}
			if ((oParameters.name !== "NewClientNewMatterCmi" && oParameters.name !== "NewClientNewMatter")) {
				return;
			} else {
				var bCmino = $.isEmptyObject(oParameters.arguments);
				if (bCmino) {
					var data = {};
					data.Searchid = "";
					data.Cmino = "";
					this.createNewRequest(data);
				} else {
					var data = this._loadJSONData();
					var oOveriewDataModel = new sap.ui.model.json.JSONModel(data);
					this.getView().setModel(oOveriewDataModel, "NRequestView");
					this.displayCategoryData();
					var ReMarkList = new sap.ui.model.json.JSONModel({
						"RemarkSet": []
					});
					this.getView().setModel(ReMarkList, "RemarkModel");
					var commentList = new sap.ui.model.json.JSONModel({
						"CommentSet": []
					});
					this.getView().setModel(commentList, "CommentsModel");
					oDynamicSideView = this.getView().byId("DynamicSideContent");
					var that = this;
					this.WizardTitle = "Client Details";
					this.validatedStep = false;
					var a = this.byId("NRWizard");
					var c = a._getProgressNavigator();
					var curr = 1;
					var old = undefined;
					c.attachStepChanged(function(e) {
						curr = e.mParameters.current;
						old = e.mParameters.previous;
						var step = e.getSource().getStepTitles();
						that.WizardTitle = step[curr - 1];
						var cType = that.WizardTitle;
						//		that.onFilterComments(cType);
					}.bind(this));
					c._moveToStep = function(newStep, suppressEvent) {
						var stepCount = c.getStepCount(),
							oldStep = c.getCurrentStep();
						if (newStep > stepCount) {
							return c;
						}
						if (newStep > c._activeStep) {
							c._updateActiveStep(newStep);
						}
						c._updateCurrentStep(newStep, oldStep, suppressEvent);
						var curr = newStep;
						var old = oldStep;
						var step = c.getStepTitles();
						that.WizardTitle = step[curr - 1];
						var cType = that.WizardTitle;
						//	that.onFilterComments(cType);
					};
					window.that = this;
					//		this.dataBP();
					var oViewModel;
					var data = oParameters.arguments;
					var Cmino = data.Cmino;
					var clientk = data.Clientk;
					var bButton = data.bEditScreen;
					if (bButton === "0") {
						bButton = false;
					} else {
						bButton = true;
					}
					var inbox;
					var rShow;
					var showConflictSearch = false;
					var searchId = "";
					if (oEvent.getParameter("arguments").Searchid) {
						inbox = false;
						rShow = false;
						this.sObjectId = data.Searchid;
						showConflictSearch = true;
						searchId = data.Searchid;
					} else {
						inbox = data.bInbox;
						if (inbox === "0") {
							inbox = false;
							rShow = true;
						} else {
							inbox = true;
							rShow = false;
						}
					}
					oViewModel = new JSONModel({
						LbLMsgp: this.getResourceBundle().getText("LbLMsgp"),
						tableBusyDelay: 0,
						visbl: true,
						editable: false,
						altVisible: false,
						classfication: "",
						Role: "",
						enablePercent: bButton,
						Designation: "",
						Name: "",
						PopInDisplay: false,
						PopInDisplaycomments: false,
						conflictMsgVisible: false,
						selectCliVisible: false,
						submitEnable: false,
						expandClientDetails: true,
						Notes: "",
						viewDisplay: true,
						CmiId: Cmino,
						state: false,
						team: true,
						Astate: false,
						saveButton: false,
						submitButton: false,
						ExistState: true,
						clientFalse: false,
						PopOverClientEdit: true,
						btnEdit: false,
						btnDiplay: false,
						NMTitle: "",
						NMCNum: clientk,
						editScreen: bButton,
						userId: sap.ushell.Container.getService("UserInfo").getUser().getId(),
						userName: sap.ushell.Container.getService("UserInfo").getUser().getFullName(),
						editTerm: true,
						editButtonSubmit: false,
						idisplayapprove: inbox,
						idisplayapprove01: rShow,
						idisplaySave: false,
						pageTitleReq: "New Client New Matter Review",
						tableCount: "",
						tableNoDataText: "",
						showConflictSearchbtn: showConflictSearch,
						Searchid: searchId
					});
					this.setModel(oViewModel, "worklistView");

					var oViewModel1 = new JSONModel({
						altVisible: false,
						expandClientDetails: true,
						altIconTabVisible: false,
						altCommnetVisible: false,
						busy: true,
						delay: 0,
						Name: "",
						Email: "",
						Phone: "",
						BillOfc: "",
						LeadPartner: "",
						saveButton: false,
						submitButton: false,
						LPPhone: "",
						LPEmail: "",
						CmiId: Cmino,
						enablePercent: true,
						clientName: "",
						countryVis: true,
						NMCNum: clientk,
						NCTitle: "",
						editScreen: bButton
					});
					this.setModel(oViewModel1, "objectView");

					this.bindMandateField();
					this.getModel().metadataLoaded().then(function() {
						this._readOData(Cmino);
					}.bind(this));
					var aChange = ["FormDisplay354ALH", "FormChange354BD", "FormChange354MI", "FormChange354BF1",
						"FormChange354OD", "FormChange354BI", "FormChange354TD", "FormChange354ID", "FormDisplay354WO"
					];
					for (var i = 0; i < aChange.length; i++) {
						this.getView().byId(aChange[i]).setVisible(true);
					}
				}
			}
		},
		_readOData: function(CmiNo) {
			var _that = this;
			var oModel = this.getModel();
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var oOveriewDataModel = new sap.ui.model.json.JSONModel();
			var sObjectPath = oModel.createKey("Cmihdrs", {
				Cmino: CmiNo,
				Clientk: "",
				Matterk: "",
				Cmirequesttype: "NCNM"
			});
			var urlParams = {
				"$expand": "Comments,Documents,ConsiderationsN,Ocgs,Clients,Clientcontacts,Leadpartners,Knownparties,Matters,Matterdetails,Offices,Altpayers,Clientcorrespondence,Clientdetails,Clientbp,Wtax"
			};
			oModel.read("/" + sObjectPath, {
				context: null,
				urlParameters: urlParams,
				async: true,
				filters: null,
				success: function(oData, oResponse) {
					oBusy.close();
					oOveriewDataModel.setData(oData);
					//	_that.getModel("worklistView").setProperty("/userId", oResponse.data.Requestuserk);
					//	_that.getModel("worklistView").setProperty("/userName", oResponse.data.Requestuser);
					_that.displayEntries(oData);
					_that.bindDataKnownParties(oData.Knownparties.results);
					_that.bindOffices(oData.Offices.results);
					_that.bindAlterData(oData.Altpayers.results);
					_that.bindLeadPartnerData(oData.Leadpartners.results);
					_that.bindWtaxData(oData.Wtax.results);
					_that.bindClientBPData(oData.Clientbp.results);
					var oViewNewModel = _that.getModel("NRequestView");
					oViewNewModel.setProperty("/Clientcontacts", oData.Clientcontacts.results);
					oViewNewModel.setProperty("/Ocgs", oData.Ocgs.results);

					var commentList = new sap.ui.model.json.JSONModel({
						"CommentSet": oData.Comments.results
					});
					_that.getView().setModel(commentList, "CommentsModel");

					var dataC = oData.ConsiderationsN,
						businessData = [],
						riskData = [];
					for (var j = 0; j < dataC.results.length; j++) {
						if (dataC.results[j].Attributetypek === "02") {
							riskData.push(dataC.results[j]);
						} else {
							businessData.push(dataC.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					oJsonBModel.setData({
						ConsiData: businessData
					});
					_that.getView().setModel(oJsonBModel, "jsonConsiModel");
					oJsonRModel.setData({
						RiskData: riskData
					});
					_that.getView().setModel(oJsonRModel, "riskConsiModel");

					var data = oData.Documents.results;
					var aFileData = [];
					var host = window.location.host;
					var protocol = window.location.protocol;
					var urlprefix = protocol + "//" + host;
					var serviceUrl = _that.getModel().sServiceUrl;
					for (var i = 0; i < data.length; i++) {
						var obj = data[i];
						obj.url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
							"',Doctype='" + obj.Doctype +
							"')/$value";
						aFileData.push(obj);
					}
					var oJsonModel = new sap.ui.model.json.JSONModel({
						FileDataSet: aFileData
					});
					_that.getView().setModel(oJsonModel, "AttachmentModel");
					/*var oJsonModel = new sap.ui.model.json.JSONModel({
						FileDataSet: oObj
					});
					_that.getView().setModel(oJsonModel, "AttachmentModel");*/
				},
				error: function(oData) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						styleClass: "customPopBg",
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function() {
							//Action to be performed on close of message dialog
						}
					});
				}
			});
		},
		displayEntries: function(data) {
			var qtc = this.getModel();
			var model = this.getModel("objectView");
			var clientData = {};
			var MatterData = {};
			var MatterDetailsData = {};
			var ClientDetailsData = {};
			var CorresDetailsData = {};
			if (data.Clients.results.length) {
				clientData = data.Clients.results.pop();
				model.setProperty("/NCTitle", clientData.Client);
			} else {
				clientData = this._loadJSONData().Clients;
			}
			if (data.Matters.results.length) {
				MatterData = data.Matters.results.pop();
			} else {
				MatterData = this._loadJSONData().Matters;
			}
			if (data.Matterdetails.results.length) {
				MatterDetailsData = data.Matterdetails.results.pop();
			} else {
				MatterDetailsData = this.handleMatterInDetails();
			}
			if (data.Clientdetails.results.length) {
				ClientDetailsData = data.Clientdetails.results.pop();
			} else {
				ClientDetailsData = this.handleClientInDetails();
			}
			if (data.Clientcorrespondence.results.length) {
				CorresDetailsData = data.Clientcorrespondence.results.pop();
			} else {
				CorresDetailsData = this.handleCorresInDetails();
			}
			this.getModel("TempModel").setData(clientData);
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
				this.getView().addDependent(this._oPopover);
			}
			var idClientExt = this.byId("SimpFormClientEdit");
			var oContextEClients = qtc.createEntry("/Cmiclients", {
				properties: clientData
			});
			idClientExt.setBindingContext(oContextEClients);

			var matter = this.byId("idMatterDetails");
			var oContextMatter = qtc.createEntry("/Cmimatters", {
				properties: MatterData
			});
			matter.setBindingContext(oContextMatter);
			var idMatterInDetailsStep = this.byId("MatterInDetailsStep");
			var oContextMatterInDetail = qtc.createEntry("/Cmimatterdetails", {
				properties: MatterDetailsData
			});
			idMatterInDetailsStep.setBindingContext(oContextMatterInDetail);
			var idClientDetailStep = this.byId("ClientDetailStep");

			var oContextClientInDetail = qtc.createEntry("/Cmiclientdetails", {
				properties: ClientDetailsData
			});
			idClientDetailStep.setBindingContext(oContextClientInDetail);

			var idCorresStep = this.byId("idCorresStep");
			var oContextCorresInDetail = qtc.createEntry("/Cmiclientcorrespondence", {
				properties: CorresDetailsData
			});
			idCorresStep.setBindingContext(oContextCorresInDetail);
		},
		bindWtaxData: function(newData) {
			var idOffice = this.byId("FormChange354WD");
			idOffice.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmiwtax", {
					properties: newData[o]
				});
				this.bindTaxDataTable(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.onAddTaxData();
			}
		},
		bindClientBPData: function(newData) {
			var idOffice = this.byId("handleCellClickChgBPBP");
			idOffice.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/CmiclientBP", {
					properties: newData[o]
				});
				this.bindBillPartnerTable(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.onAddBusinessPartner();
			}
		},
		bindOffices: function(newData) {
			var idOffice = this.byId("FormDisplay354WO");
			idOffice.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmimatteroffices", {
					properties: newData[o]
				});
				this.bindWOOffice(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.addWOOffice();
			}
		},
		bindLeadPartnerData: function(newData) {
			var idOffice = this.byId("idLeadPartnerT");
			idOffice.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextLeadPartner = qtc.createEntry("/Cmileadpartners", {
					properties: newData[o]
				});
				this.bindLPTable(oContextLeadPartner);
			}
			if (newData.length < 1) {
				this.bindLeadPartner();
			}
		},
		bindAlterData: function(newData) {
			var idAlterPayer = this.byId("FormChange354BF1");
			idAlterPayer.destroyItems();
			var idMatterBP = this.byId("FormChange354BP");
			idMatterBP.destroyItems();
			for (var o = 0; o < newData.length; o++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
					properties: newData[o]
				});
				if (newData[o].IsMulti === "X") {
					this.bindAlterTable(oContextKnownParties);
				} else {
					this.bindMatterBPTable(oContextKnownParties);
				}
			}
			if (idAlterPayer.getItems().length < 1) {
				this.addAltPayer();
			}
			if (idMatterBP.getItems().length < 1) {
				this.onAddMatterBP();
			}
		},
		bindDataKnownParties: function(newData) {
			var idKnownParty = this.byId("idKnownParty");
			idKnownParty.destroyItems();
			for (var k = 0; k < newData.length; k++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: newData[k]
				});
				this.bindKnownTable(oContextKnownParties);
			}
			if (newData.length < 1) {
				this.bindKnownParties();
			}
		},
		createNewRequest: function(data) {
			/*	if (this.getModel("TempModel").getData().Cmino === undefined) {
					this.getRouter().navTo("NewMatter", true);
				}*/
			var commentList = new sap.ui.model.json.JSONModel({
				"CommentSet": []
			});
			this.getView().setModel(commentList, "CommentsModel");
			oDynamicSideView = this.getView().byId("DynamicSideContent");
			this.dataBP();
			var that = this;
			this.WizardTitle = "Client Details";
			this.validatedStep = false;
			var a = this.byId("NRWizard");
			var c = a._getProgressNavigator();
			var curr = 1;
			var old = undefined;
			//		var suppressEvent = true;
			//		var newStep = "";
			/*	a.onAfterRendering = function() {*/
			c.attachStepChanged(function(e) {
				curr = e.mParameters.current;
				old = e.mParameters.previous;
				var step = e.getSource().getStepTitles();
				that.WizardTitle = step[curr - 1];
				var cType = that.WizardTitle;
				//	that.onFilterComments(cType);

			}.bind(this));

			c._moveToStep = function(newStep, suppressEvent) {
				var stepCount = c.getStepCount(),
					oldStep = c.getCurrentStep();

				if (newStep > stepCount) {
					return c;
				}

				if (newStep > c._activeStep) {
					c._updateActiveStep(newStep);
				}
				c._updateCurrentStep(newStep, oldStep, suppressEvent);
				var curr = newStep;
				var old = oldStep;
				var step = c.getStepTitles();
				that.WizardTitle = step[curr - 1];
				var cType = that.WizardTitle;
				//	that.onFilterComments(cType);
			};
			this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
			this.getView().addDependent(this._oPopover);
			var idClient = this.getView().byId("SimpFormClientEdit");
			this.getModel().metadataLoaded().then(function() {
				var qtc = that.getModel();
				var data = that.getModel("TempModel").getData();
				var oContextClients = qtc.createEntry("/Cmiclients", {
					properties: data
				});
				idClient.setBindingContext(oContextClients);
				that.onAddBusinessPartner();
				that.onAddTaxData();
				that.addWOOffice();
				that.onAddMatterBP();
				that.addAltPayer();
				//		IName1} {ILine1} {ILine2} {ILine3} {ILine4}
			});
			this.mytxt = "";
			window.that = this;
			var oViewModel = new JSONModel({
				altVisible: false,
				expandClientDetails: true,
				altIconTabVisible: false,
				altCommnetVisible: false,
				busy: true,
				delay: 0,
				Name: "",
				Email: "",
				Phone: "",
				BillOfc: "",
				LeadPartner: "",
				saveButton: false,
				submitButton: false,
				LPPhone: "",
				LPEmail: "",
				CmiId: data.Cmino,
				enablePercent: true,
				clientName: "",
				countryVis: true,
				NCTitle: this.getModel("TempModel").getData().Client

			});
			this.setModel(oViewModel, "objectView");
			// worlist Model
			var oModel = new JSONModel({
				PopInDisplay: false,
				clientFalse: false,
				PopOverClientEdit: true,
				btnEdit: true,
				btnDiplay: false,
				editScreen: true,
				enablePercent: true,
				userId: sap.ushell.Container.getService("UserInfo").getUser().getId(),
				userName: sap.ushell.Container.getService("UserInfo").getUser().getFullName(),
				editTerm: true,
				editButtonSubmit: false,
				NMCNum: "",
				idisplayapprove: false,
				idisplayapprove01: false,
				idisplaySave: true,
				pageTitleReq: "New Client New Matter Request",
				tableCount: "",
				tableNoDataText: "",
				showConflictSearchbtn: false,
				Searchid: data.Searchid
			});
			this.setModel(oModel, "worklistView");
			this._createnewEntry();
			var data = this._loadJSONData();
			var oOveriewDataModel = new sap.ui.model.json.JSONModel(data);
			this.getView().setModel(oOveriewDataModel, "NRequestView");
			this._readContactObject();
			this.displayCategoryData();
			this.bindKnownParties();
			this.bindLeadPartner();

			this.bindMandateField();
			//	this.displayOcgsList();
			var ReMarkList = new sap.ui.model.json.JSONModel({
				"RemarkSet": []
			});
			this.getView().setModel(ReMarkList, "RemarkModel");

			this._timeline = this.byId("idTimeline");

			this.getView().attachEvent("afterRendering", function() {
				// in production you would probably want to use something like ScrollContainer
				// but for demo purpose we want to keep it simple
				// sctretch:true on container prevents scrolling by default
				//		jQuery("section").css("overflow", "auto");
			});
			var aChange = ["FormDisplay354ALH", "FormChange354BD", "FormChange354MI", "FormChange354BF1",
				"FormChange354OD", "FormChange354BI", "FormChange354TD", "FormChange354ID", "FormDisplay354WO"
			];
			for (var i = 0; i < aChange.length; i++) {
				this.getView().byId(aChange[i]).setVisible(true);
			}
		},
		onPost: function(evt) {
			var text = evt.getParameter("value");
			var obj = {
				Cmino: "",
				CommentType: "Request",
				Sequence: "",
				UserComment: text,
				Addedby: "Basavaraj Goudar",
				Addedbyk: "UGOUDARB01",
				Addedon: new Date()
			};
			var oRemarks = this.getView().getModel("RemarkModel");
			var oRemarkData = oRemarks.getProperty("/RemarkSet");
			oRemarkData.push(obj);
			oRemarks.setProperty("/RemarkSet", oRemarkData);
		},
		bindMandateField: function() {
			var oViewModel = new JSONModel({
				vClientName: "None",
				vClassification: "None",
				vAddress1: "None",
				vCity: "None",
				vState: "None",
				vZipCode: "None",
				vCountry: "None",
				vOffice: "None",
				vEmail: "None"
					//vContactName: "None",
					//vContactPhone: "None",
					//vContactEmail: "None"
			});
			this.setModel(oViewModel, "ErrorShow");
			var oViewMatterModel = new JSONModel({
				vMatterMN: "None",
				vMatterSA: "None",
				vMatterMMA: "None",
				vMatterMD: "None",
				vMatterPG: "None",
				vMatterO: "None",
				vMatterEF: "None"
			});
			this.setModel(oViewMatterModel, "ShowMatterError");
			var Altpayers = {
				"vAlternatepayer": "None",
				"vAltpayercityk": "None",
				"vAltpayeraddr1": "None",
				"vAltpayerstate": "None",
				"vAltpayerzip": "None",
				"vAltpayercountry": "None",
				"vAltpayerphone": "None"
			};
			var oViewAltModel = new JSONModel(Altpayers);
			this.setModel(oViewAltModel, "ShowAlterError");
		},
		_createnewEntry: function() {
			//		var idClient = this.byId("idClientDetails");
			var idClient = this.getView().byId("SimpFormClientEdit");
			var idMatter = this.byId("idMatterDetails");
			//	var idLeadPartner = this.byId("idLeadPartner");

			var idMatterInDetailsStep = this.byId("MatterInDetailsStep");
			var idClientDetailStep = this.byId("ClientDetailStep");
			var idCorresStep = this.byId("idCorresStep");
			this.getModel().metadataLoaded().then(function() {
				var qtc = this.getModel();
				/*	var oContextClients = qtc.createEntry("/Cmiclients", {
						properties: this._loadJSONData().Clients
					});*/
				var oContextMatter = qtc.createEntry("/Cmimatters", {
					properties: this._loadJSONData().Matters
				});
				/*	var oContextLead = qtc.createEntry("/Cmileadpartners", {
						properties: this._readLeadParneterObject()
					});*/
				var oContextMatterInDetail = qtc.createEntry("/Cmimatterdetails", {
					properties: this.handleMatterInDetails()
				});
				idMatter.setBindingContext(oContextMatter);
				idMatterInDetailsStep.setBindingContext(oContextMatterInDetail);

				var oContextClientInDetail = qtc.createEntry("/Cmiclientdetails", {
					properties: this.handleClientInDetails()
				});
				idClientDetailStep.setBindingContext(oContextClientInDetail);

				var oContextCorresInDetail = qtc.createEntry("/Cmiclientcorrespondence", {
					properties: this.handleCorresInDetails()
				});
				idCorresStep.setBindingContext(oContextCorresInDetail);
				this.bindAddress();
			}.bind(this));
		},
		bindAddress: function() {
			var ClientAddress = this.getView().byId("SimpFormClientEdit").getBindingContext().getObject();
			var idClientDetailStep = this.byId("ClientDetailStep");
			var oModel = idClientDetailStep.getBindingContext().getModel();
			var sPath = idClientDetailStep.getBindingContext().sPath;

			oModel.setProperty(sPath + "/Iname1", ClientAddress.Client);
			oModel.setProperty(sPath + "/Iline1", ClientAddress.Addr1);
			oModel.setProperty(sPath + "/Iline2", ClientAddress.Addr2);
			oModel.setProperty(sPath + "/Iline3", ClientAddress.City);
			oModel.setProperty(sPath + "/Iline4", ClientAddress.State);
			oModel.setProperty(sPath + "/Email", ClientAddress.Email);
		},
		addressEdit: function() {
			var iddisplay = this.byId("displayAddress");
			var idEdit = this.byId("editAddress");
			iddisplay.setVisible(false);
			idEdit.setVisible(true);
		},
		addressDisplay: function() {
			var iddisplay = this.byId("displayAddress");
			var idEdit = this.byId("editAddress");
			iddisplay.setVisible(true);
			idEdit.setVisible(false);
		},
		handleCorresInDetails: function() {
			var obj = {
				"Cmino": "",
				"Vkorg": "",
				"Clientk": "",
				"Client": "",
				"Msgfn": "",
				"Maber": "",
				"Zwelsdesc": "",
				"Mahna": "",
				"Togrudesc": "",
				"Mansp": "",
				"Ztermdesc": "",
				"Knrma": "",
				"Madat": null,
				"Mahns": "",
				"Xausz": "",
				"Knrmadesc": "",
				"Zamim": "",
				"Zamir": "",
				"Zwels": "",
				"Zterm": "",
				"Manspdesc": "",
				"Zsabe": "",
				"Tlfns": "",
				"Fdgrv": "",
				"Togru": "",
				"Xauszdesc": "",
				"Mahnadesc": ""
			};
			return obj;
		},
		addAltPayerBP: function() {
			var qtc = this.getModel();
			var idAltPayer = this.byId("idAlterDetails");
			var oContextAltPayer = qtc.createEntry("/Cmialtpayers", {});
			var a = oContextAltPayer.getModel();
			a.setProperty(oContextAltPayer.getPath() + "/Alternatepayer", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayername", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr1", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerzip", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercityk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerperc", "0.00");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "");
			a.setProperty(oContextAltPayer.getPath() + "/Isnew", "");
			a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountryk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstate", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountry", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerphone", "");
			a.setProperty(oContextAltPayer.getPath() + "/Cmino", "$000000001");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerseq", "0001");
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		handleClientInDetails: function() {
			var data = this.getModel("TempModel").getData();
			var obj = {
				"Clientk": "",
				"Client": "",
				"Vkorg": data.Vkorg,
				"Vkorgdesc": data.Vkorgdesc,
				"Cmino": "",
				"Msgfn": "",
				"Langu": "",
				"Land1": "",
				"Sptxt": "",
				"Kukla": "",
				"Kukladesc": "",
				"Zzclntgrp": "",
				"Zzglobalultimate": "",
				"Zzdunsnumber": "",
				"Zzopendate": null,
				"Zzoutput": "",
				"Zzexpcodeset": "",
				"Zzexpcodedesc": "",
				"Zzcolco": "",
				"Zzcolcot": "",
				"Zzpriconf": "",
				"Zzpriconft": "",
				"Stcd1": "",
				"Stcd2": "",
				"Stcd3": "",
				"Stcd4": "",
				"Stcd5": "",
				"Stceg": "",
				"Stcd1v": "",
				"Stcd2v": "",
				"Stcd3v": "",
				"Stcd4v": "",
				"Stcd5v": "",
				"Stcegv": "",
				"Auth": "",
				"Zzownoffice": "",
				"Zzenddt": null,
				"Zzengpar": "",
				"Zzengpoff": "",
				"Zzclntoff": "",
				"Zzbustype": "",
				"Zzassgntyp": "",
				"Zzstatus": "",
				"Zzestwork": "",
				"ZzYrEmon": "",
				"Txjcd": "",
				"Txjcddesc": "",
				"Udmbp": "",
				"Etag": "",
				"Zzclnttradeas": "",
				"Zzsiccd": "",
				"Zzsiccddesc": "",
				"Zzvatvaldt": null,
				"Zzclosedate": null,
				"Zzclntprg": "",
				"Zzclntprgdesc": "",
				"Zzebillvendor": "",
				"Zzporqrd": "",
				"Zzsanction": "",
				"Zzphaseset": "",
				"Zzactset": "",
				"Zzphasesetdesc": "",
				"Zzactsetdesc": "",
				"Zzphbegda": null,
				"Zzactbegda": null,
				"Name1": "",
				"Line1": "",
				"Line2": "",
				"Line3": "",
				"Line4": "",
				"Phone": "",
				"Fax": "",
				"Email": "",
				"AddressNote": "",
				"Iname1": "",
				"Iline1": "",
				"Iline2": "",
				"Iline3": "",
				"Iline4": "",
				"Zzdrftformat": "",
				"Zzfnalformat": "",
				"Dbvtext": "",
				"Fbvtext": "",
				"Zztmdtl": "",
				"Zztksumry": "",
				"Zzcstdtsumry": "",
				"Tdtext": "",
				"Tstext": "",
				"Cdtext": "",
				"Zzpageno": "",
				"Zzsumwo": "",
				"Zzremit": ""
			};

			return obj;
		},
		handleMatterInDetails: function() {
			var obj = {
				"Auth": "",
				"BillInstDate": "",
				"CheckNoLock": "",
				"Cmino": "",
				"Error": "",
				"Errormessage": "",
				"Etag": "",
				"Txjcd": "",
				"Txjcddesc": "",
				"Werks": "",
				"Werksdesc": "",
				"Zcontinue": "",
				"Zzactcodeset": "",
				"Zzactcodesetdesc": "",
				"ZzacsetValidfrom": null,
				"Zzaol": "",
				"Zzaoldesc": "",
				"Zzbillfreq": "",
				"Zzbillfreqdesc": "",
				"Zzbillinst": "",
				"Zzbillmthd": "",
				"Zzbillmthddesc": "",
				"Zzbillteam": "",
				"Zzbillteamdesc": "",
				"Zzbspras": "",
				"Zzbsprasdesc": "",
				"Zzcap": "0.00",
				"Zzcapctrl": "",
				"Zzcapcurr": "",
				"Zzcasecatcd": "",
				"Zzcasecatcddesc": "",
				"Zzclcasename": "",
				"Zzclcasenamedesc": "",
				"Zzclcasenbr": "",
				"Zzclcasenbrdesc": "",
				"Zzclntaol": "",
				"Zzclntaoldesc": "",
				"Zzclntbusarea": "",
				"Zzclntbusareadesc": "",
				"Zzclntccenter": "",
				"Zzclntccenterdesc": "",
				"Zzclntjursd": "",
				"Zzclntjursddesc": "",
				"Zzclntsrvcat": "",
				"Zzclntsrvcatdesc": "",
				"Zzclntstatus": "",
				"Zzclntstatusdesc": "",
				"Zzclntsubenty": "",
				"Zzclntsubentydesc": "",
				"Zzclntwrktype": "",
				"Zzclntwrktypedesc": "",
				"Zzcolco": "",
				"Zzcolcodesc": "",
				"Zzcompldate": null,
				"Zzcompletion": "0.00",
				"Zzcourtnum": "",
				"Zzcourtnumdesc": "",
				"Zzcstdtsumry": "",
				"Zzcstdtsumrydesc": "",
				"Zzdrftformat": "",
				"Zzdrftformatdesc": "",
				"Zzecost": "0.00",
				"Zzefees": "0.00",
				"Zzenttype": "",
				"Zzenttypedesc": "",
				"Zzetotal": "0.00",
				"Zzexpcodeset": "",
				"Zzexpcodesetdesc": "",
				"Zzfftcset": "",
				"Zzfftcsetdesc": "",
				"ZztcsetValidfrom": null,
				"Zzfnalformat": "",
				"Zzfnalformatdesc": "",
				"Zzgrpbill": "",
				"Zzgrpbilldesc": "",
				"Zzintver": "",
				"Zzintverdesc": "",
				"Zziob": "",
				"Zziobdesc": "",
				"Zzipanuyear": "",
				"Zzipappldate": null,
				"Zzipapplnum": "",
				"Zzipapplnumdesc": "",
				"Zzipjurisdcd": "",
				"Zzipjurisdcddesc": "",
				"Zzipponum": "",
				"Zzipponumdesc": "",
				"Zziprefrtypecd": "",
				"Zziprefrtypecddesc": "",
				"Zzipregdt": null,
				"Zzipregnum": "",
				"Zzipregnumdesc": "",
				"Zzipsort1": "",
				"Zzipsort1desc": "",
				"Zzipsort2": "",
				"Zzipsort2desc": "",
				"Zzipsort3": "",
				"Zzipsort3desc": "",
				"Zzipsort4": "",
				"Zzipsort4desc": "",
				"Zzipsort5": "",
				"Zzipsort5desc": "",
				"Zzmansp": "",
				"Zzmanspdesc": "",
				"Zzmatpageno": "",
				"Zzmatpagenodesc": "",
				"Zzmatremit": "",
				"Zzmatremitdesc": "",
				"Zzmatrptgrp": "",
				"Zzmatrptgrpdesc": "",
				"Zzmattercat": "",
				"Zzmattercatdesc": "",
				"Zzmattertype": "",
				"Zzmattertypedesc": "",
				"Zzmcurr": "",
				"Zzmcurrdesc": "",
				"Zzmonlau": "",
				"Zzmonlaudesc": "",
				"Zzmprgrp": "",
				"Zzmprgrpdesc": "",
				"Zznatureprocd": "",
				"Zznatureprocddesc": "",
				"Zzpassthru": "",
				"Zzpracticegroup": "",
				"Zzpracticegroupdesc": "",
				"Zzpriconf": "",
				"Zzpriconfdesc": "",
				"Zzsubindcode": "",
				"Zzsubindcodedesc": "",
				"Zzsumwo": "",
				"Zzsumwodesc": "",
				"Zzsyndlomat": "",
				"Zztaskcodeset": "",
				"Zztaskcodesetdesc": "",
				"Zztax": "",
				"Zztaxdesc": "",
				"Zztecharea": "",
				"Zztechareadesc": "",
				"Zztimeentryunit": "",
				"Zztimeentryunitdesc": "",
				"Zztksumry": "",
				"Zztksumrydesc": "",
				"Zztmdtl": "",
				"Zztmdtldesc": "",
				"Zzwipprovpercent": ""
			};
			return obj;
		},
		onAlterChange: function(evt) {
			var selected = evt.getParameter("state"),
				that = this,
				model = this.getModel("objectView");
			if (selected) {
				model.setProperty("/altVisible", selected);
				that.byId("idAltpayerphone")._oControl.edit.attachLiveChange(
					function(oEvent) {
						that.validPhone(oEvent);
					}
				);
			} else {
				model.setProperty("/altVisible", selected);
			}
		},
		_readContactObject: function() {
			var oContact = {
				"Cmino": "$000000001",
				"Contactseq": "",
				"Contacttype": "S",
				"Email": "",
				"Name": "",
				"Phone": "",
				"Comments": ""
			};
			var oContactModel = new JSONModel(oContact);
			this.setModel(oContactModel, "oContactDataModel");
			var oViewNewModel = this.getModel("NRequestView"),
				aClientData = oViewNewModel.getProperty("/Clientcontacts");
			aClientData.push(oContact);
		},
		_readLeadParneterObject: function() {
			var oLeadPartner = {
				"Cmino": "$000000001",
				"Rank": "",
				"Officek": "",
				"Office": "",
				"Leadpartnerk": "",
				"Leadpartner": "",
				"Phone": "",
				"Email": "",
				"Parvw": "",
				"Parvwdesc": ""
			};
			return oLeadPartner;
		},
		_loadJSONData: function() {
			var data = {
				Cmino: "",
				Requestuserk: "",
				Requestuser: "",
				Requesttime: "0",
				Cmirequesttype: "00",
				Changedbyk: "",
				Changedby: "",
				Changedtime: "0",
				VAConflicts: [],
				BP: [],
				Clients: {
					"Cmino": "$000000001",
					"Clientk": "",
					"Client": "",
					"Classificationk": "",
					"Classification": "",
					"Addr1": "",
					"Addr2": "",
					"City": "",
					"Statek": "",
					"State": "",
					"Zipcode": "",
					"Countryk": "",
					"Country": "",
					"Bofficek": "",
					"Boffice": "",
					"Email": "",
					"Nstandardterms": "",
					"Vkorg": "",
					"Vkorgdesc": ""

				},
				Clientcontacts: [],
				Matters: {
					"Cmino": "$000000001",
					"Mattername": "",
					"Matter": "",
					"Serviceareak": "",
					"Servicearea": "",
					"Mmak": "",
					"Mma": "",
					"Matterlongtext": "",
					"Practicegroupk": "",
					"Practicegroup": "",
					"Mmofficek": "",
					"Mmoffice": "",
					"Quote": "",
					"Estimatedfees": "0.00",
					"Estimatedfeecurr": "",
					"Zzplsez": null,
					"Zzplfaz": null
				},
				Ocgs: [],
				Knownparties: [],
				Leadpartners: [],
				Considerations: [{
					"Cmino": "$000000001",
					"Considerationseq": "",
					"Considerationtype": "",
					"Consderationk": "",
					"Consideration": "",
					"Countryrequired": "",
					"Countryk": "",
					"Explainationrequired": "",
					"Explaination": ""
				}],
				Altpayers: {
					"Cmino": "$000000001",
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Partnertypedesc": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				},
				Altpayers1: [{
					"Cmino": "$000000001",
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Partnertypedesc": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				}]
			};
			return data;
		},
		//same method  calling from NewRequest.controller.js
		onPressIMparties: function(evt) {
			var oView = this.getView();
			sap.ui.controller("cminewrequest.controller.NewRequest").onPressIMparties(evt, oView);
		},
		addAttachments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			this.seqno = evt.getSource().getBindingContext().getObject().Knownpartyseq;
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.KPUpload", this);
				oView.addDependent(this._attchParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._attchParties);
			this._attchParties.open();
		},
		onCloseKPDialog: function() {
			this._attchParties.close();
		},
		onPressViewConfilt: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oKnownParties) {
				this._oKnownParties = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.ViewConflicts", this);
				oView.addDependent(this._oKnownParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKnownParties);
			var that = this;
			var source = evt.getSource();
			var obj = source.getBindingContext().getObject();
			var cmino = this.getModel("objectView").getProperty("/CmiId");
			var name = obj.Name;
			var aFilter = [new Filter("Cmino", sap.ui.model.FilterOperator.EQ, cmino), new Filter("Name", sap.ui.model.FilterOperator
				.EQ, name)];
			var filesPath = "/Cmigetconflicts";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					that.getModel("NRequestView").setProperty("/VAConflicts", oData.results);
					that._oKnownParties.open();
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		onPersoButtonPressed: function() {
			this._oTPC = new TablePersoController({
				table: this.getView().byId("ConflictSearchTableId"),
				componentName: "cminewrequest",
				persoService: PersoService
			});
			this._oTPC.openDialog();
		},
		onPressConflictSearch: function(oEvent, oView) {
			var aFilter = [];
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oConflictReport) {
				this._oConflictReport = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.ConfilctReport", this);
				oView.addDependent(this._oConflictReport);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oConflictReport);
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			var srchId = this.getModel("worklistView").getProperty("/Searchid");
			aFilter.push(new Filter("Searchid", "EQ", srchId));
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_CONFLICTS_SRV/");
			var oCSTableModel = new sap.ui.model.json.JSONModel();
			var oTable = that.getView().byId("ConflictSearchTableId");
			oTable.setModel(oCSTableModel, "csTableModel");
			oModel.read("/Searchresults", {
				filters: aFilter,
				success: function(oData) {
					oCSTableModel.setData(oData);
					that.setCount();
					oTable._handleRowCountModeAuto();
					oBusyDialog.close();
					that._oConflictReport.open();
				},
				error: function(oError) {
					sap.m.MessageBox.error(oError.message, {
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE]
					});
					oBusyDialog.close();
				}
			});
		},
		onCloseConflictsSearch: function() {
			this._oConflictReport.close();
		},
		setCount: function() {
			var oBinding = this.getView().byId("ConflictSearchTableId").getBinding("rows"),
				oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/tableCount", oBinding.iLength);
			if (oBinding.iLength === 0) {
				oViewModel.setProperty("/tableNoDataText", "No Data");
			}
		},
		onSubmitView: function() {
			this._oKnownParties.close();
		},
		onClosevConflicts: function() {
			this._oKnownParties.close();
		},
	/*	onPressPopinDispBtn: function(evt) {
			var oView = this.getView();
			sap.ui.controller("cminewrequest.controller.NewRequest").onPressPopinDispBtn(evt, oView);
		},*/
		onPressAddLeadPartner: function() {
			var idLeadPartner = this.byId("idLeadPartner"),
				objLead = idLeadPartner.getBindingContext().getModel(),
				path = idLeadPartner.getBindingContext().getPath(),
				oViewNewModel = this.getModel("NRequestView"),
				aLeadPartnerData = oViewNewModel.getProperty("/Leadpartners");
			var oError = this.getModel("ErrorShow");
			oError.setProperty("/vLeadOffice", "None");
			oError.setProperty("/vLeadPartner", "None");
			oError.setProperty("/vLeadEmail", "None");
			oError.setProperty("/vLeadPhone", "None");
			if (!objLead.getProperty(path + "/Office") || !objLead.getProperty(path + "/Email") || !objLead.getProperty(path + "/Phone") || !
				objLead.getProperty(path + "/Leadpartner")) {
				if (!objLead.getProperty(path + "/Office")) {
					oError.setProperty("/vLeadOffice", "Error");
				}
				if (!objLead.getProperty(path + "/Phone")) {
					oError.setProperty("/vLeadPhone", "Error");
				}
				if (!objLead.getProperty(path + "/Email")) {
					oError.setProperty("/vLeadEmail", "Error");
				}
				if (!objLead.getProperty(path + "/Leadpartner")) {
					oError.setProperty("/vLeadPartner", "Error");
				}
				return;
			}

			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			if (!validateEmail(objLead.getProperty(path + "/Email"))) {
				oError.setProperty("/vLeadEmail", "Error");
				sap.m.MessageToast.show("Enter valid Email Id.");
				return;
			}
			var odata = {
				Office: objLead.getProperty(path + "/Office"),
				Email: objLead.getProperty(path + "/Email"),
				Phone: objLead.getProperty(path + "/Phone"),
				Leadpartner: objLead.getProperty(path + "/Leadpartner"),
				Cmino: "$000000001",
				Leadpartnerk: objLead.getProperty(path + "/Leadpartnerk"),
				Officek: objLead.getProperty(path + "/Officek"),
				Parvw: objLead.getProperty(path + "/Parvw"),
				Parvwdesc: objLead.getProperty(path + "/Parvwdesc")
			};
			aLeadPartnerData.push(odata);
			oViewNewModel.refresh();
			objLead.setProperty(path + "/Office", "");
			objLead.setProperty(path + "/Email", "");
			objLead.setProperty(path + "/Phone", "");
			objLead.setProperty(path + "/Leadpartner", "");
			objLead.setProperty(path + "/Leadpartnerk", "");
			objLead.setProperty(path + "/Officek", "");
			objLead.setProperty(path + "/Parvw", "");
			objLead.setProperty(path + "/Parvwdesc", "");
			objLead.refresh();
			//idLeadPartner.setBindingContext(idLeadPartner.getBindingContext());
		},
		updateFinishedLeadPartnerTableResult: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sTotal = oEvent.getParameter("total");
			var oKwnPartiesModel = oSrc.getModel("NRequestView");
			for (var i = 0; i < sTotal; i++) {
				oKwnPartiesModel.setProperty("/Leadpartners/" + i + "/Rank", this.formatter.sequenceRankNumber(i + 1));
			}
		},
		handleDeleteLeadPartner: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oTable.indexOfItem(oItmSel);
			oTable.getModel("NRequestView").getProperty("/Leadpartners").splice(ind, 1);
			oTable.getModel("NRequestView").refresh();
		},
		handleDeleteTerms: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oTable.indexOfItem(oItmSel);
			oTable.getModel("NRequestView").getProperty("/Ocgs").splice(ind, 1);
			oTable.getModel("NRequestView").refresh();
		},
		onAddContact: function() {
			//	var oContactModel = this.getModel("oContactDataModel"),
			var oViewNewModel = this.getModel("NRequestView"),
				aClientData = oViewNewModel.getProperty("/Clientcontacts");
			var oError = this.getModel("ErrorShow");
			oError.setProperty("/vContactName", "None");
			oError.setProperty("/vContactPhone", "None");
			oError.setProperty("/vContactEmail", "None");
			/*	if (!oContactModel.getProperty("/Name") || !oContactModel.getProperty("/Phone") || !oContactModel.getProperty("/Email")) {
					if (!oContactModel.getProperty("/Name")) {
						oError.setProperty("/vContactName", "Error");
					}
					if (!oContactModel.getProperty("/Phone")) {
						oError.setProperty("/vContactPhone", "Error");
					}
					if (!oContactModel.getProperty("/Email")) {
						oError.setProperty("/vContactEmail", "Error");
					}
					return;
				}

				function validateEmail(email) {
					var re =
						/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					return re.test(String(email).toLowerCase());
				}
				if (!validateEmail(oContactModel.getProperty("/Email"))) {
					oError.setProperty("/vContactEmail", "Error");
					sap.m.MessageToast.show("Enter valid Email Id.");
					return;
				}*/
			var odata = {
				Name: "",
				Email: "",
				Phone: "",
				Comments: "",
				Contacttype: "S",
				Contactseq: "",
				Cmino: "$000000001",
				EditContact: true
			};
			aClientData.push(odata);
			oViewNewModel.refresh();
			var oTable = this.byId("TableDialog");
			this.upDateContactButtons(oTable);
		},
		upDateContactButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].getCells()[5];
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleDeleteContacts: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oTable.indexOfItem(oItmSel);
			oTable.getModel("NRequestView").getProperty("/Clientcontacts").splice(ind, 1);
			oTable.getModel("NRequestView").refresh();
			if (oTable.getItems().length < 1) {
				this.onAddContact();
			}
			this.upDateContactButtons(oTable);
		},
		handleDeleteComments: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oItmSel.getBindingContext("CommentsModel").getObject().Sequence;
			oTable.getModel("CommentsModel").getProperty("/CommentSet").splice(ind, 1);
			oTable.getModel("CommentsModel").refresh();
		},
		attachmentData: function() {
			var oObj = [];
			var oJsonModel = new sap.ui.model.json.JSONModel({
				FileDataSet: oObj
			});
			this.getView().setModel(oJsonModel, "AttachmentModel");

			var oJsonKPModel = new sap.ui.model.json.JSONModel({
				KPDataSet: []
			});
			this.getView().setModel(oJsonKPModel, "KPModel");
		},
		onChange: function(oEvent) {
			var oModel = this.getView().getModel("AttachmentModel");
			var oData = oModel.getProperty("/FileDataSet");
			var files = oEvent.getParameter("files")[0];
			var obj = {
				"AttachmentNo": files.lastModified,
				"FileName": files.name,
				"MimeType": files.type,
				"url": "https://",
				"visibleDelete": true
			};
			oData.push(obj);
			oModel.refresh();
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("NewRequest", {}, true);
			}
		},
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}
			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.CategoryID,
				sObjectName = oObject.CategoryID;
			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		OnpressSubmit2: function() {
			var oMatterData = this._readClientMatterDetails();
			var sData = JSON.stringify(oMatterData);
			var str = sData.toString();
			this._textDialog = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.TextArea", this);
			this.getView().addDependent(this._textDialog);
			this._textDialog.getContent()[0].setValue(str);
			this._textDialog.open();
		},
		_readClientMatterDetails: function() {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var CmiId = this.getModel("objectView").getProperty("/CmiId"),
				oRequestModel, matterData, clientMData, AlterData,
				matterPath = this.getBindingContextbyId("idMatterDetails").sPath,
				matterModel = this.getBindingContextbyId("idMatterDetails").getModel();
			matterModel.setProperty(matterPath + "/Cmino", CmiId);
			matterData = matterModel.getProperty(matterPath);

			var clientPath = this.getBindingContextbyId("SimpFormClientEdit").sPath,
				clientModel = this.getBindingContextbyId("SimpFormClientEdit").getModel();
			clientModel.setProperty(clientPath + "/Cmino", CmiId);
			clientMData = clientModel.getProperty(clientPath);

			/*	var AlterPath = this.getBindingContextbyId("idAlterDetails").sPath,
					AlterModel = this.getBindingContextbyId("idAlterDetails").getModel();
				AlterModel.setProperty(AlterPath + "/Cmino", CmiId);
				AlterData = AlterModel.getProperty(AlterPath);
					delete(AlterData.__metadata);*/
			oRequestModel = this.getModel("NRequestView");
			delete(clientMData.__metadata);
			delete(matterData.__metadata);

			//  Detail Section Contact Details
			var clientContactData = oRequestModel.getProperty("/Clientcontacts");
			var contactSubmitData = [];
			for (var c = 0; c < clientContactData.length; c++) {
				oRequestModel.setProperty("/Clientcontacts/" + c + "/Cmino", CmiId);
				var obj = {
					Cmino: CmiId,
					Contactseq: oRequestModel.getProperty("/Clientcontacts/" + c + "/Contactseq"),
					Contacttype: oRequestModel.getProperty("/Clientcontacts/" + c + "/Contacttype"),
					Email: oRequestModel.getProperty("/Clientcontacts/" + c + "/Email"),
					Name: oRequestModel.getProperty("/Clientcontacts/" + c + "/Name"),
					Phone: oRequestModel.getProperty("/Clientcontacts/" + c + "/Phone"),
					Comments: oRequestModel.getProperty("/Clientcontacts/" + c + "/Comments")
				};
				contactSubmitData.push(obj);
			}
			if (!contactSubmitData.length) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.information(
					"You must provide at least one (1) primary contact.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return false;
			} else {
				if (contactSubmitData[0].Name === "" || contactSubmitData[0].Phone === "" || contactSubmitData[0].Email === "") {
					sap.m.MessageBox.information(
						"You must provide at least one (1) primary contact.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					return false;
				}
				if (contactSubmitData.length === 1) {
					contactSubmitData[contactSubmitData.length - 1].Contacttype = "P";
				}
				if (contactSubmitData.length > 1) {
					var contact = contactSubmitData.filter(function(sContact) {
						return sContact.Contacttype === "P";
					});
					if (!contact.length) {
						sap.m.MessageBox.information(
							"You must select a preferred contact.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return false;
					}
				}
			}
			//  Detail Section Known parties
			var knowParty = this.byId("idKnownParty"),
				Knownparties = [];
			for (var i = 0; i < knowParty.getItems().length; i++) {
				var oItem = knowParty.getItems()[i];
				var sSequence = this.formatter.sequenceNumber(i + 1);
				var KnownPath = oItem.getBindingContext().sPath,
					KnownModel = oItem.getBindingContext().getModel();
				var obj = {
					"Cmino": CmiId,
					"Designation": KnownModel.getProperty(KnownPath + "/" + "Designation"),
					"Knownpartyseq": sSequence,
					"Classification": KnownModel.getProperty(KnownPath + "/" + "Classification"),
					"Rolek": KnownModel.getProperty(KnownPath + "/" + "Rolek"),
					"Designationk": KnownModel.getProperty(KnownPath + "/" + "Designationk"),
					"Classificationk": KnownModel.getProperty(KnownPath + "/" + "Classificationk"),
					"Role": KnownModel.getProperty(KnownPath + "/" + "Role"),
					"Name": KnownModel.getProperty(KnownPath + "/" + "Name"),
					"Comments": KnownModel.getProperty(KnownPath + "/" + "Comments"),
					"Hasconflict": KnownModel.getProperty(KnownPath + "/" + "Hasconflict")
				};
				Knownparties.push(obj);
			}
			// Detail Working Office
			var WOffice = this.byId("FormDisplay354WO"),
				aWOffice = [];
			for (var w = 0; w < WOffice.getItems().length; w++) {
				var oOItem = WOffice.getItems()[w];
				var OfficePath = oOItem.getBindingContext().sPath,
					OfficeModel = oOItem.getBindingContext().getModel();
				var wObj = {
					"Cmino": CmiId,
					"OfficeCode": OfficeModel.getProperty(OfficePath + "/" + "OfficeCode"),
					"OfficeName": OfficeModel.getProperty(OfficePath + "/" + "OfficeName"),
					"CompCode": OfficeModel.getProperty(OfficePath + "/" + "CompCode"),
					"CompanyName": OfficeModel.getProperty(OfficePath + "/" + "CompanyName"),
					"Country": OfficeModel.getProperty(OfficePath + "/" + "Country"),
					"CountryName": OfficeModel.getProperty(OfficePath + "/" + "CountryName")
				};
				aWOffice.push(wObj);
			}
			// Tax Data
			// Detail Working Office
			var wTaxData = this.byId("FormChange354WD"),
				aTaxData = [];
			for (var t = 0; t < wTaxData.getItems().length; t++) {
				var owTaxDataItem = wTaxData.getItems()[t];
				var wTaxDataPath = owTaxDataItem.getBindingContext().sPath,
					wTaxDataModel = owTaxDataItem.getBindingContext().getModel();
				var dat1 = wTaxDataModel.getProperty(wTaxDataPath + "/" + "Agtdf");
				var dat2 = wTaxDataModel.getProperty(wTaxDataPath + "/" + "Agtdt");
				if (dat1 != null && dat1 !== "" && typeof(dat1) ===
					"string") {
					dat1 = dat1 + "T00:00:00";
				} else {
					if (dat1 != null) {
						dat1 = dateFormat.format(dat1) + "T00:00:00";
					} else {
						dat1 = null;
					}
				}
				if (dat2 != null && dat2 !== "" && typeof(dat2) ===
					"string") {
					dat2 = dat2 + "T00:00:00";
				} else {
					if (dat2 != null) {
						dat2 = dateFormat.format(dat2) + "T00:00:00";
					} else {
						dat2 = null;
					}
				}

				var wObjTaxData = {
					"Cmino": CmiId,
					"Witht": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Witht"),
					"Withcd": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Withcd"),
					"Withdesc": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Withdesc"),
					"Text40": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Text40"),
					"Agent": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Agent"),
					"Agtdf": dat1,
					"Agtdt": dat2,
					"Vkorg": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Vkorg"),
					"Clientk": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Clientk"),
					"Client": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Client"),
					"Msgfn": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Msgfn"),
					"Qland": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Qland"),
					"Wtstcd": wTaxDataModel.getProperty(wTaxDataPath + "/" + "Wtstcd")
				};
				aTaxData.push(wObjTaxData);
			}
			// Detail Client BP
			var wClientBP = this.byId("handleCellClickChgBPBP"),
				aBpData = [];
			for (var bp = 0; bp < wClientBP.getItems().length; bp++) {
				var owwClientBPItem = wClientBP.getItems()[bp];
				var wClientBPPath = owwClientBPItem.getBindingContext().sPath,
					wClientBPModel = owwClientBPItem.getBindingContext().getModel();
				var wClientBPData = {
					"Cmino": CmiId,
					"Clientk": wClientBPModel.getProperty(wClientBPPath + "/" + "Clientk"),
					"Vkorg": wClientBPModel.getProperty(wClientBPPath + "/" + "Vkorg"),
					"Parvw": wClientBPModel.getProperty(wClientBPPath + "/" + "Parvw"),
					"Parnr": wClientBPModel.getProperty(wClientBPPath + "/" + "Parnr"),
					"Bpseq": wClientBPModel.getProperty(wClientBPPath + "/" + "Bpseq"),
					"Vtext": wClientBPModel.getProperty(wClientBPPath + "/" + "Vtext"),
					"Client": wClientBPModel.getProperty(wClientBPPath + "/" + "Client"),
					"Parvwdesc": wClientBPModel.getProperty(wClientBPPath + "/" + "Parvwdesc"),
					"Partnername": wClientBPModel.getProperty(wClientBPPath + "/" + "Partnername"),
					"Vkorgdesc": wClientBPModel.getProperty(wClientBPPath + "/" + "Vkorgdesc"),
					"Msgfn": wClientBPModel.getProperty(wClientBPPath + "/" + "Msgfn"),
					"Addr1": wClientBPModel.getProperty(wClientBPPath + "/" + "Addr1"),
					"Addr2": wClientBPModel.getProperty(wClientBPPath + "/" + "Addr2"),
					"Phone": wClientBPModel.getProperty(wClientBPPath + "/" + "Phone"),
					"Cityk": wClientBPModel.getProperty(wClientBPPath + "/" + "Cityk"),
					"Statek": wClientBPModel.getProperty(wClientBPPath + "/" + "Statek"),
					"Zip": wClientBPModel.getProperty(wClientBPPath + "/" + "Zip"),
					"Countryk": wClientBPModel.getProperty(wClientBPPath + "/" + "Countryk"),
					"Country": wClientBPModel.getProperty(wClientBPPath + "/" + "Country")
				};
				aBpData.push(wClientBPData);
			}
			// Detail Billing Financial
			var idBFinance = this.byId("FormChange354BF1"),
				aBFinance = [];
			for (var b = 0; b < idBFinance.getItems().length; b++) {
				var oBItem = idBFinance.getItems()[b];
				var oBFinancePath = oBItem.getBindingContext().sPath,
					oBFinanceModel = oBItem.getBindingContext().getModel();
				var oBFinance = {
					"Cmino": CmiId,
					"Alternatepayer": oBFinanceModel.getProperty(oBFinancePath + "/" + "Alternatepayer"),
					//	"Altpayeraddr1": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					//	"Altpayeraddr2": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayercityk": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercityk"),
					"Altpayercountry": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercountry"),
					"Altpayercountryk": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayercountryk"),
					"Altpayername": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayername"),
					"Partnertypedesc": oBFinanceModel.getProperty(oBFinancePath + "/" + "Partnertypedesc"),
					"Altpayerperc": (oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerperc") || "0.00"),
					"Altpayerseq": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerseq"),
					"Partnertype": oBFinanceModel.getProperty(oBFinancePath + "/" + "Partnertype"),
					"Isnew": oBFinanceModel.getProperty(oBFinancePath + "/" + "Isnew"),
					"IsMulti": oBFinanceModel.getProperty(oBFinancePath + "/" + "IsMulti"),
					"Altpayerstate": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerstate"),
					"Altpayerstatek": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerstatek"),
					"Altpayerzip": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerzip"),
					"Altpayeraddr1": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					"Altpayeraddr2": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayerphone": oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerphone")
				};
				aBFinance.push(oBFinance);
			}
			var idMatterBPartner = this.byId("FormChange354BP");
			for (var mbp = 0; mbp < idMatterBPartner.getItems().length; mbp++) {
				var oMBPItem = idMatterBPartner.getItems()[mbp];
				var oMBPPath = oMBPItem.getBindingContext().sPath,
					oMBPModel = oMBPItem.getBindingContext().getModel();
				var oMBP = {
					"Cmino": CmiId,
					"Alternatepayer": oMBPModel.getProperty(oMBPPath + "/" + "Alternatepayer"),
					//	"Altpayeraddr1": oMBPModel.getProperty(oBFinancePath + "/" + "Altpayeraddr1"),
					//	"Altpayeraddr2": oMBPModel.getProperty(oBFinancePath + "/" + "Altpayeraddr2"),
					"Altpayercityk": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercityk"),
					"Altpayercountry": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercountry"),
					"Altpayercountryk": oMBPModel.getProperty(oMBPPath + "/" + "Altpayercountryk"),
					"Altpayername": oMBPModel.getProperty(oMBPPath + "/" + "Altpayername"),
					"Partnertypedesc": oMBPModel.getProperty(oMBPPath + "/" + "Partnertypedesc"),
					"Altpayerperc": (oMBPModel.getProperty(oMBPPath + "/" + "Altpayerperc") || "0.00"),
					"Altpayerseq": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerseq"),
					"Partnertype": oMBPModel.getProperty(oMBPPath + "/" + "Partnertype"),
					"Isnew": oMBPModel.getProperty(oMBPPath + "/" + "Isnew"),
					"IsMulti": oMBPModel.getProperty(oMBPPath + "/" + "IsMulti"),
					"Altpayerstate": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerstate"),
					"Altpayerstatek": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerstatek"),
					"Altpayerzip": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerzip"),
					"Altpayerphone": oMBPModel.getProperty(oMBPPath + "/" + "Altpayerphone"),
					"Altpayeraddr1": oMBPModel.getProperty(oMBPPath + "/" + "Altpayeraddr1"),
					"Altpayeraddr2": oMBPModel.getProperty(oMBPPath + "/" + "Altpayeraddr2")
				};
				aBFinance.push(oMBP);
			}
			/*	var Alterswitch = this.byId("idAlterSwitch");
				if (Alterswitch.getState()) {
					aBFinance.push(AlterData);
				}*/
			for (var oBFS = 0; oBFS < aBFinance.length; oBFS++) {
				aBFinance[oBFS].Altpayerseq = this.formatter.sequenceNumber(oBFS + 1);
			}
			//  Detail Section lead Partner
			var idLeadPartner = this.byId("idLeadPartnerT"),
				leadData = [];
			for (var iL = 0; iL < idLeadPartner.getItems().length; iL++) {
				var oLItem = idLeadPartner.getItems()[iL];
				var sLSequence = this.formatter.sequenceRankNumber(iL + 1);
				var LeadPath = oLItem.getBindingContext().sPath,
					LeadModel = oLItem.getBindingContext().getModel();
				var objL = {
					"Cmino": CmiId,
					"Rank": sLSequence,
					"Office": LeadModel.getProperty(LeadPath + "/" + "Office"),
					"Officek": LeadModel.getProperty(LeadPath + "/" + "Officek"),
					"Leadpartnerk": LeadModel.getProperty(LeadPath + "/" + "Leadpartnerk"),
					"Leadpartner": LeadModel.getProperty(LeadPath + "/" + "Leadpartner"),
					"Parvw": LeadModel.getProperty(LeadPath + "/" + "Parvw"),
					"Parvwdesc": LeadModel.getProperty(LeadPath + "/" + "Parvwdesc"),
					"Phone": LeadModel.getProperty(LeadPath + "/" + "Phone"),
					"Email": LeadModel.getProperty(LeadPath + "/" + "Email")
				};
				leadData.push(objL);
			}

			//  Detail Section Ocgs
			var ocgData = oRequestModel.getProperty("/Ocgs");
			var ocgSubmitData = [];
			for (var o = 0; o < ocgData.length; o++) {
				oRequestModel.setProperty("/Ocgs/" + o + "/Cmino", CmiId);
				delete(ocgData[o].__metadata);
				if (Array.isArray(ocgData[o].Ostatusk) || ocgData[o].Ostatusk == 0) {
					ocgData[o].Ostatusk = "";
				}
				if (Array.isArray(ocgData[o].Ostatus)) {
					ocgData[o].Ostatus = "";
				}
				if (Array.isArray(ocgData[o].Uploadeddate)) {
					ocgData[o].Uploadeddate = null;
				}
				for (var j = 0; j < ocgData[o].OcgTerms.length; j++) {
					delete(ocgData[o].OcgTerms[j].__metadata);
				}
				var objData = {};
				objData.Ostatusk = ocgData[o].Ostatusk;
				objData.Ostatus = ocgData[o].Ostatus;
				objData.Cmino = ocgData[o].Cmino;
				objData.Cmiocgseq = ocgData[o].Cmiocgseq;
				objData.Filename = ocgData[o].Filename;
				objData.Filesize = ocgData[o].Filesize;
				objData.Uploadeddate = ocgData[o].Uploadeddate;
				objData.Uploadedbyk = ocgData[o].Uploadedbyk;
				objData.Uploadedby = ocgData[o].Uploadedby;
				objData.OcgTerms = ocgData[o].OcgTerms;
				ocgSubmitData.push(objData);
			}
			// Comments
			var oRemarks = this.getView().getModel("RemarkModel");
			var oRemarkData = oRemarks.getProperty("/RemarkSet");
			var DataComments = [];
			var dateTimeFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddhhmmss"
			});
			for (var co = 0; co < oRemarkData.length; co++) {
				var sRSequence = this.formatter.sequenceNumber(co + 1);
				var oRobj = {
					Cmino: CmiId,
					//	CommentType:oRemarkData[co].CommentType,
					CommentType: "CI",
					Sequence: sRSequence,
					UserComment: oRemarkData[co].UserComment,
					Addedby: oRemarkData[co].Addedby,
					Addedbyk: oRemarkData[co].Addedbyk,
					// 	Addedon: this.formatter.dateFormat.format(oRemarkData[co].Addedon)
					Addedon: "0"
				};
				DataComments.push(oRobj);
			}
			var oSRemarks = this.getView().getModel("CommentsModel");
			var oSRemarkData = oSRemarks.getProperty("/CommentSet");
			for (var so = 0; so < oSRemarkData.length; so++) {
				var sSRSequence = this.formatter.sequenceNumber(so + 1);
				var oSRobj = {
					Cmino: CmiId,
					//	CommentType: oSRemarkData[so].CommentType,
					CommentType: "CI",
					Sequence: sSRSequence,
					UserComment: oSRemarkData[so].UserComment,
					Addedby: oSRemarkData[so].Addedby,
					Addedbyk: oSRemarkData[so].Addedbyk,
					// 	Addedon: this.formatter.dateFormat.format(oRemarkData[co].Addedon)
					Addedon: typeof(oSRemarkData[so].Addedon) === "string" ? oSRemarkData[so].Addedon : dateTimeFormat.format(oSRemarkData[so].Addedon)
				};
				DataComments.push(oSRobj);
			}
			// Detail Matter in Detail
			/*	var MatterInDetailPath = this.getBindingContextbyId("MatterInDetailsStep").sPath,
					MatterInDetailModel = this.getBindingContextbyId("MatterInDetailsStep").getModel(),
					MatterInDetailData = MatterInDetailModel.getProperty(MatterInDetailPath);
				var oMatterIndetail = {
					Cmino: CmiId,
					"Zzmattertypedesc": MatterInDetailData.Zzmattertypedesc,
					"Zzmattertype": MatterInDetailData.Zzmattertype,
					"Zzenttypedesc": MatterInDetailData.Zzenttypedesc,
					"Zzenttype": MatterInDetailData.Zzenttype,
					"Zztimeentryunitdesc": MatterInDetailData.Zztimeentryunitdesc,
					"Zztimeentryunit": MatterInDetailData.Zztimeentryunit,
					"Zzmattercatdesc": MatterInDetailData.Zzmattercatdesc,
					"Zzmattercat": MatterInDetailData.Zzmattercat,
					"Zzmprgrpdesc": MatterInDetailData.Zzmprgrpdesc,
					"Zzmprgrp": MatterInDetailData.Zzmprgrp,
					"Zzmatrptgrpdesc": MatterInDetailData.Zzmatrptgrpdesc,
					"Zzmatrptgrp": MatterInDetailData.Zzmatrptgrp,
					"Zzgrpbilldesc": MatterInDetailData.Zzgrpbilldesc,
					"Zzgrpbill": MatterInDetailData.Zzgrpbill,
					"Zzpracticegroupdesc": MatterInDetailData.Zzpracticegroupdesc,
					"Zzpracticegroup": MatterInDetailData.Zzpracticegroup,
					"Zzefees": MatterInDetailData.Zzefees,
					"Zzecost": MatterInDetailData.Zzecost,
					"Zzetotal": MatterInDetailData.Zzetotal,
					"Zzwipprovpercent": MatterInDetailData.Zzwipprovpercent,
					"Zzsyndlomat": MatterInDetailData.Zzsyndlomat,
					"Zzpassthru": MatterInDetailData.Zzpassthru,
					"Zzpriconfdesc": MatterInDetailData.Zzpriconfdesc,
					"Zzpriconf": MatterInDetailData.Zzpriconf
				};*/
			var oMatterIndetail = this.getBindingContextbyId("MatterInDetailsStep").getObject();
			delete(oMatterIndetail.__metadata);

			if (matterData.Zzplfaz != null && matterData.Zzplfaz !== "" && typeof(matterData.Zzplfaz) ===
				"string") {
				matterData.Zzplfaz = matterData.Zzplfaz + "T00:00:00";
			} else {
				if (matterData.Zzplfaz != null) {
					matterData.Zzplfaz = dateFormat.format(matterData.Zzplfaz) + "T00:00:00";
				} else {
					matterData.Zzplfaz = null;
				}
			}
			if (matterData.Zzplsez != null && matterData.Zzplsez !== "" && typeof(matterData.Zzplsez) ===
				"string") {
				matterData.Zzplsez = matterData.Zzplsez + "T00:00:00";
			} else {
				if (matterData.Zzplsez != null) {
					matterData.Zzplsez = dateFormat.format(matterData.Zzplsez) + "T00:00:00";
				} else {
					matterData.Zzplsez = null;
				}
			}

			if (oMatterIndetail.ZztcsetValidfrom != null && oMatterIndetail.ZztcsetValidfrom !== "" && typeof(oMatterIndetail.ZztcsetValidfrom) ===
				"string") {
				oMatterIndetail.ZztcsetValidfrom = oMatterIndetail.ZztcsetValidfrom + "T00:00:00";
			} else {
				if (oMatterIndetail.ZztcsetValidfrom != null) {
					oMatterIndetail.ZztcsetValidfrom = dateFormat.format(oMatterIndetail.ZztcsetValidfrom) + "T00:00:00";
				} else {
					oMatterIndetail.ZztcsetValidfrom = null;
				}
			}
			if (oMatterIndetail.Zzipappldate != null && oMatterIndetail.Zzipappldate !== "" && typeof(oMatterIndetail.Zzipappldate) ===
				"string") {
				oMatterIndetail.Zzipappldate = oMatterIndetail.Zzipappldate + "T00:00:00";
			} else {
				if (oMatterIndetail.Zzipappldate != null) {
					oMatterIndetail.Zzipappldate = dateFormat.format(oMatterIndetail.Zzipappldate) + "T00:00:00";
				} else {
					oMatterIndetail.Zzipappldate = null;
				}
			}
			if (oMatterIndetail.Zzipregdt != null && oMatterIndetail.Zzipregdt !== "" && typeof(oMatterIndetail.Zzipregdt) === "string") {
				oMatterIndetail.Zzipregdt = oMatterIndetail.Zzipregdt + "T00:00:00";
			} else {
				if (oMatterIndetail.Zzipregdt != null) {
					oMatterIndetail.Zzipregdt = dateFormat.format(oMatterIndetail.Zzipregdt) + "T00:00:00";
				} else {
					oMatterIndetail.Zzipregdt = null;
				}
			}
			if (oMatterIndetail.ZzacsetValidfrom != null && oMatterIndetail.ZzacsetValidfrom !== "" && typeof(oMatterIndetail.ZzacsetValidfrom) ===
				"string") {
				oMatterIndetail.ZzacsetValidfrom = oMatterIndetail.ZzacsetValidfrom + "T00:00:00";
			} else {
				if (oMatterIndetail.ZzacsetValidfrom != null) {
					oMatterIndetail.ZzacsetValidfrom = dateFormat.format(oMatterIndetail.ZzacsetValidfrom) + "T00:00:00";
				} else {
					oMatterIndetail.ZzacsetValidfrom = null;
				}
			}
			if (!oMatterIndetail.Zzefees) {
				oMatterIndetail.Zzefees = "0.00";
			}
			if (!oMatterIndetail.Zzecost) {
				oMatterIndetail.Zzecost = "0.00";
			}
			if (!oMatterIndetail.Zzetotal) {
				oMatterIndetail.Zzetotal = "0.00";
			}
			if (!oMatterIndetail.Zzcompletion) {
				oMatterIndetail.Zzcompletion = "0.00";
			}
			if (!oMatterIndetail.Zzcap) {
				oMatterIndetail.Zzcap = "0.00";
			}
			oMatterIndetail.Cmino = CmiId;
			var oClientIndetail = this.getBindingContextbyId("ClientDetailStep").getObject();
			delete(oClientIndetail.__metadata);

			if (oClientIndetail.Zzopendate != null && oClientIndetail.Zzopendate !== "" && typeof(oClientIndetail.Zzopendate) ===
				"string") {
				oClientIndetail.Zzopendate = oClientIndetail.Zzopendate + "T00:00:00";
			} else {
				if (oClientIndetail.Zzopendate != null) {
					oClientIndetail.Zzopendate = dateFormat.format(oClientIndetail.Zzopendate) + "T00:00:00";
				} else {
					oClientIndetail.Zzopendate = null;
				}
			}
			if (oClientIndetail.Zzclosedate != null && oClientIndetail.Zzclosedate !== "" && typeof(oClientIndetail.Zzclosedate) ===
				"string") {
				oClientIndetail.Zzclosedate = oClientIndetail.Zzclosedate + "T00:00:00";
			} else {
				if (oClientIndetail.Zzclosedate != null) {
					oClientIndetail.Zzclosedate = dateFormat.format(oClientIndetail.Zzclosedate) + "T00:00:00";
				} else {
					oClientIndetail.Zzclosedate = null;
				}
			}
			if (oClientIndetail.Zzenddt != null && oClientIndetail.Zzenddt !== "" && typeof(oClientIndetail.Zzenddt) ===
				"string") {
				oClientIndetail.Zzenddt = oClientIndetail.Zzenddt + "T00:00:00";
			} else {
				if (oClientIndetail.Zzenddt != null) {
					oClientIndetail.Zzenddt = dateFormat.format(oClientIndetail.Zzenddt) + "T00:00:00";
				} else {
					oClientIndetail.Zzenddt = null;
				}
			}
			if (oClientIndetail.Zzphbegda != null && oClientIndetail.Zzphbegda !== "" && typeof(oClientIndetail.Zzphbegda) ===
				"string") {
				oClientIndetail.Zzphbegda = oClientIndetail.Zzphbegda + "T00:00:00";
			} else {
				if (oClientIndetail.Zzphbegda != null) {
					oClientIndetail.Zzphbegda = dateFormat.format(oClientIndetail.Zzphbegda) + "T00:00:00";
				} else {
					oClientIndetail.Zzphbegda = null;
				}
			}
			if (oClientIndetail.Zzvatvaldt != null && oClientIndetail.Zzvatvaldt !== "" && typeof(oClientIndetail.Zzvatvaldt) ===
				"string") {
				oClientIndetail.Zzvatvaldt = oClientIndetail.Zzvatvaldt + "T00:00:00";
			} else {
				if (oClientIndetail.Zzvatvaldt != null) {
					oClientIndetail.Zzvatvaldt = dateFormat.format(oClientIndetail.Zzvatvaldt) + "T00:00:00";
				} else {
					oClientIndetail.Zzvatvaldt = null;
				}
			}
			if (oClientIndetail.Zzactbegda != null && oClientIndetail.Zzactbegda !== "" && typeof(oClientIndetail.Zzactbegda) ===
				"string") {
				oClientIndetail.Zzactbegda = oClientIndetail.Zzactbegda + "T00:00:00";
			} else {
				if (oClientIndetail.Zzactbegda != null) {
					oClientIndetail.Zzactbegda = dateFormat.format(oClientIndetail.Zzactbegda) + "T00:00:00";
				} else {
					oClientIndetail.Zzactbegda = null;
				}
			}
			var oCoressIndetail = this.getBindingContextbyId("idCorresStep").getObject();
			delete(oCoressIndetail.__metadata);
			if (oCoressIndetail.Madat != null && oCoressIndetail.Madat !== "" && typeof(oCoressIndetail.Madat) ===
				"string") {
				oCoressIndetail.Madat = oCoressIndetail.Madat + "T00:00:00";
			} else {
				if (oCoressIndetail.Madat != null) {
					oCoressIndetail.Madat = dateFormat.format(oCoressIndetail.Madat) + "T00:00:00";
				} else {
					oCoressIndetail.Madat = null;
				}
			}
			//		var idClientDetailStep = this.byId("ClientDetailStep");
			//		var idCorresStep = this.byId("idCorresStep");
			oClientIndetail.Cmino = CmiId;
			oCoressIndetail.Cmino = CmiId;
			// Display All details
			var clientMatterDetails = {
				clientData: clientMData,
				Clientcontacts: contactSubmitData,
				matterData: matterData,
				Altpayers: aBFinance,
				Knownparties: Knownparties,
				Leadpartners: leadData,
				Ocgs: ocgSubmitData,
				Comments: DataComments,
				WOffice: aWOffice,
				MatterInDetail: oMatterIndetail,
				ClientInDetail: oClientIndetail,
				ClientCoress: oCoressIndetail,
				WtaxData: aTaxData,
				CllientbpData: aBpData
			};
			return clientMatterDetails;
		},
		onStepSubmit: function(CmiId) {
			var sPath = "/Cmihdrs";
			var oModel = this.getModel(),
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var Cmino = CmiId ? CmiId : "$000000001";
			var clientData = {
				Matterk: "$000000001",
				Clientk: this.getModel("worklistView").getProperty("/NMCNum"),
				Cmino: Cmino,
				Requesttime: "0",
				Cmirequesttype: "NCNM",
				Changedtime: "0",
				Clients: [this._readClientMatterDetails().clientData],
				Clientcontacts: this._readClientMatterDetails().Clientcontacts,
				ConsiderationsN: []
			};

			if (clientData.Clients.length) {
				delete(clientData.Clients[0].__metadata);
			}
			for (var i = 0; i < clientData.Clientcontacts.length; i++) {
				delete(clientData.Clientcontacts[i].EditContact);
				delete(clientData.Clientcontacts[i].__metadata);
			}

			var that = this;
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					that.getModel("objectView").setProperty("/CmiId", oResponse.data.Cmino);
					that.getModel("worklistView").setProperty("/NMCNum", oResponse.data.Clientk);

					//	that.getModel("worklistView").setProperty("/userId", oResponse.data.Requestuserk);
					//	that.getModel("worklistView").setProperty("/userName", oResponse.data.Requestuser);
					var data = oResponse.data.ConsiderationsN;
					var businessData = [],
						riskData = [];
					for (var j = 0; j < data.results.length; j++) {
						if (data.results[j].Attributetypek === "02") {
							riskData.push(data.results[j]);
						} else {
							businessData.push(data.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					if (data) {
						oJsonBModel.setData({
							ConsiData: businessData
						});
						that.getView().setModel(oJsonBModel, "jsonConsiModel");
						oJsonRModel.setData({
							RiskData: riskData
						});
						that.getView().setModel(oJsonRModel, "riskConsiModel");
					} else {
						oJsonBModel.setData({
							ConsiData: []
						});
						that.getView().setModel(oJsonBModel, "jsonConsiModel");
						oJsonRModel.setData({
							RiskData: []
						});
						that.getView().setModel(oJsonRModel, "riskConsiModel");
					}
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		onAlterMandatory: function(e) {
			var that = this;
			var oAlterData = that.byId("idAlterDetails").getBindingContext().getObject();
			var sFlag = true;
			for (var key in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key === "__metadata" || key === "Altpayeraddr1" || key === "Altpayeraddr2" || key === "Alternatepayer") {
						continue;
					}
					var oError = this.getModel("ShowAlterError");
					var Field = formatter.getAlterKeyField(key);
					if (oAlterData[key] === "") {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		OnpressSave: function() {
			var title = this.WizardTitle;

			if (!this.getContactsValidated()) {
				return;
			}
			var client = this.getBindingContextbyId("SimpFormClientEdit").getObject();
			var Email = client.Email;
			var oError = this.getModel("ErrorShow");

			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			oError.setProperty("/vEmail", "None");
			if (!validateEmail(Email)) {
				oError.setProperty("/vEmail", "Error");
				sap.m.MessageToast.show("Enter valid Email Id.");
				return;
			}
			if (!this._readClientMatterDetails()) {
				this.byId("NRWizard").goToStep(this.byId("ClientDetailStep"));
				return;
			}
			/*	if (!this.getMatterValidated()) {
					this.byId("NRWizard").goToStep(this.byId("MatterDetailsStep"));
					return;
				}
				if (!this.onAlterMandatory()) {
					this.byId("NRWizard").goToStep(this.byId("MatterDetailsStep"));
					return;
				}*/
			var sPath = "/Cmihdrs";
			var oModel = this.getModel(),
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var CmiId = this.getModel("objectView").getProperty("/CmiId");
			var srchId = this.getModel("worklistView").getProperty("/Searchid");
			var clientData = {
				Matterk: "$000000001",
				Cmino: CmiId,
				Clientk: this.getModel("worklistView").getProperty("/NMCNum"),
				Searchid: srchId,
				Requestuserk: "",
				Requestuser: "",
				Requesttime: "0",
				Cmirequesttype: "NCNM",
				Changedbyk: "",
				Changedby: "",
				Changedtime: "0"
			};
			var clientStepData = this.handleData(title, clientData);

			for (var i = 0; i < clientStepData.Clientcontacts.length; i++) {
				delete(clientStepData.Clientcontacts[i].EditContact);
				delete(clientStepData.Clientcontacts[i].__metadata);
			}
			var that = this;
			oModel.create(sPath, clientStepData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var cmiNo = oResponse.data.Cmino;
					var msg = "Client matter intake " + cmiNo + " has been created successfully,Do you want to continue?";
					sap.m.MessageBox.show(msg, {
						icon: "SUCCESS",
						title: "Success",
						//	actions: [sap.m.MessageBox.Action.OK],
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction === "YES") {
								//			that.byId("idToggle").setPressed(false);
								//			that.byId("idToggle").setText("Documents / Comments");
								that.byId("NRWizard").setVisible(true);
								that.bindDataKnownParties(oResponse.data.Knownparties.results);
								//			that.byId("idAttachment").setVisible(false);
								// jQuery.sap.delayedCall(600, this, function() {
								// 	that.byId("NRWizard").goToStep(that.byId("ClientDetailStep"));
								// 	that.validatedStep = true;
								// 	that.onFilterComments("Client Details");
								// });
							} else {
								that.onCancelSubmit();
							}
						}
					});
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		handleData: function(title, clientData) {
			clientData.Clients = [this._readClientMatterDetails().clientData];
			clientData.Matters = [this._readClientMatterDetails().matterData];
			clientData.Altpayers = this._readClientMatterDetails().Altpayers;
			clientData.Clientcontacts = this._readClientMatterDetails().Clientcontacts;
			clientData.Leadpartners = this._readClientMatterDetails().Leadpartners;
			clientData.Knownparties = this._readClientMatterDetails().Knownparties;
			clientData.Ocgs = this._readClientMatterDetails().Ocgs;
			clientData.Comments = this._readClientMatterDetails().Comments;
			clientData.Offices = this._readClientMatterDetails().WOffice;
			clientData.Matterdetails = [this._readClientMatterDetails().MatterInDetail];
			clientData.Clientdetails = [this._readClientMatterDetails().ClientInDetail];
			clientData.Clientcorrespondence = [this._readClientMatterDetails().ClientCoress];
			clientData.Wtax = this._readClientMatterDetails().WtaxData;
			clientData.Clientbp = this._readClientMatterDetails().CllientbpData;
			var CmiId = this.getModel("objectView").getProperty("/CmiId");
			var bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			var consiData = [];
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = CmiId;
				delete(bconsiData[c].__metadata);
			}
			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = CmiId;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);
			clientData.ConsiderationsN = consiData;
			for (var k = clientData.Knownparties.length - 1; k >= 0; k--) {
				var data = clientData.Knownparties[k];
				if (data.Name === "" || data.Classification === "" || data.Classification === "" || data.Role === "" || data.Role === "" ||
					data.Designation === "" || data.Designation === "") {
					clientData.Knownparties.splice(k, 1);
				}
			}
			for (var l = clientData.Leadpartners.length - 1; l >= 0; l--) {
				var dataLead = clientData.Leadpartners[l];
				if (dataLead.Office === "" || dataLead.Phone === "" || dataLead.Email === "" || dataLead.Leadpartner === "") {
					clientData.Leadpartners.splice(l, 1);
				}
			}
			if (clientData.Matterdetails.length) {
				delete(clientData.Matterdetails[0].__metadata);
				if (clientData.Matterdetails[0].Zzmattertypedesc.trim() === "" || clientData.Matterdetails[0].Zzenttype.trim() === "" ||
					clientData.Matterdetails[0].Zzmattercatdesc.trim() === "" ||
					clientData.Matterdetails[0].Zztimeentryunit.trim() === "" || clientData.Matterdetails[0].Zzpracticegroupdesc.trim() === "" ||
					clientData.Matterdetails[0].Zzbillfreqdesc.trim() ===
					"" || clientData.Matterdetails[0].Zzmcurrdesc.trim() === "" ||
					clientData.Matterdetails[0].Zzbsprasdesc.trim() === "") {
					clientData.Matterdetails = [];
				}
			}
			if (clientData.Matters.length) {
				if (clientData.Matters[0].Mattername === "" || clientData.Matters[0].Servicearea === "" || clientData.Matters[0].Mmak === "" ||
					clientData.Matters[0].Mmofficek === "") {
					clientData.Matters = [];
				}
			}
			return clientData;
		},
		OnpressSubmit: function() {
			if (!this.getContactsValidated()) {
				return;
			}
			var client = this.getBindingContextbyId("SimpFormClientEdit").getObject();
			var Email = client.Email;
			var that = this;
			var oBusy = new sap.m.BusyDialog();
			var oError = this.getModel("ErrorShow");

			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			oError.setProperty("/vEmail", "None");
			if (!validateEmail(Email)) {
				oError.setProperty("/vEmail", "Error");
				sap.m.MessageToast.show("Enter valid Email Id.");
				return;
			}
			var sPath = "/Cmihdrs";
			var oModel = this.getModel();
			var CmiId = this.getModel("objectView").getProperty("/CmiId");
			var srchId = this.getModel("worklistView").getProperty("/Searchid");
			var bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			var consiData = [];
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = CmiId;
				delete(bconsiData[c].__metadata);
			}
			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = CmiId;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);
			var clientCreateData = this._readClientMatterDetails();
			if (clientCreateData === false) {
				return;
			}
			var clientData = {
				Matterk: "$000000001",
				Action: "SUBM",
				Cmino: CmiId,
				Clientk: this.getModel("worklistView").getProperty("/NMCNum"),
				Searchid: srchId,
				Requesttime: "0",
				Cmirequesttype: "NCNM",
				Changedtime: "0",
				Clients: [clientCreateData.clientData],
				Matters: [clientCreateData.matterData],
				Altpayers: clientCreateData.Altpayers,
				Clientcontacts: clientCreateData.Clientcontacts,
				Leadpartners: clientCreateData.Leadpartners,
				Knownparties: clientCreateData.Knownparties,
				Ocgs: clientCreateData.Ocgs,
				Comments: clientCreateData.Comments,
				Offices: clientCreateData.WOffice,
				Matterdetails: [clientCreateData.MatterInDetail],
				Clientdetails: [clientCreateData.ClientInDetail],
				Clientcorrespondence: [clientCreateData.ClientCoress],
				Wtax: clientCreateData.WtaxData,
				Clientbp: clientCreateData.CllientbpData,
				ConsiderationsN: consiData
			};
			for (var i = 0; i < clientData.Clientcontacts.length; i++) {
				delete(clientData.Clientcontacts[i].EditContact);
				delete(clientData.Clientcontacts[i].__metadata);
			}
			oBusy.open();
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var cmiNo = oResponse.data.Cmino;
					var dataC = oData.ConsiderationsN;
					var businessData = [],
						riskData = [];
					if (dataC) {
						for (var j = 0; j < dataC.results.length; j++) {
							if (dataC.results[j].Attributetypek === "02") {
								riskData.push(dataC.results[j]);
							} else {
								businessData.push(dataC.results[j]);
							}
						}
						var oJsonBModel = new sap.ui.model.json.JSONModel();
						var oJsonRModel = new sap.ui.model.json.JSONModel();
						oJsonBModel.setData({
							ConsiData: businessData
						});
						that.getView().setModel(oJsonBModel, "jsonConsiModel");
						oJsonRModel.setData({
							RiskData: riskData
						});
						that.getView().setModel(oJsonRModel, "riskConsiModel");
					}
					var msg = "Client matter intake " + cmiNo + " has been Submitted successfully,Do you want to continue?";
					sap.m.MessageBox.show(msg, {
						icon: "SUCCESS",
						title: "Success",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction === "YES") {
								jQuery.sap.delayedCall(600, this, function() {
									that.byId("NRWizard").goToStep(that.byId("ClientDetailStep"));
								});
							} else {
								that.onCancelSubmit();
							}
						}
					});
				},
				error: function(oData) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		OnPressCDetails: function(oEvent) {
			var that = this;
			var bEdit = true;
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.NMRClientDetailsPopover", this);
				//this._oPopover.bindElement("/ProductCollection/0");
				this.getView().addDependent(this._oPopover);
			}
			if (bEdit) {
				var idClient = this.getView().byId("SimpFormClientEdit");
				var qtc = that.getModel();
				var data = that.getModel("TempModel").getData();
				var obj = {
					"Cmino": data.Cmino,
					"Clientk": data.Clientk,
					"Client": data.Client,
					"Classificationk": data.Classificationk,
					"Classification": data.Classification,
					"Addr1": data.Addr1,
					"Addr2": data.Addr2,
					"City": data.City,
					"Statek": data.Statek,
					"State": data.State,
					"Zipcode": data.Zipcode,
					"Countryk": data.Countryk,
					"Country": data.Country,
					"Bofficek": data.Bofficek,
					"Boffice": data.Boffice,
					"Email": data.Email,
					"Nstandardterms": data.Nstandardterms,
					"Vkorg": data.Vkorg,
					"Vkorgdesc": data.Vkorgdesc
				};
				var oContextClients = qtc.createEntry("/Cmiclients", {
					properties: obj
				});
				idClient.setBindingContext(oContextClients);
			}
			this._oPopover.openBy(oEvent.getSource());
		},
		handlepopDisplay: function() {
			var data = this.getBindingContextbyId("SimpFormClientEdit").getObject();
			var source = this.byId("idPopOverClassification");
			source.getAggregation("_content").setValue(data.Classification);
		},
		handleClientEdit: function() {
			var viewModel = this.getModel("worklistView");
			//viewModel.setProperty("/PopOverClientEdit", true);
			viewModel.setProperty("/btnDiplay", true);
			viewModel.setProperty("/clientFalse", true);
			viewModel.setProperty("/btnEdit", false);
			var data = this.getBindingContextbyId("SimpFormClientEdit").getObject();
			var source = this.byId("idPopOverClassification");
			source.getAggregation("_content").setValue(data.Classification);
		},

		handleClientDisplay: function() {
			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			var cObj = this.getBindingContextbyId("SimpFormClientEdit").getObject();
			if (!this.getContactsValidated("e")) {
				sap.m.MessageToast.show("Please fill mandatory fields");
				return;
			}
			var Email = cObj.Email;
			//			var oError = this.getModel("ErrorShow");
			//			oError.setProperty("/vEmail", "None");
			if (!validateEmail(Email)) {
				//				oError.setProperty("/vEmail", "Error");
				sap.m.MessageToast.show("Enter valid Email Id.");
				return;
			}

			var oClientData = this.byId("SimpFormClientEdit").getBindingContext().getObject();

			this.getModel("TempModel").setData(oClientData);
			var viewModel = this.getModel("worklistView");
			var model = this.getModel("objectView");
			var client = this.getModel("TempModel").getData().Client;
			model.setProperty("/NCTitle", client);
			// viewModel.setProperty("/PopOverClientDipl", true);
			viewModel.setProperty("/btnEdit", true);
			viewModel.setProperty("/clientFalse", false);
			viewModel.setProperty("/btnDiplay", false);
			var source = this.byId("idPopOverClassification");
			source.getAggregation("_content").setValue(oClientData.Classification);
			this.bindAddress();
			this.officeChange(oClientData);
		},

		handleclose: function() {
			var bEdit = true;
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			if (bEdit) {
				var idClient = this.getView().byId("SimpFormClientEdit");
				var qtc = this.getModel();
				var data = this.getModel("TempModel").getData();
				var obj = {
					"Cmino": data.Cmino,
					"Clientk": data.Clientk,
					"Client": data.Client,
					"Classificationk": data.Classificationk,
					"Classification": data.Classification,
					"Addr1": data.Addr1,
					"Addr2": data.Addr2,
					"City": data.City,
					"Statek": data.Statek,
					"State": data.State,
					"Zipcode": data.Zipcode,
					"Countryk": data.Countryk,
					"Country": data.Country,
					"Bofficek": data.Bofficek,
					"Boffice": data.Boffice,
					"Email": data.Email,
					"Nstandardterms": data.Nstandardterms,
					"Vkorg": data.Vkorg,
					"Vkorgdesc": data.Vkorgdesc
				};
				var oContextClients = qtc.createEntry("/Cmiclients", {
					properties: obj
				});
				idClient.setBindingContext(oContextClients);
				//	var source = this.byId("idPopOverClassification");
				//	source.getAggregation("_content").setValue(data.Classification);
				this.getContactsValidated("e");
				this.bindAddress();
			}
			this._oPopover.close();
		},

		changeField: function(evt) {
			// source.getAggregation("_content").getSelectedItem().getBindingContext().getObject()
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oClientContext = this.getBindingContextbyId("SimpFormClientEdit");
			var sPath = oClientContext.getPath();
			var oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
			if (path === "Countryk") {
				oClientModel.setProperty(sPath + "/" + "Statek", "");
				oClientModel.setProperty(sPath + "/" + "State", "");
			}
			if (path === "Client") {
				if (value.trim()) {
					this.getModel("objectView").setProperty("/clientName", "Client Name : " + value);
				} else {
					this.getModel("objectView").setProperty("/clientName", "");
				}

			}

			this.getContactsValidated("ch");
		},
		officeChange: function(c) {
			var oClientContext = this.getBindingContextbyId("ClientDetailStep");
			var sPath = oClientContext.getPath();
			var oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + "Vkorg", c.Vkorg);
			oClientModel.setProperty(sPath + "/" + "Vkorgdesc", c.Vkorgdesc);

		},
		getContactsValidated: function(e) {
			var that = this;
			var oClientData = that.byId("SimpFormClientEdit").getBindingContext().getObject();
			var sFlag = true;
			for (var key in oClientData) {
				if (oClientData.hasOwnProperty(key)) {
					if (key == "Addr2" || key == "Nstandardterms" || key == "__metadata") {
						continue;
					}
					var oError = this.getModel("ErrorShow");
					var Field = formatter.getKeyField(key);
					if (oClientData[key] == "") {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			if (e) {
				this.byId("ClientDetailStep").setValidated(sFlag);
				if (sFlag) {
					//		this._visibleComments();
					//		var scrollHeight = this.byId("NRWizard")._scroller.getMaxScrollTop();
					//		this.byId("NRWizard")._scroller.scrollTo(0, scrollHeight, 400);
				}
			}
			return sFlag;
		},
		getMatterValidated: function(e) {
			var that = this;
			var oMatterData = that.byId("idMatterDetails").getBindingContext().getObject();
			var sFlag = true;
			for (var key in oMatterData) {
				if (oMatterData.hasOwnProperty(key)) {
					if (key == "Quote" || key == "__metadata") {
						continue;
					}
					var oError = this.getModel("ShowMatterError");
					var Field = formatter.getMatterKeyField(key);
					if (oMatterData[key] == "") {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		changeMatterDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idMatterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
			this.getMatterValidated("ch");
		},
		changeInMatterDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			// set Value for Client Details Context
			var oMatterInContext = this.getBindingContextbyId("MatterInDetailsStep");
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeInClientDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			// set Value for Client Details Context
			var oMatterInContext = this.getBindingContextbyId("ClientDetailStep");
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeInClientCoresspondence: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			// set Value for Client Details Context
			var oMatterInContext = this.getBindingContextbyId("idCorresStep");
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeMatterInCurrDetails: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			// set Value for Client Details Context
			var path = source.getBindingPath("value");
			var oMatterContext = this.getBindingContextbyId("MatterInDetailsStep");
			var sPath = oMatterContext.getPath();
			var oMatterInModel = oMatterContext.getModel();

			var str = value.replace(/[^0-9.]+/g, "");

			function count(s1, letter) {
				return (s1.match(RegExp(letter, 'g')) || []).length;
			}

			function findAndReplace(string, target, replacement) {
				var i = 0,
					length = string.length;
				for (i; i < length; i++) {
					var count1 = count(string, '\\.');
					if (count1 > 1) {
						string = string.replace(target, replacement);
					}
				}
				return string;
			}
			var amount = findAndReplace(str, ".", "");
			oMatterInModel.setProperty(sPath + "/" + path, amount);
			source.setValue(amount);
		},
		handleSwitchChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var oMatterInContext = this.getBindingContextbyId("MatterInDetailsStep");
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		handleSwitchConsiChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("jsonConsiModel").getPath();
			var ConsiInModel = source.getBindingContext("jsonConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		handleSwitchRiskChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("riskConsiModel").getPath();
			var ConsiInModel = source.getBindingContext("riskConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		handleSwitchClientChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var oMatterInContext = this.getBindingContextbyId("ClientDetailStep");
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeMatterCurrDetails: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			var unit = source.getUnitOfMeasure();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idMatterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();

			var str = value.replace(/[^0-9.]+/g, "");

			function count(s1, letter) {
				return (s1.match(RegExp(letter, 'g')) || []).length;
			}

			function findAndReplace(string, target, replacement) {
				var i = 0,
					length = string.length;
				for (i; i < length; i++) {
					var count1 = count(string, '\\.');
					if (count1 > 1) {
						string = string.replace(target, replacement);
					}
				}
				return string;
			}
			var amount = findAndReplace(str, ".", "");
			oMatterModel.setProperty(sPath + "/Estimatedfees", amount);
			source.setValue(amount);
			oMatterModel.setProperty(sPath + "/Estimatedfeecurr", unit);
			this.getMatterValidated("ch");
		},
		changeAltDetails: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oMatterContext = this.getBindingContextbyId("idAlterDetails");
			var sPath = oMatterContext.getPath();
			var oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
			this.onAlterMandatory("ch");
		},
		changeLeadPartner: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Client Details Context
			var oLeadPartnerContext = this.getBindingContextbyId("idLeadPartner");
			var sPath = oLeadPartnerContext.getPath();
			var oLeadPartnerModel = oLeadPartnerContext.getModel();
			oLeadPartnerModel.setProperty(sPath + "/" + path, value);
			// hardcoded fields
			//	oLeadPartnerModel.setProperty(sPath + "/Office", "Hou");
			//	oLeadPartnerModel.setProperty(sPath + "/Leadpartner", "ISSAC ERIC DAVIES");
		},
		changeKnownDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			var oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Classification") {
					id = "Classificationk";
					description = "STEXT";
					key = "CLASSIFICATIONK";
				}
				if (path === "Role") {
					id = "Rolek";
					description = "STEXT";
					key = "ROLEK";
				}
				if (path === "Designation") {
					id = "Designationk";
					description = "STEXT";
					key = "DESIGNATIONK";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		changeAltTableDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		changeOfficeTableDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		getBindingContextbyId: function(sId) {
			var oContext = this.getView().byId(sId).getBindingContext();
			return oContext;
		},
		handleContactEdit: function(evt) {
			var oControl = evt.getSource(),
				oContext = oControl.getBindingContext("NRequestView"),
				sPath = oContext.sPath,
				allContext = oContext.getModel().mContexts,
				oContexts = Object.getOwnPropertyNames(allContext);
			oContexts.map(function(sPathItem) {
				if (sPathItem.indexOf("/Clientcontacts") !== -1) {
					oContext.getModel().setProperty(sPathItem + "/EditContact", false);
				}
			});
			oContext.getModel().setProperty(sPath + "/EditContact", true);
		},
		//Excell Import
		handleUpload: function() {
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file);

			}
		},
		_import: function(file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					//	xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					if (sheetData[0].Name === undefined && sheetData[0].Notes === undefined && sheetData[0].Classification === undefined &&
						sheetData[0].Role === undefined && sheetData[0].Designation === undefined && sheetData[0].Classificationk === undefined &&
						sheetData[0].Rolek === undefined && sheetData[0].Designationk === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i].Classification === undefined) {
							sheetData[i].Classification = "";
						}
						if (sheetData[i].Role === undefined) {
							sheetData[i].Role = "";
						}
						if (sheetData[i].Designation === undefined) {
							sheetData[i].Designation = "";
						}
						if (sheetData[i].Classificationk === undefined) {
							sheetData[i].Classificationk = "";
						}
						if (sheetData[i].Rolek === undefined) {
							sheetData[i].Rolek = "";
						}
						if (sheetData[i].Designationk === undefined) {
							sheetData[i].Designationk = "";
						}
						if (sheetData[i].Name === undefined) {
							sheetData[i].Name = "";
						}
						if (sheetData[i].Notes === undefined) {
							sheetData[i].Notes = "";
						}
					}
					that.abd(sheetData);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		onShowHideClientDetail: function(oEvent) {
			var bVal = oEvent.getParameter("pressed"),
				oViewModel = this.getModel("objectView"),
				oWizard = this.getView().byId("NRWizard");

			if (!bVal) {
				//	oViewModel.setProperty("/altCommnetVisible", false);
				oViewModel.setProperty("/expandClientDetails", true);
				oWizard.setHeight("360px");
			} else {
				//	var bIconTab = oViewModel.getProperty("/altIconTabVisible");
				//	oViewModel.setProperty("/altCommnetVisible", !bIconTab);
				oViewModel.setProperty("/expandClientDetails", false);
				oWizard.setHeight("500px");
			}
		},
		_visibleComments: function() {
			var oViewModel = this.getModel("objectView"),
				oWizard = this.getView().byId("NRWizard");
			oViewModel.setProperty("/expandClientDetails", false);
			oViewModel.setProperty("/altCommnetVisible", true);
			oWizard.setHeight("58%");
		},
		onPresshandleWizard: function(evt) {
			if (evt.getSource().getPressed()) {
				evt.getSource().setText("Client / Matter Details");
				this.byId("NRWizard").setVisible(false);
				this.getModel("objectView").setProperty("/altCommnetVisible", false);
				this.byId("idAttachment").setVisible(true);
			} else {
				evt.getSource().setText("Documents / Comments");
				//		this.getModel("objectView").setProperty("/altCommnetVisible", true);
				if (this.getModel("objectView").getProperty("/expandClientDetails")) {
					this.getModel("objectView").setProperty("/altCommnetVisible", false);
				} else {
					this.getModel("objectView").setProperty("/altCommnetVisible", true);
				}
				this.byId("NRWizard").setVisible(true);
				this.byId("idAttachment").setVisible(false);
			}
		},

		abd: function(newData) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var Designation = data.Designation.trim();
				var Name = data.Name.trim();
				var Notes = data.Notes.trim();
				var Classification = data.Classification.trim();
				var Role = data.Role.trim();
				var Classificationk = data.Classificationk.trim();
				var Rolek = data.Rolek.trim();
				var Designationk = data.Designationk.trim();
				var obj = {
					"Cmino": "$000000001",
					"Designation": Designation,
					"Knownpartyseq": "",
					"Classification": Classification,
					"Rolek": Rolek,
					"Designationk": Designationk,
					"Classificationk": Classificationk,
					"Role": Role,
					"Name": Name,
					"Comments": "",
					"Hasconflict": ""
						//"Notes": Notes,
						//"Action": "M"
				};
				if (Designation === "" && Name === "" && Role === "" && Classification) {
					continue;
				} else {
					objArray.push(obj);
					var qtc = this.getModel();
					var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
						properties: obj
					});
					this.bindKnownTable(oContextKnownParties);
				}
			}

			var aKnownParties = this.getModel("NRequestView").getProperty("/Knownparties");
			this.getModel("NRequestView").setProperty("/Knownparties", aKnownParties.concat(objArray));

		},
		bindAlterPayer: function(evt) {
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aaPayer = that.getModel("NRequestView").getProperty("/Altpayers");
				var qtc = that.getModel();

				that.getModel("NRequestView").setProperty("/Altpayers", aaPayer);
				var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
					properties: aaPayer[0]
				});
				that.bindAlterTable(oContextKnownParties);
			});
		},
		bindAlterTable: function(oContextKnownParties, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var addButton = new sap.m.Button({
				//	text: "Add Payer",
				icon: "sap-icon://add",
				press: this.addAltPayer.bind(this),
				enabled: "{worklistView>/enablePercent}",
				tooltip: "{i18n>detailBFLabelTooltip1}",
				type: "Emphasized"
			});
			var idAlterPayer = this.byId("FormChange354BF1");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeBillPartnerDDDetails.bind(this),
						value: "{Partnertypedesc}",
						editable: false
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeAltTableDetails.bind(this),
						value: "{Alternatepayer}",
						valueListChanged: this.valueListChangedBP.bind(this),
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'worklistView>/editScreen'
							}],
							formatter: formatter.checkStatus
						}
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeAltTableDetails.bind(this),
						value: "{Altpayername}",
						editable: false
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					new sap.m.Input({
						value: "{Altpayerperc}",
						enabled: "{worklistView>/editScreen}",
						liveChange: this.liveChangePercent.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idAlterPayer.addItem(oColumnListItem);
			this.updateAlterBtn(idAlterPayer);
		},
		updateAlterBtn: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleDeletePayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var total = 0.00;
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var idBFinance = this.byId("FormChange354BF1");
			for (var b = 0; b < idBFinance.getItems().length; b++) {
				var oBItem = idBFinance.getItems()[b];
				var oBFinancePath = oBItem.getBindingContext().sPath,
					oBFinanceModel = oBItem.getBindingContext().getModel();
				var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerperc");
				var oTVal = oFloatFormat.format(oTPercent);
				if (!oTVal) {
					oTVal = "0.00";
				}
				total = total + oFloatFormat.parse(oTVal);
			}
			var model = this.getModel("worklistView");
			if (total >= 100) {
				model.setProperty("/enablePercent", false);
			} else {
				model.setProperty("/enablePercent", true);
			}
			this._removeAlterCondition(idBFinance);
		},
		_removeAlterCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addAltPayer();
			}
			this.updateMatterBP(oTable);
		},
		liveChangePercent: function(oEvent) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			var idBFinance = this.byId("FormChange354BF1");

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
			var total;

			function validTotalPercent() {
				total = 0.00;
				for (var b = 0; b < idBFinance.getItems().length; b++) {
					var oBItem = idBFinance.getItems()[b];
					var oBFinancePath = oBItem.getBindingContext().sPath,
						oBFinanceModel = oBItem.getBindingContext().getModel();
					var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + path);
					var oTVal = oFloatFormat.format(oTPercent);
					if (!oTVal) {
						oTVal = "0.00";
					}
					total = total + oFloatFormat.parse(oTVal);
				}
			}
			validTotalPercent();

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100 || total > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);
					validTotalPercent();
					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			var valPercent = oFloatFormat.format(oPhone);
			var model = this.getModel("worklistView");
			if (valPercent >= 100 || total >= 100) {
				model.setProperty("/enablePercent", false);
			} else {
				model.setProperty("/enablePercent", true);
			}
			//	vPhone = oFloatFormat.format(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		liveMatterPercent: function(oEvent) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);

					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		addBP: function() {
			var oViewNewModel = this.getModel("NRequestView"),
				aClientData = oViewNewModel.getProperty("/BP");
			var obj = {
				"Addrln": "",
				"Name1": "",
				"ParnrNew": "",
				"Parvw": "",
				"Update": true,
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Partnertypedesc": "",
				"Altpayeraddr1": "Payer",
				"Altpayeraddr2": "",
				"Altpayerphone": "",
				"Altpayercityk": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerperc": "0.00",
				"Partnertype": "",
				"Isnew": "",
				"IsMulti": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			aClientData.push(obj);
			oViewNewModel.refresh();
		},
		addNewBP: function() {
			this.addNewAltPayer();
		},
		onSubmitAltData: function() {

			var qtc = this.getModel();
			var cObj = this.getBindingContextbyId("idAlterDetails").getObject();
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var key = oIconTabBarKey.split("--")[ln - 1];
			if (!this.onAlterMandatory()) {
				return;
			}
			if (key === "BP") {
				var oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
					properties: cObj
				});
				this.bindMatterBPTable(oContextMatterBP, "New");
			} else {
				var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
					properties: cObj
				});
				this.bindAlterTable(oContextKnownParties, "New");
			}

			this._oAltPayer.close();
		},
		addAltPayer: function() {
			var that = this;
			var objArray = [];
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "",
				"Altpayeraddr2": "",
				"Altpayercityk": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerperc": "0.00",
				"Partnertype": "PY",
				"Partnertypedesc": "Payer",
				"Isnew": "",
				"IsMulti": "X",
				"Altpayerphone": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			objArray.push(obj);
			var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindAlterTable(oContextKnownParties, "Add");
		},
		addNewAltPayer: function() {
			if (!this._oAltPayer) {
				this._oAltPayer = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.AltPayer", this);
				this.getView().addDependent(this._oAltPayer);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAltPayer);
			this._oAltPayer.open();
		},
		beforeAltPayer: function() {
			this.addAltPayerDialog();
			var oAlterData = this.byId("idAlterDetails").getBindingContext().getObject();
			for (var key in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key === "__metadata") {
						continue;
					}
					var oError = this.getModel("ShowAlterError");
					var Field = formatter.getAlterKeyField(key);
					if (Field) {
						oError.setProperty("/" + Field, "None");
					}
				}
			}
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var keyI = oIconTabBarKey.split("--")[ln - 1];
			var idAltPayer = this.byId("idAlterDetails");
			var oContextAltPayer = idAltPayer.getBindingContext();
			var a = oContextAltPayer.getModel();
			if (keyI === "BP") {
				this._oAltPayer.setTitle("Add New Business Partner");
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			} else {
				this._oAltPayer.setTitle("Add New Payer");
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "PY");
				a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "Payer");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "X");
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		addAltPayerDialog: function() {
			var qtc = this.getModel();
			var idAltPayer = this.byId("idAlterDetails");
			var oContextAltPayer = qtc.createEntry("/Cmialtpayers", {});
			var a = oContextAltPayer.getModel();
			a.setProperty(oContextAltPayer.getPath() + "/Alternatepayer", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayername", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr1", "");
			a.setProperty(oContextAltPayer.getPath() + "/Isnew", "X");
			a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerzip", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercityk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerperc", "0.00");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "");
			a.setProperty(oContextAltPayer.getPath() + "/Partnertypedesc", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountryk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstate", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountry", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerphone", "");
			a.setProperty(oContextAltPayer.getPath() + "/Cmino", "$000000001");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerseq", "0001");
			var oIconTabBarKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var ln = oIconTabBarKey.split("--").length;
			var key = oIconTabBarKey.split("--")[ln - 1];
			if (key === "BP") {
				this.byId("idPayerSelect").setEnabled(true);
			} else {
				this.byId("idPayerSelect").setEnabled(false);
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		onCloseAltData: function() {
			this._oAltPayer.close();
		},
		bindWOOffice: function(oContextKnownParties) {
			var idKnownParty = this.byId("FormDisplay354WO");
			var bEdit = true;
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				//	text: "Add WO",
				enabled: "{worklistView>/editScreen}",
				press: this.addWOOffice.bind(this),
				type: "Emphasized"
			});
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{OfficeName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CompanyName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CountryName}",
						width: "65%",
						editable: bEdit,
						change: this.changeOfficeTableDetails.bind(this)
					}).setConfiguration(c),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idKnownParty.addItem(oColumnListItem);
			this.updateMatterWOButtons(idKnownParty);
		},
		updateMatterWOButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleWOPayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormDisplay354WO");
			this._removeMatterWOCondition(oTable);
		},
		_removeMatterWOCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addWOOffice();
			}
			this.updateMatterWOButtons(oTable);
		},
		addWOOffice: function() {
			var that = this;
			var objArray = [];
			var aKnownParties = that.getModel("NRequestView").getProperty("/Altpayers1");
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"OfficeCode": "",
				"OfficeName": "",
				"CompCode": "",
				"CompanyName": "",
				"Country": "",
				"CountryName": ""
			};
			objArray.push(obj);
			that.getModel("NRequestView").setProperty("/Altpayers1", aKnownParties.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmimatteroffices", {
				properties: obj
			});
			that.bindWOOffice(oContextKnownParties);
		},
		bindKnownParties: function(evt) {
			if (evt) {
				var oContext = evt.getSource().getBindingContext();
				var sPath = oContext.getPath();
				var oContextModel = oContext.getModel();
				if (oContextModel.getProperty(sPath + "/Designation").trim() === "" || oContextModel.getProperty(sPath + "/Name").trim() === "" ||
					oContextModel.getProperty(sPath + "/Role").trim() === "" || oContextModel.getProperty(sPath + "/Classification").trim() === "") {
					sap.m.MessageToast.show("Please fill all fields");
					return;
				}
			}
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var objArray = [];
				var aKnownParties = that.getModel("NRequestView").getProperty("/Knownparties");
				var qtc = that.getModel();
				var obj = {
					"Cmino": "$000000001",
					"Designation": "",
					"Knownpartyseq": "",
					"Classification": "",
					"Rolek": "",
					"Designationk": "",
					"Classificationk": "",
					"Role": "",
					"Name": "",
					"Comments": "",
					"Hasconflict": ""
				};
				objArray.push(obj);
				that.getModel("NRequestView").setProperty("/Knownparties", aKnownParties.concat(objArray));
				var idKnownParty = that.byId("idKnownParty");
				if (idKnownParty.getItems().length === 0) {
					var clientObj = that.getView().byId("SimpFormClientEdit").getBindingContext().getObject();
					var objc = {
						Classification: clientObj.Classification,
						Classificationk: clientObj.Classificationk,
						Client: clientObj.Client
					};
					obj.Name = objc.Client;
					obj.Role = "Client";
					obj.Rolek = "01";
					obj.Classificationk = objc.Classificationk;
					obj.Classification = objc.Classification;
					obj.Designation = "Client's Family Memb";
					obj.Designationk = "08";
				}
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: obj
				});
				that.bindKnownTable(oContextKnownParties);
			});
		},
		handleDeleteKnownParties: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			var oTable = this.byId("idKnownParty");
			oItmSel.destroy();
			this._removeCondition(oTable);
		},
		_removeCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.bindKnownParties();
			}
			this.upDateButtons(oTable);
		},
		upDateButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		bindKnownTable: function(oContextKnownParties) {
			var idKnownParty = this.byId("idKnownParty");
			var model = this.getModel("worklistView");
			var bEdit = true;
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				//	text: "Add KP",
				type: "Emphasized",
				enabled: bEdit,
				press: this.bindKnownParties.bind(this)
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Name}",
						enabled: bEdit,
						change: this.changeKnownDetails.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{path:'Classification',formatter:'myKnown.setTextOnly'}",
						editable: bEdit,
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Role}",
						editable: bEdit,
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Designation}",
						editable: bEdit,
						change: this.changeKnownDetails.bind(this)
					}).setConfiguration(c),
					new sap.m.Button({
						icon: "sap-icon://bell",
						type: "Reject",
						visible: {
							path: 'Hasconflict',
							formatter: formatter.myBooleanBDOD
						},
						press: this.onPressViewConfilt.bind(this)
					}),
					new sap.m.Button({
						icon: "sap-icon://message-popup",
						type: "{=${Comments} ? 'Emphasized':'Default'}",
						press: function(evt) {
							this.onPressComments(evt);
						}.bind(this)
					}),
					new sap.m.Button({
						enabled: bEdit,
						icon: "sap-icon://attachment",
						type: "Default",
						press: this.addAttachments.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);

			idKnownParty.addItem(oColumnListItem);
			this.upDateButtons(idKnownParty);
		},
		updateFinishedTableResult: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sTotal = oEvent.getParameter("total");
			var oKwnPartiesModel = oSrc.getModel("NRequestView");
			for (var i = 0; i < sTotal; i++) {
				oKwnPartiesModel.setProperty("/Knownparties/" + i + "/Knownpartyseq", this.formatter.sequenceNumber(i + 1));
			}
		},
		handleClientFinish: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sTotal = oEvent.getParameter("total");
			var oClientcontactsModel = oSrc.getModel("NRequestView");
			for (var i = 0; i < sTotal; i++) {
				oClientcontactsModel.setProperty("/Clientcontacts/" + i + "/Contactseq", this.formatter.sequenceNumber(i + 1));
			}
			var oTable = this.byId("TableDialog");
			this.upDateContactButtons(oTable);
		},
		handleCommentFinish: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sTotal = this.getModel("CommentsModel").getProperty("/CommentSet").length;
			var CommentsModel = oSrc.getModel("CommentsModel");
			for (var i = 0; i < sTotal; i++) {
				CommentsModel.setProperty("/CommentSet/" + i + "/Sequence", i);
			}
		},
		handlePrimaryContact: function(evt) {
			var oControl = evt.getSource(),
				oContext = oControl.getBindingContext("NRequestView"),
				sPath = oContext.sPath,
				allContext = oContext.getModel().mContexts,
				oContexts = Object.getOwnPropertyNames(allContext);
			oContexts.map(function(sPathItem) {
				if (sPathItem.indexOf("/Clientcontacts") !== -1) {
					oContext.getModel().setProperty(sPathItem + "/Contacttype", "S");
				}
			});
			oContext.getModel().setProperty(sPath + "/Contacttype", "P");
		},
		onPressComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oEvt = evt.getSource();
			if (!this._oKPNotes) {
				this._oKPNotes = sap.ui.xmlfragment("cminewrequest.fragments.KPNotes", this);
				oView.addDependent(this._oKPNotes);
			}
			this._oKPNotes.setBindingContext(oEvt.getBindingContext());
			//	this._oKPNotes.bindElement(sPath + "/Comments");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPNotes);
			this._oKPNotes.openBy(evt.getSource());
		},
		onPressContactComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oEvt = evt.getSource();
			var sPath = oEvt.getBindingContext("NRequestView").sPath;
			if (!this.ContactComment) {
				this.ContactComment = sap.ui.xmlfragment("cminewrequest.fragments.ContactComment", this);
				oView.addDependent(this.ContactComment);
			}
			//		this.ContactComment.setBindingContext(oEvt.getBindingContext());
			//	this.ContactComment.bindElement(sPath);
			this.ContactComment.bindElement("NRequestView>" + sPath);
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPNotes);
			this.ContactComment.openBy(evt.getSource());
		},
		onMultiComment: function(evt) {
			var oEvt = evt.getSource();
			var sPath = this._oKPNotes.getBindingContext().sPath;
			var path = oEvt.getBindingPath("value");
			var value = oEvt.getValue();
			// set Value for Client Details Context
			var oMatterModel = oEvt.getBindingContext().getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
		},

		addComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oCommentsForSteps) {
				this._oCommentsForSteps = sap.ui.xmlfragment("cminewrequest.fragments.CommentsForSteps", this);
				oView.addDependent(this._oCommentsForSteps);
			}
			this._oCommentsForSteps.open();
		},
		//terms 
		getGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.key,
				upperCase: false
			});
		},
		handleTermsUpload: function(evt) {
			var oFileUploader = this.getView().byId("idTermFileUploader");
			var fileData = new Blob([oFileUploader.oFileUpload.files[0]]);
			var buf = function getBuffer(resolve) {
				var reader = new FileReader();
				reader.readAsBinaryString(fileData);
				reader.onload = function() {
					var arrayBuffer = reader.result;
					resolve(arrayBuffer);
				};
			};
			var that = this;
			var promise = new Promise(buf);
			// Wait for promise to be resolved, or log error.
			promise.then(function(data) {
				var base64 = btoa(data);
				that.onAddTermReview(base64, 1.3);
			}).catch(function(err) {});
		},
		onTermReviewPress: function() {
			var that = this;
			this.attachEdit = false;
			this.addDocument = true;
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.TermReviews", this);
			this.getView().addDependent(this._oDialog);
			this.byId("ID_FRAME").setVisible(false);
			this.getModel("worklistView").setProperty("/editTerm", false);
			this.getModel("worklistView").setProperty("/editButtonSubmit", false);
			this.byId("idZoomin").setEnabled(false);
			this.byId("idZoomOut").setEnabled(false);
			this.byId("idFullOut").setEnabled(false);
			//	this.byId("submitTerm").setEnabled(false);
			var $pdfContainer = jQuery("#pdfContainer");
			if ($pdfContainer) {
				$pdfContainer.empty();
				$pdfContainer.css("height", "0px").css("width", "0px");
			}
			this._oDialog.open();
		},
		onCListDialogClose: function() {
			this.mytxt = "";
			this._oCListDialog.close();
		},
		onSelectCategories: function() {
			/*		if (that.mytxt !== "") {
						MessageToast.
					}*/
			if (this._oCListDialog) {
				this._oCListDialog.destroy();
			}
			this._oCListDialog = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.CategoriesList", this);
			this._oCListDialog.open();
			this.getView().byId("idCategoriesList").setModel(this.getView().getModel("jsonAmendModel"), "jsonAmendModel");

		},
		handleZoom: function() {
			this.byId("idImport").setVisible(!this.byId("idImport").getVisible());
			if (!this.byId("idImport").getVisible()) {
				this.byId("idPdf").setLayoutData(new sap.ui.layout.GridData({
					span: "L12 M12 S12"
				}));
				this.byId("idFullOut").setIcon("sap-icon://exit-full-screen");
				this.scaleT = 1.9;
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				this.byId("idPdf").setLayoutData(new sap.ui.layout.GridData({
					span: "L8 M8 S8"
				}));
				this.byId("idFullOut").setIcon("sap-icon://full-screen");
				this.scaleT = 1.3;
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}

			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		handleZoomIn: function() {
			this.scaleT = this.scaleT + 0.5;
			if (!this.byId("idImport").getVisible()) {
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}
			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		handleZoomOut: function() {
			this.scaleT = this.scaleT - 0.5;
			if (!this.byId("idImport").getVisible()) {
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}
			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		onAddTermReview: function(base64, scale) {
			this.scaleT = scale;
			this.byId("ID_FRAME").setVisible(true);
			var tag = "<div id='pdfContainer' class='pdf-content'></div>";
			this.getView().byId("idFrame").setContent(tag);
			var $pdfContainer = jQuery("#pdfContainer");
			$pdfContainer.empty();
			jQuery.sap.delayedCall(1000, this, function() {
				function base64ToUint8Array(base64) {
					var raw = atob(base64); //This is a native function that decodes a base64-encoded string.
					var uint8Array = new Uint8Array(new ArrayBuffer(raw.length));
					for (var i = 0; i < raw.length; i++) {
						uint8Array[i] = raw.charCodeAt(i);
					}
					return uint8Array;
				}

				function renderPage(page) {
					var viewport = page.getViewport(scale);
					var $canvas = jQuery("<canvas></canvas>");
					//Set the canvas height and width to the height and width of the viewport
					var canvas = $canvas.get(0);
					var context = canvas.getContext("2d");

					var devicePixelRatio = window.devicePixelRatio || 1,
						backingStoreRatio = context.webkitBackingStorePixelRatio ||
						context.mozBackingStorePixelRatio ||
						context.msBackingStorePixelRatio ||
						context.oBackingStorePixelRatio ||
						context.backingStorePixelRatio || 1,
						auto,

						ratio = devicePixelRatio / backingStoreRatio;

					canvas.height = viewport.height * ratio;
					canvas.width = viewport.width * ratio;
					if (typeof auto === 'undefined') {
						auto = true;
					}
					var $textLayerDiv = jQuery("<div />")
						.addClass("textLayer")
						.css("height", viewport.height * ratio + "px")
						.css("width", viewport.width * ratio + "px")
						.offset({
							top: "-" + canvas.height,
							left: 0
						});

					//Append the canvas to the pdf container div
					$pdfContainer = jQuery("#pdfContainer");
					var $pdfDiv = jQuery("<div></div>");
					$pdfContainer.append($pdfDiv);
					$pdfDiv.css("height", canvas.height + "px").css("width", canvas.width + "px");
					$pdfDiv.append($canvas);

					//The following few lines of code set up scaling on the context if we are on a HiDPI display
					var outputScale = getOutputScale();
					if (outputScale.scaled) {
						var cssScale = 'scale(' + (1 / outputScale.sx) + ', ' +
							(1 / outputScale.sy) + ')';
						CustomStyle.setProp('transform', canvas, cssScale);
						CustomStyle.setProp('transformOrigin', canvas, '0% 0%');

						if ($textLayerDiv.get(0)) {
							CustomStyle.setProp('transform', $textLayerDiv.get(0), cssScale);
							CustomStyle.setProp('transformOrigin', $textLayerDiv.get(0), '0% 0%');
						}
						var oldWidth = canvas.width;
						var oldHeight = canvas.height;

						canvas.width = oldWidth * ratio;
						canvas.height = oldHeight * ratio;

						canvas.style.width = oldWidth + 'px';
						canvas.style.height = oldHeight + 'px';
						context.scale(ratio, ratio);
					}
					$pdfDiv.append($textLayerDiv);

					page.getTextContent().then(function(textContent) {
						var textLayer = new TextLayerBuilder($textLayerDiv.get(0), 0); //The second zero is an index identifying
						//the page. It is set to page.number - 1.
						textLayer.setTextContent(textContent);
						var renderContext = {
							canvasContext: context,
							viewport: viewport,
							textLayer: textLayer
						};
						page.render(renderContext);
					});
				}

				function renderPdf(pdf) {
					for (var i = 0; i < pdf.numPages; i++) {
						pdf.getPage(i + 1).then(renderPage);
					}
				}
				var pdfData = base64ToUint8Array(base64);

				function loadPdf() {
					PDFJS.disableWorker = true;
					var pdf = PDFJS.getDocument(pdfData);
					pdf.then(renderPdf);
				}
				loadPdf();

				if (!window.x) {
					var x = {};
				}
				x.Selector = {};
				x.Selector.getSelected = function() {
					var t = "";
					if (window.getSelection) {
						t = window.getSelection();
					} else if (document.getSelection) {
						t = document.getSelection();
					} else if (document.selection) {
						t = document.selection.createRange().text;
					}
					return t;
				};
				$(function() {
					$("#pdfContainer").on('selectstart', function() {
						$(window).keydown(function(e) {
							jQuery.sap.delayedCall(2000, this, function() {
								var sel = window.getSelection();
								var textBody = document.createElement("div");
								var container = jQuery("<div />").addClass("textLayers");
								container[0].appendChild(sel.getRangeAt(0).cloneContents());
								var arr = [];
								for (var i = 0; i < container[0].children.length; i++) {
									if (!arr.includes(container[0].children[i].style.top)) {
										arr.push(container[0].children[i].style.top);
									}
								}
								for (var j = 0; j < arr.length; j++) {
									var textV = document.createElement("div");
									textV.style.fontSize = "12px";
									textV.style.paddingLeft = "4px";
									var text = "";
									for (var k = 0; k < container[0].children.length; k++) {
										if (arr[j] == container[0].children[k].style.top) {
											text = text + " " + container[0].children[k].innerText;
										}
									}
									textV.append(text);
									textBody.appendChild(textV);
								}
								var containerHTML = jQuery("<div />");
								textBody.style = "width: 581.4px;";
								containerHTML[0].appendChild(textBody);
								var html = containerHTML[0].innerHTML;
								that.mytxt = html;
								if (!container[0].children.length) {
									that.mytxt = container[0].innerText;
								}

							}.bind(this));
						});
					});
				});
				$("#pdfContainer")[0].addEventListener("mouseup", function() {
					var sel = window.getSelection();
					var textBody = document.createElement("div");
					var container = jQuery("<div />").addClass("textLayers");
					container[0].appendChild(sel.getRangeAt(0).cloneContents());
					var arr = [];
					for (var i = 0; i < container[0].children.length; i++) {
						if (!arr.includes(container[0].children[i].style.top)) {
							arr.push(container[0].children[i].style.top);
						}
					}
					for (var j = 0; j < arr.length; j++) {
						var textV = document.createElement("div");
						textV.style.fontSize = "12px";
						textV.style.paddingLeft = "4px";
						var text = "";
						for (var k = 0; k < container[0].children.length; k++) {
							if (arr[j] == container[0].children[k].style.top) {
								text = text + " " + container[0].children[k].innerText;
							}
						}
						textV.append(text);
						textBody.appendChild(textV);
					}
					var containerHTML = jQuery("<div />");
					textBody.style = "width: 581.4px;";
					containerHTML[0].appendChild(textBody);
					var html = containerHTML[0].innerHTML;
					that.mytxt = html;
					if (!container[0].children.length) {
						that.mytxt = container[0].innerText;
					}
				}, false);
			});
		},

		onDialogClose: function() {

			this._oDialog.close();
		},

		onListItemPress: function(oEvent) {
			var that = this;
			var sCategoryText = oEvent.getParameters().listItem.getTitle();
			var oContextTerm = oEvent.getParameters().listItem.getBindingContext("jsonAmendModel");
			var aImportedTermsList = this.getView().byId("idListImportedTerms").getItems();
			var qtc = this.getModel();
			var obj = oContextTerm.getObject();
			if (!sCategoryText.trim()) {
				return;
			}
			for (var i = 0; i < aImportedTermsList.length; i++) {
				if ("Category: " + sCategoryText === aImportedTermsList[i].getContent()[0].getHeaderToolbar().getContent()[0].getText()) {
					sap.m.MessageToast.show(sCategoryText + " Already Exists");
					return;
				}
				this.getView().byId("idListImportedTerms").getItems()[i].getContent()[0].setExpanded(false);
			}
			var oContext = qtc.createEntry("/Cmiocgterms", {
				properties: {
					"Categoryid": obj.Categoryid,
					"CategoryidDesc": obj.CategoryidDesc,
					"Subcategoryid": obj.Subcategoryid,
					"SubcategoryidDesc": obj.SubcategoryidDesc,
					"Status": "",
					"Cmiocgseq": this.formatter.sequenceNumber(aImportedTermsList.length + 1)
				}
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.Panel({
					expandable: true,
					expanded: true,
					width: "auto",
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Title({
								text: "Category: " + sCategoryText
							}),
							new sap.m.ToolbarSpacer(),
							new sap.m.Button({
								tooltip: "Delete Item",
								icon: "sap-icon://sys-cancel",
								press: function(oEvt) {
									that.onITDeletePress(oEvt);
								}
							})
						]
					}),
					content: [
						/*	new sap.m.TextArea({
								growing: true,
								width: "100%",
								value: this.mytxt
							}),*/
						new sap.ui.richtexteditor.RichTextEditor({
							editable: "{worklistView>/editScreen}",
							editorType: sap.ui.richtexteditor.EditorType.TinyMCE4,
							width: "100%",
							height: "200px",
							customToolbar: false,
							showGroupFont: false,
							showGroupStructure: false,
							showGroupFontStyle: false,
							showGroupClipboard: false,
							showGroupTextAlign: false,
							value: this.mytxt
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Text({
									text: "{Status}"
								}),
								new sap.m.Button({
									icon: "sap-icon://save",
									type: "Emphasized",
									text: "Submit",
									enabled: {
										parts: [{
											path: 'Status'
										}, {
											path: 'worklistView>/editScreen'
										}, {
											path: 'worklistView>/editButtonSubmit'
										}],
										formatter: formatter.checkStatusSave
									},
									press: function(oEvt) {
										that.onSubmitPress(oEvt);
									}
								}).addStyleClass("sapUiTinyMarginBegin")
							]
						}).addStyleClass("sapUiTinyMargin")
					]
				}).addStyleClass("sapUiNoContentPadding")
			}).setBindingContext(oContext);
			this.getView().byId("idListImportedTerms").addItem(oCustomListItem);
			this.mytxt = "";
			this.getModel("worklistView").setProperty("/editButtonSubmit", false);
			this._oCListDialog.close();
		},
		onSubmitAddTermsDialog: function(e) {
			var aImportedTermsList = this.getView().byId("idListImportedTerms").getItems();
			var cmiNo = this.getModel("objectView").getProperty("/CmiId");
			var array = [];
			var that = this;
			//	var sPath = "/Cmiocgs";
			//	var batchChanges = [];
			for (var i = 0; i < aImportedTermsList.length; i++) {
				var obj = {};
				var context = aImportedTermsList[i].getBindingContext().getObject();
				obj.Termitem = (context.SubcategoryidDesc || context.Termitem);
				obj.Terms = aImportedTermsList[i].getContent()[0].getContent()[0].getValue();
				obj.Cmiocgseq = this.formatter.sequenceNumber(i + 1);
				obj.Cmino = cmiNo;
				obj.Termhdrk = (context.Categoryid || context.Termhdrk);
				obj.Termhdr = (context.CategoryidDesc || context.Termhdr);
				obj.Termitemk = (context.Subcategoryid || context.Termitemk);
				obj.Status = context.Status;
				array.push(obj);
				//	batchChanges.push(that.oModel.createBatchOperation("Cmiocgterms", "POST", obj));
			}
			for (var j = 0; j < array.length; j++) {
				delete(array[j].__metadata);
			}
			this.OcgData.OcgTerms = array;

			this.OcgData.Cmiocgseq = this.formatter.sequenceNumber(this.OcgData.Cmiocgseq);
			this.OcgData.Cmino = cmiNo;
			if (this.attachEdit) {
				var sPath = this.OcgContext.sPath;
				this.getModel("NRequestView").setProperty(sPath, this.OcgData);
			} else {
				if (this.addDocument) {
					this.OcgData.Ostatus = "";
					var aTermsData = [];
					var ocgTermsData = this.getModel("NRequestView").getProperty("/Ocgs");
					aTermsData.push(this.OcgData);
					this.getModel("NRequestView").setProperty("/Ocgs", aTermsData.concat(ocgTermsData));
				} else {
					this.getModel("NRequestView").setProperty("/Ocgs/0", this.OcgData);
				}
			}
			//	that._oDialog.close();
			if (e !== "WF") {
				that.handleSaveDataForTerms();
			}
			/*var oModel = this.getModel();
			var oBusy = new sap.m.BusyDialog();
			oBusy.open();
			delete(this.OcgData.__metadata);
						
			batchChanges.push(oModel.createBatchOperation("Cmiocgs", "POST",this.OcgData));*/

			/*	oModel.create(sPath, this.OcgData, {
					success: function(oData, oResponse) {
						oBusy.close();
						that.displayOcgsList();
						that._oDialog.close();

					},
					error: function(oData, oResponse) {
						oBusy.close();
						var obj = JSON.parse(oData.responseText);
						var msg = obj.error.message.value;
						sap.m.MessageBox.show(msg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					},
					async: true
				});*/
			/*oModel.addBatchChangeOperations(batchChanges);
			//submit changes and refresh the table and display message
			oModel.submitBatch(function(data,response) {
				that.displayOcgsList();
				that._oDialog.close();
			}, function(oData, oResponse) {
				oBusy.close();
				var obj = JSON.parse(oData.responseText);
				var msg = obj.error.message.value;
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
			});*/
		},
		onITDeletePress: function(oEvent) {
			var that = this;
			var sPanelHeaderText = oEvent.getSource().getParent().getContent()[0].getText();
			var dialog = new sap.m.Dialog({
				title: "Confirm",
				type: "Message",
				content: new sap.m.Text({
					text: "Are you sure you want to delete " + sPanelHeaderText + "?"
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {
						that.onITDeleteDialogOK(sPanelHeaderText);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onITDeleteDialogOK: function(sPanelHeaderText) {
			var that = this;
			var aImportedTermsList = that.getView().byId("idListImportedTerms").getItems();

			for (var i = 0; i < aImportedTermsList.length; i++) {
				if (sPanelHeaderText === aImportedTermsList[i].getContent()[0].getHeaderToolbar().getContent()[0].getText()) {
					aImportedTermsList.splice(i, 1);
				}
			}

			that.getView().byId("idListImportedTerms").removeAllItems();
			for (i = 0; i < aImportedTermsList.length; i++) {
				that.getView().byId("idListImportedTerms").addItem(aImportedTermsList[i]);
			}
		},

		onSubmitPress: function(oEvent) {
			//	var sPanelHeaderText = oEvent.getSource().getParent().getParent().getHeaderToolbar().getContent()[0].getText();
			//	sap.m.MessageToast.show(sPanelHeaderText + " submit button pressed");
			var cmiNo = this.getModel("objectView").getProperty("/CmiId");
			var data = oEvent.getSource().getBindingContext().getObject();
			var oModel = this.getModel();
			var oSource = oEvent.getSource();
			var oSModel = oSource.getBindingContext().getModel();
			var sPath = oSource.getBindingContext().sPath,
				msg, status, statusk;
			var that = this;
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: (data.Subcategoryid || data.Termitemk),
						Termhdrk: (data.Categoryid || data.Termhdrk),
						Cmino: cmiNo,
						Cmiocgsequence: String(that.OcgData.Cmiocgseq)
					},
					success: function(oData, response) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									msg = oData.results[0].Message;
									if (msg.indexOf("|") !== -1) {
										statusk = msg.split("|")[0];
										status = msg.split("|")[1];
										sap.m.MessageToast.show(status);
										oSModel.setProperty(sPath + "/Statusk", statusk);
										oSModel.setProperty(sPath + "/Status", status);
									}
									that.onSubmitAddTermsDialog("WF");
								}
							} else {
								sap.m.MessageToast.show("");
							}
						} else {
							sap.m.MessageToast.show("");
						}

					},
					error: function(oError) {}
				});

		},
		onSubmitTerms: function(oEvent) {
			var cmiNo = this.getModel("objectView").getProperty("/CmiId");
			var data = oEvent.getSource().getBindingContext("NRequestView").getObject();
			var oModel = this.getModel();
			var oSource = oEvent.getSource();
			var oSModel = oSource.getBindingContext("NRequestView").getModel();
			var sPath = oSource.getBindingContext("NRequestView").getPath(),
				msg, status, statusk;
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: "",
						Termhdrk: "",
						Cmino: cmiNo,
						Cmiocgsequence: data.Cmiocgseq
					},
					success: function(oData, response) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									msg = oData.results[0].Message;
									if (msg.indexOf("|") !== -1) {
										statusk = msg.split("|")[0];
										status = msg.split("|")[1];
										sap.m.MessageToast.show(status);
										oSModel.setProperty(sPath + "/Ostatus", status);
										oSModel.setProperty(sPath + "/Ostatusk", statusk);
									}
									oSModel.setProperty(sPath + "/Uploadeddate", new Date());
									oSModel.refresh();
								}

							} else {
								sap.m.MessageToast.show("");
							}
						} else {
							sap.m.MessageToast.show("");
						}
					},
					error: function(oError) {}
				});
		},
		onCloseDialog: function() {
			this._oDialog.close();
		},
		handleSteps: function(evt) {
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				return;
			}
			var step = true;
			this.validatedStep = false;

			function validateEmail(email) {
				var re =
					/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(String(email).toLowerCase());
			}
			var CmiId = this.getModel("objectView").getProperty("/CmiId");
			// Change by BG, condition to make true when navigating from conflict search
			if (this.srchIdOnly !== "Done") {
				this.srchIdOnly = this.getModel("worklistView").getProperty("/Searchid");
			}
			if (!CmiId || (this.srchIdOnly && this.srchIdOnly !== "")) {
				this.srchIdOnly = "Done";
				if (!this.getContactsValidated()) {
					this.validatedStep = true;
					sap.m.MessageToast.show("Enter all Mandatory fields");
					this.byId("NRWizard").goToStep(this.byId("ClientDetailStep"));
					this.byId("NRWizard").discardProgress(this.byId("ClientDetailStep"));
					return;
				}
				var client = this.getBindingContextbyId("SimpFormClientEdit").getObject();
				var Email = client.Email;

				if (!validateEmail(Email)) {
					//	oError.setProperty("/vContactEmail", "Error");
					sap.m.MessageToast.show("Enter valid Email Id.");
					this.validatedStep = true;
					this.byId("NRWizard").goToStep(this.byId("ClientDetailStep"));
					this.byId("NRWizard").discardProgress(this.byId("ClientDetailStep"));
					return;
				}
				if (!this._readClientMatterDetails()) {
					this.validatedStep = true;
					this.byId("NRWizard").goToStep(this.byId("ClientDetailStep"));
					this.byId("NRWizard").discardProgress(this.byId("ClientDetailStep"));
					return;
				}
				this.onStepSubmit(CmiId);
			} else {
				this.validatedStep = false;
			}
			if (evt.getParameter("index") === 2) {
				this.getModel("objectView").setProperty("/submitButton", true);
			}
			if (evt.getParameter("index") === 4) {
				/*var that = this;
				that.byId("idPhone")._oControl.edit.attachLiveChange(
					function(oEvent) {
						that.validPhone(oEvent);
					}
				);*/
			}
		},
		changeDunningLevel: function(e) {
			var that = this;
			var control = this.getInnerControls()[0];
			control.attachLiveChange(
				function(oEvent) {
					that.validLevel(oEvent);
				}
			);
		},
		changeInClientAdd: function(oEvent) {
			var src = oEvent.getSource();
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			var validPh = /^[0-9]{1,30}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
		},
		validLevel: function(oEvent) {
			var src = oEvent.getSource();
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			var validPh = /^[0-9]{0,1}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
		},
		onPostCommnets: function(evt) {
			if (this.validatedStep) {
				this.WizardTitle = "Client Details";
			}
			var title = this.WizardTitle;
			var cType = "";
			if (title === "Client Details") {
				cType = "CC";
			} else if (title === "Known Parties") {
				cType = "KP";
			} else if (title === "Terms") {
				cType = "TE";
			} else if (title === "Client Service Directors") {
				cType = "LP";
			} else if (title === "Matter Details") {
				cType = "MD";
			} else {
				cType = "CO";
			}
			var text = evt.getParameter("value");
			var userId = this.getModel("worklistView").getProperty("/userId");
			var name = this.getModel("worklistView").getProperty("/userName");
			var obj = {
				Cmino: "",
				//	CommentType: cType,
				CommentType: "",
				Sequence: "",
				UserComment: text,
				Addedby: name,
				Addedbyk: userId,
				Addedon: new Date()
			};
			var oRemarks = this.getView().getModel("CommentsModel");
			var oRemarkData = oRemarks.getProperty("/CommentSet");
			oRemarkData.push(obj);
			oRemarks.setProperty("/CommentSet", oRemarkData);
			//	this.onFilterComments(cType);
			if (this._oCommentsForSteps) {
				this._oCommentsForSteps.close();
			}

		},
		next: function(evt) {
			console.log(1);
		},
		onFilterComments: function(val) {
			if (this.validatedStep) {
				this.WizardTitle = "Client Details";
			}
			var title = this.WizardTitle;
			var cType = "";
			if (title === "Client Details") {
				cType = "CC";
			} else if (title === "Known Parties") {
				cType = "KP";
			} else if (title === "Terms") {
				cType = "TE";
			} else if (title === "Client Service Directors") {
				cType = "LP";
			} else if (title === "Matter Details") {
				cType = "MD";
			} else {
				cType = "CO";
			}
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("CommentType", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oList = this.getView().byId("idCommentsList");
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		// Lead Partner Add, Delete, Bind Data to Table
		bindLeadPartner: function(evt) {
			if (evt) {
				var oContext = evt.getSource().getBindingContext();
				var sPath = oContext.getPath();
				var oContextModel = oContext.getModel();
				if (oContextModel.getProperty(sPath + "/Office").trim() === "" ||
					oContextModel.getProperty(sPath + "/Phone").trim() === "" || oContextModel.getProperty(sPath + "/Leadpartner").trim() === "" ||
					oContextModel.getProperty(sPath + "/Email").trim() === "") {
					sap.m.MessageToast.show("Please fill all fields");
					return;
				}
			}
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var objArray = [];
				var aLeadPartner = that.getModel("NRequestView").getProperty("/Leadpartners");
				var qtc = that.getModel();
				//		var rank = aKnownParties.length + 1;
				var obj = {
					"Cmino": "$000000001",
					"Rank": "",
					"Officek": "",
					"Office": "",
					"Leadpartnerk": "",
					"Leadpartner": "",
					"Phone": "",
					"Email": "",
					"Parvwdesc": "",
					"Parvw": ""
				};
				objArray.push(obj);
				that.getModel("NRequestView").setProperty("/Leadpartners", aLeadPartner.concat(objArray));
				var oContextLeadPartner = qtc.createEntry("/Cmileadpartners", {
					properties: obj
				});
				that.bindLPTable(oContextLeadPartner);
			});
		},
		onPressPopinDispBtn: function(evt, oView) {
			if (!oView) {
				var oView = this.getView();
			}
			var oViewMode = oView.getModel("worklistView");
			var flag = oViewMode.getProperty("/PopInDisplay");
			if (flag) {
				oViewMode.setProperty("/PopInDisplay", false);
			} else {
				oViewMode.setProperty("/PopInDisplay", true);
			}
		},
		bindLPTable: function(oContextLeadPartner) {
			var idLeadPartner = this.byId("idLeadPartnerT");
			var bEdit = true;
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				//	text: "Add",
				type: "Emphasized",
				enabled: bEdit,
				press: this.bindLeadPartner.bind(this)
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			//		var a= new sap.ui.comp.smartfield.Configuration({controlType:"dropDownList"}); addAggregation("configuration",a,false)
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
						text: "{Rank}",
						change: this.changeLPDetails.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Office}",
						editable: bEdit,
						change: this.changeLPDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Leadpartner}",
						editable: bEdit,
						change: this.changeLPDetails.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						editable: bEdit,
						change: this.changeLPDPDetails.bind(this)
					}).setConfiguration(a),
					new sap.m.Input({
						value: "{Phone}",
						enabled: bEdit,
						liveChange: this.changeInClientAdd.bind(this)
					}),
					new sap.m.Input({
						value: "{Email}",
						enabled: bEdit,
						change: this.changeLPDetails.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextLeadPartner);
			idLeadPartner.addItem(oColumnListItem);
			this.upDateLPButtons(idLeadPartner);
		},
		changeLPDPDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			var oItem = source.getAggregation("_content");
			if (oItem) {
				var selData = oItem.getSelectedItem().getBindingContext().getObject();
				model.setProperty(sPath + "/Parvw", selData.PARVW);
				model.setProperty(sPath + "/Parvwdesc", selData.PARVWDESC);
				source.getAggregation("_content").setValue(selData.PARVWDESC);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		upDateLPButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
				var oItem = oTable.getItems()[i];
				var sSequence = i + 1;
				var LeadPath = oItem.getBindingContext().sPath,
					LeadModel = oItem.getBindingContext().getModel();
				LeadModel.setProperty(LeadPath + "/" + "Rank", sSequence.toString());
			}
		},
		handleDeleteLPartner: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			var oTable = this.byId("idLeadPartnerT"),
				ind = oTable.indexOfItem(oItmSel);
			oItmSel.destroy();
			oTable.getModel("NRequestView").getProperty("/Leadpartners").splice(ind, 1);
			oTable.getModel("NRequestView").refresh();
			this._removeConditionLP(oTable);
		},
		_removeConditionLP: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.bindLeadPartner();
			}
			this.upDateLPButtons(oTable);
		},
		changeLPDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		//-------------------------------- Start File Upload------------------------------------------------------------------------------//

		onAttachmentChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			for (var i = 0; i < oEvent.mParameters.files.length; i++) {
				this.ContentData = oEvent.mParameters.files[i];
				var cmiNo = this.getModel("objectView").getProperty("/CmiId");
				//	var cmiNo = "1000000036";
				var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
					name: "slug",
					value: cmiNo + "|" + oEvent.mParameters.files[i].name + "|" + oEvent.mParameters.files[i].size
				});
				oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
			}
		},
		onUploadTerminated: function(oEvent) {

			oEvent.getSource().bindAggregation("items", "/results", new sap.m.UploadCollectionItem({
				documentId: "{AttachmentNo}",
				fileName: "{Filename}",
				url: "{url}",
				enableDelete: true,
				visibleEdit: false
			}));
		},
		onUploadComplete: function(oEvent) {
			if (oEvent.getParameter("files")[0].status === 201) {
				this._UploadA.close();
				this.getModel("worklistView").setProperty("/editTerm", true);
				//	this.byId("submitTerm").setEnabled(true);
				this.OcgData = {};
				var response = oEvent.getParameter("files")[0].responseRaw;
				var resJson = xmlToJSON.parseString(response);
				this.OcgData.Cmino = resJson.entry[0].properties[0].Cmino[0]._text;
				this.OcgData.Cmiocgseq = resJson.entry[0].properties[0].Cmiocgseq[0]._text;
				this.OcgData.Ostatusk = resJson.entry[0].properties[0].Ostatusk[0]._text;
				this.OcgData.Ostatus = resJson.entry[0].properties[0].Ostatus[0]._text;
				this.OcgData.Filename = resJson.entry[0].properties[0].Filename[0]._text;
				this.OcgData.Filesize = String(resJson.entry[0].properties[0].Filesize[0]._text);
				this.OcgData.Uploadeddate = resJson.entry[0].properties[0].Uploadeddate[0]._text;
				this.OcgData.Uploadedbyk = resJson.entry[0].properties[0].Uploadedbyk[0]._text;
				this.OcgData.Uploadedby = resJson.entry[0].properties[0].Uploadedby[0]._text;
				this.OcgData.Filecontent = resJson.entry[0].properties[0].Filecontent[0]._text;
				this.byId("idListImportedTerms").destroyItems();
				this.byId("idZoomin").setEnabled(true);
				this.byId("idZoomOut").setEnabled(true);
				this.byId("idFullOut").setEnabled(true);
				//
				//	this.displayOcgsList();
				var fileData = this.ContentData;
				var buf = function getBuffer(resolve) {
					var reader = new FileReader();
					reader.readAsBinaryString(fileData);
					reader.onload = function() {
						var arrayBuffer = reader.result;
						resolve(arrayBuffer);
					};
				};
				var that = this;
				var promise = new Promise(buf);
				// Wait for promise to be resolved, or log error.
				promise.then(function(data) {
					var base64 = btoa(data);
					that.onAddTermReview(base64, 1.3);
				}).catch(function(err) {

				});

			} else {
				var response = oEvent.getParameter("files")[0];
				if (response.responseRaw) {
					var resText = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resText.error[0].message[0]._text;
					fileModel.setData({
						"results": dataItem.items
					});
					this.getView().setModel(fileModel);
					oEvent.getSource().bindAggregation("items", "/results", new sap.m.UploadCollectionItem({
						documentId: "{AttachmentNo}",
						fileName: "{Filename}",
						url: "{url}",
						enableDelete: true,
						visibleEdit: false
					}));
					this._oDialogA.setTitle("Attachments (" + dataItem.items.length + ")");
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		onTypeMissmatch: function() {
			var errmessage = "Allowed file types are : PDF, DOC, DOCX, XLX, XLSX, JPEG, GIF, TIF MP4";
			sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
		},
		handleLinkTrem: function(evt) {
			this.attachEdit = true;
			var that = this;
			this.OcgData = evt.getSource().getBindingContext("NRequestView").getObject();
			this.OcgContext = evt.getSource().getBindingContext("NRequestView");
			this.getModel("worklistView").setProperty("/editButtonSubmit", false);
			if (this.OcgData.OcgTerms.__deferred) {
				var Cmino = evt.getSource().getBindingContext("NRequestView").getObject().Cmino;
				var seq = evt.getSource().getBindingContext("NRequestView").getObject().Cmiocgseq;
				var spath = "/Cmiocgs(Cmino='" + Cmino + "',Cmiocgseq='" + seq + "')";
				this.OcgData = evt.getSource().getBindingContext("NRequestView").getObject();
				if (this._oDialog) {
					this._oDialog.destroy();
				}
				this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.TermReviews", this);
				that.getView().addDependent(this._oDialog);

				var model = this.getModel("worklistView");

				if (model.getProperty("/editScreen")) {
					this.getModel("worklistView").setProperty("/editTerm", true);
					//that.byId("submitTerm").setEnabled(true);
					this.byId("ID_FRAME").setVisible(true);
				}
				var $pdfContainer = jQuery("#pdfContainer");
				if ($pdfContainer) {
					$pdfContainer.empty();
					$pdfContainer.css("height", "0px").css("width", "0px");
				}
				this._oDialog.open();
				var oModel = this.getModel();
				var oBusy = new sap.m.BusyDialog();
				var urlParam = {
					"$expand": "OcgTerms"
				};
				oBusy.open();
				oModel.read(spath, {
					urlParameters: urlParam,
					success: function(oData, OResponse) {
						oBusy.close();
						that.onAddTermReview(oData.Filecontent, 1.3);
						that.OcgData.OcgTerms = oData.OcgTerms.results;
						that.displayAllTerms(that.OcgData);
					},
					error: function(err) {
						oBusy.close();
						var errmessage = JSON.parse(err.response.body).error.message.value;
						sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					}
				});
			} else {
				if (this._oDialog) {
					this._oDialog.destroy();
				}
				this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragments.TermReviews", this);
				that.getView().addDependent(this._oDialog);
				var model = this.getModel("worklistView");
				if (model.getProperty("/editScreen")) {
					this.getModel("worklistView").setProperty("/editTerm", true);
					//that.byId("submitTerm").setEnabled(true);
				}
				this.byId("ID_FRAME").setVisible(true);
				var $pdfContainer = jQuery("#pdfContainer");
				if ($pdfContainer) {
					$pdfContainer.empty();
					$pdfContainer.css("height", "0px").css("width", "0px");
				}
				that.onAddTermReview(this.OcgData.Filecontent, 1.3);
				that.displayAllTerms(this.OcgData);
			}
			this._oDialog.open();

		},
		displayAllTerms: function(oData) {
			var oListTemplate = new sap.ui.core.Item({
				key: "{Name}",
				text: "{Name}"
			});
			var data = oData.OcgTerms;

			var oSelect = new sap.m.Select().bindAggregation("items", "/RouteToCollection", oListTemplate).addStyleClass(
				"sapUiTinyMarginBegin");
			for (var i = 0; i < data.length; i++) {
				var qtc = this.getModel();
				var oContextOcgTerms = qtc.createEntry("/Cmiocgterms", {
					properties: data[i]
				});
				var oCustomListItem = new sap.m.CustomListItem({
					content: new sap.m.Panel({
						expandable: true,
						expanded: true,
						width: "auto",
						headerToolbar: new sap.m.Toolbar({
							content: [
								new sap.m.Title({
									text: "Category: " + data[i].Termitem
								}),
								new sap.m.ToolbarSpacer(),
								new sap.m.Button({
									visible: "{worklistView>/editScreen}",
									tooltip: "Delete Item",
									icon: "sap-icon://sys-cancel",
									press: function(oEvt) {
										that.onITDeletePress(oEvt);
									}
								})
							]
						}),
						content: [
							new sap.ui.richtexteditor.RichTextEditor({
								editable: "{worklistView>/editScreen}",
								editorType: sap.ui.richtexteditor.EditorType.TinyMCE4,
								width: "100%",
								height: "200px",
								customToolbar: false,
								showGroupFont: false,
								showGroupStructure: false,
								showGroupFontStyle: false,
								showGroupClipboard: false,
								showGroupTextAlign: false,
								value: data[i].Terms
							}),
							new sap.m.HBox({
								justifyContent: "SpaceBetween",
								items: [
									new sap.m.Text({
										text: "{Status}"
									}),
									new sap.m.Button({
										icon: "sap-icon://save",
										type: "Emphasized",
										text: "Submit",
										enabled: {
											parts: [{
												path: 'Status'
											}, {
												path: 'worklistView>/editScreen'
											}, {
												path: 'worklistView>/editButtonSubmit'
											}],
											formatter: formatter.checkStatusSave
										},
										press: function(oEvt) {
											that.onSubmitPress(oEvt);
										}
									}).addStyleClass("sapUiTinyMarginBegin")
								]
							}).addStyleClass("sapUiSmallMargin")
						]
					}).addStyleClass("sapUiNoContentPadding")
				}).setBindingContext(oContextOcgTerms);
				this.getView().byId("idListImportedTerms").addItem(oCustomListItem);
			}
		},
		displayOcgsList: function() {
			var cmiId = this.getModel("objectView").getProperty("/CmiId");
			//		var cmiId = "1000000036";
			var that = this;
			var aFilter = [new Filter("Cmino", sap.ui.model.FilterOperator.EQ, cmiId)];
			var uriParameter = {
				"$select": "Cmino,Error,Cmiocgseq,Message,Ostatusk,Ostatus,Filename,Filesize,Uploadeddate,Uploadedbyk,Uploadedby",
				"$expand": "OcgTerms"
			};
			var filesPath = "/Cmiocgs";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: uriParameter,
				success: function(oData, OResponse) {
					that.getModel("NRequestView").setProperty("/Ocgs", oData.results);
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		onAttachmentDeleteConfirm: function() {
			var that = this;
			var items = that.byId("idListImportedTerms").getItems();
			if (items.length > 0) {
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Imported Terms will be refreshed,Are u sure want to continue?"
					}),
					beginButton: new sap.m.Button({
						text: "Yes",
						press: function() {
							that.handleAttchRequest();
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				that.handleAttchRequest();
			}
		},
		handleAttchRequest: function() {
			if (!this._UploadA) {
				this._UploadA = sap.ui.xmlfragment("cminewrequest.fragments.fileupload", this);
				this.getView().addDependent(this._UploadA);
			}
			var oJsonModel = new sap.ui.model.json.JSONModel({
				results: [{
					"AttachmentNo": "",
					"Filename": "Note: Please upload pdf file."
				}]
			});
			var proto = window.location.protocol;
			var host = window.location.host;
			var service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmiocgs";
			this._UploadA.getContent()[0].setUploadUrl(service);
			this._UploadA.getContent()[0].bindAggregation("items", "upLoadData>/results", new sap.m.UploadCollectionItem({
				documentId: "{upLoadData>AttachmentNo}",
				fileName: "{upLoadData>Filename}",
				url: "{upLoadData>url}",
				visibleDelete: false,
				visibleEdit: false
			}));
			this._UploadA.getContent()[0].setModel(oJsonModel, "upLoadData");
			//		this._UploadA.getContent()[0].destroyItems();
			this._UploadA.open();
		},
		handleCloseAttachment: function() {
			this._UploadA.close();
		},
		displayCategoryData: function() {
			//this.onCancelJCM();
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_ADMIN_TABS_SRV/");
			var path = "Terms";
			var oJsonModel = new sap.ui.model.json.JSONModel();
			//	oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			oModel.read(path, null, null, false, function(oData, oResponse) {
				oJsonModel.setData({
					modelData: oData.results
				});
				that.getView().setModel(oJsonModel, "jsonAmendModel");
			}, function(oResponse) {

			});
			/*		var oJsonAModel = new sap.ui.model.json.JSONModel();
					var conPath = "Busconsiderations";
					oModel.read(conPath, null, null, false, function(oData, oResponse) {
						oJsonAModel.setData({
							ConsiData: oData.results
						});
						that.getView().setModel(oJsonAModel, "jsonConsiModel");
					}, function(oResponse) {

					});*/
		},

		//--------------------------------  End File Upload------------------------------------------------------------------------------//
		validPhone: function(oEvent) {
			var src = oEvent.getSource();
			/*		if (src.getBindingContext()) {
						var path = src.getBindingPath("value");
						var matterPath = src.getBindingContext().sPath;
						var matterModel = src.getBindingContext().getModel();
					}*/
			var vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			var validPh = /^[0-9]{1,30}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				/*	if (src.getBindingContext()) {
						matterModel.setProperty(matterPath + "/" + path, vPhone);
					}*/
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				/*if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}*/
			}
		},
		onCancelSubmit: function() {
			/*var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}*/
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: "#Shell-home"
				}
			});
		},
		BusinessListFactory: function(sId, oContext) {
			var qType = oContext.getProperty("Questiontypek");
			var oControl = null;
			var mData = {
				selected: [],
				items: [{
					key: "0",
					text: "Answer 1"
				}, {
					key: "1",
					text: "Answer 2"
				}, {
					key: "2",
					text: "Answer 3"
				}, {
					key: "3",
					text: "Answer 4"
				}]
			};
			var oItemTemplate = new sap.ui.core.Item({
				key: "{key}",
				text: "{text}"
			});
			var oModel = new sap.ui.model.json.JSONModel(mData);
			oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'jsonConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchConsiChange.bind(this),
				enabled: "{worklistView>/editScreen}"
			});
			/*	switch (qType) {
					case "01":
						oControl = new sap.m.Switch({
							state:"{jsonConsiModel>Answer}"
						});
						break;
					case "02":
						oControl = new sap.m.MultiComboBox({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							},
							selectedKeys: {
								path: "/selected",
								template: "{selected}"
							}
						});
						oControl.setModel(oModel);
						break;
					case "03":
						oControl = new sap.m.Select({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							}
						});
						oControl.setModel(oModel);
						break;
					case "04":
						oControl = new sap.m.RangeSlider({
							width: "20rem",
							height: "3rem",
							min: 0,
							max: 30,
							range: [5, 20],
							enableTickmarks: true
								//	scale: new sap.m.ResponsiveScale({tickmarksBetweenLabels: 3})
						});
						break;
					default:
						oControl = new sap.m.Input({
							width: "12rem"
						});
				}*/
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'jsonConsiModel>QuestionText'}, {path: 'jsonConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		riskListFactory: function() {
			var oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'riskConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchRiskChange.bind(this),
				enabled: "{worklistView>/editScreen}"
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'riskConsiModel>QuestionText'}, {path: 'riskConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		businessUpdate: function(evt) {
			var evtr = evt.getSource();
			for (var i = 0; i < evtr.getItems().length; i++) {
				if (i % 2 === 0) {
					evtr.getItems()[i].addStyleClass("colorR");
				}

			}
		},
		handleAddRowChgBF: function(oEvent) {
			var oTable = this.getView().byId("FormChange354BF1");
			var oModel = oTable.getModel();
			var modelData = oModel.getData();
			var aTable = [];
			for (var i = 0; i < modelData.modelData.length; i++) {
				var value = modelData.modelData[i];
				aTable.push(value);
			}
			var oRow = {
				Etag: "",
				Payer_old: "",
				Payer_new: "",
				Name1: "",
				Perc: "",
				Update: "I"
			};
			aTable.push(oRow);
			oModel.setData({
				modelData: aTable
			});
			sap.m.MessageToast.show("Rows added: " + 1);
		},
		handleDelRowChgBF: function(oEvent) {
			var oView = this.getView();
			var that = this;

			var oTable = oView.byId("FormChange354BF1");
			var m = oTable.getModel();
			var data = m.getData();
			var aSelIndices = oTable.getSelectedIndices();
			aSelIndices = aSelIndices.reverse();
			var count = aSelIndices.length;
			if (data.modelData.length > 0) {
				if (count > 0) {
					var oConfirmMsg = "Are you sure you want to delete?";
					sap.m.MessageBox.confirm(oConfirmMsg, {
						icon: sap.m.MessageBox.Icon.QUESTION,
						title: "Confirmation",
						onClose: function(oEvent1) {
							if (oEvent1 === "OK") {

								for (var i = 0; i < count; i++) {
									var value = aSelIndices[i];
									that._aDelTableBF.push(data.modelData[value]);
									data.modelData.splice(value, 1);
								}
								m.setData(data);
								oTable.clearSelection();
								sap.m.MessageToast.show("Rows deleted: " + count);
							}
						}
					});
				}
			} else {
				sap.m.MessageToast.show("Please select a row to delete");
			}
		},
		handleChangeCountry: function(evt) {
			var bFlag = evt.getParameter("state"),
				model = this.getModel("objectView");
			model.setProperty("/countryVis", bFlag);
		},
		handleCellClickChgBFBP: function(oEvent) {
			this._oTblPrtnrNmbrRowBFBP = oEvent.getParameter("rowIndex");
		},
		handleSelectPartnerTypeBP: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("selectedKey");
			var value = source.getSelectedItem().getKey();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			/*	if (oSelKey === "SP") {
				sap.m.MessageToast.show("CLIENT can be selected only once.");
				oEvent.getSource().setSelectedKey("PY");
			}*/
			/*	var oSelKey = oEvent.getSource().getSelectedKey();
		
				var oTable = this.getView().byId("FormChange354BP");
				var oModel = oTable.getModel("NRequestView");
				var modelData = oModel.getData();
				var aTable = [];

				for (var i = 0; i < modelData.BP.length; i++) {
					var value = modelData.BP[i];
					aTable.push(value);
				}
				var PModel = this.getModel("partner");
				var PData = PModel.getProperty("/results");
				var bdata = this.getModel("NRequestView").getProperty("/BP");
				for (var p = 0; p < PData.length; p++) {
					PData[p].vis = true;
				}
				for (var d = 0; d < bdata.length; d++) {
					var key = bdata[d].Parvw;
					PData.filter(function(sData) {
						if (sData.Parvw) {
							if (sData.Parvw === key) {
								sData.vis = false;
							}
						}
					});
				}
				PData.filter(function(sData) {
					if (sData.Parvw) {
						if (sData.Parvw === oSelKey) {

							sData.vis = false;
						}
					}
				});
				PModel.refresh();*/
			/*	var iIndex = oEvent.getSource().getParent().getIndex();
				if (aTable[this._oTblPrtnrNmbrRowBPBP].Update !== "I") {
				  aTable[this._oTblPrtnrNmbrRowBPBP].Update = "U";
				}
				if (aTable[iIndex].Update !== "I") {
					aTable[iIndex].Update = "U";
				}
				oModel.setData({
					modelData: aTable
				});*/
		},
		dataBP: function() {
			var data = {
				"results": [{
					Parvw: "",
					Vtext: "",
					vis: true
				}, {
					Parvw: "SP",
					Vtext: "Sold-to party",
					vis: true
				}, {

					Parvw: "BP",
					Vtext: "Bill-to party",
					vis: true
				}, {

					Parvw: "PY",
					Vtext: "Payer",
					vis: true
				}, {

					Parvw: "SH",
					Vtext: "Ship-to party",
					vis: true
				}, {

					Parvw: "Z2",
					Vtext: "Client Bill Contact",
					vis: true
				}, {

					Parvw: "Z3",
					Vtext: "Alt Billing Address",
					vis: true
				}, {

					Parvw: "Z4",
					Vtext: "Alt Bill Contact",
					vis: true
				}, {

					Parvw: "ZE",
					Vtext: "Bill Approver",
					vis: true
				}, {

					Parvw: "ZL",
					Vtext: "Matter Lead Partner",
					vis: true
				}, {

					Parvw: "ZO",
					Vtext: "Bill Reviewer",
					vis: true
				}, {
					Parvw: "ZS",
					Vtext: "Signing Officer",
					vis: true
				}]
			};
			var oPartnerModel = new sap.ui.model.json.JSONModel();
			this.setModel(oPartnerModel, "partner");
			oPartnerModel.setData(data);
		},
		changeInMatterDetailsDD: function(evt) {
			var source = evt.getSource();
			var value = source.getValue();
			var path = source.getBindingPath("value");
			var oControl = source.getAggregation("_content");
			var oMatterInContext = this.getBindingContextbyId("MatterInDetailsStep");
			var oMatterInModel = oMatterInContext.getModel();
			var sPath = oMatterInContext.getPath();
			var id, description, key;
			if (path === "Zzbillfreqdesc") {
				id = "Zzbillfreq";
				description = "ZZDESC";
				key = "ZZBILLFREQ";
			}
			if (path === "Zzbillmthddesc") {
				id = "Zzbillmthd";
				description = "ZZDESC";
				key = "ZZBILLMTHD";
			}
			if (path === "Zzmanspdesc") {
				id = "Zzmansp";
				description = "TEXT1";
				key = "MANSP";
			}
			if (path === "Zzmattertypedesc") {
				id = "Zzmattertype";
				description = "DESCRIPTION";
				key = "MATTERTYPE";
			}
			if (path === "Zzpracticegroupdesc") {
				id = "Zzpracticegroup";
				description = "ZZDESC";
				key = "ZZPGP";
			}

			if (path === "Classification") {
				id = "Classificationk";
				description = "STEXT";
				key = "CLASSIFICATIONK";
			}
			if (oControl) {
				var oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					var selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oMatterInModel.setProperty(sPath + "/" + path, selData[description]);
					oMatterInModel.setProperty(sPath + "/" + id, selData[key]);
					source.getAggregation("_content").setValue(selData[description]);
				} else {
					oMatterInModel.setProperty(sPath + "/" + path, value);
					oMatterInModel.setProperty(sPath + "/" + id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
		},
		changeFieldDD: function(evt) {

			var source = evt.getSource();
			var value = source.getValue();
			var path = source.getBindingPath("value");
			var oControl = source.getAggregation("_content");
			var oMatterInContext = this.getBindingContextbyId("SimpFormClientEdit");
			var oMatterInModel = oMatterInContext.getModel();
			var sPath = oMatterInContext.getPath();
			var id, description, key;

			if (path === "Classification") {
				id = "Classificationk";
				description = "STEXT";
				key = "CLASSIFICATIONK";
			}
			if (oControl) {
				var oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					var selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oMatterInModel.setProperty(sPath + "/" + path, selData[description]);
					oMatterInModel.setProperty(sPath + "/" + id, selData[key]);
					source.getAggregation("_content").setValue(selData[description]);
				} else {
					oMatterInModel.setProperty(sPath + "/" + path, value);
					oMatterInModel.setProperty(sPath + "/" + id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
			//	this.getContactsValidated("ch");
		},
		// Billing Partner table 
		bindBillingPartner: function(newData) {
			var idBillPartenr = this.byId("handleCellClickChgBPBP");
			idBillPartenr.destroyItems();
			for (var k = 0; k < newData.length; k++) {
				var qtc = this.getModel();
				var oContextWOFC = qtc.createEntry("/CmiclientBP", {
					properties: newData[k]
				});
				this.bindBillPartnerTable(oContextWOFC);
			}
			//	this.getModel("jsonAmendModel").setProperty("/Cllientbp", newData);
		},
		bindBillPartnerTable: function(oContextKnownParties) {
			var idBillPartenr = this.byId("handleCellClickChgBPBP");
			var bEdit = true;
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				//	text: "Add BP",
				press: this.onAddBusinessPartner.bind(this),
				type: "Emphasized",
				enabled: "{worklistView>/editScreen}"
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						editable: bEdit,
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parnr}",
						editable: bEdit,
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedClientBP.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnername}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Addr1} {Addr2}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idBillPartenr.addItem(oColumnListItem);
			this.updateClientBPButtons(idBillPartenr);
		},
		valueListChangedClientBP: function(evt) {
			var that = this;
			var data = evt.getSource().getBindingContext().getObject();
			var source = evt.getSource();
			var model = source.getModel();
			var sPath = source.getBindingContext().getPath();

			var sPartnertype = data.Parvw;
			var sAlternatepayer = data.Parnr;
			var aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, sPartnertype), new Filter("Alternatepayer", sap.ui.model
				.FilterOperator
				.EQ, sAlternatepayer)];
			var filesPath = "/Cmialtpayers";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Addr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Addr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Cityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Statek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Countryk", obj.Altpayercountryk);

						}
					}

				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		changeBillPartnerDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			if (path === "Parvwdesc") {
				model.setProperty(sPath + "/Partnername", "");
				model.setProperty(sPath + "/Parnr", "");
				model.setProperty(sPath + "/Addr1", "");
				model.setProperty(sPath + "/Addr2", "");
				model.setProperty(sPath + "/Cityk", "");
				model.setProperty(sPath + "/Statek", "");
				model.setProperty(sPath + "/Countryk", "");

			}
			if (path === "Partnertypedesc") {
				model.setProperty(sPath + "/Alternatepayer", "");
				model.setProperty(sPath + "/Altpayername", "");
				model.setProperty(sPath + "/Altpayercountry", "");
				model.setProperty(sPath + "/Altpayeraddr1", "");
				model.setProperty(sPath + "/Altpayeraddr2", "");
				model.setProperty(sPath + "/Altpayercityk", "");
				model.setProperty(sPath + "/Altpayerstatek", "");
				model.setProperty(sPath + "/Altpayercountryk", "");
			}
		},
		onAddBusinessPartner: function() {
			var that = this;
			var objArray = [];
			var qtc = that.getModel();
			var obj = {
				"Cmino": "",
				"Parvwdesc": "",
				"Parnr": "",
				"Partnername": "",
				"Clientk": "",
				"Vkorgdesc": "",
				"Vkorg": "",
				"Parvw": "",
				"Bpseq": "",
				"Msgfn": "",
				"Vtext": "",
				"Client": "",
				"Addr1": "",
				"Addr2": "",
				"Phone": "",
				"Cityk": "",
				"State": "",
				"Statek": "",
				"Zip": "",
				"Countryk": "",
				"Country": ""
			};
			objArray.push(obj);
			var oContextKnownParties = qtc.createEntry("/CmiclientBP", {
				properties: obj
			});
			that.bindBillPartnerTable(oContextKnownParties);
		},
		handleBillPartnerDelete: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("handleCellClickChgBPBP");
			this._removeClientBPCondition(oTable);
		},
		_removeClientBPCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddBusinessPartner();
			}
			this.updateClientBPButtons(oTable);
		},
		updateClientBPButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		// Tax Data binding
		bindTaxData: function(newData) {
			var idTaxData = this.byId("FormChange354WD");
			idTaxData.destroyItems();
			for (var k = 0; k < newData.length; k++) {
				var qtc = this.getModel();
				var oContextWOFC = qtc.createEntry("/Cmiwtax", {
					properties: newData[k]
				});
				this.bindTaxDataTable(oContextWOFC);
			}
			this.getModel("jsonAmendModel").setProperty("/Cmiwtax", newData);
		},
		onAddTaxData: function() {
			var that = this;
			var data = this.getModel("TempModel").getData();
			var qtc = that.getModel();
			var obj = {
				"Cmino": "",
				"Vkorg": data.Vkorg,
				"Clientk": "",
				"Client": "",
				"Msgfn": "",
				"Qland": "",
				"Witht": "",
				"Withcd": "",
				"Agtdf": null,
				"Agtdt": null,
				"Agent": "",
				"Wtstcd": "",
				"Text40": "",
				"Withdesc": ""
			};
			var oContextKnownParties = qtc.createEntry("/Cmiwtax", {
				properties: obj
			});
			that.bindTaxDataTable(oContextKnownParties);
		},
		bindTaxDataTable: function(oContextKnownParties) {
			var bEdit = true;
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				//	text: "Add WTD",
				press: this.onAddTaxData.bind(this),
				type: "Emphasized",
				enabled: "{worklistView>/editScreen}"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var idBillPartenr = this.byId("FormChange354WD");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Withdesc}",
						editable: bEdit,
						change: this.changeTaxDataDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Text40}",
						editable: bEdit,
						change: this.changeTaxDataDetails.bind(this)
					}).setConfiguration(c),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Text40}",
						change: this.changeTaxDataDetails.bind(this),
						editable: false
					}),
					new sap.m.Switch({
						state: {
							path: 'Agent',
							formatter: formatter.myBooleanV
						},
						enabled: bEdit,
						change: this.handleSwitchTaxChange.bind(this)
					}),
					new sap.m.DatePicker({
						value: {
							path: 'Agtdf',
							formatter: formatter.myDate1
						},
						valueFormat: "yyyy-MM-dd",
						displayFormat: "yyyy-MM-dd",
						enabled: bEdit,
						change: this.changeTaxDataDetails.bind(this)
					}),
					new sap.m.DatePicker({
						value: {
							path: 'Agtdt',
							formatter: formatter.myDate1
						},
						valueFormat: "yyyy-MM-dd",
						displayFormat: "yyyy-MM-dd",
						enabled: bEdit,
						change: this.changeTaxDataDetails.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idBillPartenr.addItem(oColumnListItem);
			this.updateClientWXButtons(idBillPartenr);
		},
		updateClientWXButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		_removeClientWXCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddTaxData();
			}
			this.updateClientWXButtons(oTable);
		},
		handleTaxDataDelete: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var idBillPartenr = this.byId("FormChange354WD");
			this._removeClientWXCondition(idBillPartenr);
		},

		handleSwitchTaxChange: function(evt) {
			var source = evt.getSource();
			var path = source.getBinding("state").getPath();
			var value = "";
			var state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var oMatterInContext = source.getBindingContext();
			var sPath = oMatterInContext.getPath();
			var oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeTaxDataDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			var sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			if (path === "Withdesc") {
				model.setProperty(sPath + "/Withcd", "");
				model.setProperty(sPath + "/Text40", "");
			}
		},
		onAddMatterBP: function() {
			var that = this;
			var objArray = [];
			var qtc = that.getModel();
			var obj = {
				"Cmino": "$000000001",
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "",
				"Altpayeraddr2": "",
				"Altpayercityk": "",
				"Altpayerperc": "0.00",
				"Partnertype": "",
				"Partnertypedesc": "",
				"Isnew": "",
				"IsMulti": "",
				"Altpayerphone": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			objArray.push(obj);
			var oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindMatterBPTable(oContextMatterBP);
		},
		bindMatterBPTable: function(oContextMatterBP, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var model = this.getModel("worklistView");
			if (!model.getProperty("/editScreen")) {
				bEdit = false;
			}
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var addButton = new sap.m.Button({
				//	text: "Add BP",
				icon: "sap-icon://add",
				enabled: "{worklistView>/editScreen}",
				press: this.onAddMatterBP.bind(this),
				type: "Emphasized"
			});
			var idBillPartenr = this.byId("FormChange354BP");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnertypedesc}",
						editable: bEdit,
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Alternatepayer}",
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'worklistView>/editScreen'
							}],
							formatter: formatter.checkStatus
						},
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedBP.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Altpayername}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextMatterBP);
			idBillPartenr.addItem(oColumnListItem);
			this.updateMatterBP(idBillPartenr);
		},
		updateMatterBP: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleDeleteBP: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormChange354BP");
			this._removeMatterBPCondition(oTable);
		},
		_removeMatterBPCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddMatterBP();
			}
			this.updateMatterBP(oTable);
		},
		changeBillPartnerDDDetails: function(evt) {
			var source = evt.getSource();
			var model = source.getModel();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var sPath = source.getBindingContext().getPath();
			var oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Partnertypedesc") {
					id = "Partnertype";
					description = "VTEXT";
					key = "PARVW";
				}
				if (path === "Parvwdesc") {
					id = "Parvw";
					description = "VTEXT";
					key = "PARVW";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},

		valueListChangedBP: function(evt) {
			var that = this;
			var data = evt.getSource().getBindingContext().getObject();
			var source = evt.getSource();
			var model = source.getModel();
			var sPath = source.getBindingContext().getPath();

			var sPartnertype = data.Partnertype;
			var sAlternatepayer = data.Alternatepayer;
			var aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, sPartnertype), new Filter("Alternatepayer", sap.ui.model
				.FilterOperator
				.EQ, sAlternatepayer)];
			var filesPath = "/Cmialtpayers";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Altpayeraddr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Altpayeraddr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Altpayercityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Altpayerstatek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Altpayercountryk", obj.Altpayercountryk);

						}
					}

				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		//Documents Upload
		onDocumentClick: function(e) {
			var proto = window.location.protocol;
			var host = window.location.host;
			var k = this.byId("idAttachment").getSelectedKey();
			if (k === "CD" || k === "MD") {
				var service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmidocuments";
				this.byId(k).getContent()[0].setUploadUrl(service);
				this.fileattachmentFilter(this.byId(k).getContent()[0], k);
			}
			if (k === "CM") {
				this.handleScroll();
			}
		},

		onChangeDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var cmiNo = this.getModel("objectView").getProperty("/CmiId");
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = this.byId("idAttachment").getSelectedKey();
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + clientk + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size + "|" + key
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [];
				var resText = xmlToJSON.parseString(response.responseRaw);
				var key = this.byId("idAttachment").getSelectedKey();
				var host = window.location.host;
				var protocol = window.location.protocol;
				var urlprefix = protocol + "//" + host;
				var serviceUrl = this.getModel().sServiceUrl;
				var url = "";
				var clnt = this.getModel("worklistView").getProperty("/NMCNum");
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": clnt,
					"Client": resText.entry[0].properties[0].Client[0]._text
				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
				this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", arr.concat(data));
				this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId;
			var type = this.byId("idAttachment").getSelectedKey();
			var that = this;
			var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
			var Cmino = "";
			var Docseq = "";
			var Doctype = "";
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos && data[i].Doctype === type) {
					Cmino = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", data);
			var path = "/Cmidocuments(Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData, oResponse) {
					sap.m.MessageToast.show("Document deleted successfully.");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},
		handleSaveDataForTerms: function() {
			var sPath = "/Cmihdrs";
			var that = this;
			var cmiId = this.getModel("objectView").getProperty("/CmiId");
			var srchId = this.getModel("worklistView").getProperty("/Searchid");
			var oModel = this.getModel(),
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			var bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			var consiData = [];
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = cmiId;
				delete(bconsiData[c].__metadata);
			}
			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = cmiId;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);
			var clientData = {
				Matterk: "$000000001",
				Cmino: cmiId,
				Clientk: this.getModel("worklistView").getProperty("/NMCNum"),
				Searchid: srchId,
				Requesttime: "0",
				Cmirequesttype: "NCNM",
				Changedtime: "0",
				Clients: [this._readClientMatterDetails().clientData],
				Matters: [this._readClientMatterDetails().matterData],
				Altpayers: this._readClientMatterDetails().Altpayers,
				Clientcontacts: this._readClientMatterDetails().Clientcontacts,
				Leadpartners: this._readClientMatterDetails().Leadpartners,
				Knownparties: this._readClientMatterDetails().Knownparties,
				Ocgs: this._readClientMatterDetails().Ocgs,
				Comments: this._readClientMatterDetails().Comments,
				Offices: this._readClientMatterDetails().WOffice,
				Matterdetails: [this._readClientMatterDetails().MatterInDetail],
				Clientdetails: [this._readClientMatterDetails().ClientInDetail],
				Clientcorrespondence: [this._readClientMatterDetails().ClientCoress],
				Wtax: this._readClientMatterDetails().WtaxData,
				Clientbp: this._readClientMatterDetails().CllientbpData,
				ConsiderationsN: consiData
			};
			oModel.create(sPath, clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					that.addDocument = false;
					that.getModel("worklistView").setProperty("/editButtonSubmit", true);
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		onCreateClientMatter: function() {
			var oModel = this.getModel();
			var cmiId = this.getModel("objectView").getProperty("/CmiId");
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			var that = this,
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			oModel.callFunction(
				"/CreateCmi", {
					method: "GET",
					urlParameters: {
						Cmino: cmiId,
						Clientk: clientk,
						Requesttype: "NCNM"
					},
					success: function(oData, response) {
						oBusy.close();
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									sap.m.MessageToast.show(oData.results[0].Message);
								}
							} else {
								sap.m.MessageToast.show("");
							}
						} else {
							sap.m.MessageToast.show("");
						}

					},
					error: function(oError) {
						oBusy.close();
					}
				});
		},
		onChangeKPDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var cmiNo = this.getModel("objectView").getProperty("/CmiId");
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = "KP";
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + clientk + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size + "|" + key +
					"|" +
					this.seqno
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteKPDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [];
				var resText = xmlToJSON.parseString(response.responseRaw);
				var key = "KP";
				var host = window.location.host;
				var protocol = window.location.protocol;
				var urlprefix = protocol + "//" + host;
				var serviceUrl = this.getModel().sServiceUrl;
				var url = "";
				var clnt = this.getModel("worklistView").getProperty("/NMCNum");
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": clnt,
					"Client": resText.entry[0].properties[0].Client[0]._text
				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + obj.Clientk + "',Cmino='" + obj.Cmino + "',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("KPModel").getProperty("/KPDataSet");
				this.getView().getModel("KPModel").setProperty("/KPDataSet", arr.concat(data));
				this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentKPFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileKPDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId;
			var type = "KP";
			var data = this.getView().getModel("KPModel").getProperty("/KPDataSet");
			var Cmino = "";
			var Docseq = "";
			var Doctype = "";
			var clientk = this.getModel("worklistView").getProperty("/NMCNum");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos && data[i].Doctype === type) {
					Cmino = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("KPModel").setProperty("/KPDataSet", data);
			var path = "/Cmidocuments(Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData) {
					sap.m.MessageToast.show("Document deleted successfully.");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		}

	});
});
myFormatter = {
	requiredQuestion: function(sValue1, sValue2) {

		if (sValue2 === "X") {
			this.addStyleClass("sapMLabelRequired");
			return " " + sValue1;
		} else {
			return " " + sValue1;
		}
	}
};
myKnown = {
	setTextOnly: function(evt) {}
};