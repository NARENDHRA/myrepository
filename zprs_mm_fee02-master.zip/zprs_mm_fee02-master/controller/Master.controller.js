/*global history */
sap.ui.define([
	"feebillcollect/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"feebillcollect/model/formatter",
	"sap/ui/generic/app/navigation/service/NavigationHandler"
], function(BaseController, JSONModel, History, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, formatter, NavigationHandler) {
	"use strict";

	return BaseController.extend("feebillcollect.controller.Master", {

		formatter: formatter,
		onInit: function() {
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oViewModel = this._createViewModel();
			this.setModel(oViewModel, "masterView");
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this._Filters();
		},

		handleItemPress: function(oEvt) {
			this._showDetail(oEvt.getSource());
		},
		handleDataReceived: function(oEvent) {
			var tbl = this.getView().byId("SmartFeeBillCollectTable").getTable(),
				selItem = tbl.getRows();
			if (selItem.length) {
				tbl.setSelectedIndex(0);
				setTimeout(function() {
						this._showDetail(selItem[0]);
					}.bind(this), 0);
			}
		},
		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Category",
				groupBy: "None"
			});
		},

		_onMasterMatched: function() {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			var iIndex, oselrow;
			if (oItem.getSelectedIndex) {
				iIndex = oItem.getSelectedIndex();
				oselrow = oItem.getContextByIndex(iIndex);
			} else {
				iIndex = oItem.getIndex();
				oselrow = oItem.getBindingContext();
			}
			if (!oselrow) {
				return;
			}
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
				var objectId = oselrow.sPath;
			objectId = objectId.split("/").slice(-1).pop();
			this.getRouter().navTo("object", {
				objectId: objectId
			}, bReplace);
		},
		_Filters: function() {
			//Note: This will not work in WebIDE
			var oSmartTable = this.getView().byId("SmartFeeBillCollectTable");
			// if (sap.ui.generic.app.navigation.service.hasOwnProperty("NavigationHandler")) {
			var oNavigationHandler = new NavigationHandler(this);
			var oParseNavigationPromise = oNavigationHandler.parseNavigation();
			var oSmartFilter = this.getView().byId("FeeBillerFilterId");
			oParseNavigationPromise.done(function(oAppData, oStartupParameters, sNavType) {
					if (oStartupParameters.hasOwnProperty("Ovptype")) {
					var oCards = {
						"01": "Risk Matters",
						"02": "Matter Performance",
						"03": "WIP Unbilled AR",
						"04": "Fees"
					};
					var oFilterData = {
						Ovptype: {
							items: [ //MultiInput fields with filter-restriction="multi-value" (Ex: shown as Tokens based on control type)
								{
									key: oStartupParameters.Ovptype[0],
									text: oCards[oStartupParameters.Ovptype[0]] //Display text on the token --> not used for filtering!
								}
							]
						}

					};
					var aKeys = Object.keys(oStartupParameters);
					$.each(aKeys, function(i, val) {
						var aFilter = oSmartFilter.getFilterBarViewMetadata()[1].fields.filter(obj => obj.name === val);
						if (aFilter.length > 0) {
							oSmartFilter.addFieldToAdvancedArea(val);
						}
					});

					oSmartFilter.setFilterData(oFilterData);
					oSmartFilter.setDataSuiteFormat(oAppData.selectionVariant);
					
					// this.getModel("appView").setProperty("/filters", oSmartFilter.getFilters());
					}
			}.bind(this)).then(function() {
				if (oSmartFilter.isInitialised()) {
					oSmartFilter.search();
				} else {
					oSmartTable.setEnableAutoBinding(true);
				}
			});
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		
		onBeforeRebindTable: function(oEvent) { 
			
			var oSmartTable = oEvent.getSource(),
				oTable = oSmartTable.getTable();

			oSmartTable.attachDataReceived(function() {
				oTable._handleRowCountModeAuto();

				jQuery.sap.delayedCall(150, this, function() {
					oTable.setSelectedIndex(0);
				});
			});

			//handle personalization column visiblity
			oSmartTable._oPersController.attachDialogAfterOpen(function(e) {
				var src = e.getSource();
				var columns = src._oDialog.getPanels()[0];

				var aItems = columns._oTable.getItems();

				var persIgnorFields = {
					"Ovptype": "Ovptype",
					"Timeperiod": "Time Period",
					"Clientk": "Client Number",
					"Parvw": "Partner Role",
					"Pernrk": "Partner",
					"Currency": "Curr."

				};
				var aF = [];
				$.each(aItems, function(index, item) {
					var sPath = item.getBindingContextPath();
					var columnKey = item.getModel().getProperty(sPath).columnKey;
					if (persIgnorFields.hasOwnProperty(columnKey)) {
						aF.push(new sap.ui.model.Filter("text", "NE", item.getCells()[0].getText()));
						// item.setVisible(false);
					}
					// if (columnKey === "Matterk") {
					// 	f = new sap.ui.model.Filter("text", "NE", item.getCells()[0].getText());
					// }
					
				});
				var f = new Filter({
					filters: aF,
					and: true
				});
				// var f = new  sap.ui.model.Filter("text", "NE" , "Matter");
					jQuery.sap.delayedCall(150, this, function() {
						columns._oTable.getBinding('items').filter(f,'Application');
				});
			
				// columns._oTable.getBinding('items').refresh(true);
			})
			
			
			var aFilter = oEvent.getParameter('bindingParams').filters;
			//Set the Globel filter value
			this.getModel("appView").setProperty("/filters", aFilter);
		}

	});

});