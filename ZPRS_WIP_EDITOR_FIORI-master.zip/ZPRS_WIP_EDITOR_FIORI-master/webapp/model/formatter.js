sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		SeTStatusIcon: function(IsError) {
			if (IsError === "S")
				return "sap-icon://message-success";
			else if (IsError === "X")
				return "sap-icon://message-error";
			else if (IsError === "W")
				return "sap-icon://message-warning";

			else if (IsError === "" || IsError === null || IsError === undefined)
				return "";

		},
		SeTStatusIconColor: function(IsError) {

			if (IsError === "S")
				return "Green";
			else if (IsError === "X")
				return "Red";
			else if (IsError === "W")
				return "Orange";
		},
		reviewComplete: function(ReviewComplete) {
			if (ReviewComplete === "X") {
				return "Reviewed";
			} else if (ReviewComplete === " ") {
				return "";
			}

		}

	};

});