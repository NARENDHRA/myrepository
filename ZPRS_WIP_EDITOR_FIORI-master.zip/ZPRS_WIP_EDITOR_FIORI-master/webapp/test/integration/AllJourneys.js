jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"wipeditor/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"wipeditor/test/integration/pages/Worklist",
		"wipeditor/test/integration/pages/Object",
		"wipeditor/test/integration/pages/NotFound",
		"wipeditor/test/integration/pages/Browser",
		"wipeditor/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "wipeditor.view."
	});

	sap.ui.require([
		"wipeditor/test/integration/WorklistJourney",
		"wipeditor/test/integration/ObjectJourney",
		"wipeditor/test/integration/NavigationJourney",
		"wipeditor/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});
