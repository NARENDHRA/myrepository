/*global history */
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter"
], function(BaseController, JSONModel, History, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter) {
	"use strict";

	return BaseController.extend("fgtcmrec.ZPRS_CMReconciliation.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {
			// Control state model
			var oList = this.byId("list"),
				oViewModel = this._createViewModel();
			// Put down master list's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the master list is
			// taken care of by the master list itself.
			// iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			this.oLayout = this.getView().byId('synamicPage');
			// this._ofragmentLoad();
			// this._oloadContent();
			// this._oGroupFunctions = {
			// 	GrossAmount: function(oContext) {
			// 		var iGrouper = oContext.getProperty('GrossAmount'),
			// 			key, text;
			// 		if (iGrouper <= 20) {
			// 			key = "LE20";
			// 			text = this.getResourceBundle().getText("masterGroup1Header1");
			// 		} else {
			// 			key = "GT20";
			// 			text = this.getResourceBundle().getText("masterGroup1Header2");
			// 		}
			// 		return {
			// 			key: key,
			// 			text: text
			// 		};
			// 	}.bind(this)
			// };

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// // break after the busy indication for loading the view's meta data is
			// // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			// oList.attachEventOnce("updateFinished", function() {
			// 	// Restore original busy indicator delay for the list
			// 	oViewModel.setProperty("/delay", iOriginalBusyDelay);
			// });

			// this.getView().addEventDelegate({
			// 	onBeforeFirstShow: function () {
			// 		this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
			// 	}.bind(this)
			// });

			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);

		},
		onUpdateFinshedMaaterTbl: function(evt) {
			// debugger;
			var oItem = evt.getSource().getItems()[0];
			this._showDetail(oItem);
		},
		onUpdateClientTbl: function(evt) {
			var oItem = evt.getSource().getItems()[0];
			this._showDetail(oItem);
		},
		_ofragmentLoad: function() {
			this._oMatterfragment = new sap.ui.xmlfragment("fgtcmrec.ZPRS_CMReconciliation.fragments.MatterSection", this);
			this._oClientfragment = new sap.ui.xmlfragment("fgtcmrec.ZPRS_CMReconciliation.fragments.ClientSection", this);
		},
		_oloadContent: function(evt) {
			// oFragment = sap.ui.xmlfragment(this.fragmentName.bind(this));
			this.oLayout.setContent(this._oMatterfragment);
		},
		// onSearchMatterFilter: function(evt) {
		// 	// this.oLayout.destroyContent();
		// 	this.oLayout.setContent(this._oMatterfragment);
		// 	this.onMtrDiaCancel();
		// },
		// onSearchClientFilter: function(evt) {
		// 	// this.oLayout.destroyContent();
		// 	this.oLayout.setContent(this._oClientfragment);
		// 	this.onCntDiaCancel();
		// },

		onPressMatterLink: function(evt) {
			var src = evt.getSource();
			this._showDetail(src, "M");
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oList.getBinding("items").refresh();
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			var oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				// eslint-disable-next-line sap-no-history-manipulation
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "SalesOrderID",
				groupBy: "None"
			});
		},

		_onMasterMatched: function() {
			//Set the layout property of the FCL control to 'OneColumn'
			this.getModel("appView").setProperty("/layout", "OneColumn");
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem, Role) {
			var bReplace = !Device.system.phone,
				oValue, oRole;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsBeginExpanded");
			var oClient = oItem.getBindingContext().getProperty("Client");
			var oMatter = oItem.getBindingContext().getProperty("Matter");
			 oRole = oItem.getBindingContext().getProperty("Role");
			if (oClient) {
				oValue = oClient;
			}
			if (oMatter) {
				oValue = oMatter;
			}
			// if (Role === "M") {
			// 	oRole = Role;
			// 	oValue = oMatter;
			// } else {
			// 	oRole = "C";
			// 	oValue = oClient;
			// }
			this.getRouter().navTo("object", {
				objectId: oValue,
				Role: oRole
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function(sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},
		onMatterPress: function() {
			if (!this._oMatterDialog) {
				this._oMatterDialog = sap.ui.xmlfragment("fgtcmrec.ZPRS_CMReconciliation.fragments.matter", this.getView().getController());
				this.getView().addDependent(this._oMatterDialog);
			}
			this._oMatterDialog.open();
		},
		onClientPress: function() {
			if (!this._oClientDialog) {
				this._oClientDialog = sap.ui.xmlfragment("fgtcmrec.ZPRS_CMReconciliation.fragments.client", this.getView().getController());
				this.getView().addDependent(this._oClientDialog);
			}
			this._oClientDialog.open();
		},
		onMtrDiaCancel: function() {
			this._oMatterDialog.close();
		},
		onCntDiaCancel: function() {
			this._oClientDialog.close();
		}

	});

});