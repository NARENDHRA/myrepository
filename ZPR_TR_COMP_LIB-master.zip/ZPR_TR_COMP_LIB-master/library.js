/**
 * Initialization Code and shared classes of library sap.nw.core.lib.reuse.
 */
sap.ui.define(
/* aDependencies = */
[ "sap/m/library", "sap/ui/core/Core", "sap/ui/core/library", "sap/ui/layout/library" ],
/* vFactory = */
function() {
	"use strict";

	/**
	 * Reuse Library for Netweaver Fiori Applications
	 * 
	 * @namespace
	 * @name fgt.trustdispdoc.control.comp
	 * @public
	 */

	// library dependencies
	// delegate further initialization of this library to the Core
	return sap.ui.getCore().initLibrary({
		name: "fgt.trustdispdoc.control.comp",
		dependencies: [ "sap.ui.core", "sap.ui.layout", "sap.m" ],
		types: [],
		interfaces: [],
		controls: [],
		elements: [],
		noLibraryCSS: true,
		version: "1.1.0"
	});

	
}, /* bExport= */false);