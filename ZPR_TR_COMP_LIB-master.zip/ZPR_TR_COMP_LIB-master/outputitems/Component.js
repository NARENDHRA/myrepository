sap.ui.define([
	"sap/m/routing/RouteMatchedHandler",
	"sap/ui/core/UIComponent",
	"fgt/trustdispdoc/control/comp/outputitems/controller/ErrorHandler"
], function(RouteMatchedHandler, UIComponent, ErrorHandler) {
	"use strict";

	var Component = UIComponent.extend("fgt.trustdispdoc.control.comp.outputitems.Component", {

		metadata: {
			manifest: "json",
			publicMethods: ["invokeDocDisp"]
		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);
			this._oErrorHandler = new ErrorHandler(this);
		},
		
		destroy : function () {
				this._oErrorHandler.destroy();
				// call the base component's destroy function
				UIComponent.prototype.destroy.apply(this, arguments);
			},

		invokeDocDisp: function(sFiscalYear,sDocumentNumber,sCompanyCode) {
			this.getAggregation("rootControl").getController().invokeDocDisp(sFiscalYear,sDocumentNumber,sCompanyCode);
		}
	});

	return Component;

});