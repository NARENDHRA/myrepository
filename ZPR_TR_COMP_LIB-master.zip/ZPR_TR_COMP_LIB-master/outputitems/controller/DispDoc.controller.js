sap.ui.define([
	"fgt/trustdispdoc/control/comp/outputitems/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"fgt/trustdispdoc/control/comp/outputitems/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"
], function(BaseController, JSONModel, formatter, MessageBox, Filter) {
	"use strict";

	return BaseController.extend("fgt.trustdispdoc.control.comp.outputitems.controller.DispDoc", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			this.setModel(oViewModel, "dispDocView");
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			//	this._bindView();
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("dispDocView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @public
		 */
		invokeDocDisp: function(sFiscalYear, sDocumentNumber, sCompanyCode) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("dispDocView");
			this.sFiscalYear = sFiscalYear;
			this.sDocumentNumber = sDocumentNumber;
			this.sCompanyCode = sCompanyCode;
			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);
			//sObjectPath = "/DocHeaderS(Gjahr='2016',Belnr='1900000000',Bukrs='GB11')";
			var sObjectPath = "/DocHeaderS(Gjahr='" + sFiscalYear + "',Belnr='" + sDocumentNumber + "',Bukrs='" + sCompanyCode + "')";
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
						this._bindTable(sObjectPath);
					}.bind(this),
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				//this.getRouter().getTargets().display("objectNotFound");
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"Document Not Found", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}
		},

		_bindTable: function(sObjectPath) {
			var oTemplate = this.getView().byId("columnListItem");
			this.getTable().bindItems({
				path: sObjectPath + "/DocItemSet",
				template: oTemplate
			});
			//this.initBindingEventHandler();
			this.onModelRefresh();
		},

		getTable: function() {
			return this.getView().byId("table");
		},

		onModelRefresh: function() {
			this.getTable().getBinding("items").refresh(true);
		},

		onPressAttachments: function() {
			//	var oAttachModel = new sap.ui.model.json.JSONModel();
			var aFilter = [new Filter("Gjahr", "EQ", this.sFiscalYear), new Filter("Belnr", "EQ", this.sDocumentNumber), new Filter("Bukrs",
				"EQ", this.sCompanyCode)];
			//	var aFilter = [new Filter("Gjahr", "EQ", "2018"), new Filter("Belnr", "EQ", "100075346"), new Filter("Bukrs", "EQ", "US11")];
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "fgt.trustdispdoc.control.comp.outputitems.fragments.Attachment",
					this);
				this.getView().addDependent(this._attchParties);
			}
			var oAttachModel = new sap.ui.model.json.JSONModel(),
				oModel = this.getOwnerComponent().getModel(),
				that = this;
			sap.ui.core.BusyIndicator.show();
			oModel.read("/AttchmentS", {
				filters: aFilter,
				success: function(odata) {
					sap.ui.core.BusyIndicator.hide();
					oAttachModel.setData(odata.results);
					that.getView().byId("idAttachment").setModel(oAttachModel, "oAttachModel");
					//	that._attchParties.open();
				},
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.show("Fail to retrive the attachments");
				}
			});
			this._attchParties.open();
			/*	var oTemplate = new sap.m.UploadCollectionItem({
					fileName: "{ObjDescr}.{= ${ObjType}.toLowerCase()}",
					url: "/sap/opu/odata/sap/ZPRS_DOCUMENT_DISPLAY_SRV/DownloadAttS(DocId='{DocId}')/$value",
					visibleDelete: false,
					visibleEdit: false,
					uploadedDate: "{CreatDate}",
					attributes: [new sap.m.ObjectAttribute({
						text: "Uploaded By : {CreatName}"
					})]
				});
				//	var oTemplate = this.getView().byId("uploadCollectionId");
				this.getView().byId("UploadCollection").bindAggregation('items', {
					path: "/AttchmentS",
					filters: aFilter,
					template: oTemplate
				});*/

		},

		onPressAttachmentCancel: function() {
			this._attchParties.close();
		},
		onChangeDocuments: function(oEvent) {
			var that = this;
			//	viewContext = this.getView().getBindingContext().getObject();
			//	oUploadCollection = this.byId("UploadCollection");
			var oModel = this.getView().byId("idAttachment").getModel("oAttachModel");
			//	var oData = oUploadCollection.getModel().getData();
			var fileData = new Blob([oEvent.getParameter("files")[0]]);
			var sFileName = oEvent.getParameter("files")[0].name;
			var buf = function getBuffer(resolve) {
				var reader = new FileReader();
				reader.readAsBinaryString(fileData);
				reader.onload = function() {
					var arrayBuffer = reader.result;
					resolve(arrayBuffer);
				};
			};

			var promise = new Promise(buf);
			// Wait for promise to be resolved, or log error.
			promise.then(function(data) {
				// Here you can pass the bytes to another function.
				var bData = btoa(data);
				that.url = bData;
				var uploadPaylaod = {
					"Gjahr": that.sFiscalYear,
					"Belnr": that.sDocumentNumber,
					"Bukrs": that.sCompanyCode,
					"Ind": "C",
					"File": bData,
					"Slug": sFileName

				};
				//	that.FileUploadSet.push(obj);
				//	oModel.setData(uploadPaylaod);
				/*	that.getView().byId("idAttachment").setModel(oModel, "oAttachModel");
					that.getView().byId("idAttachment").getModel("oAttachModel").refresh();*/
				that._createUploadAttachment(uploadPaylaod);

			}).catch(function(err) {});
		},
		onUploadComplete: function() {

		},

		_createUploadAttachment: function(uploadPaylaod) {
			var oModel1 = this.getOwnerComponent().getModel();
			var bVal = true,
				that = this,
				Slug = uploadPaylaod.Slug,
				File = uploadPaylaod.File;
			var oAttachmentModel = this.getView().byId("idAttachment").getModel("oAttachModel");
			oModel1.create("/AttchmentS", uploadPaylaod, {
				//groupId: "saveall",
				success: function(oData) {
					if (bVal) {
						MessageBox.show("Data Successfully Updated");
						bVal = false;
					}
					oData.Slug = Slug;
					oData.File = File;
					oAttachmentModel.getData().push(oData);

					oAttachmentModel.refresh();
					//	that._attchParties.close();

				},
				error: function(oData) {

				}

			});
		},

		onFileDeleted: function(oEvent) {
			this.deleteItemById(oEvent.getParameter("documentId"));
			//	this.deleteItemById(oEvent.getParameter("item").getProperty("fileName"));
		},
		deleteItemById: function(sItemToDeleteId) {
			var that = this;
		
			var oData = this.getView().byId("idAttachment").getModel("oAttachModel").getData();
			var oModel = this.getOwnerComponent().getModel();
			//	var deleteItem, fileUploadSetData = m.getProperty(s + "/FileUploadSet");
			var aItems = jQuery.extend(true, {}, oData);
			jQuery.each(aItems, function(index) {
				if (aItems[index] && aItems[index].DocId === sItemToDeleteId) {
					// if (sItemToDeleteId.length < 10) {
					var deleteItem = {
						"DocId": sItemToDeleteId,
						"Gjahr": that.sFiscalYear,
						"Belnr": that.sDocumentNumber,
						"Bukrs": that.sCompanyCode,
						"Ind": "D"

					};
					oModel.create("/AttchmentS", deleteItem, {
						success: function(oData, resp) {
							that.getView().byId("idAttachment").getModel("oAttachModel").getData().splice(index, 1);
							that.getView().byId("idAttachment").getModel("oAttachModel").refresh();
							MessageBox.show("File Deleted Successfully");
							//	oTable._oTable.destroyItems();
							//	oTable.rebindTable();
							//that._attchParties.close();
						},
						error: function(oErr) {
							MessageBox.show("Failed to Delete");
							//	that._attchParties.close();
						}
					});

				}
			});
			//	m.setProperty(s + "/FileUploadSet", fileUploadSetData);
			this.getView().byId("idAttachment").getModel("oAttachModel").setData(oData);

		}

	});
});