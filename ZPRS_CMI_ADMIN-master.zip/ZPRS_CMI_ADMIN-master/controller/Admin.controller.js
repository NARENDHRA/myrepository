sap.ui.define([
	"cmiadmin/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cmiadmin/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, GroupHeaderListItem, MessageBox) {
	"use strict";

	return BaseController.extend("cmiadmin.controller.Admin", {

		formatter: formatter,

		onInit: function() {
			var sPath = jQuery.sap.getModulePath("cmiadmin.model", "/Admin.json"),
				oAdminModel = new sap.ui.model.json.JSONModel();
			$.ajax({
				url: sPath
			}).then(function(oData) {
				oAdminModel.setData(oData);
				this.getView().setModel(oAdminModel, "adminModel");
			}.bind(this));

			var that = this;
			var oBusConsModel = this.getOwnerComponent().getModel();
			oBusConsModel.metadataLoaded().then(function() {
				var oContextClients = oBusConsModel.createEntry("/Busconsiderations", {});
				oBusConsModel.setDefaultBindingMode("TwoWay");
				oContextClients.getModel().setProperty(oContextClients.getPath() + "/Questiontype", "");

				that.getView().setBindingContext(oContextClients);
			});

			var sUrl = "/Riskmatrices",
				oRiskModel = new sap.ui.model.json.JSONModel();
			var mParameters = {
				success: function(oData) {
					oRiskModel.setData(oData);
					that.getView().setModel(oRiskModel, "riskMatrixModel");
				},
				error: function(oError) {}
			};
			oBusConsModel.read(sUrl, mParameters);

			var oRootPath = jQuery.sap.getModulePath("cmiadmin");
			var oImageModel = new sap.ui.model.json.JSONModel({
				path: oRootPath
			});
			this.getView().setModel(oImageModel, "imageModel");

			var oBusConsTableModel = new sap.ui.model.json.JSONModel({
				"busConsData": []
			});
			this.getView().setModel(oBusConsTableModel, "busConsTableModel");
		},

		onAddPress: function(oEvent) {
			var oAQuestionsTable = this.getView().byId("idAQuestionsTable"),
				s = oEvent.getSource(),
				oQueData = s.getBindingContext().getObject();
			// var oBusConsData = this.getView().getModel("busConsTableModel").getProperty("/busConsData");
			
			$.each(oAQuestionsTable.getBinding().getContexts(),function(i,oqId){
				if (oqId.getObject().Questioncategoryk === oqId.getObject().Questioncategoryk && oqId.getObject().Uniqueid === oqId.getObject().Uniqueid) {
					sap.m.MessageToast.show("Question Already Exists");
					return;
				}
			});
			
			//oBusConsData.push(oQueData);
			//this.getView().getModel("busConsTableModel").setProperty("/busConsData", oBusConsData);

			var oPayload = {
				"Uniqueid": oQueData.Uniqueid,
				"Isactive": "X"
			};
			var oModel = this.getModel();
			oModel.create("/Busconsiderations", oPayload, {
				success: function() {
					MessageBox.success("Question Added", {});
					oAQuestionsTable.getBinding().refresh(true);
				}
			});
		},

		onBusConsRowDelete: function(oEvent) {
			// var iIndex = oEvent.getSource().getParent().getParent().getIndex();
			// var oBusConsData = this.getView().getModel("busConsTableModel").getProperty("/busConsData");
			// oBusConsData.splice(iIndex, 1);
			// this.getView().getModel("busConsTableModel").refresh();
			var oAQuestionsTable = this.getView().byId("idAQuestionsTable"),
				s = oEvent.getSource(),
				oQueData = s.getBindingContext().getObject();
			var oPayload = {
				"Uniqueid": oQueData.Uniqueid,
				"Isactive": ""
			};
			var oModel = this.getModel();
			oModel.create("/Busconsiderations", oPayload, {
				success: function() {
					MessageBox.success("Question is deleted", {});
					oAQuestionsTable.getBinding().refresh(true);
				}
			});
		},

		handleAddQuestions: function() {
			var oView = this.getView();
			this.oDialog = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.AddQuestions", this);
			oView.addDependent(this.oDialog);

			this.oDialog.open();
		},

		onQueTypeChange: function(oEvent) {
			var that = this;
			jQuery.sap.delayedCall(500, this, function() {
				var oView = that.getView(),
					oFrag,
					sValue = oEvent.getSource().getBindingContext().getObject().Questiontypek;

				if (that.getView().byId("idQuesTypes")) {
					var id = that.getView().byId("idQuesTypes");
					id.destroy();
				}

				if (sValue === "01") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.YesOrNo", that);
				} else if (sValue === "02") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.MultipleChoice", that);
				} else if (sValue === "03") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.Dropdown", that);
				} else if (sValue === "04") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.ScaleRange", that);
				} else if (sValue === "05") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.Ranking", that);
				} else if (sValue === "06") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.SingleTextbox", that);
				} else if (sValue === "07") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.CommentBox", that);
				} else if (sValue === "08") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.DateTime", that);
				} else if (sValue === "09") {
					oFrag = sap.ui.xmlfragment(oView.getId(), "cmiadmin.fragments.questionTypes.Text", that);
				}

				that.getView().byId("idAddQueVBox").addItem(oFrag);
			}).bind(oEvent);
		},

		onRadioDefRoutSelect: function(oEvent) {
			var sSelectedRadio = oEvent.getSource().getSelectedButton().getText();
			var oViewModel = this.getModel("adminModel");
			if (sSelectedRadio === "Practice Manager") {
				oViewModel.setProperty("/PractMgrVisible", true);
				oViewModel.setProperty("/groupVisible", false);
				this.getView().byId("idSFDefRoutPractMgr").setValue("");
				this.getView().byId("idSFDefRoutGroup").setValue("");
			} else if (sSelectedRadio === "Group") {
				oViewModel.setProperty("/groupVisible", true);
				oViewModel.setProperty("/PractMgrVisible", false);
				this.getView().byId("idSFDefRoutPractMgr").setValue("");
				this.getView().byId("idSFDefRoutGroup").setValue("");
			}
		},

		onAddQueSubmit: function(oEvent) {
			var payload = {
				"Attributetypek": "01",
				"Questiontypek": "AF",
				"Requiredquestion": "X",
				"QuestionText": "Is this adverse to a govt. entity",
				"DefaultAnswer": "X",
				"Answerchoice1": "No. It does not interfere with govt. regulations",
				"Answerchoice1Risk": "01",
				"AddNaColumn": "X"
			};

			/*var oModel = this.getOwnerComponent().getModel();
			oModel.create("/Busconsiderations", payload, {
				success: function(oData, oResponse) {
					var msg = oResponse.statusText;
					sap.m.MessageToast.show(msg);
				},
				error: function(oError) {
					sap.m.MessageToast.show(oError);
				}
			});*/
		},

		onAddQueCancel: function() {
			this.getView().byId("idQT").setValue("");
			this.oDialog.destroyContent();
			this.oDialog.close();
		},

		onRQUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total"),
				sTitleCount = "(" + iTotalItems + ")";
			this.getModel("adminModel").setProperty("/RQCount", sTitleCount);
		},

		onPQUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total"),
				sTitleCount = "(" + iTotalItems + ")";
			this.getModel("adminModel").setProperty("/PQCount", sTitleCount);
		},

		onAFUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total"),
				sTitleCount = "(" + iTotalItems + ")";
			this.getModel("adminModel").setProperty("/AFCount", sTitleCount);
		},

		onALUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total"),
				sTitleCount = "(" + iTotalItems + ")";
			this.getModel("adminModel").setProperty("/ALCount", sTitleCount);
		},

		onMiscUpdateFinished: function(oEvent) {
			var iTotalItems = oEvent.getParameter("total"),
				sTitleCount = "(" + iTotalItems + ")";
			this.getModel("adminModel").setProperty("/MiscCount", sTitleCount);
		}

	});
});

var myFormatter = {
	requiredQuestion: function(sValue1, sValue2) {
		if (sValue2 === "X") {
			this.addStyleClass("sapMLabelRequired");
			return " " + sValue1;
		} else {
			return " " + sValue1;
		}
	}
};