sap.ui.define([
	] , function () {
		"use strict";

		return {

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			
			returnFloat : function (sValue) {
				if (!sValue) {
					return [];
				}
				
				var aSval = sValue.split(","); 
				
				var aRetVal = [parseFloat(aSval[0]),parseFloat(aSval[1])];
				return aRetVal;
			}

		};

	}
);