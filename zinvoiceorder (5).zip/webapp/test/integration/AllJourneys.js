/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 MasterDataSet in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/App",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Browser",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Master",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Detail",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zinvoiceorder.zinvoiceorder.view."
	});

	sap.ui.require([
		"zinvoiceorder/zinvoiceorder/test/integration/MasterJourney",
		"zinvoiceorder/zinvoiceorder/test/integration/NavigationJourney",
		"zinvoiceorder/zinvoiceorder/test/integration/NotFoundJourney",
		"zinvoiceorder/zinvoiceorder/test/integration/BusyJourney",
		"zinvoiceorder/zinvoiceorder/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});