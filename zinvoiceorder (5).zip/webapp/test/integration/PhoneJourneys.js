/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/App",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Browser",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Master",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/Detail",
	"zinvoiceorder/zinvoiceorder/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zinvoiceorder.zinvoiceorder.view."
	});

	sap.ui.require([
		"zinvoiceorder/zinvoiceorder/test/integration/NavigationJourneyPhone",
		"zinvoiceorder/zinvoiceorder/test/integration/NotFoundJourneyPhone",
		"zinvoiceorder/zinvoiceorder/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});