/*global location */
sap.ui.define([
	"zinvoiceorder/zinvoiceorder/controller/BaseController",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/m/Button",
	"zinvoiceorder/zinvoiceorder/model/formatter"
], function (BaseController, MessageToast, Fragment, MessagePopover, MessagePopoverItem, Controller, JSONModel, MessageBox, Dialog,
	Label,
	TextArea, Button,
	formatter) {
	"use strict";

	return BaseController.extend("zinvoiceorder.zinvoiceorder.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

			var oEventBus1 = sap.ui.getCore().getEventBus();
			oEventBus1.subscribe("Detail", "_bindView", this._bindView, this);

		},

		onPressItem: function (oEvent) {
			sap.ui.core.BusyIndicator.show();
			var oTable = this.getView().byId("table0");
			var Lineitem = oTable.indexOfItem(oTable.getSelectedItem());
			Lineitem = Lineitem + 2;
			// Because Line item in sap is maintain like this, so after 0009 we need to slice it 0010
			if (Lineitem <= 9) {
				Lineitem = "000" + Lineitem;
			}

			if (Lineitem >= 10) {
				Lineitem = "00" + Lineitem;
			}

			// Because Line item in sap is maintain like this, so after 0009 we need to slice it 0010
			// if (Lineitem.length >= 5) {
			// 	Lineitem.slice(1);
			// }

			var materialNo = oEvent.getParameter("listItem").getCells()[1].getText();
			var objectId = this.selectObject;
			this.getRouter().navTo("item", {
				objectId: objectId,
				materialNo: materialNo,
				Lineitem: Lineitem
			});
		},

		// BEGIN PJHA
		// onTabSelect: function (oData) {

		// 	var AttchIcon = this.getView().byId("iconTabBar").getSelectedKey();

		// 	if (AttchIcon === "Attachment") {

		// 		this.getView().byId("UploadCollection").setUploadButtonInvisible(true);

		// 		var oDataModel = this.getOwnerComponent().getModel();
		// 		var task_url =
		// 			"/MasterDataSet(Reqid='" + this.selectObject + "')";
		// 		oDataModel.read(task_url, {
		// 			urlParameters: {
		// 				"$expand": ["NAV_REQ_ATTACH"]
		// 			},
		// 			success: jQuery.proxy(this.onSuccessAttach, this),
		// 			error: jQuery.proxy(this.onErrorAttach, this)
		// 		});
		// 	}

		// },

		// onSuccessAttach: function (oData) {
		// 	// debugger;
		// 	var oModel = new sap.ui.model.json.JSONModel();
		// 	oModel.setData(oData.NAV_REQ_ATTACH.results);
		// 	this.getView().byId("UploadCollection").setModel(oModel, "attachMent");
		// },
		// onErrorAttach: function (oData) {},
		onFilePress: function (oEvt) {

			// var bin = oEvt.getSource().getUrl();
			// // var fil = oEvt.getSource().getFileName();
			// var fileType = "application/pdf";
			// var fMres = atob(bin);

			// var byteNumbers = new Array(fMres.length);

			// for (var i; i < fMres; i++) {
			// 	byteNumbers[i] = fMres.charCodeAt(i);

			// }
			// // var byteArray = new Unit8Array(byteNumbers);
			// var blob = new Blob([byteNumbers], {
			// 	type: fileType
			// });
			// var url = URL.createObjectURL(blob);
			// window.open(url, '_blank');

			// var flname = fil.split(".");

			// var length = flname.length;

			// length = length - 1;
			// var ext = flname[length];

			// var fileType;

			// if ((ext == 'pdf') || (ext == 'PDF')) {
			// 	fileType = "data:application/pdf;base64,";
			// } else if ((ext == 'jpg') || (ext == 'JPG')) {
			// 	fileType = "data:image/jpg;base64,";
			// 	// data:application/octet-stream
			// } else if ((ext == 'doc') || (ext == 'DOC')) {
			// 	fileType = "data:application/msword;base64,";
			// } else if ((ext == 'docx') || (ext == 'DOCX')) {
			// 	fileType = "data:application/msword;base64,";
			// } else if ((ext == 'png') || (ext == 'PNG')) {
			// 	fileType = "data:image/png;base64,";
			// } else if ((ext == 'jpeg') || (ext == 'JPEG')) {
			// 	fileType = "data:image/jpeg;base64,";
			// } else if ((ext == 'xls') || (ext == 'XLS')) {
			// 	fileType = "data:application/vnd.ms-excel;base64,";
			// } else if ((ext == 'xlsx') || (ext == 'XLSX')) {
			// 	fileType = "data:application/vnd.ms-excel;base64,";
			// } else if ((ext == 'txt') || (ext == 'TXT')) {
			// 	fileType = "data:text/plain;base64,";
			// }

			// var a = document.createElement("a"); //Create <a>
			// // a.href = oEvt.getSource().getUrl(); //Image Base64 Goes here
			// a.href = "data:application/pdf;base64," + oEvt.getSource().getUrl();
			// a.download = oEvt.getSource().getFileName(); //File name Here
			// a.click();

			var json = JSON.stringify(oEvt.getSource().getUrl());

			// var u8_2 = new Uint8Array(atob(oEvt.getSource().getUrl()).split("").map(function(c) {
			//                     return c.charCodeAt(0);
			//                 }));

			//                 var a = window.document.createElement('a');
			//                 a.href = window.URL.createObjectURL(new Blob([u8_2], {
			//                     type: item.getMimeType()
			//                 }));

			// var blob = new Blob([json], {
			// 	type: "application/pdf"
			// });
			// var url = window.URL.createObjectURL(blob);
			// window.location.assign(url);

			// var a = document.createElement("a");
			// document.body.appendChild(a);
			// a.style = "display: none";
			// var blob = new Blob([json], {
			// 	type: "application/pdf"
			// });
			// var url = window.URL.createObjectURL(blob);
			// a.href = url;
			// a.download = oEvt.getSource().getFileName();
			// a.click();
			// window.URL.revokeObjectURL(url); 

			// sap.ui.core.util.File.save(oEvt.getSource().getUrl(), oEvt.getSource().getFileName().replace(".pdf", ""), "pdf", fileType, "utf-8",
			// 	true);

			// parent.window.open(a.href, '_blank');
			// this.getView().byId("pdfViewer").setSource(a.href);
			// this.getView().byId("pdfViewer").setTitle(oEvt.getSource().getFileName());

			// var length = flname.length;
			// fil = '';
			// length = length - 1;
			// var ext = flname[length];
			// for (var i = 0; i < length; i++) {
			// 	if (i >= 1) {
			// 		fil = fil + '.' + flname[i];

			// 	} else {
			// 		fil = flname[i];
			// 	}
			// }
			// var mim = oEvt.getSource().getMimeType();
			// sap.ui.core.util.File.save(bin, fil, ext, 'application/pdf');

			var convString = this.hexToBase64(oEvt.getSource().getUrl());
			var contentType = 'application/pdf';
			var b64Data =
				convString;

			var blob = this.b64toBlob(b64Data, contentType);
			var blobUrl = URL.createObjectURL(blob);
			jQuery.sap.addUrlWhitelist("blob");
			// window.location.assign(blobUrl);
			window.open(blobUrl, '_blank');
			this.getView().byId("pdfViewer").setSource(blobUrl)
		},
		hexToBase64: function (str) {
			var bString = "";
			for (var i = 0; i < str.length; i += 2) {
				bString += String.fromCharCode(parseInt(str.substr(i, 2), 16));
			}
			return btoa(bString);
		},

		b64toBlob: function (b64Data, contentType, sliceSize) {
			contentType = contentType || '';
			sliceSize = sliceSize || 512;
			var byteCharacters = atob(b64Data);
			var byteArrays = [];
			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);
				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
				}
				var byteArray = new Uint8Array(byteNumbers);
				byteArrays.push(byteArray);
			}
			var blob = new Blob(byteArrays, {
				type: contentType
			});
			return blob;
		},

		//END PJHA
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function () {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		handlePopoverPress: function (oEvent) {
			var oButton = oEvent.getSource();

			// create popover
			if (!this._oPopover) {
				this._oDialog = sap.ui.xmlfragment("zinvoiceorder.zinvoiceorder.fragment.Popover", this);
				this.getView().addDependent(this._oDialog);

				// Fragment.load({
				// 	name: "zinvoiceorder.zinvoiceorder.view.Detail",
				// 	controller: this
				// }).then(function(pPopover) {
				// 	this._oPopover = pPopover;
				// 	this.getView().addDependent(this._oPopover);
				// 	this._oPopover.bindElement("/ProductCollection/0");
				// 	this._oPopover.openBy(oButton);
				// }.bind(this));
			} else {
				this._oPopover.openBy(oButton);
			}

			this._oDialog.open();
		},

		handlePopoverPress1: function (oEvent) {
			var oButton = oEvent.getSource();

			// create popover
			if (!this._oPopover) {
				Fragment.load({
					name: "zinvoiceorder.zinvoiceorder.fragment.Popover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					// this._oPopover.bindElement("/ProductCollection/0");
					this._oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopover.openBy(oButton);
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function () {
			var oViewModel = this.getModel("detailView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});

			oShareDialog.open();
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.selectObject = sObjectId;

			this.getModel().metadataLoaded().then(function () {
				var sObjectPath = this.getModel().createKey("MasterDataSet", {
					Reqid: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function (sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		// _onBindingChange : function () {
		// 	var oView = this.getView(),
		// 		oElementBinding = oView.getElementBinding();

		// 	// No data for the binding
		// 	if (!oElementBinding.getBoundContext()) {
		// 		this.getRouter().getTargets().display("detailObjectNotFound");
		// 		// if object could not be found, the selection in the master list
		// 		// does not make sense anymore.
		// 		this.getOwnerComponent().oListSelector.clearMasterListSelection();
		// 		return;
		// 	}

		// 	var sPath = oElementBinding.getPath(),
		// 		oResourceBundle = this.getResourceBundle(),
		// 		oObject = oView.getModel().getObject(sPath),
		// 		sObjectId = oObject.Reqid,
		// 		sObjectName = oObject.Reqid,
		// 		oViewModel = this.getModel("detailView");

		// 	this.getOwnerComponent().oListSelector.selectAListItem(sPath);

		// 	oViewModel.setProperty("/saveAsTileTitle",oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
		// 	oViewModel.setProperty("/shareOnJamTitle", sObjectName);
		// 	oViewModel.setProperty("/shareSendEmailSubject",
		// 		oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		// 	oViewModel.setProperty("/shareSendEmailMessage",
		// 		oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		// },
		_onBindingChange: function () {
			this.getView().setBusy(true);
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Reqid,
				sObjectName = oObject.Reqid,
				oViewModel = this.getModel("detailView");
			//------------------------------Coding Done By Sujoy----------------------------------------------
			//------------------------------To Bring Data from Backend----------------------------------------------

			var oModel = this.getView().byId("table0").getModel();
			var itemData = oModel.getProperty("/ReadDataSet");

			var sServiceUrl = "/sap/opu/odata/sap/ZUI_SDAPP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oJsonModel = new sap.ui.model.json.JSONModel();
			// var spath1 = "/ReadDataSet?$filter=Reqid eq";
			// var spath2 = "'" + sObjectId + "'";
			// var spath3 = "&$expand";
			// var sUri = spath1 + spath2 + spath3;
			var sUri = "/ReadDataSet('" + sObjectId + "')";
			// Intializing table here - Start 
			var itemRow = {
				"ReadDataSet": []
			};
			var oModel1 = new JSONModel();
			oModel1.setData(itemRow);
			this.getView().byId("table0").setModel(oModel1);
			// Intializing table here - End

			// Getting Data From Backend - Start
			// var that = this;
			oModel.read(sUri, {
				async: false,
				urlParameters: {
					"$expand": ["NAV_READ_ATTACH", "NAV_READ_ITEMS", "NAV_READ_REJECTLOG"] //PJHA 30-04
				},
				success: jQuery.proxy(this.onSuccess, this)
			});
			//----------------------------------------------------------------------------

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		onSuccess: function (odata) {

			if ((odata.Status == 'A') || (odata.Status == 'R')) {
				this.getView().byId("idAccept").setEnabled(false);
				this.getView().byId("idReject").setEnabled(false);
			} else {
				this.getView().byId("idAccept").setEnabled(true);
				this.getView().byId("idReject").setEnabled(true);
			}

			var oModel1 = this.getView().byId("table0").getModel();
			var itemData = oModel1.getProperty("/ReadDataSet");
			var i;
			for (i = 0; i < odata.NAV_READ_ITEMS.results.length; i++) {
				// var reqID = odata.results[i].Reqid;
				// var xData = odata.results[i].Xdata;
				// var Description = xData.split("|")[5];
				// var Quantity = xData.split("|")[3];
				// var Unit = xData.split("|")[4];
				// var MaterialNo = xData.split("|")[1];
				// var Price = xData.split("|")[6] + " " + xData.split("|")[7];
				// var oAction1 = odata.results[i].Status;
				// var oTotal1 = xData.split("|")[6] * xData.split("|")[3];
				// oTotal1 = oTotal1.toFixed(2);
				// var oTotal = oTotal1 + " " + xData.split("|")[7];
				// var OrderNumber = xData.split("|")[2];
				// var CostCentre = xData.split("|")[8];

				// var RefDate = xData.split("|")[9];
				var reqID = odata.NAV_READ_ITEMS.results[i].Reqid;
				var xData = odata.NAV_READ_ITEMS.results[i].Xdata;
				var Description = xData.split("|")[5];
				var Quantity = xData.split("|")[3];
				var Unit = xData.split("|")[4];
				var MaterialNo = xData.split("|")[1];
				// var Price = xData.split("|")[6] + " " + xData.split("|")[7];
				var Price = xData.split("|")[6];
				var oAction1 = odata.NAV_READ_ITEMS.results[i].Status;
				var oTotal1 = xData.split("|")[6] * xData.split("|")[3];
				oTotal1 = oTotal1.toFixed(2);
				// var oTotal = oTotal1 + " " + xData.split("|")[7];
				var oTotal = oTotal1;
				var OrderNumber = xData.split("|")[2];
				var CostCentre = xData.split("|")[8];

				var RefDate = xData.split("|")[9];
				var itemRow = {
					RefDate: RefDate,
					MaterialNo: MaterialNo,
					Description: Description,
					CostCentre: CostCentre,
					OrderNo: OrderNumber,
					Quantity: Quantity,
					Unit: Unit,
					Price: Price,
					Total: oTotal
				};
				itemData.push(itemRow);
				oModel1.setData({
					ReadDataSet: itemData
				});
				//BEGIN PJHA 30-04 
				// var oModel2 = new sap.ui.model.json.JSONModel();
				// oModel2.setData(odata.NAV_READ_ATTACH.results);
				// this.getView().byId("UploadCollection").setModel(oModel2, "attachMent");
				// this.getView().byId("UploadCollection").setUploadButtonInvisible(true);
				// this.getView().setBusy(false);
				//END PJHA 30-04
				//Sujoy
				// this.getView().byId("table0").setModel("/", oModel1);
			}
			//BEGIN PJHA 30-04 
			var oModel2 = new sap.ui.model.json.JSONModel();
			oModel2.setData(odata.NAV_READ_ATTACH.results);
			this.getView().byId("UploadCollection").setModel(oModel2, "attachMent");
			this.getView().byId("UploadCollection").setUploadButtonInvisible(true);
			this.getView().setBusy(false);

			var oModel3 = new sap.ui.model.json.JSONModel();
			oModel3.setData(odata.NAV_READ_REJECTLOG.results);
			this.getView().byId("idRejectionLog").setModel(oModel3, "rejectLog");
			this.getView().byId("iconTabBarFilter4").setCount(odata.NAV_READ_REJECTLOG.results.length);
			//END PJHA 30-04			

		},

		handleMessagePopoverPress: function (oEvent) {

			var oMessagePopover = new MessagePopover({
				items: {
					template: new sap.m.MessagePopoverItem({
						description: "Sujoy Description",
						title: "Sujoy title"
					})
				}
			});

			// oMessagePopover.openBy(oEvent.getSource());

			//         var oButton = oEvent.getSource();

			//         if (!this._oDialog) {

			// 	this._oDialog = sap.ui.xmlfragment("zinvoiceorder.zinvoiceorder.fragment.Popover", this);
			// 	this.getView().addDependent(this._oDialog);

			// }
			//         this._oDialog.open();
			//         			// create popover
			// if (!this._oPopover) {
			// 	Fragment.load({
			// 		name: "zinvoiceorder.zinvoiceorder.fragment.Popover",
			// 		controller: this
			// 	}).then(function(pPopover) {
			// 		this._oPopover = pPopover;
			// 		this.getView().addDependent(this._oPopover);
			// 		this._oPopover.bindElement("/ProductCollection/0");
			// 		this._oPopover.openBy(oButton);
			// 	}.bind(this));
			// } else {
			// 	this._oPopover.openBy(oButton);
			// }

		},

		formatLabel3: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";
			var formattedString1 = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var custNumber = Xdata.split("|")[1];
					this.byId("custNumber").setText(custNumber);
					formattedString = this.byId("custNumber").setText(custNumber);
					//return formattedString;
					formattedString = formattedString.getText();

					var sum = Xdata.split("|")[13];
					this.byId("labelTotal").setText(custNumber);
					formattedString1 = this.byId("labelTotal").setText(sum);
					formattedString1 = formattedString1.getText();
				}
			}
			return formattedString;

		},

		formatLabel4: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var custAddress = Xdata.split("|")[3];
					this.byId("custAddress").setText(custAddress);
					formattedString = this.byId("custAddress").setText(custAddress);
					//return formattedString;
					formattedString = formattedString.getText();

				}
				if (oStatus === "ZSD_INV_Line") {
					var sum = Xdata.split("|")[3];

					//formattedString = this.byId("label133").setText(sum);
					//return formattedString;
					//formattedString = formattedString.getText();

				}
			}
			return formattedString;

		},
		formatLabel5: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var custAddress1 = Xdata.split("|")[4];

					formattedString = this.byId("custAddress1").setText(custAddress1);
					//return formattedString;
					formattedString = formattedString.getText();

				}
			}
			return formattedString;

		},

		formatLabel6: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {

					var requestType = Xdata.split("|")[19];
					this.byId("requestType").setText(requestType);

					var custCity = Xdata.split("|")[5];
					formattedString = this.byId("custCity").setText(custCity);
					//return formattedString;
					formattedString = formattedString.getText();

				}
			}
			return formattedString;

		},

		formatLabel7: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";
			var formattedString1 = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var custCity = Xdata.split("|")[5];
					var total = Xdata.split("|")[13];
					formattedString1 = this.byId("custCity").setText(total);
					formattedString = this.byId("custCity").setText(custCity);
					//return formattedString;
					formattedString = formattedString.getText();
					formattedString1 = formattedString1.getText();
				}
			}
			return formattedString, formattedString1;

		},

		formatLabel8: function (Xdata) {

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var total = Xdata.split("|")[8];
					this.byId("labelTotal").setText(total);
					this.byId("invoiceValue").setText(total);
					formattedString = this.byId("invoiceValue").getText(total);
					return formattedString;
					//formattedString = this.byId("labelTotal").setText(total);
					//return formattedString;
					//formattedString = formattedString.getText();

				}
			}

		},

		//user name;
		formatLabel11: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var username = Xdata.split("|")[7];
					this.byId("username").setText(username);
					formattedString = this.byId("username").getText(username);
					return formattedString;

				}
			}

		},

		//Sales Organiyation;
		formatLabel12: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var salesOrg = Xdata.split("|")[11];
					this.byId("salesOrg").setText(salesOrg);
					formattedString = this.byId("salesOrg").getText(salesOrg);
					return formattedString;

				}
			}

		},
		//Preffered Date;
		formatLabel14: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var PreferredDate = Xdata.split("|")[12];
					this.byId("PreferredDate").setText(PreferredDate);
					formattedString = this.byId("PreferredDate").getText(PreferredDate);
					return formattedString;

				}
			}

		},

		//Payment Term;
		formatLabel15: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {
					var paymentTerm = Xdata.split("|")[22];
					this.byId("paymentTerm").setText(paymentTerm);
					formattedString = this.byId("paymentTerm").getText(paymentTerm);
					return formattedString;

				}
			}

		},

		//Customer Header Refernces;
		formatLabel16: function (Xdata) {
			//var formattedString = "T";
			//if (Status  !== undefined && Status  !== null) {
			//  formattedString = "In progress – pending for approval";
			//}
			//return formattedString;

			var formattedString = " ";

			if (Xdata !== null) {
				var oStatus = Xdata.split("|")[0];
				if (oStatus === "ZSD_INV_Head") {

					var chr1 = Xdata.split("|")[14];
					this.byId("id_CHR1").setText(chr1);

					var chr2 = Xdata.split("|")[15];
					this.byId("id_CHR2").setText(chr2);

					var chr3 = Xdata.split("|")[16];
					this.byId("id_CHR3").setText(chr3);

					var st = Xdata.split("|")[17];
					this.byId("shorttext").setText(st);

					var lt = Xdata.split("|")[18];
					this.byId("longtext").setText(lt);

					var sentBy = Xdata.split("|")[20];
					this.byId("sentBy").setText(sentBy);

					var Email = Xdata.split("|")[21];
					this.byId("Email").setText(Email);

					var name = Xdata.split("|")[23];
					this.byId("id_Name").setText(name);

					var phone = Xdata.split("|")[24];
					this.byId("id_Phone").setText(phone);

					var vat = Xdata.split("|")[6];
					this.byId("vat").setText(vat);

					formattedString = this.byId("id_CHR1").getText(chr1);
					return formattedString;

				}
			}

		},

		//Customer Header Refernces;
		formatLabel17: function (Xdata) {

			var formattedString = "DAM";
			var sServiceUrl = "/sap/opu/odata/sap/ZUI_SDAPP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var spath1 = "/ContactDetailsSet?$filter=Parau eq ";

			var spath2 = "'" + "USERNAME" + "'";
			var sUri = spath1 + spath2;
			oModel.read(sUri, {
				async: false,
				success: jQuery.proxy(this.onLoadContactDetails, this)
			});

		},

		onLoadContactDetails: function (odata) {
			var PartnerNumber = odata.results[0].Parnr;
			var NameF = odata.results[0].Name1;
			var NameL = odata.results[0].Namev;
			var Name = NameL + " " + NameF;
			var Tel = odata.results[0].Telf1;
			this.getView().byId("PartnerNumber").setText(PartnerNumber);
			this.getView().byId("ContactPerson").setText(Name);
			this.getView().byId("CPPhoneNumner").setText(Tel);
			return;

		},

		onSemanticAccept: function () {
			MessageBox.confirm("Would you like to approve ? This will create a SD Order in SAP", {
				title: "Sales Order Approve",
				onClose: this.popupClose.bind(this)
			});
		},

		popupClose: function (choice) {
			if (choice === "OK") {
				//	var oFirtTab = this.getView().byId("idItemData");
				//	oFirtTab.setVisible(false);
				// var oReqId = this.getView().byId("Reqid").getTitle();

				var oView = this.getView(),
					oElementBinding = oView.getElementBinding();
				var sPath = oElementBinding.getPath(),
					oResourceBundle = this.getResourceBundle(),
					oObject = oView.getModel().getObject(sPath),
					sObjectId = oObject.Reqid;
				var oReqId = oObject.Reqid;

				var sServiceUrl = "/sap/opu/odata/sap/ZUI_SDAPP_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
				var oEntry = {};
				oEntry.Reqid = sObjectId;
				oEntry.Xdata = "Accept";

				var oGlobalBusyDialog = new sap.m.BusyDialog({
					text: "Please Wait....Request is in Progress"
				});
				oGlobalBusyDialog.open(); //Open Busy Dialog
				//MessageToast.show("GCN Reason Code is Approved", {duration: 4000});
				jQuery.sap.delayedCall(3000, this, function () {
					oGlobalBusyDialog.close();
				});

				var that = this;
				oModel.update("/ApprovalSet('" + oReqId + "')", oEntry, {

					success: function (oData, oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						var sCompleteMessage = oResponse.headers["sap-message"];
						var oMessage = JSON.parse(sCompleteMessage);
						var oResultSuccess = oMessage.message.slice(1) + "." + "Go to SAP transaction VA02 to check and bill the order.";
						var oResulterror = oMessage.message.slice(1);

						if (oMessage.severity === "error") {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageBox.error(oResulterror, {
								actions: [sap.m.MessageBox.Action.OK],
								emphasizedAction: sap.m.MessageBox.Action.OK,
								onClose: function (sAction) {
									// MessageToast.show("Action selected: " + sAction);
									var oGlobalBusyDialog = new sap.m.BusyDialog({
										text: "Next Request is getting uploaded"
									});
									oGlobalBusyDialog.open(); //Open Busy Dialog
									//MessageToast.show("GCN Reason Code is Approved", {duration: 4000});
									jQuery.sap.delayedCall(4000, this, function () {
										oGlobalBusyDialog.close();
									});
									var eventBus = sap.ui.getCore().getEventBus();
									eventBus.publish("Master", "onRefresh1");
									var objectId1 = sap.ui.getCore()._yourData;
									that.getRouter().navTo("object", {
										objectId: objectId1
									});
								}
							});
						}

						if (oMessage.severity === "info") {
							// sap.m.MessageBox.success(oResult);
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageBox.success(oResultSuccess, {
								actions: [sap.m.MessageBox.Action.OK],
								emphasizedAction: sap.m.MessageBox.Action.OK,
								onClose: function (sAction) {
									// MessageToast.show("Action selected: " + sAction);
									var oGlobalBusyDialog = new sap.m.BusyDialog({
										text: "Next Request is getting uploaded"
									});
									oGlobalBusyDialog.open(); //Open Busy Dialog
									//MessageToast.show("GCN Reason Code is Approved", {duration: 4000});
									jQuery.sap.delayedCall(4000, this, function () {
										oGlobalBusyDialog.close();
									});
									var eventBus = sap.ui.getCore().getEventBus();
									eventBus.publish("Master", "onRefresh1");
									var objectId1 = sap.ui.getCore()._yourData;
									that.getRouter().navTo("object", {
										objectId: objectId1
									});
								}
							});

							// var eventBus = sap.ui.getCore().getEventBus();
							//        eventBus.publish("Master","onRefresh1");
							//        sap.m.MessageBox.information(oResult);
							//       // eventBus.publish("Master","onRefresh");
							//       //this.getView().getModel().refresh();
							//         var objectId1 = sap.ui.getCore()._yourData;
							//       that.getRouter().navTo("object", {
							// 	 objectId : objectId1 }
							// 	 );
							//       sap.m.MessageBox.information("Hi from Detail controller");
						}

					},
					error: function (oData) {
						sap.ui.core.BusyIndicator.hide();
						var i;
						var error = JSON.parse(oData.response.body).error.innererror.errordetails;

						var str = '';
						for (i = 0; i < error.length; i++) {

							var code = JSON.parse(oData.response.body).error.innererror.errordetails[i].code;
							var message = JSON.parse(oData.response.body).error.innererror.errordetails[i].message;
							if (code !== "/IWBEP/CX_MGW_TECH_EXCEPTION") {
								str += message + ".";
							}

						}
						MessageBox.error(str);
					}

				});

			}
		},

		onSemanticReject: function () {
			var oDataModel = this.getView().getModel();
			// Get Request id number
			var oReqId = this.selectObject;

			var dialog = new Dialog({
				title: "Reason for Reject",
				type: "Message",
				content: [
					new Label({
						text: "Do you want to reject request - "
					}),
					new Label("reqId", {
						text: oReqId,
						labelFor: "submitDialogTextarea"
					}),
					new Label({
						text: "?"
					}),
					new TextArea("submitDialogTextarea", {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter("value");
							var parent = oEvent.getSource().getParent();

							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: "100%",
						maxLength: 49,
						placeholder: "Feedback is required"
					})
				],
				beginButton: new Button({
					text: "Submit",
					enabled: false,
					press: function () {
						sap.ui.core.BusyIndicator.show(0);
						var sServiceUrl = "/sap/opu/odata/sap/ZUI_SDAPP_SRV/";
						var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

						var sText = sap.ui.getCore().byId("submitDialogTextarea").getValue();
						var oReqIdReject = sap.ui.getCore().byId("reqId").getText();
						var oEntry = {};
						oEntry.Reqid = oReqIdReject;
						// oEntry.Remark = sText;
						oEntry.Xdata = sText;
						// var oModel = new sap.ui.model.json.JSONModel();
						// oModel.setData(oEntry);
						// sap.ui.getCore().setModel(oModel);
						// var oDataModel1 =  sap.ui.getCore().byId('reqId').setModel();
						// var oDataModel2 = sap.ui.getCore().getModel();
						if (oEntry.Xdata.charAt(0) === " ") {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Blank Comment is not allowed");
						} else {
							dialog.close();
							var that = this;
							oModel.update("/ApprovalSet('" + oReqIdReject + "')", oEntry, {

								success: function (oData, oResponse) {

									sap.ui.core.BusyIndicator.hide(0);
									var oResultRejectSuccess = "Request has been Rejected.Email Notofication is  triggred to Requester";

									sap.m.MessageBox.success(oResultRejectSuccess, {
										actions: [sap.m.MessageBox.Action.OK],
										emphasizedAction: sap.m.MessageBox.Action.OK,
										onClose: function (sAction) {
											// MessageToast.show("Action selected: " + sAction);
											var oGlobalBusyDialog = new sap.m.BusyDialog({
												text: "Next Request is getting uploaded"
											});
											oGlobalBusyDialog.open(); //Open Busy Dialog
											//MessageToast.show("GCN Reason Code is Approved", {duration: 4000});
											jQuery.sap.delayedCall(4000, this, function () {
												oGlobalBusyDialog.close();
											});
											var eventBus = sap.ui.getCore().getEventBus();
											eventBus.publish("Master", "onRefresh1");
											var objectId1 = sap.ui.getCore()._yourData;
											this.getRouter().navTo("object", {
												objectId: objectId1
											});
										}
									});

								},
								error: function (oData) {
									//var sCompleteMessage = oResponse.headers["sap-message"];
									//var oMessage = "GCN is Rejected";
									//sap.m.MessageBox.error(oMessage.message);
									//sap.ui.core.BusyIndicator.hide();
								}

							});

						}

					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			dialog.open();

		},

		_onMetadataLoaded: function () {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});