sap.ui.define([
	"zinvoiceorder/zinvoiceorder/controller/BaseController",
	"sap/ui/core/routing/History",
], function (BaseController, History) {
	"use strict";

	return BaseController.extend("zinvoiceorder.zinvoiceorder.controller.ItemDetail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zinvoiceorder.zinvoiceorder.view.ItemDetail
		 */
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRoutePatternMatched(this.handleRoute, this);
		},
		handleRoute: function (oParams) {

			var objectId = oParams.getParameter("arguments").objectId;
			this.materialNo = oParams.getParameter("arguments").materialNo;
			this.Lineitem = oParams.getParameter("arguments").Lineitem;

			var sServiceUrl = "/sap/opu/odata/sap/ZUI_SDAPP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			// var oJsonModel = new sap.ui.model.json.JSONModel();
			var spath1 = "/ReadDataSet?$filter=Reqid eq";
			var spath2 = "'" + objectId + "'";
			var spath3 = "&$expand";
			var sUri = spath1 + spath2 + spath3;
			var that = this;
			oModel.read(sUri, {
				async: false,
				success: function (odata, response) {
					sap.ui.core.BusyIndicator.hide();
					var i;
					for (i = 0; i < odata.results.length; i++) {
						// var reqID = odata.results[i].Reqid;
						var xData = odata.results[i].Xdata;
						// var Description = xData.split("|")[5];
						// var Quantity = xData.split("|")[3];
						// var Unit = xData.split("|")[4];
						// if (that.materialNo == xData.split("|")[1]) {
						if (that.Lineitem === odata.results[i].Lineitem) {
							// var Price = xData.split("|")[6] + " " + xData.split("|")[7];
							// var oAction1 = odata.results[i].Status;
							// var oTotal1 = xData.split("|")[6] * xData.split("|")[3];
							// var oTotal = oTotal1 + " " + xData.split("|")[7];
							var OrderNumber = xData.split("|")[2];
							// var CostCentre = xData.split("|")[8];

							var RefDate = xData.split("|")[9];
							var lineitemtext = xData.split("|")[10];
							that.getView().byId("idRefDate").setText(RefDate);
							that.getView().byId("idOrderNumber").setText(OrderNumber);
							that.getView().byId("idlineitemtext").setText(lineitemtext);
							break;
						} else {
							that.getView().byId("idRefDate").setText(null);
							that.getView().byId("idOrderNumber").setText(null);
						}

					}
				}
			});
		},

		onNavBack: function () {
				var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
					history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: "#Shell-home"
						}
					});
				}
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf zinvoiceorder.zinvoiceorder.view.ItemDetail
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zinvoiceorder.zinvoiceorder.view.ItemDetail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zinvoiceorder.zinvoiceorder.view.ItemDetail
		 */
		//	onExit: function() {
		//
		//	}

	});

});