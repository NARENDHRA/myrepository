jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		formatDate: function(iValue) {
			var value1;
			if (!iValue) {
				return null;
			} else {
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
					pattern: "YYYY-MM-dd"
				});
				value1 = oDateFormat.format(iValue);
				var dateVal = value1 + "T00:00:00";
				return value1;
			}
		},
		formatFlag: function(flag){
			if (flag === "true")
			{
				return true;
			} else{
				return false;
			}
			
		},
		
		formatAccountType: function(atValue) {
			var atValue1;
			if(atValue === "P")
			{
				atValue1="Pooled";
				
				
			}else if(atValue === "D")
			{
				atValue1="Designated";
			}
			return atValue1;
			
		},
		formatDocumentFlag: function(val){
			if(val === "X"){
				return "Emphasized";
			}else{
				return "Default";
			}
		},
		formatCloseDate:function(val){
			if(val === null){
				return true;
			}else{
				return false;
			}
		}
	

};

});