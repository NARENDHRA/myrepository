sap.ui.define([
	"trustaccmapping/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustaccmapping/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("trustaccmapping.controller.TrustAccMapping", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				flagAdd: false,
				ErrorList: []
			});

			this.setModel(oViewModel, "worklistView");
			this.OfficeDesc = "";
			this.oMatter = "";
			this.url = "";
			this.FileUploadSet = [];
			this.localJson = [];
			var that = this;

			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/ItemAccSet", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/AccType", "");
				c.setProperty(oContextClients.getPath() + "/BankAccNu", "");
				c.setProperty(oContextClients.getPath() + "/OpenDate", null);
				c.setProperty(oContextClients.getPath() + "/CloseDate", null);

				that.getView().setBindingContext(oContextClients);
			});
		},

		// before rebind table getting filter values
		handlebeforeRebindTable: function(OEVT) {
			this.isItemCanSave = false;
			this.flagAdd = false;

			var smartFilterBar = this.getView().byId("Trustworkbench"),
				sOffice = smartFilterBar.getControlByKey("OfficeDesc").getValue(),
				sOfficeKey = smartFilterBar.getControlByKey("Office").getValue(),
				sMatter = smartFilterBar.getControlByKey("MatterTxt").getValue(),
				sMatterKey = smartFilterBar.getControlByKey("Matter").getValue();
			this.sOfficeDesc = sOffice;
			this.sMatterTxt = sMatter;

			var oBindingParams = OEVT.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};

			if (sOfficeKey) {
				//aFilter.push(new Filter("Matter", "EQ", this.oMatterVal));
				oBindingParams.filters.push(new Filter("Office", "EQ", sOfficeKey));
			}
			if (sMatterKey) {
				oBindingParams.filters.push(new Filter("Matter", "EQ", sMatterKey));
			}

			//getting office and matter filter values 
			this.filter = OEVT.getParameters().bindingParams.filters[0];
			if (this.filter) {
				if (this.filter.oValue1) {
					this.oOffice = sOfficeKey;
				} else {
					this.getView().byId("idRefresh").setVisible(true);
					this.getView().byId("idAdd").setVisible(true);
					this.OfficeDesc = sOffice;
					this.oOffice = sOfficeKey;
					this.oMatter = sMatterKey;
				}
			}

		},
		handleChangeOffice: function(oEvent) {
			this.getView().byId("idRefresh").setVisible(false);
			this.getView().byId("idAdd").setVisible(false);

			var smartFilterBar = this.getView().byId("Trustworkbench"),
				sOffice = smartFilterBar.getControlByKey("OfficeDesc").getValue(),
				sOfficeKey = smartFilterBar.getControlByKey("Office").getValue(),
				sMatter = smartFilterBar.getControlByKey("MatterTxt").getValue(),
				sMatterKey = smartFilterBar.getControlByKey("Matter").getValue();

			if (sOffice !== this.OfficeDesc) {
				smartFilterBar.getControlByKey("MatterTxt").setValue("");
				this.OfficeDesc = sOffice;
			} else {
				smartFilterBar.getControlByKey("MatterTxt").setValue(sMatter);
			}
		},

		// handling cells editable for existing line items
		handleLineItemEdit: function(oEvent) {
			var oListItem, openDate, closeDate;
			this.getView().byId("isSaveMTA").setEnabled(true);
			this.flagAdd = false;
			oListItem = oEvent.getSource().getParent();
			openDate = oListItem.getCells()[2];
			closeDate = oListItem.getCells()[3];

			if (openDate.getEditable() && closeDate.getEditable()) {

				openDate.setEditable(false);
				closeDate.setEditable(false);
			} else {
				openDate.setEditable(false);
				//	openDate.setEditable(true);
				closeDate.setEditable(true);

			}

		},
		//On change of properties adding those values to bbinding context
		handleChangeOpenOrCloseDate: function(evt) {
			//var oTable = this.getView().byId("MTASmartTableId").getTable();
			this.isItemCanSave = true;
			var source = evt.getSource();
			var path = source.getBindingPath("dateValue");
			var value = source.getDateValue();
			// set Value for Trust Revarsal Details Context
			var sPath = source.getBindingContext().getPath();
			var oDateModel = source.getBindingContext().getModel();

			//code for setting sPath for different lineItems
			// var newSpath = this.sPath;
			// if (this.flagAdd === true) {
			// 	sPath = newSpath;
			// 	this.flagAdd = false;
			// } else {
			// 	sPath = sPath;
			// }

			if (!evt.getParameter("valid")) {
				source.setDateValue();
				oDateModel.setProperty(sPath + "/" + path, null);
				source.setValueState("Error");
				return;
			}
			//to set Min Date require JS DATE 
			if (path === "OpenDate") {
				var dateJSON = new Date(value);
				oDateModel.setProperty(sPath + "/OpenDate", dateJSON);
				source.getParent().getCells()[2].setDateValue(value);
			} else {
				oDateModel.setProperty(sPath + "/" + path, value);
			}
			source.setValueState("None");

		},
		handleChangeAccountType: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var accTypeValue = source.getValue();
			// set Value for Trust Revarsal Details Context
			var sPath = source.getBindingContext().getPath();
			var oAccTypeModel = source.getBindingContext().getModel();
			oAccTypeModel.setProperty(sPath + "/" + path, accTypeValue);
			oAccTypeModel.setProperty(sPath + "/" + "BankAccNu", "");
			oAccTypeModel.setProperty(sPath + "/" + "OpenDate", null);
			oAccTypeModel.setProperty(sPath + "/" + "CloseDate", null);
			source.setValueState("None");

		},

		onAccountTypeChange: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/" + "BankAccNu", "");
		},
		handleChangeBankAccNumber: function(evt) {
			var source = evt.getSource();
			var sPath = source.getBindingContext().getPath();
			var oBankAccNumberModel = source.getBindingContext().getModel();
			var path = source.getBindingPath("value");

			// checking for Bank account Number Duplication
			var oTable = source.getParent().getParent(),
				length = oTable.getItems().length,
				count, itemsBankAcc, itemsAccType, itemsCloseDate;

			//getting current line item values of Acc Type and Bank Account Number
			var BankaccValue, BankaccValue1 = source.getValue(),
				currentAccType = source.getParent().getCells()[0].getValue();

			for (count = 0; count < length; count++) {
				itemsBankAcc = oTable.getItems()[count].getBindingContext().getObject().BankAccNu;
				itemsAccType = oTable.getItems()[count].getBindingContext().getObject().AccType;
				itemsCloseDate = oTable.getItems()[count].getBindingContext().getObject().CloseDate;
				if (itemsAccType === "P") {
					itemsAccType = "Pooled";
				} else if (itemsAccType === "D") {
					itemsAccType = "Designated";
				}
				if (itemsBankAcc === BankaccValue1 && currentAccType === itemsAccType) {
					if (itemsCloseDate === null) {
						BankaccValue = "";
						oBankAccNumberModel.setProperty(sPath + "/" + path, null);
						MessageBox.error("Please Select Unique Bank Account Number ");
						source.setValueState("Error");
						return;
					} else {
						oBankAccNumberModel.setProperty(sPath + "/" + path, BankaccValue1);
						source.setValueState("Nones");
					}
				} else {
					BankaccValue = BankaccValue1;
					source.setValueState("None");
				}
			}
			source.setValue(BankaccValue);
			oBankAccNumberModel.setProperty(sPath + "/" + path, BankaccValue);

		},

		// //adding new line item for existing office and matter
		onAddItemPress: function(oEvent) {
			this.isItemCanSave = true;
			this.getView().byId("isSaveMTA").setEnabled(true);
			var oOffice, oMatter, oListItem, oContextBankAccountValueHelp;
			var oTable = oEvent.getSource().getParent().getParent(),
				accType = "",
				bankAccNum = "";
			oOffice = this.oOffice;
			oMatter = this.oMatter;

			this.flagAdd = true;

			var oModel = this.getOwnerComponent().getModel();

			//adding lineitem level BankAccNum filters to the binding context
			oContextBankAccountValueHelp = oModel.createEntry("/ItemAccSet", {
				properties: {
					Office: oOffice,
					Matter: oMatter
				}
			});
			oListItem = new sap.m.ColumnListItem({

				cells: [
					new sap.m.ComboBox({
						items: [new sap.ui.core.Item({
							text: "Pooled",
							key: "P"
						}), new sap.ui.core.Item({
							text: "Designated",
							key: "D"
						})],
						value: "{AccType}",
						width: "55%",
						editable: true,
						change: this.handleChangeAccountType.bind(this)
					}).bindValue({
						path: "AccType",
						formatter: function(value) {
							if (value === "P") {
								value = "Pooled";

							} else if (value === "D") {
								value = "Designated";
							}
							return value;
						}
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{BankAccNu}",
						width: "60%",
						required: true,
						editable: true,
						change: this.handleChangeBankAccNumber
					}),
					new sap.m.DatePicker({
						dateValue: "{OpenDate}",
						width: "60%",
						displayFormat: "short",
						editable: true,
						change: this.handleChangeOpenOrCloseDate
					}),
					new sap.m.DatePicker({
						dateValue: "{CloseDate}",
						width: "60%",
						displayFormat: "short",
						valueFormat: "yyyy.MM.dd",
						minDate: "{OpenDate}",
						editable: true,
						change: this.handleChangeOpenOrCloseDate

					}),
					new sap.m.Button({
						icon: "sap-icon://sys-cancel",
						press: this.handleDelete
					}),
					new sap.m.Button({
						icon: "sap-icon://attachment",
						press: this.onPressHandleAttachments.bind(this)
					})
				]

			});

			// oList = new sap.m.List({
			// 	items: oListItem
			// });
			// this.sPath = "/ItemAccSet(Office='" + this.oOffice + "', Matter='" + this.oMatter + "',AccType='" + oListItem.getCells()[0].getValue() + "',BankAccNu='" +
			// 	oListItem.getCells()[1].getValue() + "')";
			oListItem.setBindingContext(oContextBankAccountValueHelp);
			oTable._oTable.addItem(oListItem);

		},

		//handling new added line item delete
		handleDelete: function(oEvent) {
			var oListItem, oTable;
			oListItem = oEvent.getSource().getParent();
			oTable = oEvent.getSource().getParent().getParent();
			oTable.removeItem(oListItem);
		},

		//refreshing table Items
		onRefresh: function(oEvent) {

			var oTable = oEvent.getSource().getParent().getParent();
			// oTable._oTable.getBinding("items").refresh();
			oTable.rebindTable();

		},

		onAfterRendering: function() {
			var oModel = this.getView().getModel();
			oModel.setUseBatch(false);
			//oModel.setDeferredGroups(["saveall", "changes"]);
		},
		//Posting and Updating the lineitems
		onSavePress: function(oEvent) {
			var bVal = this.handleTableValid(),
				that = this,
				oModel = this.getOwnerComponent().getModel();
			if (!bVal) {
				return;
			}

			//defining table items and length
			var oTable = this.getView().byId("MTASmartTableId"),
				respTable = oTable.getTable();

			//defining table properties to push
			var oOffice, oMatter,
				createPayloadData = {};
			oOffice = this.oOffice;
			oMatter = this.oMatter;

			createPayloadData = {
				Office: oOffice,
				Matter: oMatter,
				ItemAccSet: this.getTableData(respTable)[0]

			};
			var that = this;

			if (this.isItemCanSave === true) {
				oModel.create("/HeaderAccSet", createPayloadData, {
					//	groupId: "saveall",
					success: function(oData, resp) {
						var msg = oData.Return;
						MessageBox.confirm(msg);
						that.getView().byId("isSaveMTA").setEnabled(false);
						oTable._oTable.destroyItems();
						oTable.rebindTable();
					},
					error: function(oErr) {
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							that.applyResp(jQuery.parseJSON(result));
						}
						that.getView().setBusy(false);
					}
				});
			}
		},
		getTableData: function(oTable) {
			var aTableData = [],
				aAttachmentsData = [],
				aPayload = [],
				obj, itemsObj;
			var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
				pattern: "YYYY-MM-dd"
			});
			$.each(oTable.getItems(), function(rindex, row) {
				obj = row.getBindingContext().getObject();
				if (obj.AccType === "Pooled" || obj.AccType === "P") {
					obj.AccType = "P";
				} else if (obj.AccType === "Designated" || obj.AccType === "D") {
					obj.AccType = "D";
				}
				obj.OpenDate = oDateFormat.format(obj.OpenDate);
				obj.OpenDate = obj.OpenDate + "T00:00:00";

				if (obj.CloseDate) {
					obj.CloseDate = oDateFormat.format(obj.CloseDate);
					obj.CloseDate = obj.CloseDate + "T00:00:00";
				} else {
					obj.CloseDate = null;
				}
				itemsObj = {
					AccType: obj.AccType,
					BankAccNu: obj.BankAccNu,
					OpenDate: obj.OpenDate,
					CloseDate: obj.CloseDate
				};
				if (obj.FileUploadSet && obj.FileUploadSet.length > 0) {
					aAttachmentsData.push(obj.FileUploadSet);
				}
				aTableData.push(itemsObj);
			});
			aPayload = [aTableData, aAttachmentsData];
			return aPayload;
		},
		handleTableValid: function() {
			var oTable = this.getView().byId("respTableId"),
				aItems = oTable.getItems(),
				bValidationError = false;

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 0 || index === 1 || index === 2) {
						if (oCell.getValue().length > 0) {
							bValidationError = true;
							oCell.setValueState("None");
						} else {
							oCell.setValueState("Error");
						}
					}
				});
			});

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 0 || index === 1 || index === 2) {
						if (oCell.getValueState() === "Error") {
							bValidationError = false;
						}
					}
				});
			});
			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (oCell.getEnabled() && index !== 4) {
						/*	if (oCell.getValueState() === "Error") {
								bValidationError = false;
							}*/
					}
				});
			});

			return bValidationError;

		},
		onPressHandleAttachments: function(oEvent) {
			this.getView().byId("isSaveMTA").setEnabled(true);
			this.source = oEvent.getSource();

			var oSmtTable = oEvent.getSource().getParent().getParent();
			var objLI = oEvent.getSource().getBindingContext().getObject();
			var oModel = this.getOwnerComponent().getModel();
			var aFilter = [new Filter("Office", "EQ", this.oOffice), new Filter("Matter", "EQ", this.oMatter), new Filter("AccType",
				"EQ", objLI.AccType), new Filter("BankAccNu", "EQ", objLI.BankAccNu)];
			this.filter = aFilter;
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "trustaccmapping.fragments.MTAAttachment", this);
				this.getView().addDependent(this._attchParties);

			}

			//condition for CloseDate Upload
			if (objLI.CloseDate === null || objLI.CloseDate === "" || objLI.CloseDate === undefined) {
				this.getView().byId("idAttachment").setUploadButtonInvisible(false);
			} else {
				this.getView().byId("idAttachment").setUploadButtonInvisible(true);
			}

			var oAttachModel = new sap.ui.model.json.JSONModel();
			var that = this;
			var array = [];
			oSmtTable.setBusy(true);
			// this.getView().setBusy(true);
			oModel.read("/attachmentsSet", {
				filters: aFilter,
				success: function(odata) {
					array = odata.results;
					var odataArray = [];
					for (var i = 0; i < array.length; i++) {
						if (array[i].Del !== "X") {
							odataArray.push(array[i]);
						}

					}
					oSmtTable.setBusy(false);
					oAttachModel.setData(odataArray);
					that.getView().byId("idAttachment").setModel(oAttachModel, "oAttachModel");
					that._attchParties.open();
				},
				error: function(odata) {
					oSmtTable.setBusy(false);
					MessageBox.show("Fail to retrive the attachments");
				}
			});

		},
		onPressAttachmentCancel: function(oEvent) {
			this._attchParties.close();
		},
		onChangeDocuments: function(oEvent) {
			var oParameter = oEvent.getParameter("files"),
				that = this,
				sFileName = oParameter[0].name;

			//To Read filecontent
			var fileData = new Blob([oParameter[0]]);

			var buf = function getBuffer(resolve) {
				var reader = new FileReader();
				reader.readAsBinaryString(fileData);
				reader.onload = function() {
					var arrayBuffer = reader.result;
					resolve(arrayBuffer);
				};
			};
			var promise = new Promise(buf);

			var objectLineItem = this.source.getBindingContext().getObject();
			if (objectLineItem.AccType === "Pooled" || objectLineItem.AccType === "P") {
				objectLineItem.AccType = "P";
			} else if (objectLineItem.AccType === "Designated" || objectLineItem.AccType === "D") {
				objectLineItem.AccType = "D";
			}

			// Wait for promise to be resolved, or log error.
			promise.then(function(data) {
				// Here you can pass the bytes to another function.
				var bData = btoa(data);

				//creating object to store the file Content and pushing every file content to the array
				var fileObj = {
						"Office": that.oOffice,
						// "OfficeDesc": that.sOfficeDesc,
						"Matter": that.oMatter,
						// "MatterTxt": that.sMatterTxt,
						"Del": "",
						"Zfilename": bData,
						"Slug": sFileName,
						"AccType": objectLineItem.AccType,
						"BankAccNu": objectLineItem.BankAccNu

					},

					array = [];
				array.push(fileObj);
				that.attachmentPostCall(fileObj);
			}).catch(function(err) {});

		},
		attachmentPostCall: function(fileObj) {
			var oModel1 = this.getOwnerComponent().getModel(),
				Slug = fileObj.Slug,
				Zfilename = fileObj.Zfilename;

			var bVal = true,
				that = this;
			var oAttachmentModel = this.getView().byId("idAttachment").getModel("oAttachModel");
			this._attchParties.setBusy(true);
			oModel1.create("/attachmentsSet", fileObj, {
				//groupId: "saveall",
				success: function(oData) {
					that._attchParties.setBusy(false);
					if (bVal) {
						MessageBox.show("Data Successfully Updated");
						bVal = false;
					}
					oData.Slug = Slug;
					oData.Zfilename = Zfilename;

					if (oAttachmentModel.getData().length > 0) {
						oAttachmentModel.getData().unshift(oData);
					} else {
						oAttachmentModel.getData().push(oData);
					}
					oAttachmentModel.refresh();

				}

			});
		},
		onFileDeleted: function(oEvent) {
			this.deleteItemById(oEvent.getParameter("documentId"));
			//	this.deleteItemById(oEvent.getParameter("item").getProperty("fileName"));
		},
		deleteItemById: function(sItemToDeleteId) {
			var that = this,
				objectLineItemD = this.source.getBindingContext().getObject(),
				oModel = this.getOwnerComponent().getModel();

			var oData = this.getView().byId("idAttachment").getModel("oAttachModel").getData();
			var deleteItem;
			var aItems = jQuery.extend(true, {}, oData);
			this._attchParties.setBusy(true);
			jQuery.each(aItems, function(index) {
				if (aItems[index].Zfileno === undefined) {
					aItems[index].Zfileno = "";
				}
				if (aItems[index] && aItems[index].Zfileno === sItemToDeleteId) {
					if (objectLineItemD.AccType === "Pooled" || objectLineItemD.AccType === "P") {
						objectLineItemD.AccType = "P";
					} else if (objectLineItemD.AccType === "Designated" || objectLineItemD.AccType === "D") {
						objectLineItemD.AccType = "D";
					}

					deleteItem = {
						"Office": that.oOffice,
						"Matter": that.oMatter,
						"Del": "X",
						"Zfilename": aItems[index].Zfilename,
						"Slug": aItems[index].Slug,
						"AccType": objectLineItemD.AccType,
						"BankAccNu": objectLineItemD.BankAccNu
					};

					oModel.create("/attachmentsSet", deleteItem, {
						success: function(oData, resp) {
							that.getView().byId("idAttachment").getModel("oAttachModel").getData().splice(index, 1);
							that.getView().byId("idAttachment").getModel("oAttachModel").refresh();
							that._attchParties.setBusy(false);
							MessageBox.show("File Deleted Successfully");

						},
						error: function(oErr) {
							that._attchParties.setBusy(false);
							MessageBox.show("Failed to Delete");
							that._attchParties.close();
						}
					});

				}

			});
			this.getView().byId("idAttachment").getModel("oAttachModel").setData(
				oData);

		}

	});
});