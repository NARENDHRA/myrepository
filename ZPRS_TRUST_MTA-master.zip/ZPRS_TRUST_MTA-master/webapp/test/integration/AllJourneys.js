jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"trustaccmapping/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"trustaccmapping/test/integration/pages/Worklist",
		"trustaccmapping/test/integration/pages/Object",
		"trustaccmapping/test/integration/pages/NotFound",
		"trustaccmapping/test/integration/pages/Browser",
		"trustaccmapping/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "trustaccmapping.view."
	});

	sap.ui.require([
		"trustaccmapping/test/integration/WorklistJourney",
		"trustaccmapping/test/integration/ObjectJourney",
		"trustaccmapping/test/integration/NavigationJourney",
		"trustaccmapping/test/integration/NotFoundJourney",
		"trustaccmapping/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});