sap.ui.define(["sap/ovp/cards/generic/Component", "jquery.sap.global"],

	function(CardComponent, jQuery) {
		"use strict";

		return CardComponent.extend("fgt.mmpartner.overview.ext.customcard.Component", {
			// use inline declaration instead of component.json to save 1 round trip
			metadata: {
				properties: {
					"contentFragment": {
						"type": "string",
						"defaultValue": "fgt.mmpartner.overview.ext.customcard.List"
					},
					"controllerName": {
						"type": "string",
						"defaultValue": "fgt.mmpartner.overview.ext.customcard.List"
					},
					"annotationPath": {
						"type": "string",
						"defaultValue": "com.sap.vocabularies.UI.v1.LineItem"
					},
					"headerFragment": {
						"type": "string",
						"defaultValue": "fgt.mmpartner.overview.ext.customcard.CountHeader"
					}
				},

				version: "1.56.5",

				library: "sap.ovp",

				includes: [],

				dependencies: {
					libs: ["sap.suite.ui.microchart"],
					components: []
				},
				config: {}
			}
		});
	}
);

// (function () {
// 	"use strict";

// 	/* component for custom card */

// 	jQuery.sap.declare("fgt.mmpartner.overview.ext.Component");
// 	jQuery.sap.require("sap.ovp.cards.custom.Component");

// 	sap.ovp.cards.custom.Component.extend("fgt.mmpartner.overview.ext.Component", {
// 		// use inline declaration instead of component.json to save 1 round trip
// 		metadata: {
// 			properties: {
// 				"contentFragment": {
// 					"type": "string",
// 					"defaultValue": "sap.ovp.cards.list.List"
// 				},
// 				"headerFragment": {
// 					"type": "string",
// 					"defaultValue": "sap.ovp.cards.generic.KPIHeader"
// 				},
// 				"footerFragment": {
// 					"type": "string",
// 					"defaultValue": ""
// 				}
// 			},

// 			version: "@version@",

// 			library: "sap.ovp",

// 			includes: [],

// 			dependencies: {
// 				libs: ["sap.m"],
// 				components: []
// 			},
// 			config: {},
// 			customizing: {
// 				"sap.ui.controllerExtensions": {
// 					"sap.ovp.cards.generic.Card": {
// 						controllerName: "sap.ovp.cards.list.List"
// 					}
// 				}
// 			}
// 		}
// 	});
// })();