sap.ui.define([
	"trustclientbill/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustclientbill/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast',
	"sap/m/MessageBox",
	"sap/m/Button",
	"sap/m/Dialog"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast, MessageBox, Button, Dialog) {
	"use strict";

	return BaseController.extend("trustclientbill.controller.ClientBill", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this._formFragments = {};
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");
			if (!this.oOutputComp) {
				this.oOutputComp = sap.ui.getCore().createComponent({
					name: "fgt.trustdispdoc.control.comp.outputitems"
				});
			}
			this._showFormFragment("TrustClientBill");
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				FeeAmt: "",
				HardCostAmt: "",
				SoftCostAmt: "",
				ResonPay: "",
				AvailMattBal: "",
				TotMattBal: "",
				InvoiceBal: "",
				FeeBal: "",
				HardCostBal: "",
				SoftCostBal: "",
				editfeeAmt: false,
				editHCAmt: false,
				editSCAmt: false,
				requiredFAmt: true,
				requiredHCAmt: true,
				requiredSFAmt: true,
				ErrorList: [],
				VSoffice: "None",
				VSPostDate: "None",
				VSMatter: "None",
				VSClient: "None",
				VSTbankAcNo: "None",
				VSFeeAmt: "None",
				VSHDAmt: "None",
				VSSftCAmt: "None",
				VSClientInv: "None",
				VSAuthBy: "None",
				VSoBankAc: "None",
				VSResnPay: "None",
				Currency: "",
				documentTitle: ""
			});
			this.setModel(oViewModel, "worklistView");
			this.createSmart();
			this.oOfficeId = "";
			this.oSrcMatter = "";
		},

		createSmart: function(evt) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/ClientBillS", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/OfficeT", "");
				c.setProperty(oContextClients.getPath() + "/MatterTxt", "");
				c.setProperty(oContextClients.getPath() + "/PostDate", "");
				c.setProperty(oContextClients.getPath() + "/Client", "");
				c.setProperty(oContextClients.getPath() + "/Currency", "");
				c.setProperty(oContextClients.getPath() + "/TBankAccNo", "");
				c.setProperty(oContextClients.getPath() + "/Invoice", "");
				c.setProperty(oContextClients.getPath() + "/OBankAccNo", "");
				c.setProperty(oContextClients.getPath() + "/AuthorisedByT", "");
				that.getView().setBindingContext(oContextClients);
			});
		},
		onFeeAmtval: function(evt) {
			var oVal = parseFloat(evt.getSource().getValue());
			var oViewModel = this.getView().getModel("worklistView"),
				oFeeBal = parseFloat(oViewModel.getProperty("/FeeBal")),
				oFeeAmt = oViewModel.getProperty("/FeeAmt"),
				oHardCostAmt = oViewModel.getProperty("/HardCostAmt"),
				oSoftCostAmt = oViewModel.getProperty("/SoftCostAmt");

			if (oVal > oFeeBal) {
				var sTex1 = this.getResourceBundle().getText("LBLFeeAmount"),
					sText2 = this.getResourceBundle().getText("messageTex"),
					sText3 = this.getResourceBundle().getText("LBLOfeeamt"),
					finText = sTex1 + " " + sText2 + " " + sText3;
				MessageBox.warning(finText, {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/FeeAmt", "");
						}
					}
				});
			} else if (oVal < 0) {
				MessageBox.warning("Negative values are not allowed", {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/FeeAmt", "");
						}
					}
				});
			}
			if (oFeeAmt) {
				oViewModel.setProperty("/requiredSFAmt", false);
				oViewModel.setProperty("/requiredHCAmt", false);
			}
			if (oFeeAmt) {
				oViewModel.setProperty("/VSFeeAmt", "None");
				oViewModel.setProperty("/VSHDAmt", "None");
				oViewModel.setProperty("/VSSftCAmt", "None");
			}

		},
		onFHardCostAmtval: function(evt) {
			var oVal = parseFloat(evt.getSource().getValue());
			var oViewModel = this.getView().getModel("worklistView"),
				oHardCostBal = parseFloat(oViewModel.getProperty("/HardCostBal"));
			if (oVal > oHardCostBal) {
				var sTex1 = this.getResourceBundle().getText("LBLHCamount"),
					sText2 = this.getResourceBundle().getText("messageTex"),
					sText3 = this.getResourceBundle().getText("LBLOHdAmt"),
					finText = sTex1 + " " + sText2 + " " + sText3;
				MessageBox.warning(finText, {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/HardCostAmt", "");
						}
					}
				});
			} else if (oVal < 0) {
				MessageBox.warning("Negative values are not allowed", {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/HardCostAmt", "");
						}
					}
				});
			}
			if (oVal) {
				oViewModel.setProperty("/requiredSFAmt", false);
				oViewModel.setProperty("/requiredFAmt", false);
			}
			if (oVal) {
				oViewModel.setProperty("/VSFeeAmt", "None");
				oViewModel.setProperty("/VSHDAmt", "None");
				oViewModel.setProperty("/VSSftCAmt", "None");
			}
		},
		onSoftCostAmtval: function(evt) {
			var oVal = parseFloat(evt.getSource().getValue());
			var oViewModel = this.getView().getModel("worklistView"),
				oSoftCostBal = parseFloat(oViewModel.getProperty("/SoftCostBal"));
			if (oVal > oSoftCostBal) {
				var sTex1 = this.getResourceBundle().getText("LBLSCAmt"),
					sText2 = this.getResourceBundle().getText("messageTex"),
					sText3 = this.getResourceBundle().getText("LBLoSCAmt"),
					finText = sTex1 + " " + sText2 + " " + sText3;
				MessageBox.warning(finText, {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/SoftCostAmt", "");
						}
					}
				});
			} else if (oVal < 0) {
				MessageBox.warning("Negative values are not allowed", {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/SoftCostAmt", "");
						}
					}
				});
			}
			if (oVal) {
				oViewModel.setProperty("/requiredHCAmt", false);
				oViewModel.setProperty("/requiredFAmt", false);
			}
			if (oVal) {
				oViewModel.setProperty("/VSFeeAmt", "None");
				oViewModel.setProperty("/VSHDAmt", "None");
				oViewModel.setProperty("/VSSftCAmt", "None");
			}
		},
		onChangeVSAuthBy: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (value) {
				m.setProperty("/VSAuthBy", "None");
			}
		},
		onChangeBankAcno: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (value) {
				m.setProperty("/VSoBankAc", "None");
			}
		},
		onChangeresPayState: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (value) {
				m.setProperty("/VSResnPay", "None");
			}
		},
		onChangeInvoice: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var ctx = oView.getBindingContext(),
				obj = ctx.getObject(),
				Client = obj.Client,
				Invoice = obj.Invoice,
				Matter = obj.Matter;
			if (Client && Invoice && Matter) {
				var CIPath = "/InvBalS(Client='" + Client + "',Matter='" + Matter + "',Invoice='" + Invoice + "')";
				var that = this;
				oModel.read(CIPath, {
					success: function(oData, oResp) {
						m.setProperty("/InvoiceBal", oData.InvoiceBal);
						m.setProperty("/FeeBal", oData.FeeBal);
						m.setProperty("/HardCostBal", oData.HardCostBal);
						m.setProperty("/SoftCostBal", oData.SoftCostBal);
						var ofeeBalAmt = m.getProperty("/FeeBal"),
							oHdBalAmt = m.getProperty("/HardCostBal"),
							oSFCbalAmt = m.getProperty("/SoftCostBal");

						if (ofeeBalAmt > 0 || oHdBalAmt > 0 || oSFCbalAmt > 0) {
							m.setProperty("/editfeeAmt", true);
							m.setProperty("/editHCAmt", true);
							m.setProperty("/editSCAmt", true);
						}
						if (ofeeBalAmt <= 0) {
							m.setProperty("/editfeeAmt", false);
						}
						if (oHdBalAmt <= 0) {
							m.setProperty("/editHCAmt", false);
						}
						if (oSFCbalAmt <= 0) {
							m.setProperty("/editSCAmt", false);
						}
					},
					error: function(oError) {}
				});
			}
			if (value) {
				m.setProperty("/VSClientInv", "None");
			}
			var odata = this.getView().getBindingContext().getObject();
			var ocurrecny = odata.Currency;
			if (value) {
				m.setProperty("/Currency", ocurrecny);
			}
		},
		onChangeBankAc: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var ctx = oView.getBindingContext(),
				obj = ctx.getObject(),
				oOffice = obj.Office,
				Matter = obj.Matter,
				oAccountNum = obj.TBankAccNo;
			if (oOffice && Matter && oAccountNum) {
				var oPath = "/TrustAccBalanceS(Office='" + oOffice + "',Matter='" + Matter + "',TBankAccNo='" + oAccountNum + "')";
				var that = this;
				oModel.read(oPath, {
					success: function(oData, oResp) {
						m.setProperty("/AvailMattBal", oData.AvlBalnace);
						m.setProperty("/TotMattBal", oData.TotBalnace);
					},
					error: function(oError) {}
				});
			}
			if (value) {
				m.setProperty("/VSTbankAcNo", "None");
			}
		},
		onChangeMatterSourcce: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (this.oSrcMatter) {
				if (this.oSrcMatter !== value) {
					this.oSrcMatter = value;
					this.restMatterbaseData();
				}
			}
			this.oSrcMatter = value;
			if (value) {
				this.getView().getModel("worklistView").setProperty("/VSMatter", "None");
			}
		},
		restMatterbaseData: function(evt) {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();

			var sPath = that.getView().getBindingContext().getPath();
			var sModel = that.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/Matter", that.oSrcMatter);
			sModel.setProperty(sPath + "/Client", "");
			sModel.setProperty(sPath + "/Currency", "");
			sModel.setProperty(sPath + "/TBankAccNo", "");
			sModel.setProperty(sPath + "/Invoice", "");
			sModel.setProperty(sPath + "/AuthorisedBy", "");
			sModel.setProperty(sPath + "/OBankAccNo", "");
			sModel.setProperty(sPath + "/OBankAccDesc", "");
			sModel.setProperty(sPath + "/TBankAccDesc", "");
			oViewModel.setProperty("/ResonPay", "");
			oViewModel.setProperty("/SoftCostBal", "");
			oViewModel.setProperty("/HardCostBal", "");
			oViewModel.setProperty("/FeeBal", "");
			oViewModel.setProperty("/InvoiceBal", "");
			oViewModel.setProperty("/SoftCostAmt", "");
			oViewModel.setProperty("/HardCostAmt", "");
			oViewModel.setProperty("/FeeAmt", "");
			oViewModel.setProperty("/TotMattBal", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/Currency", "");
		},
		changeDateState: function(evt) {
			var src = evt.getSource();
			var oval = src.getValue();
			if (oval) {
				this.getView().getModel("worklistView").setProperty("/VSPostDate", "None");
			}
		},
		onChangeTrustoffice: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (this.oOfficeId) {
				if (this.oOfficeId !== value) {
					this.oOfficeId = value;
					this.restValuesData();
				}
			}
			this.oOfficeId = value;
			if (value) {
				this.getView().getModel("worklistView").setProperty("/VSoffice", "None");
			}
		},
		restValuesData: function() {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");
			// var oModel = this.getOwnerComponent().getModel();
			var sPath = this.getView().getBindingContext().getPath();
			var sModel = this.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/OfficeT", that.oOfficeId);
			sModel.setProperty(sPath + "/MatterTxt", "");
			sModel.setProperty(sPath + "/Client", "");
			sModel.setProperty(sPath + "/Currency", "");
			sModel.setProperty(sPath + "/TBankAccNo", "");
			sModel.setProperty(sPath + "/Invoice", "");
			sModel.setProperty(sPath + "/AuthorisedByT", "");
			sModel.setProperty(sPath + "/OBankAccNo", "");
			sModel.setProperty(sPath + "/ClientT", "");
			sModel.setProperty(sPath + "/TBankAccDesc", "");
			sModel.setProperty(sPath + "/OBankAccDesc", "");
			// input values Property setting null 
			oViewModel.setProperty("/ResonPay", "");
			oViewModel.setProperty("/SoftCostBal", "");
			oViewModel.setProperty("/HardCostBal", "");
			oViewModel.setProperty("/FeeBal", "");
			oViewModel.setProperty("/InvoiceBal", "");
			oViewModel.setProperty("/SoftCostAmt", "");
			oViewModel.setProperty("/HardCostAmt", "");
			oViewModel.setProperty("/FeeAmt", "");
			oViewModel.setProperty("/TotMattBal", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/PostDate", "");
			oViewModel.setProperty("/Currency", "");
		},
		onSaveMatter: function(evt) {
			var oView = this.getView(),
				ctx = oView.getBindingContext(),
				data = ctx.getObject();
			var oViewModel = this.getView().getModel("worklistView"),
				ofeeAmt = oViewModel.getProperty("/FeeAmt"),
				oHardAmt = oViewModel.getProperty("/HardCostAmt"),
				oSoftAmt = oViewModel.getProperty("/SoftCostAmt"),
				oReasonpay = formatter.modeldata(data.ResonPay),
				oTrasDate = oViewModel.getProperty("/PostDate"),
				oOffice = formatter.modeldata(data.Office),
				oMatter = formatter.modeldata(data.Matter),
				oClient = formatter.modeldata(data.Client),
				oTotBalance = oViewModel.getProperty("/TotMattBal"),
				oAvlBalnace = oViewModel.getProperty("/AvailMattBal"),
				oHardCostBal = oViewModel.getProperty("/HardCostBal"),
				oSoftCostBal = oViewModel.getProperty("/SoftCostBal"),
				oInvoiceBal = oViewModel.getProperty("/InvoiceBal"),
				oFeeBal = oViewModel.getProperty("/FeeBal"),
				oCurrency = formatter.modeldata(data.Currency),
				oInvoice = formatter.modeldata(data.Invoice),
				oAuthorisedBy = formatter.modeldata(data.AuthorisedBy),
				oTBankAccNo = formatter.modeldata(data.TBankAccNo),
				oOBankAccNo = formatter.modeldata(data.OBankAccNo);

			if (!oReasonpay || !oTrasDate || !oOffice || !oMatter || !oInvoice || !oAuthorisedBy || !
				oTBankAccNo || !oOBankAccNo) {
				if (!oReasonpay) {
					oViewModel.setProperty("/VSResnPay", "Error");
				}
				if (!oTrasDate) {
					oViewModel.setProperty("/VSPostDate", "Error");
				}
				if (!oOffice) {
					oViewModel.setProperty("/VSoffice", "Error");
				}
				if (!oMatter) {
					oViewModel.setProperty("/VSMatter", "Error");
				}
				if (!oInvoice) {
					oViewModel.setProperty("/VSClientInv", "Error");
				}
				if (!oAuthorisedBy) {
					oViewModel.setProperty("/VSAuthBy", "Error");
				}
				if (!oTBankAccNo) {
					oViewModel.setProperty("/VSTbankAcNo", "Error");
				}
				if (!oOBankAccNo) {
					oViewModel.setProperty("/VSoBankAc", "Error");
				}
				MessageBox.warning("Provide all the mandatory fields");
				return;
			} else {
				if (!ofeeAmt && !oHardAmt && !oSoftAmt) {
					MessageBox.warning("Please Provied any one values for Fee or Hard Cost or Soft Cost Amounts");
					return;
				}
				if (!ofeeAmt) {
					ofeeAmt = "0.00";
				}
				if (!oHardAmt) {
					oHardAmt = "0.00";
				}
				if (!oSoftAmt) {
					oSoftAmt = "0.00";
				}
				var oTotalAmt = parseFloat(ofeeAmt) + parseFloat(oHardAmt) + parseFloat(oSoftAmt);
				if (oTotalAmt > oAvlBalnace || oTotalAmt > oInvoiceBal) {
					MessageBox.warning(
						"Total of Fee, Hard Cost & Soft Cost Amount should not exceed  Available Matter Balance or Outstanding Invoice Amount ");
					return;
				}

				var oObjectParm = {
					Office: oOffice,
					ResonPay: oReasonpay,
					Matter: oMatter,
					Client: oClient,
					TotBalnace: oTotBalance,
					AvlBalnace: oAvlBalnace,
					PostDate: oTrasDate,
					Currency: oCurrency,
					HardCostBal: oHardCostBal,
					SoftCostBal: oSoftCostBal,
					InvoiceBal: oInvoiceBal,
					Invoice: oInvoice,
					FeeBal: oFeeBal,
					HardCostAmt: oHardAmt,
					SoftCostAmt: oSoftAmt,
					FeeAmt: ofeeAmt,
					AuthorisedBy: oAuthorisedBy,
					TBankAccNo: oTBankAccNo,
					OBankAccNo: oOBankAccNo
				};

				this.getView().setBusy(true);
				var that = this;
				var oCreateModel = this.getOwnerComponent().getModel();
				oCreateModel.create("/ClientBillS", oObjectParm, {
					success: function(oData, response) {
						that.getView().setBusy(false);
						var smg = oData.ReturnMsg;
						if (oData.ReturnTyp === "S") {
							that.onMessageSuccessDialog(oData);
							// MessageBox.success(smg, {
							// 	onClose: function(sButton) {
							// 		if (sButton === MessageBox.Action.OK) {

							// 		}
							// 	}
							// });

						} else {
							// MessageBox.show(smg);
						}
					},
					error: function(oErr) {
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							//var respError = that.converttoJson(result);
							that.applyResp(jQuery.parseJSON(result));
						}
						that.getView().setBusy(false);

					}
				});
			}
		},
		onMessageSuccessDialog: function(oResp) {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");
			var dialog = new Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: oResp.ReturnMsg
				}),
				buttons: [
					new Button({
						text: "Display Document",
						press: function() {
							dialog.close();
							this._showFormFragment("MTrustReceiptDisplay");
							oViewModel.setProperty("/documentTitle", "Document " + oResp.DocNo);
							this.oOutputComp.invokeDocDisp(oResp.Gjahr, oResp.Belnr, oResp.Bukrs);
							oViewModel.setProperty("/documentTitle", "Document " + oResp.DocNo);
							this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
						}.bind(this)
					}),
					new Button({
						text: "OK",
						press: function() {
							that.createSmart();
							oViewModel.setProperty("/ResonPay", "");
							oViewModel.setProperty("/SoftCostBal", "");
							oViewModel.setProperty("/HardCostBal", "");
							oViewModel.setProperty("/FeeBal", "");
							oViewModel.setProperty("/InvoiceBal", "");
							oViewModel.setProperty("/SoftCostAmt", "");
							oViewModel.setProperty("/HardCostAmt", "");
							oViewModel.setProperty("/FeeAmt", "");
							oViewModel.setProperty("/TotMattBal", "");
							oViewModel.setProperty("/AvailMattBal", "");
							oViewModel.setProperty("/PostDate", "");
							oViewModel.setProperty("/Currency", "");
							oViewModel.setProperty("/editfeeAmt", false);
							oViewModel.setProperty("/editHCAmt", false);
							oViewModel.setProperty("/editSCAmt", false);
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "trustclientbill.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},
		handleOnNewDoc: function() {
			this._showFormFragment("TrustClientBill");
			this._handleResetValues();
		},

		_handleResetValues: function() {
			var oViewModel = this.getView().getModel("worklistView");
			this.createSmart();
			oViewModel.setProperty("/ResonPay", "");
			oViewModel.setProperty("/SoftCostBal", "");
			oViewModel.setProperty("/HardCostBal", "");
			oViewModel.setProperty("/FeeBal", "");
			oViewModel.setProperty("/InvoiceBal", "");
			oViewModel.setProperty("/SoftCostAmt", "");
			oViewModel.setProperty("/HardCostAmt", "");
			oViewModel.setProperty("/FeeAmt", "");
			oViewModel.setProperty("/TotMattBal", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/PostDate", "");
			oViewModel.setProperty("/Currency", "");
			oViewModel.setProperty("/editfeeAmt", false);
			oViewModel.setProperty("/editHCAmt", false);
			oViewModel.setProperty("/editSCAmt", false);
		},

		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});