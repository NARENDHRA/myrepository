jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"mattertomatter/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"mattertomatter/test/integration/pages/Worklist",
		"mattertomatter/test/integration/pages/Object",
		"mattertomatter/test/integration/pages/NotFound",
		"mattertomatter/test/integration/pages/Browser",
		"mattertomatter/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "mattertomatter.view."
	});

	sap.ui.require([
		"mattertomatter/test/integration/WorklistJourney",
		"mattertomatter/test/integration/ObjectJourney",
		"mattertomatter/test/integration/NavigationJourney",
		"mattertomatter/test/integration/NotFoundJourney",
		"mattertomatter/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});