sap.ui.define([
	"mattertomatter/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"mattertomatter/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast',
	"sap/m/MessageBox",
	"sap/m/Button",
	"sap/m/Dialog"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast, MessageBox, Button, Dialog) {
	"use strict";

	return BaseController.extend("mattertomatter.controller.MatterToMatter", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this._formFragments = {};
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");
				if (!this.oOutputComp) {
					this.oOutputComp = sap.ui.getCore().createComponent({
						name: "fgt.trustdispdoc.control.comp.outputitems"
					});
				}
			this._showFormFragment("MatterToMatter");

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				TransferDate: "",
				Amount: "",
				ReasonForTrns: "",
				AvailMattBal: "",
				TotMattBal: "",
				ErrorList: [],
				ClientNumS: "",
				Currency: "",
				valueState: "None",
				VSoffice: "None",
				VsSrcMatter: "None",
				VSClient: "None",
				VSAmount: "None",
				VSCurrency: "None",
				VSCAvBal: "None",
				VSCTotBal: "None",
				VSCDesMatter: "None",
				VSClientDes: "None",
				VSAuthBy: "None",
				VSTrDate: "None",
				VSResTras: "None",
				VSAccNum: "None",
				documentTitle: "",
				PostDate: "",
				VSPostDate: "None"

			});
			this.setModel(oViewModel, "worklistView");
			this.createSmart();
			this.oOfficeId = "";
			this.srcMatter = "";
		},
		// for mandatory Fileds
		onValidationSate: function(evt) {

		},
		onUpdateDestValue: function(evt) {
			var oChangeValues = evt.getParameter("changes");
			var sPath = this.getView().getBindingContext().sPath;

			this.getView().getBindingContext().getModel().setProperty(sPath + "/DestinMatter", oChangeValues.DestinMatter);
			/* if (oChangeValues.hasOwnProperty("Office")) {
			  this.getView().getModel().setProperty(sPath + "/DestinMatter", oChangeValues.DestinMatter);
			 
			 }*/
			//  return Office;
		},
		changeDateState: function(evt) {
			var src = evt.getSource();
			var oval = src.getValue();
			if (oval) {
				this.getView().getModel("worklistView").setProperty("/VSTrDate", "None");
			}
		},
		onAmountValidate: function(evt) {
			var oViewModel = this.getView().getModel("worklistView"),
				oAvlMBal = Number(oViewModel.getProperty("/AvailMattBal")),
				oValAmt = Number(evt.getSource().getValue());
			if (oValAmt > oAvlMBal) {
				MessageBox.warning("Amount should not exceed Available Matter Balance", {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/Amount", "");
						}
					}
				});
			} else if (oValAmt < 0) {
				MessageBox.warning("Negative values are not allowed", {
					onClose: function(sButton) {
						if (sButton === MessageBox.Action.OK) {
							oViewModel.setProperty("/Amount", "");
						}
					}
				});
			}
			if (oValAmt) {
				oViewModel.setProperty("/VSAmount", "None");
			}

		},

		onResTransChange: function(evt) {
			var val = evt.getParameters().value;
			var oViewModel = this.getView().getModel("worklistView");
			if (val) {
				oViewModel.setProperty("/VSResTras", "None");
			}
		},
		createSmart: function(evt) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/Trustmatters", {});
				var c = oContextClients.getModel();
				c.setDefaultBindingMode("TwoWay");
				c.setProperty(oContextClients.getPath() + "/OfficeDesc", "");
				c.setProperty(oContextClients.getPath() + "/SorcMattDesc", "");
				c.setProperty(oContextClients.getPath() + "/AccNum", "");
				c.setProperty(oContextClients.getPath() + "/DestMattDesc", "");
				c.setProperty(oContextClients.getPath() + "/AuthByDesc", "");
				c.setProperty(oContextClients.getPath() + "/TransferDate", "");
				c.setProperty(oContextClients.getPath() + "/DestClntDesc", "");
				c.setProperty(oContextClients.getPath() + "/ClntNumSDesc", "");
				c.setProperty(oContextClients.getPath() + "/ClientNumS", "");
				c.setProperty(oContextClients.getPath() + "/ClientNumD", "");
				c.setProperty(oContextClients.getPath() + "/SourceMatter", "");
				c.setProperty(oContextClients.getPath() + "/DestinMatter", "");
				that.getView().setBindingContext(oContextClients);
			});
		},
		onChangeTransferDetails: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (this.oOfficeId) {
				if (this.oOfficeId !== value) {
					this.oOfficeId = value;
					this.restValuesData();
				}
			}
			this.oOfficeId = value;
			if (!value) {
				this.getView().getModel("worklistView").setProperty("/VSoffice", "None");
			}
			var sModel = this.getView().getBindingContext().getModel();
			/*	sModel.setProperty(sPath + "/SorcMattDesc", "");
				sModel.setProperty(sPath + "/DestMattDesc", "");
				sModel.setProperty(sPath + "/ClientNumS", "");
				sModel.setProperty(sPath + "/ClientNumD", "");*/
			this._handleAmountInnerControl("idMatter", true);
			this._handleAmountInnerControl("idDestinMatter", true);
			//	this.getView().byId("idMatter").setEnabled(true);
			//	this.getView().byId("idDestinMatter").setEnabled(true);
		},

		_handleAmountInnerControl: function(sId, bVal) {
			var oSmartField = this.getView().byId(sId);
			oSmartField.getInnerControls()[0].setEditable(bVal);
		},
		ChangeTrustMatter: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (this.srcMatter) {
				if (this.srcMatter !== value) {
					this.srcMatter = value;
					this.restsrcMatterData();
				}
			}
			this.srcMatter = value;

			jQuery.sap.delayedCall(500, this, function() {
				var ctx = this.getView().getBindingContext().getObject(),
					osrcMatter = ctx.SourceMatter,
					odestMatter = ctx.DestinMatter;
				var sModel = this.getView().getBindingContext().getModel();
				if (osrcMatter === odestMatter) {
					var omsg = "Source Matter and Destion Matter should not be same";
					MessageBox.warning(omsg, {
						onClose: function(sButton) {
							if (sButton === MessageBox.Action.OK) {
								sModel.setProperty(sPath + "/DestMattDesc", "");
								sModel.setProperty(sPath + "/DestinMatter", "");
								sModel.setProperty(sPath + "/DestClntDesc", "");
							}
						}
					});
				}
			});
			if (!value) {
				this.getView().getModel("worklistView").setProperty("/VsSrcMatter", "None");
			}
		},

		ChangeTrustClient: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			/*if (this.srcMatter) {
				if (this.srcMatter !== value) {
					this.srcMatter = value;
					this.restsrcMatterData();
				}
			}*/

			//var sPath = this.getView().getBindingContext().getPath();
			var sModel = this.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/SorcMattDesc", "");
			sModel.setProperty(sPath + "/SourceMatter", "");

			//	sModel.setProperty(sPath + "/DestMattDesc", "");
			//	sModel.setProperty(sPath + "/ClientNumS", "");
			//	sModel.setProperty(sPath + "/ClientNumD", "");
			//	sModel.setProperty(sPath + "/DestClntDesc", "");
			//	this._handleAmountInnerControl("idMatter", false);
			//	this._handleAmountInnerControl("idDestinMatter", false);

			this.srcMatter = value;
			if (!value) {
				this.getView().getModel("worklistView").setProperty("/VsSrcMatter", "None");
			}
		},
		ChangeDestClient: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var sModel = this.getView().getBindingContext().getModel();
			//	sModel.setProperty(sPath + "/SorcMattDesc", "");
			sModel.setProperty(sPath + "/DestMattDesc", "");
			sModel.setProperty(sPath + "/DestinMatter", "");

			//	this._handleAmountInnerControl("idMatter", false);
			//	this._handleAmountInnerControl("idDestinMatter", false);
			this.srcMatter = value;
			if (!value) {
				this.getView().getModel("worklistView").setProperty("/VsSrcMatter", "None");
			}
			jQuery.sap.delayedCall(500, this, function() {
				var ctx = this.getView().getBindingContext().getObject(),
					osrcClient = ctx.ClientNumS,
					odestClient = ctx.ClientNumD;
				var sModel1 = this.getView().getBindingContext().getModel();
				/*if (osrcClient === odestClient) {
					var omsg = "Source Client and Destion Client should not be same";
					MessageBox.warning(omsg, {
						onClose: function(sButton) {
							if (sButton === MessageBox.Action.OK) {
								sModel1.setProperty(sPath + "/DestMattDesc", "");
								sModel1.setProperty(sPath + "/DestClntDesc", "");
							}
						}
					});
				}*/
			});
		},
		restsrcMatterData: function(evt) {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");

			var sPath = that.getView().getBindingContext().getPath();
			var sModel = that.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/SourceMatter", that.srcMatter);
			sModel.setProperty(sPath + "/AccNum", "");
			sModel.setProperty(sPath + "/Currency", "");
			sModel.setProperty(sPath + "/HbankDesc", "");
			sModel.setProperty(sPath + "/DestMattDesc", "");
			//	sModel.setProperty(sPath + "/DestClntDesc", "");
			oViewModel.setProperty("/Amount", "");
			oViewModel.setProperty("/ReasonForTrns", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/TotMattBal", "");
		},
		onChangeSrcMatter: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (!value) {
				this.getView().getModel("worklistView").setProperty("/VsSrcMatter", "None");
			}

			jQuery.sap.delayedCall(500, this, function() {
				var ctx = this.getView().getBindingContext().getObject(),
					osrcMatter = ctx.SourceMatter,
					odestMatter = ctx.DestinMatter;
				var sModel = this.getView().getBindingContext().getModel();
				if (osrcMatter === odestMatter) {
					var omsg = "Source Matter and Destion Matter should not be same";
					MessageBox.warning(omsg, {
						onClose: function(sButton) {
							if (sButton === MessageBox.Action.OK) {
								sModel.setProperty(sPath + "/DestMattDesc", "");
								sModel.setProperty(sPath + "/DestinMatter", "");
								sModel.setProperty(sPath + "/DestClntDesc", "");
							}
						}
					});
				}
			});
		},
		onChangeAuthBy: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			if (!value) {
				this.getView().getModel("worklistView").setPropert("/VsSrcMatter", "None");
			}
		},
		restValuesData: function() {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");
			// var oModel = this.getOwnerComponent().getModel();
			var sPath = this.getView().getBindingContext().getPath();
			var sModel = this.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/OfficeDesc", that.oOfficeId);
			sModel.setProperty(sPath + "/SorcMattDesc", "");
			sModel.setProperty(sPath + "/SourceMatter", "");
			sModel.setProperty(sPath + "/ClientNumS", "");
			sModel.setProperty(sPath + "/AccNum", "");
			sModel.setProperty(sPath + "/DestinMatter", "");
			sModel.setProperty(sPath + "/DestMattDesc", "");
			sModel.setProperty(sPath + "/AuthByDesc", "");
			// sModel.setProperty(sPath + "/TransferDate", "");
			sModel.setProperty(sPath + "/ClntNumSDesc", "");
			sModel.setProperty(sPath + "/DestClntDesc", "");
			sModel.setProperty(sPath + "/ClientNumD", "");
			sModel.setProperty(sPath + "/HbankDesc", "");
			sModel.setProperty(sPath + "/Currency", "");
			oViewModel.setProperty("/ReasonForTrns", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/TotMattBal", "");
			oViewModel.setProperty("/Amount", "");
			oViewModel.setProperty("/TransferDate", "");
			oViewModel.setProperty("/DestClntDesc", "");
			oViewModel.setProperty("/ClntNumSDesc", "");
		},

		onChangeBankAccount: function(evt) {
			var oView = this.getView();
			var m = oView.getModel("worklistView");
			var oModel = this.getOwnerComponent().getModel();
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var oPath;
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			jQuery.sap.delayedCall(1000, this, function() {
				var ctx = oView.getBindingContext(),
					obj = ctx.getObject(),
					oOffice = obj.Office,
					oSCMatter = obj.SourceMatter,
					oAccountNum = obj.AccNum;

				if (oSCMatter === "" || oSCMatter === undefined) {
					oPath = "/Trustmatterbalances(Office='" + oOffice + "',SourceMatter='',AccNum='" + oAccountNum + "')";
				} else {
					oPath = "/Trustmatterbalances(Office='" + oOffice + "',SourceMatter='" + oSCMatter + "',AccNum='" + oAccountNum + "')";
				}
				if (oOffice && oAccountNum) {
					//	var oPath = "/Trustmatterbalances(Office='" + oOffice + "',SourceMatter='" + oSCMatter + "',AccNum='" + oAccountNum + "')";
					var that = this;
					oModel.read(oPath, {
						success: function(oData, oResp) {
							var oAvlmBal = oData.AvailMattBal;
							m.setProperty("/AvailMattBal", oData.AvailMattBal);
							m.setProperty("/TotMattBal", oData.TotMattBal);
						},
						error: function(oError) {}
					});

				}

			});
			if (!value) {
				this.getView().getModel("worklistView").setPropert("/VSAccNum", "None");
			}
		},
		onSaveMatter: function(evt) {
			var oView = this.getView(),
				smg,
				ctx = oView.getBindingContext(),
				data = ctx.getObject();
			var olocModel = this.getView().getModel("worklistView");
			var oAmt = olocModel.getProperty("/Amount"),
				oResTrans = formatter.validate(data.ReasonForTrns),
				// oTransferDate = formatter.validate(data.TransferDate),
				oTransferDate = olocModel.getProperty("/TransferDate"),
				oOfiice = formatter.validate(data.Office),
				osrcMatter = formatter.validate(data.SourceMatter),
				oClientS = formatter.validate(data.ClientNumS),
				oAccNum = formatter.validate(data.AccNum),
				oAvlMBal = olocModel.getProperty("/AvailMattBal"),
				oTotmBal = olocModel.getProperty("/TotMattBal"),
				oDesMatter = formatter.validate(data.DestinMatter),
				oCurry = formatter.validate(data.Currency),
				oClientNumD = formatter.validate(data.ClientNumD),
				// oDestClntDesc = formatter.validate(data.DestClntDesc),
				oAutzby = formatter.validate(data.AuthBy);

			var oAVlBalAmt = Number(oAvlMBal);

			if (!oTransferDate || !oAmt || !oResTrans || !oOfiice || !oAccNum || !
				oAutzby) {
				if (!oTransferDate) {
					olocModel.setProperty("/VSTrDate", "Error");
				}
				if (!oAmt) {
					olocModel.setProperty("/VSAmount", "Error");
				}
				if (!oResTrans) {
					olocModel.setProperty("/VSResTras", "Error");
				}
				if (!oOfiice) {
					olocModel.setProperty("/VSoffice", "Error");
				}
				// if (!osrcMatter) {
				// 	olocModel.setProperty("/VsSrcMatter", "Error");
				// }

				if (!oAccNum) {
					olocModel.setProperty("/VSAccNum", "Error");
				}
				// if (!oDesMatter) {
				// 	olocModel.setProperty("/VSCDesMatter", "Error");
				// }

				if (!oAutzby) {
					olocModel.setProperty("/VSAuthBy", "Error");
				}
				MessageBox.alert("Provide all the mandatory fields ");
				// olocModel.setProperty("/valueState", "Error");

			} else if (!oClientS || !oClientNumD) {
				if (!oClientS) {
					olocModel.setProperty("/VSClient", "Error");
				}
				if (!oClientNumD) {
					olocModel.setProperty("/VSClientDes", "Error");
				}
				MessageBox.alert("Please fill Source client and destination client");
			} else if (osrcMatter === "" && oDesMatter === "") {
				if (!oClientS) {
					olocModel.setProperty();
				}
				if (!oClientNumD) {
					olocModel.setProperty();
				}
				MessageBox.alert("Please fill any one Source matter or destination matter");
			} else if (oAVlBalAmt <= 0) {
				var msg = " Invalid Source Matter " + (osrcMatter) + " Availablie Balance Amount";
				MessageBox.show(msg);
				return;
			} else {
				var oObjectParm = {
					Office: oOfiice,
					TransferDate: oTransferDate,
					SourceMatter: osrcMatter,
					ClientNumS: oClientS,
					AccNum: oAccNum,
					AvailMattBal: oAvlMBal,
					TotMattBal: oTotmBal,
					DestinMatter: oDesMatter,
					ClientNumD: oClientNumD,
					Amount: oAmt,
					Currency: oCurry,
					AuthBy: oAutzby,
					ReasonForTrns: oResTrans
				};
				var MMModel = this.getOwnerComponent().getModel();
				var that = this;
				that.getView().setBusy(true);
				MMModel.create("/Trustmatters", oObjectParm, {
					success: function(oData, response) {
						if (oData.GeneratedId === "S") {
							that.getView().setBusy(false);
							smg = oData.Return;
							that.onMessageSuccessDialog(oData);
							// MessageBox.confirm(smg);
							// that.createSmart();
							// that.onresetData(that);
						}

					},
					error: function(oErr) {
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							that.applyResp(jQuery.parseJSON(result));
						}
						that.getView().setBusy(false);
					}
				});
			}
		},
		onresetData: function(that) {
			var oViewModel = that.getView().getModel("worklistView");
			oViewModel.setProperty("/Amount", "");
			oViewModel.setProperty("/ReasonForTrns", "");
			oViewModel.setProperty("/TransferDate", "");
			oViewModel.setProperty("/AvailMattBal", "");
			oViewModel.setProperty("/TotMattBal", "");
		},

		onMessageSuccessDialog: function(oResp) {
			var that = this;
			var oViewModel = this.getView().getModel("worklistView");
			var dialog = new Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: oResp.Return
				}),
				buttons: [
					new Button({
						text: "Display Document",
						press: function() {
							dialog.close();
							this._showFormFragment("MTrustReceiptDisplay");
							//oViewModel.setProperty("/documentTitle","Document " + oResp.DocNo);
							this.oOutputComp.invokeDocDisp(oResp.Gjahr, oResp.DocNo, oResp.Bukrs);
							this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
						}.bind(this)
					}),
					new Button({
						text: "OK",
						press: function() {
							that.createSmart();
							that.onresetData(that);
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "mattertomatter.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},
		handleOnNewDoc: function() {
			this._showFormFragment("MatterToMatter");
			// this._handleResetValues();
			this.createSmart();
			this.onresetData(this);
		},

		// _handleResetValues: function() {

		// },
		onAfterRendering: function() {

		},
		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});