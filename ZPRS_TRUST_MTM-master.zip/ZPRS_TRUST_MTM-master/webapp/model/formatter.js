sap.ui.define([
	"sap/ui/unified/Currency"
], function(Currency) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		validate: function(val) {
			if (val) {
				return val;
			} else {
				return "";
			}
		},
		currencyFormatter: function(val, cur) {
			//var oNumberFormat = NumberFormat.getCurrencyInstance();
			//debugger
			var sVal = "";
			if (val !== "") {
				val = parseFloat(val);
				sVal = val;
				if (val && cur) {
					var oCurr = new Currency({
						value: val,
						currency: cur
					});
					sVal = oCurr.getFormattedValue();
				}
			}

			return sVal;
		}

	};

});