sap.ui.define([
	"trustworkbench/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustworkbench/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/core/format/DateFormat"
], function(BaseController, JSONModel, History, formatter, Filter, DateFormat) {
	"use strict";

	return BaseController.extend("trustworkbench.controller.TrustWB", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");
			this._formFragments = {};
			if (!this.oOutputComp) {
				this.oOutputComp = sap.ui.getCore().createComponent({
					name: "fgt.trustdispdoc.control.comp.outputitems"
				});
			}
			this._showFormFragment("TrustWorkbench");
			// Model used to manipulate control states
			var oSmartFilterBar = this.getView().byId("Trustworkbench");
			sap.ui.core.ResizeHandler.register(oSmartFilterBar, function(evt) {
				this.handleSize(evt);
			}.bind(this));
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				ErrorList: []
			});
			this.setModel(oViewModel, "worklistView");
			//this.oCreateModel();
			this.sComapnyCodedesc = "";
			this.sCompCode = "";
			this.trustWorkbench();
		},
		onChangeBukrs: function(evt) {
			var a;
		},

		handleSize: function() {
			var oView = this.getView(),
				oSmartTable = oView.byId("TworkbenchId"),
				oSmartFilterBar = oView.byId("Trustworkbench");

			if (oSmartTable && oSmartFilterBar) {
				if (oSmartFilterBar.getFilterBarExpanded()) {
					oSmartTable.setHeight("81%");
				} else {
					oSmartTable.setHeight("92%");
				}
			}
		},

		onSearchFilter: function(evt) {
			var oSmartFilterbar = this.getView().byId("Trustworkbench");
			oSmartFilterbar.setFilterBarExpanded(false);
		},
		trustWorkbench: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/Trustdocs", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/MatterT", "");
				c.setProperty(oContextClients.getPath() + "/BukrsT", "");
				c.setProperty(oContextClients.getPath() + "/Gjahr", "");
				c.setProperty(oContextClients.getPath() + "/Cpudt", "");
				that.getView().setBindingContext(oContextClients);
			});
		},
		onChangevaluehelp: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			var oModel = this.getView().getBindingContext().getModel();
			if (!value) {
				if (path === "MatterT") {
					//	oModel.setProperty(sPath + "/MatterT", oChangeValues.MatterT);
					oModel.setProperty(sPath + "/Matter", "");
				}
				if (path === "BukrsT") {
					//	oModel.setProperty(sPath + "/BukrsT", oChangeValues.BukrsT);
					oModel.setProperty(sPath + "/Bukrs", "");
				}
			}
			oModel.setProperty(sPath + "/" + path, value);
		},
		onBeforeRebindTable: function(oEvent) {
			var src = oEvent.getSource(),
				contx = src.getBindingContext(),
				obj = contx.getObject();
			var oBindingParams = oEvent.getParameter("bindingParams"),
				oSmartFilterbar = this.getView().byId("Trustworkbench"),
				//Get Document Date
				sDocDateKey = oSmartFilterbar.getControlByKey("Cpudt").getValue(),
				sBukrsKey = oSmartFilterbar.getControlByKey("Bukrs").getValue(),
				sBukrsTKey = oSmartFilterbar.getControlByKey("BukrsT").getValue(),
				sMatterKey = oSmartFilterbar.getControlByKey("Matter").getValue(),
				sMatterTKey = oSmartFilterbar.getControlByKey("MatterT").getValue(),
				sGjahrKey = oSmartFilterbar.getControlByKey("Gjahr").getValue(),
				sOfficeKey = oSmartFilterbar.getControlByKey("Office").getValue();

			//var filters = [];
			// $.each(filters, function(i, f) {
			// 	filters.pop(i);
			// });
			oBindingParams.filters = oBindingParams.filters || [];
			oBindingParams.parameters = oBindingParams.parameters || {};
			// //var aFilter = [];
			if (sMatterTKey) {
				oBindingParams.filters.push(new Filter("Matter", "EQ", sMatterKey));
			}
			if (sBukrsTKey) {
				oBindingParams.filters.push(new Filter("Bukrs", "EQ", sBukrsKey));
			}
			if (sOfficeKey) {
				oBindingParams.filters.push(new Filter("Office", "EQ", sOfficeKey));
			}

		},

		onUpdateValue: function(oEvent) {
			var oChangeValues = oEvent.getParameter("changes");
			var sPath = this.getView().getBindingContext().sPath;
			var oModel = this.getView().getBindingContext().getModel();

			if (oChangeValues.hasOwnProperty("Matter")) {
				//	oModel.setProperty(sPath + "/MatterT", oChangeValues.MatterT);
				oModel.setProperty(sPath + "/Matter", oChangeValues.Matter);
			}
			if (oChangeValues.hasOwnProperty("Bukrs")) {
				//	oModel.setProperty(sPath + "/BukrsT", oChangeValues.BukrsT);
				oModel.setProperty(sPath + "/Bukrs", oChangeValues.Bukrs);
			}
		},

		// Trust Reversel
		oCreateModel: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			//	oModel.metadataLoaded().then(function() {
			var oContextClients = oModel.createEntry("/TrustreversalSet", {});
			var c = oContextClients.getModel();
			c.setProperty(oContextClients.getPath() + "/BukrsT", "");
			c.setProperty(oContextClients.getPath() + "/CompCode", "");
			c.setProperty(oContextClients.getPath() + "/FiscalYear", "");
			c.setProperty(oContextClients.getPath() + "/ReversalDate", "");
			c.setProperty(oContextClients.getPath() + "/SourceMatter", "");
			c.setProperty(oContextClients.getPath() + "/DocNumber", "");
			c.setProperty(oContextClients.getPath() + "/ReversalText", "");

			//that.getView().setBindingContext(oContextClients);
			return oContextClients;
			//	});

		},
		handleChangeFields: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Trust Revarsal Details Context
			var fieldContext = this._reverselDialog.getBindingContext();
			var sPath = fieldContext.getPath();
			var oDocNumberModel = fieldContext.getModel();
			oDocNumberModel.setProperty(sPath + "/" + path, value);

			if (path === "ReversalDate") {
				if (value === "") {
					source.setValueState("Error");
					return;
				}
			}
			source.setValueState("None");

		},
		handleChangeCompanyCode: function(evt) {
			// set Value for Trust Revarsal Details Context
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();

			var CompCode = source.getName();

			// set Value for Trust Revarsal Details Context
			var fieldContext = this._reverselDialog.getBindingContext();
			var sPath = fieldContext.getPath();
			var oDocNumberModel = fieldContext.getModel();
			oDocNumberModel.setProperty(sPath + "/" + path, value);
			oDocNumberModel.setProperty(sPath + "/FiscalYear", "");
			oDocNumberModel.setProperty(sPath + "/SourceMatter", "");
			oDocNumberModel.setProperty(sPath + "/MatterTxt", "");
			oDocNumberModel.setProperty(sPath + "/ReversalDate", "");
			oDocNumberModel.setProperty(sPath + "/DocNumber", "");

		},
		onReverselSave: function() {
			var oView = this._reverselDialog,
				ctx = oView.getBindingContext(),
				obj = ctx.getObject();
			// var oDateFormat = DateFormat.getDateInstance({
			// 	pattern: "YYYY-MM-dd"
			// });
			var CompCodeValue, FiscalYearValue, SourceMatterValue, DocNumberValue, ReversalText, ReversalDate;
			CompCodeValue = obj.CompCode;
			FiscalYearValue = obj.FiscalYear;
			SourceMatterValue = obj.SourceMatter;
			DocNumberValue = obj.DocNumber;
			ReversalText = obj.ReversalText;
			ReversalDate = obj.ReversalDate;

			// if (ReversalDate !== undefined && ReversalDate !== null && ReversalDate !== "") {
			// 	ReversalDate = oDateFormat.format(new Date(ReversalDate));
			// 	ReversalDate = ReversalDate + "T00:00:00";
			// } else {
			// 	ReversalDate = null;
			// }

			var oModel = this.getOwnerComponent().getModel();
			var createPayloadData = {
				"CompCode": CompCodeValue,
				"FiscalYear": FiscalYearValue,
				"SourceMatter": SourceMatterValue,
				"DocNumber": DocNumberValue,
				"ReversalText": ReversalText,
				"ReversalDate": ReversalDate
			};
			if (CompCodeValue === "" || FiscalYearValue === "" || SourceMatterValue === "" || DocNumberValue === "" || ReversalText === "" ||
				ReversalDate === "") {
				sap.m.MessageBox.alert("Provide all the mandatory fields ");

			} else {
				var that = this;
				oModel.create("/TrustreversalSet", createPayloadData, {
					success: function(oData, resp) {
						var sflag = oData.MsgId;
						var msg = oData.Message;
						if (sflag === "S") {
							sap.m.MessageBox.success(msg);
							// that.oCreateModel();
							that.onCancelDialog();
							// that.jsonPropertyNull();
						}
						// else {
						// 	sap.m.MessageToast.show(msg);

						// }
					},
					error: function(oErr) {
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							//var respError = that.converttoJson(result);
							that.applyResp(jQuery.parseJSON(result));
						}
						that.getView().setBusy(false);
					}
				});
			}
		},
		getTable: function() {
			var otbl = this.getView().byId("TworkbenchId");
			return otbl.getTable();
		},
		onReverselTrust: function(evt) {
			var tbl = this.getTable(),
				index = tbl.getSelectedIndices();
			var sPath = this.getView().getBindingContext().getPath();
			var sModel = this.getView().getBindingContext().getModel();

			// // for Reversel tesing i am comment lines 
			// // if (tbl.getSelectedIndices().length === 0) {
			// // 	var wMsg = this.getResourceBundle().getText("warningMsg");
			// // 	sap.m.MessageBox.warning(wMsg);
			// // 	return;
			// // }
			// // var sobj = tbl.getContextByIndex(index).getObject(),
			// // 	oCompanyCode = sobj.Bukrs,
			// // 	oMatter = sobj.Matter,
			// // 	oFiscalYear = sobj.Gjahr,
			// // 	oDocNumber = sobj.Belnr;
			var sobj, oCompanyCode, compCodeDesc, matterDesc, oMatter, oFiscalYear, oDocNumber;
			if (tbl.getSelectedIndices().length === 0) {
				compCodeDesc = "";
				matterDesc = "";
				oCompanyCode = "";
				oMatter = "";
				oFiscalYear = "";
				oDocNumber = "";
			} else if (tbl.getSelectedIndices().length === 1) {
				sobj = tbl.getContextByIndex(index).getObject();
				compCodeDesc = sobj.BukrsT;
				oCompanyCode = sobj.Bukrs;
				oMatter = sobj.Matter;
				matterDesc = sobj.MatterT;
				oFiscalYear = sobj.Gjahr;
				oDocNumber = sobj.Belnr;
			}

			var sFrgmntNameM = "trustworkbench.fragments.Reversel";

			if (!this._reverselDialog) {
				this._reverselDialog = sap.ui.xmlfragment(sFrgmntNameM, this);
				this.getView().addDependent(this._reverselDialog);
			}
			var oContextClients = this.oCreateModel();
			this._reverselDialog.setBindingContext(oContextClients);
			this._reverselDialog.open();
			var sPath = this._reverselDialog.getBindingContext().getPath();
			var sModel = this._reverselDialog.getBindingContext().getModel();
			sModel.setProperty(sPath + "/CompCode", oCompanyCode);
			sModel.setProperty(sPath + "/BukrsT", compCodeDesc);
			sModel.setProperty(sPath + "/FiscalYear", oFiscalYear);
			sModel.setProperty(sPath + "/MatterTxt", matterDesc);
			sModel.setProperty(sPath + "/SourceMatter", oMatter);
			sModel.setProperty(sPath + "/DocNumber", oDocNumber);

		},
		onCancelDialog: function(evt) {
			// var tbl = this.getTable();
			// tbl.clearSelection();
			this.oresetData();
			// tbl.getModel().refresh(true);
			this._reverselDialog.close();
		},
		oresetData: function() {
			var sPath = this.getView().getBindingContext().getPath();
			var sModel = this.getView().getBindingContext().getModel();
			sModel.setProperty(sPath + "/CompCode", "");
			sModel.setProperty(sPath + "/FiscalYear", "");
			sModel.setProperty(sPath + "/SourceMatter", "");
			sModel.setProperty(sPath + "/DocNumber", "");
		},
		// Navigation for the tust aaplication
		TrustReceiptNav: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "receipt"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		MTMAppNav: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "matter"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		onATCBAppNav: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "display"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		ontrsuAccountNav: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "account"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		ontrustPaymentNav: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "payment"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		onBTBNavApp: function(evt) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZPRSTRU",
					action: "transfer"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Belnr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
		onDocumentPress: function(evt) {
			// var oViewModel = this.getView().getModel();
			var src = evt.getSource(),
				obj = src.getBindingContext().getObject();
			this._showFormFragment("MTrustReceiptDisplay");
			// oViewModel.setProperty("/documentTitle", "Document " + oResp.DocNo);
			this.oOutputComp.invokeDocDisp(obj.Gjahr, obj.Belnr, obj.Bukrs);
			// oViewModel.setProperty("/documentTitle", "Document " + oResp.DocNo);
			this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
		},
		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},
		handleOnNewDoc: function() {
			this._showFormFragment("TrustWorkbench");
		},
		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "trustworkbench.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},
		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});