/*global location*/
sap.ui.define([
	"vendoroverviewlsm/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"vendoroverviewlsm/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("vendoroverviewlsm.controller.MatterDetails", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			this.getView().setBusy(true);
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				});

			this.getRouter().getRoute("master").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			this.oModel = this.getOwnerComponent().getModel("MatterDetailssrv");
			this.getView().setModel(this.oModel);
			this.getView().setBusy(false);

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("VendorOverview", {}, true);
			}
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			// this.getView().setBusy(true);
			var oAllMatter = new JSONModel();
			var sObjectId = oEvent.getParameter("arguments").Vendor,
				sPtAreat = oEvent.getParameter("arguments").PArea,
				sLegal = oEvent.getParameter("arguments").Legalval;

			var oModel = this.getOwnerComponent().getModel("MatterDetailssrv");
			var oPath = "/VendorGroupSet" + "(" + "Vendor=" + "'" + sObjectId + "'" + "," + "Practicearea=" + "'" + sPtAreat + "'" + "," +
				"Legalentity=" +
				"'" + sLegal + "'" +
				")" +
				"/VendorGroupToVendorMatters";
			var that = this;
			oModel.read(oPath, {
				success: function(odata) {
					oAllMatter.setData(odata);
					that.getView().setModel(oAllMatter, "oAllMatter");
					that.getView().setBusy(false);
				},
				error: function(odata) {}
			});
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("VendorHeaderSet", {
					Vendor: sObjectId,
					Practicearea: sPtAreat,
					Legalentity: sLegal
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
			// jQuery.sap.delayedCall(50, this, function() {
			// this.getView().setBusy(false);
			// });
			this.getView().byId("ObjectPageLayout").setSelectedSection("__section1");
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// this.getView().setBusy(false);
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

		},
		onNavSection: function(evt) {
			var oevt = evt.getSource();
			var sct = evt.getParameters().section.getProperty("title");
			var oTable = this.getView().byId("idTable");
			if (sct === "At Risk Matters") {
				var aFilters = [new sap.ui.model.Filter("Atrisk", "EQ", "X")];
				oTable.getBinding("items").filter(aFilters);
			}
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.Zzseqnr,
				sObjectName = oObject.Zterm;

			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		}

	});

});