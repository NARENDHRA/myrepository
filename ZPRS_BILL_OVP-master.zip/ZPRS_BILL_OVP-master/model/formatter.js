sap.ui.define(["sap/ui/unified/Currency"], function(Currency) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		checkForFbill: function(val1) {
			if (val1 === "04" || val1 === "10" || val1 === "06") {
				return true;
			}
			return false;
		},
		columnHideShow: function(val1) {
			if (val1 === "01" || val1 === "06") {
				return true;
			}
			return false;
		},
		checkoutbyHide: function(val1) {
			if (val1 === "03") {
				return false;
			}
			return true;
		},
	
		currencyFormatter: function(val, cur) {
			//var oNumberFormat = NumberFormat.getCurrencyInstance();
			//debugger
			var sVal = "";
			if (val !== "") {
				val = parseFloat(parseFloat(val).toFixed(2));
				sVal = val;
			//	if (val && cur) {
					var oCurr = new Currency({
						value: val,
						currency: cur
					});
					sVal = oCurr.getFormattedValue();
			//	}
			}

			return sVal;
		},
		leadingZeroRemoveing: function(iValue) {
			if (iValue !== null) {
				iValue = iValue.replace(/^0+/, '');
				return iValue;
			}
		},

		CheckingAllZero: function(iValue) {
			if (iValue === "00000000") {

				return "";
			}
		}

	};

});