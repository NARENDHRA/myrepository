sap.ui.define([
	"billingoverview/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"billingoverview/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/BusyDialog",
	"sap/m/MessageBox",
	'sap/m/MessagePopover',
	'sap/m/MessageItem'
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, BusyDialog, MessageBox, MessagePopover, MessageItem) {
	"use strict";
	return BaseController.extend("billingoverview.controller.BillingOverview", {

		formatter: formatter,

		onInit: function() {
			window.that = this;
			var oViewModel;
			this.busyDialog = new BusyDialog();
			this.sStatus = "";
			this.sSelKey = "";
			this._oTableSearchState = [];
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				iCountSum: 0,
				i01Count: 0,
				i02Count: 0,
				i03Count: 0,
				i04Count: 0,
				i05Count: 0,
				cFilter: "01",
				draftBill: "",
				NewComments: "",
				messages: []
			});
			this.getView().setModel(oViewModel, "worklistView");
			//oMessagePopover.setModel(oViewModel);

			jQuery.sap.delayedCall(5000, this, function() {
				this.sSelKey = this.getView().byId("selId").getSelectedKey();
				this.getView().byId("billingOverViewSTable").rebindTable();
				this.readData(this.sSelKey);
			}.bind(this));
		},

		onAfterRendering: function() {
			var oModel = this.getModel();
			var aDeferredGroups = oModel.getDeferredGroups();
			aDeferredGroups = aDeferredGroups.concat(["changes"]);
			oModel.setDeferredGroups(aDeferredGroups);
		},

		onBeforeRebindTable: function(oEvent) {
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("Action", sap.ui.model.FilterOperator.EQ, this.sStatus || "01"));
			aFilter.push(new sap.ui.model.Filter("Zzbillteamk", sap.ui.model.FilterOperator.EQ, this.sSelKey));
			mBindingParams.filters = aFilter;
		},
		formatCheckIn: function(sValue) {
			var tileStatus = ["01", "05", "07"];
			if (tileStatus.indexOf(sValue) >= 0) {
				return true;
			}
			return false;
		},
		formatCheckOut: function(sValue) {
			var tileStatus = ["06"];
			if (tileStatus.indexOf(sValue) >= 0) {
				return true;
			}
			return false;
		},
		formatPrintFinalBill: function(sValue) {
			var tileStatus = ["04", "10"];
			//var tileStatus = [ "10"];
			if (tileStatus.indexOf(sValue) >= 0) {
				return true;
			}
			return false;
		},

		formatPrintDraftBill: function(sValue) {
			var tileStatus1 = ["01", "02", "03", "06", "07", "08", "10", "04"];

			if (tileStatus1.indexOf(sValue) >= 0) {
				return true;
			}
			return false;
		},
		formatCreateDraftBill: function(sValue) {
			var tileStatus = ["11"],
				flagStatus = false;
			var filtered = tileStatus.filter(function(str) {
				if (str.indexOf(sValue) !== -1) {
					flagStatus = true;
				}
			});
			if (flagStatus === true) {
				return true;
			} else {
				return false;
			}
		},
		readData: function() {
			//var batchChanges = [];
			this.busyDialog.open();
			var oModel = this.getOwnerComponent().getModel(),
				oViewModel = this.getView().getModel("worklistView");
			oViewModel.setProperty("/iCountSum", 0);
			//	aFilter.push(new sap.ui.model.Filter("Zzbillteamk", sap.ui.model.FilterOperator.EQ, this.sSelKey));
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "01"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "02"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "03"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});

			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "04"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "05"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});

			//new status
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "06"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "07"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "08"), new Filter("Zzbillteamk", "EQ", this.sSelKey)],
				groupId: "tilesCount"
			});

			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "09")],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "10")],
				groupId: "tilesCount"
			});
			oModel.read("/OverviewSet/$count", {
				filters: [new Filter("Action", "EQ", "11")],
				groupId: "tilesCount"
			});

			oModel.setDeferredGroups(["tilesCount"]);
			oModel.submitChanges({
				groupId: "tilesCount",
				success: function(odata) {
					var oStatus = {
						//PROG
						"0": {
							"count": "/i01Count"
						},
						"1": {
							"count": "/i02Count"
						},
						"2": {
							"count": "/i03Count"
						},
						"3": {
							"count": "/i04Count"
						},
						"4": {
							"count": "/i05Count"
						},
						"5": {
							"count": "/i06Count"
						},
						"6": {
							"count": "/i07Count"
						},
						"7": {
							"count": "/i08Count"
						},
						"8": {
							"count": "/i09Count"
						},
						"9": {
							"count": "/i10Count"
						},
						"10": {
							"count": "/i11Count"
						},
						"11": {
							"count": "/i12Count"
						}

					};

					if (odata.hasOwnProperty("__batchResponses")) {
						var aResponses = odata.__batchResponses;
						jQuery.each(aResponses, function(index, oResponse) {
							var iCount = parseInt(oResponse.data, 10);
							oViewModel.setProperty(oStatus[index].count, iCount);
							var iCountSum = oViewModel.getProperty("/iCountSum");
							iCountSum += iCount;
							oViewModel.setProperty("/iCountSum", iCountSum);

						});
					}
					this.busyDialog.close();
				}.bind(this)
			});
		},
		getTable: function() {
			var oTable = this.getView().byId("billingOverViewSTable");
			return oTable.getTable();
		},
		_handleTileSelection: function() {
			var aGridContent = this.getView().byId("gridID").getContent();
			jQuery.each(aGridContent, function(index, oContent) {
				if (oContent.hasStyleClass("highlight")) {
					oContent.removeStyleClass("highlight");
				}
			});
		},
		handleOnPressTile: function(oEvent) {
			//this.readData();
			// new status
			//this._handleTileSelection();
			this._clearSelection();
			var segment = oEvent.getParameter("segment");
			// var	selectedSegments = oEvent.getParameter("selectedSegments");

			// $.each(selectedSegments, function(i, seg) {
			// 	if (seg.getId() !== segment.getId()) {
			// 		seg.setSelected(false);
			// 	}
			// });
			segment.setSelected(true);
			var oSrc = oEvent.getSource(),
				aFilter = [],
				path = "Action";
			//	sStatus = oSrc.data("tileStatus");
			// new status
			//this.sStatus = oSrc.data("tileStatus");
			this.sStatus = segment.data("tileStatus");
			this.getView().getModel("worklistView").setProperty("/cFilter", this.sStatus);
			oSrc.addStyleClass("highlight");
			var oTab = this.getTable(),
				cntx = oTab.getBinding("rows");
			aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, this.sStatus));
			aFilter.push(new sap.ui.model.Filter("Zzbillteamk", sap.ui.model.FilterOperator.EQ, this.sSelKey));
			cntx.filter(aFilter, "Application");
		},
		_clearSelection: function() {
			var oMyDraftBill = this.getView().byId("myDraftBillId");
			var oMyTeamDF = this.getView().byId("myTeamDraftBillId");
			$.each(oMyDraftBill.getSelectedSegments(), function(i, seg) {
				seg.setSelected(false);
			});
			$.each(oMyTeamDF.getSelectedSegments(), function(i, seg) {
				seg.setSelected(false);
			});
		},
		_showObject: function(oItem) {
			var bc = oItem.getSource().getBindingContext();
			this.getRouter().navTo("object", {
				objectId: oItem.getSource().getText(),
				Dbill: bc.getProperty("Dbill")
			});
		},

		onPressDraftBillLink: function(Event) {
			var viewModel = this.getView().getModel("worklistView"),
				oselRow = Event.getSource().getBindingContext().getObject();

			if (!this._draftBillPopOver) {
				this._draftBillPopOver = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.DraftBillPopOver", this);
			}
			viewModel.setProperty("/oselRow", oselRow);
			this._draftBillPopOver.openBy(Event.getSource());
		},
		onPressMatterLink: function(Event) {
			var viewModel = this.getView().getModel("worklistView"),
				oselRow = Event.getSource().getBindingContext().getObject();
			if (!this._MatterLinkPopOver) {
				this._MatterLinkPopOver = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.MatterPopOver", this);
			}
			viewModel.setProperty("/oselRow", oselRow);
			this._MatterLinkPopOver.openBy(Event.getSource());
		},
		onExit: function() {
			if (this._draftBillPopOver) {
				this._draftBillPopOver.destroy();
			}
			if (this._MatterLinkPopOver) {
				this._MatterLinkPopOver.destroy();
			}
		},
		onPressNavigation: function(oEvent) {
			var oSource = oEvent.getSource(),
				oHref, sObject, action,
				slinkStatus = oSource.data("linkStatus"),
				viewModel = this.getView().getModel("worklistView"),
				oselRow = viewModel.getProperty("/oselRow");

			if (slinkStatus === "WipReport") {
				oHref = "/sap/bc/ui5_ui5/sap/ZPRS_WIP_Rpt/index.html#/main/" + oselRow.Pspid;
				oHref = this.getDomain() + oHref;
				sap.m.URLHelper.redirect(oHref, true);
			}
			if (slinkStatus === "WipEditor") {
				oHref = "/sap/bc/ui5_ui5/sap/ZPRS_WIPEDIT/index.html#/main/" + oselRow.Pspid;
				oHref = this.getDomain() + oHref;
				sap.m.URLHelper.redirect(oHref, true);
			}
			if (slinkStatus === "FirmMatter") {
				sObject = "ZPRS_MATTERS";
				action = "display" + "&/MatterSet('" + oselRow.Pspid + "')";
				this._CrossApplicationNavigation(sObject, action);
			}
			if (slinkStatus === "FirmClient") {
				sObject = "ZPRS_CLIENTS";
				action = "display" + "&/MYCLIENTSSet('" + oselRow.Client + "')";
				this._CrossApplicationNavigation(sObject, action);
			}
			if (slinkStatus === "WorkItem") {
				sObject = "ZPRS_MY_WKLIST";
				action = "display" + "&/MyWorkList/" + oselRow.Client + "/" + oselRow.Dbill;
				this._CrossApplicationNavigation(sObject, action);
			}
			if (slinkStatus === "dbEditor") {
				oHref = "/sap/bc/ui5_ui5/sap/zprs_bedit/index.html#/main/" + oselRow.Dbill;
				oHref = this.getDomain() + oHref;
				sap.m.URLHelper.redirect(oHref, true);
			}
			//ZPRS_BM_WRKLIST
			if (slinkStatus === "worklist") {
				sObject = "zprs_db_wrklist";
				action = "display&" + "/" + oselRow.Dbill;
				this._CrossApplicationNavigation(sObject, action);
			}
			if (slinkStatus === "wfAudit") {
				sObject = "ZPRS_WF_DA";
				action = "display&" + "/" + oselRow.Dbill;
				this._CrossApplicationNavigation(sObject, action);
			}

		},

		getDomain: function() {
			var org = window.location.origin;
			if (org.search("fgtappg4b") > 0) {
				return "http://fgtappg4b.fulcrum-gt.com:8000";
			}
			if (org.search("fgtappg4a") > 0) {
				return "http://fgtappg4a.fulcrum-gt.com:8000";
			}
			if (org.search("bbfgtappds1") > 0) {
				return "http://bbfgtappds1.bbfulcrumgt.com:8000";
			}
			if (org.search("bmeurx2893ac") > 0) {
				return "https://bmeurx2893ac.bakernet.com/";
			}

			return org;
			//	return "http://fgtappg4b.fulcrum-gt.com:8000";

		},
		_CrossApplicationNavigation: function(sObject, action) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sObject,
					action: action
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onSort: function() {
			var sStatus = this.sStatus,
				_mFilters = [];
			jQuery.sap.delayedCall(500, this, function() {
				var oTableBinding = this.getView().byId('billingOverViewSTable').getTable().getBinding("rows");
				_mFilters.push(new sap.ui.model.Filter("Action", sap.ui.model.FilterOperator.EQ, sStatus));
				oTableBinding.filter(_mFilters, "Application");
			});

		},
		_getSelectedBills: function(billType) {
			var tbl = this.getView().byId("billingOverViewSTable").getTable(),
				bills = [];
			var Zzbillmthd;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var selContext = tbl.getContextByIndex(o),
					obj = selContext.getObject();
				bills.push(obj[billType]);
			});
			return bills;
		},
		_getSelectedBillsAsFilter: function(billType) {
			var tbl = this.getView().byId("billingOverViewSTable").getTable(),
				bills = [];
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var selContext = tbl.getContextByIndex(o),
					obj = selContext.getObject();

				bills.push(new sap.ui.model.Filter("DraftBill", sap.ui.model.FilterOperator.EQ, obj[billType]));
			});
			return bills;
		},
		// multiple Draft bill with Diffrent biiling Method 06_feb_2019
		_DraftbiillingMethodcheck: function() {

			var tbl = this.getView().byId("billingOverViewSTable").getTable();
			this.Zzbillmthd = "";
			var bFlag = false;
			var that = this;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var selContext = tbl.getContextByIndex(o),
					obj = selContext.getObject();
				if (i === 0) {
					that.Zzbillmthd = obj.Zzbillmthd;
				}
				if (that.Zzbillmthd !== obj.Zzbillmthd) {
					bFlag = true;
				}
			});

			return bFlag;
		},
		onPressPrintBills: function(evt) {
			//	var bType = evt.getSource().data("ptype");
			var oView = this.getView().byId("menubtnPrintDBill");
			var otab = this.getView().byId("billingOverViewSTable"),
				tbl = otab.getTable(),
				that = this;
			var filterStr;
			var filterStr1 = [];

			//this.Kappl, this.Pspid, this.Dbill;
			if (this._getSelectedBills("Dbill").length > 0) {
				$.each(tbl.getSelectedIndices(), function(i, index) {
					var context1 = tbl.getContextByIndex(index).getObject();
					var fKappl = new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, "V1"),
						fPspid = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, context1.Pspid),
						fVbeln = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, context1.Dbill);

					var obj = {
						"Kappl": fKappl,
						"Pspid": fPspid,
						"Vbeln": fVbeln

					};
					filterStr1.push(obj);
					filterStr = [new sap.ui.model.Filter(
						[
							new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, "V1"),
							new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, context1.Pspid),
							new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, context1.Dbill)
						],
						true)];

				});
				this.draftbill = filterStr1;
				var oModel = this.getView().getModel("billedit");
				this.busyDialog.open();
				oModel.read("/DbOutputTypeSet", {
					filters: filterStr,
					success: function(oData) {
						that.busyDialog.close();
						if (oData.results.length > 1) {
							oView.setEnabled(true);
							that._handelPrentDraftBill(oData.results);
						} else {
							//sap.m.MessageBox.error("Failed to Schedule Background job for mass bill print");
						}
					},
					error: function(oError) {
						that.busyDialog.close();
						//sap.m.MessageBox.error(oError.message + ", Failed to Schedule Background job for mass bill print");
					}
				});
			} else {
				oView.setEnabled(false);
				sap.m.MessageBox.error("Select atleast one draft/final bill to print");
			}

		},
		_handelPrentDraftBill: function(data) {
			/*	if (!this._viewPrentDraftBillFragment) {
					this._viewPrentDraftBillFragment = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.PrentDraftBill", this);
				}*/
			//this._viewCommentPopOver.setModel(oJsonModel, "oJsonModel");

			var JsonModel = new JSONModel();
			JsonModel.setData(data);
			this.getView().setModel(JsonModel, "printDraftBillModel");
			//this._viewPrentDraftBillFragment.open();
		},

		onPressPrintFinalBills: function(evt) {
			//	var bType = evt.getSource().data("ptype");
			var oView = this.getView().byId("menubtnPrintFBill");
			var otab = this.getView().byId("billingOverViewSTable"),
				tbl = otab.getTable(),
				that = this;
			var filterStr;
			if (this._getSelectedBills("Dbill").length > 0) {
				$.each(tbl.getSelectedIndices(), function(i, index) {
					var context1 = tbl.getContextByIndex(index).getObject();
					filterStr = [new sap.ui.model.Filter(
						[
							new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, "V3"),
							new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, context1.Pspid),
							new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, context1.Dbill)
						],
						true)];
				});
				this.finalBill = filterStr;
				var oModel = this.getView().getModel("billedit");
				this.busyDialog.open();
				oModel.read("/FbOutputTypeSet", {
					filters: filterStr,
					success: function(oData) {
						that.busyDialog.close();
						if (oData.results.length > 1) {
							oView.setEnabled(true);
							that._handelPrentFinalBill(oData.results);
						} else {
							//sap.m.MessageBox.error("Failed to Schedule Background job for mass bill print");
						}
					},
					error: function(oError) {
						oView.setEnabled(false);
						that.busyDialog.close();
						//sap.m.MessageBox.error(oError.message + ", Failed to Schedule Background job for mass bill print");
					}
				});
			} else {
				sap.m.MessageBox.error("Select atleast one draft/final bill to print");
			}
		},

		/*_getSelectedBills: function(billType) {
			var tbl = this.getView().byId("billingOverViewSTable").getTable(),
				bills = [];
			var Zzbillmthd;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var selContext = tbl.getContextByIndex(o),
					obj = selContext.getObject();
				bills.push(obj[billType]);
			});
			return bills;
		},*/
		_handelPrentFinalBill: function(data) {
			var JsonModel = new JSONModel();
			JsonModel.setData(data);
			this.getView().setModel(JsonModel, "printFinalBillModel");

		},
		onPressAddComment: function(Event) {
			var oView = this.getView();
			if (!this._addCommentPopOver) {
				this._addCommentPopOver = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.AddComments", this);
				oView.addDependent(this._addCommentPopOver);

			}
			this._addCommentPopOver.setBindingContext(Event.getSource().getBindingContext());
			this._addCommentPopOver.openBy(Event.getSource());

		},
		onPressViewComment: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel(),
				s = oEvent.getSource(),
				that = this,
				oJsonModel = new sap.ui.model.json.JSONModel(),
				ctx = s.getBindingContext().getObject();
			var
				path = "/WFComment";
			//	Area = "W1";
			var aFilter = [];
			//	var filter = new sap.ui.model.Filter("Area", sap.ui.model.FilterOperator.EQ, Area);
			//	aFilter.push(filter);
			var filter1 = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, ctx.Dbill);
			aFilter.push(filter1);
			this.busyDialog.open();
			oModel.read(path, {
				filters: aFilter,
				success: function(oData) {
					this.busyDialog.close();
					oJsonModel.setData(oData.results);
					//that.getView().setModel(oJsonModel, "oJsonModel");
					this._viewCommentFragment(s, oData.results);
				}.bind(this),
				error: function(oResponse) {
					this.busyDialog.close();
				}.bind(this)
			});

		},
		_viewCommentFragment: function(source, data) {
			if (!this._viewCommentPopOver) {
				this._viewCommentPopOver = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.ViewComments", this);
			}
			//this._viewCommentPopOver.setModel(oJsonModel, "oJsonModel");

			var JsonModel = new JSONModel();
			JsonModel.setData(data);
			this._viewCommentPopOver.setModel(JsonModel);
			this._viewCommentPopOver.openBy(source);
		},
		handleCommentCancel: function(oEvt) {
			this._viewCommentPopOver.close();
		},

		onPost: function(oEvent) {
			var s = oEvent.getSource(),
				action = s.data("Action");
			var oSmtTable = this.getView().byId("billingOverViewSTable"),
				tbl = oSmtTable.getTable();
			var index = tbl.getSelectedIndices(),
				batchChanges = [];
			var oMessageTemplate = new MessageItem({
				type: "{=${Iserror} === 'S' ? 'Success' : 'Error'}",
				title: '{Message}',
				subtitle: '{subtitle}'
			});
			var oMessagePopover = new MessagePopover({
				items: {
					path: '/',
					template: oMessageTemplate
				}
			});
			if (!index.length) {
				this.handleAlertMessageBox(action);
				return;
			}

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DBILL_OVERVIEW_SRV/");
			$.each(tbl.getSelectedIndices(), function(a, b) {
				var obj = tbl.getContextByIndex(b).getObject();
				var pobj = {
					Dbill: obj.Dbill,
					Wfaction: action,
					Comments: obj.Comments
				};
				batchChanges.push(oModel.createBatchOperation("/OverviewSet", "POST", pobj));
			});
			oModel.attachRequestSent(this.onRequestSent);
			oModel.addBatchChangeOperations(batchChanges);
			oModel.setUseBatch(true);
			oModel.submitBatch(function(oResp) {
				tbl.getBinding("rows").refresh();
				tbl.setSelectedIndex();
				this.readData();
				this._handleMessages(oResp);
				//sap.m.MessageBox.success("Saved Successfully ");
				var aResponse = [];
				$.each(oResp.__batchResponses, function(ib, bResp) {
					$.each(bResp.__changeResponses, function(ia, obResp) {
						aResponse.push(obResp.data);
					});
				});
				var oModelLog = new JSONModel();
				oModelLog.setData(aResponse);
				oMessagePopover.setModel(oModelLog);
				oMessagePopover.toggle(s);
				//tbl.getModel().refresh();
			}.bind(this), function() {
				sap.m.MessageBox.error("Not Saved");
			});
		},
		_handleMessages: function(oResp) {
			var aResp = oResp.__batchResponses[0].__changeResponses,
				aMessage = [],
				oModel = this.getModel("worklistView");
			oModel.setProperty("/messagesLength", aResp.length);
			$.each(aResp, function(i, oContent) {
				var sType = oContent.data.Iserror === "S" ? "Success" : "Error";
				var sMessage = oContent.data.Iserror === "S" ? "Success message" : "Error message";
				var obj = {
					title: sMessage,
					subtitle: oContent.data.Dbill,
					type: sType,
					description: oContent.data.Dbill + " - " + oContent.data.Message
				};
				aMessage.push(obj);
			});
			oModel.setProperty("/messages", aMessage);
		},

		handleAlertMessageBox: function(sAction) {
			var sVal = sAction === "CIN" ? "Check In" : "Check Out";
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.alert(
				"Please Select at least one row from table to " + sVal, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},

		onPressCreateDraftBill: function(oEvent) {
			var oSmtTable = this.getView().byId("billingOverViewSTable"),
				tbl = oSmtTable.getTable();
			var batchChanges = [];
			var fnSuccess = function(oResp) {

			};
			var fnError = function(oResp) {

			};
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DBILL_OVERVIEW_SRV/");
			$.each(tbl.getSelectedIndices(), function(i, oselRow) {
				var obj = tbl.getContextByIndex(i).getObject();
				oModel.callFunction("/CreateDraft", {
					method: "GET",
					urlParameters: {
						ACTION: 'DRAFT',
						PSPID: obj.Pspid,
						Submit: '',
						budat_from: '20140101',
						budat_to: '20180619'
					},
					success: fnSuccess,
					error: fnError
				});
			});
			/*$.each(tbl.getSelectedIndices(), function(i, oselRow) {
				var obj = tbl.getContextByIndex(i).getObject();
				var pUrl = "CreateDraft?ACTION='DRAFT'&PSPID='<pspid>'&Submit=''&budat_from='20140101'&budat_to='<currdate>'";
				pUrl = pUrl.replace("<pspid>", obj.Pspid);
				pUrl = pUrl.replace("<currdate>", "20180619");
				batchChanges.push(oModel.createBatchOperation(pUrl, "GET"));
			});
			oModel.attachRequestSent(this.onRequestSent);
			oModel.addBatchChangeOperations(batchChanges);
			oModel.setUseBatch(true);
			oModel.submitBatch(function(oResp) {
				// tbl.getBinding("rows").refresh();
				// tbl.setSelectedIndex();
				// this.readData();
				// this._handleMessages(oResp);
				// sap.m.MessageBox.success("Saved Successfully ");
				//tbl.getModel().refresh();
			}.bind(this), function() {
				sap.m.MessageBox.error("Not Saved");
			});*/
		},

		handleMessagePopoverPress: function(oEvent) {
			//	this.getModel("worklistView").setProperty("/ErrorList", respError.error.innererror.errordetails);
			// if (!this.messageList) {
			// 	this.messageList = sap.ui.xmlfragment(this.getView().getId(), "billingoverview.fragments.MessageList",
			// 		this);
			// 	this.getView().addDependent(this.messageList);
			// }
			// this.messageList.openBy(oEvent.getSource());
			//	oMessagePopover.toggle();
			//oMessagePopover.toggle(oEvent.getSource());
		},

		handleCloseButton: function() {
			this._addCommentPopOver.close();
		},

		handleAddComment: function(evt) {
			var tbl = this.getTable();
			var src = evt.getSource();
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData(),

				obj = src.getBindingContext().getObject();
			var oData = {
				"Area": "W2",
				"Vbeln": obj.Dbill,
				"Usercomment": worklistData.NewComments
			};
			tbl.setBusy(true);
			var oModel = this.getOwnerComponent().getModel();
			oModel.create("/WFComment", oData, {
				success: function(res) {
					tbl.setBusy(false);
					var omsg = "Successfully Posted ";
					sap.m.MessageToast.show(omsg);
					tbl.getBinding("rows").refresh(true);
				},
				error: function(res) {
					tbl.setBusy(false);
					var omsg = "Error while posting the comments";
					sap.m.MessageToast.show(omsg);
				}
			});

			this.handleCloseButton();
			worklistModel.setProperty("/NewComments", "");
		},
		/*onDefaultAction: function() {
			sap.m.MessageToast.show("Default action triggered");
		},
		onDefaultActionAccept: function() {
			sap.m.MessageToast.show("Accepted");
		},*/
		onMenuActionDraftBill: function(oEvent) {
			var draftBillData = this.draftbill;
			var Kappl;
			var Vbeln;
			var mainUrl;

			var oItem = oEvent.getParameter("item"),
				sItemPath = "";
			while (oItem instanceof sap.m.MenuItem) {
				sItemPath = oItem.getText() + " > " + sItemPath;
				var sKschl = oItem.data("Kschl");
				oItem = oItem.getParent();
			}

			sItemPath = sItemPath.substr(0, sItemPath.lastIndexOf(" > "));

			//	sap.m.MessageToast.show("Action triggered on item: " + sItemPath);
			var oHost = window.location.host,
				http = window.location.protocol;

			if (draftBillData.length === 1) {
				Kappl = draftBillData[0].Kappl.oValue1;
				Vbeln = draftBillData[0].Vbeln.oValue1;

				mainUrl = http + "//" + oHost + "/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV" +
					"/PDFOutCollection(Kappl='" + Kappl + "',Kschl='" + sKschl + "',DraftBill='" + Vbeln + "')/$value";
				sap.m.URLHelper.redirect(mainUrl, true);
			} else if (draftBillData.length > 1) {

				Kappl = draftBillData[0].Kappl.oValue1;
				var str = "";
				var aFilter = [];
				for (var i = 0; i < draftBillData.length; i++) {
					Vbeln = draftBillData[i].Vbeln.oValue1;
					var filterByName = new sap.ui.model.Filter("DraftBill", sap.ui.model.FilterOperator.EQ, Vbeln);
					aFilter.push(filterByName);

					/*	if (i < draftBillData.length - 1) {
							//str += "DraftBill eq '" + Vbeln + "' or ";
							var filterByName = new sap.ui.model.Filter("DraftBill", sap.ui.model.FilterOperator.EQ, Vbeln);
							aFilter.push(filterByName);
							//str += "DraftBill eq '" + Vbeln + "' or ";
						} else {
							str += "DraftBill eq '" + Vbeln + "'";
						}*/
					// DraftBill eq '70000151' or DraftBill eq '70000163' or DraftBill eq '70000167'
				}

				var filterOffice = new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, Kappl);
				aFilter.push(filterOffice);
				//	aFilter.push(filterByName);
				/*	mainUrl = http + "//" + oHost + "/sap/opu/odata/SAP/ZPRS_DBILL_OVERVIEW_SRV" +
						"/PDFOutSet?$filter=(Kappl eq '" + Kappl + "' and (" + str + "))/$value";*/

				//	mainUrl = "/PDFOutSet?$filter=(Kappl eq '" + Kappl + "' and (" + str + "))";

				var oModel = this.getView().getModel();

				oModel.read("/PDFOutSet", {
					filters: aFilter,
					success: function(oData) {
						//if (oData.results.length > 1) {
						sap.m.MessageBox.success("Print Scheduled Successfully");
						/*	} else {
								//sap.m.MessageBox.error("Failed to Schedule Background job for mass bill print");
							}*/
					},
					error: function(oError) {
						sap.m.MessageBox.error("Failed to print please try again");
					}
				});
			}

		},
		onMenuActionFinalBill: function(oEvent) {
			var oItem = oEvent.getParameter("item"),
				sItemPath = "";
			var finalBillData = this.finalBill[0],
				Kappl = finalBillData.aFilters[0].oValue1,
				Pspid = finalBillData.aFilters[1].oValue1,
				Vbeln = finalBillData.aFilters[2].oValue1;
			while (oItem instanceof sap.m.MenuItem) {
				sItemPath = oItem.getText() + " > " + sItemPath;
				var sKschl = oItem.data("Kschl");
				oItem = oItem.getParent();
			}

			sItemPath = sItemPath.substr(0, sItemPath.lastIndexOf(" > "));

			var oHost = window.location.host,
				http = window.location.protocol,
				mainUrl = http + "//" + oHost + "/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV" +
				"/PDFOutCollection(Kappl='" + Kappl + "',Kschl='" + sKschl + "',DraftBill='" + Vbeln + "')/$value";

			sap.m.URLHelper.redirect(mainUrl, true);
		},
		onSelectItem: function(evt) {
			this.sSelKey = evt.getSource().getSelectedKey();
			this.readData();
			this.getView().byId("billingOverViewSTable").rebindTable();
			// var oModel = this.getView().getModel();
			// var filters= [new Filter("Zzbillteamk", "EQ", sSelectedKey)];
			// 	oModel.read("/OverviewSet", {
			// 	filters: filters,
			// 	success: function(oData) {

			// 	},
			// 	error: function(oError) {

			// 	}
			// });

		},
		rowSelect: function(evt) {
			var oView = this.getView().byId("menubtnPrintDBill");
			var oViewFBill = this.getView().byId("menubtnPrintFBill");
			if (this._getSelectedBills("Dbill").length > 0) {
				if (this.sStatus === "04" || this.sStatus === "10") {
					this.onPressPrintFinalBills();
					this.onPressPrintBills();
				} else {
					this.onPressPrintBills();
				}
			} else {
				//	this.onPressPrintBills();
				oView.setEnabled(false);
				oViewFBill.setEnabled(false);
			}

		}

	});
});