/*global location*/
sap.ui.define([
	"billingoverview/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"billingoverview/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("billingoverview.controller.Object", {

		formatter: formatter,
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					cFilter: "01"
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
		},
		onShareInJamPress: function() {
			var oViewModel = this.getModel("objectView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("BillingOverview", {}, true);
			}
		},
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId,
				dbill = oEvent.getParameter("arguments").Dbill;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("FbillheaderSet", {
					Finalbill: sObjectId
				});
				this._bindView("/" + sObjectPath, dbill);
			}.bind(this));
		},

		_bindView: function(sObjectPath, Dbill) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

			var smrtitemTbl = this.getView().byId("idoiTable"),
				UploadCollection = this.getView().byId("UploadCollection"),
				itemTbl = smrtitemTbl.getTable(),
				path = "FbillDetailSet",
				rows = {
					path: path
				};
			itemTbl.bindRows(rows);
			// UploadCollection.bindItems({
			// 	path: "FileListSet",
			// 	templateShareable: false
			// });

		},
		onChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			this.oUploadCollection = oUploadCollection;
			oUploadCollection.setUploadUrl("/sap/opu/odata/sap/ZPRS_DBILL_OVERVIEW_SRV/FileAttachSet");
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oUploadCollection.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var fDetail = this.getView().getBindingContext().getObject();
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: fDetail.Finalbill + '|' + oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadComplete: function(oEvent) {
			var s = oEvent.getSource();
			var ib = s.getBinding("items");
			ib.refresh();
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			// var oResourceBundle = this.getResourceBundle(),
			// 	oObject = oView.getBindingContext().getObject(),
			// 	sObjectId = oObject.Dbill,
			// 	sObjectName = oObject.Baname;

			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			// oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			// oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			// oViewModel.setProperty("/shareSendEmailSubject",
			// oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			// oViewModel.setProperty("/shareSendEmailMessage",
			// oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		onFileDeleted: function(oEvent) {
			var source = oEvent.getSource();
			var sPath = oEvent.mParameters.item.getBindingContext().getPath();
			var oModel = this.getView().getModel();
			var obj = oModel.getProperty(sPath);
			source.setBusy(true);
			var url = "/FileListSet(Vbeln='" + obj.Vbeln + "',Objkey='" + obj.Objkey + "')/FileDelete";
			oModel.read(url, {
				success: function(data) {
					oModel.refresh();
					source.setBusy(false);
				},
				error: function(data) {
					source.setBusy(false);
				}
			});
		}

	});

});