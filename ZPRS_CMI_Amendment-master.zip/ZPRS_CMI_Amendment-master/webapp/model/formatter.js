jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	] , function () {
		"use strict";

		return {

			emailValidation: function(email) {
			if($.isEmptyObject(email)){
				return "None";
			}
			var re =
				/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			 if(re.test(String(email).toLowerCase())){
			 	return "None";
			 }
			 return "Error";
		},
		checkTeamButton: function(sValue) {
   if (sValue === "ZL" || sValue === "ZR") {
    return false;
   } else {
    return true;
   }
  },
		checkValidCC: function(svalue){
			if(!$.isEmptyObject(svalue)){
				return "None";
			}
			return "Error";
		},
			newBusiness: function(sValue) {
			if (sValue) {
				return true;
			} else {
				return true;
			}
		},
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			showButton: function(d) {
			if (d) {
				return "Delete";
			} else {
				return "None";
			}
		},
	checkCPPerc: function(sValue) {
			if (sValue==="CS") {
				return false;
			} else {
				return true;
			}
		},
		showValueDate: function(oDate) {
			if ($.isArray(oDate)) {
				return null;
			}
			var oDateFormat;
			oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
				pattern: "dd.MM.YYYY"
			});
			if (oDate != null) {
				var date = oDateFormat.format(oDate);
				return date;
			} else {
				return oDate;
			}
		},
		HasconflictBtn: function(HCB){
			if (HCB === "X") {
				return true;
			} else {
				return false;
			}
		},
		HasdocumentsBtn: function(HDB){
				if (HDB === "X") {
				return "Emphasized";
			} else {
				return "Default";
			}
		},
		ComButton: function(com) {
			if (com) {
				return "Emphasized";
			} else {
				return "Default";
			}
		},
			sequenceNumber: function(number) {
			var value,
				sNumber = number.toString(),
				sLength = sNumber.length;
			switch (sLength) {
				case 1:
					value = "000" + sNumber;
					break;
				case 2:
					value = "00" + sNumber;
					break;
				case 3:
					value = "0" + sNumber;
					break;
				case 4:
					value = sNumber;
					break;
				default:
					break;
			}
			return value;
		},
		sequenceNumberKnown: function(number) {
			var value,
				sNumber = number.toString(),
				sLength = sNumber.length;
			switch (sLength) {
				case 1:
					value = "0" + sNumber;
					break;
				case 2:
					value = sNumber;
					break;
				default:
					break;
			}
			return value;
		},
		sequenceRankNumber: function(number) {
			var sNumber = number.toString();
			return sNumber;
		},
		checkStatus: function(val1, val2) {
			if (val2) {
				if (val1) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}
		},
		checkStatusSave1: function(status, isEdit, cmino) {
			if($.isEmptyObject(status) && isEdit && !$.isEmptyObject(cmino)){
				
			}
		},
			checkStatusSave: function(val1, val2, val3) {
			if (val2) {
				if (val1 === "" && val3 === true) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
			singleDates: function(oDate, oTime) {
			var oDateFormat;
			oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
				pattern: "dd.MM.YYYY"
			});
			var TimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "hh:mm:ss"
			});
			if (oDate != null) {
				var dateTime = "";
				if (typeof(oDate) === "object") {
					var date = oDateFormat.format(oDate);
					var time = TimeFormat.format(oDate);
					dateTime = date + " " + time;
					return dateTime;
				} else if (typeof(oDate) === "string") {
					if (oDate !== "") {
						var year = oDate.substring(0, 4);
						var month = oDate.substring(4, 6);
						var day = oDate.substring(6, 8);
						var hr = oDate.substring(8, 10);
						var mn = oDate.substring(10, 12);
						var s = oDate.substring(12, 14);
						var sDate = new Date(year, month - 1, day, hr, mn, s);
						var sFDate = oDateFormat.format(sDate);
						var sFTime = TimeFormat.format(sDate);
						dateTime = sFDate + " " + sFTime;
						return dateTime;
					}
					return dateTime;
				} else {
					return dateTime;
				}
			} else {
				return oDate;
			}
		},
			SubmitTerm: function(v1, v2) {
			if (v2) {
				if (v1) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
				myBoolean: function(sBool) {
			var bValue = false;
			if (sBool === "true") {
				bValue = true;
			}
			return bValue;
		},
		myBooleanV: function(sBool) {
			var bValue = false;
			if (sBool === "X") {
				bValue = true;
			}
			return bValue;
		},
		myBoolean1: function(sBool) {
			var bValue = false;
			if (sBool !== "SP" && sBool !== "PY" && sBool !== "Z3" && sBool !== "ZE" && sBool !== "ZL") {
				bValue = true;
			}
			return bValue;
		},
		myBoolean1CP: function(sBool) {
			var bValue = false;
			if (sBool !== "SP") {
				bValue = true;
			}
			return bValue;
		},
		utcDate: function(dt) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "medium",
				UTC: true
			});

			var dateStr = dateFormat.format(dt);
			return dateStr;
		},
		myDate: function(sBool) {
			if (sBool) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
				return dateStr;
			}
		},
		// myDate1: function(sBool) {
		// 	if(typeof(sBool)==="string"){
  //  return sBool;
  // }
		// 	if (sBool) {
		// 		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
		// 			pattern: "yyyy-MM-dd"
		// 		});
		// 		var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
		// 		var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
		// 		return dateStr;
		// 	}
		// },
myDate1: function(sBool) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				}),
				dateStr;
			if (typeof(sBool) === "string") {
				dateStr = dateFormat.format(new Date(sBool));
				return dateStr;
			}
			if (sBool) {
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
				return dateStr;
			}
		},

		myTime: function(sBool) {
			if (sBool) {
				var time = sBool.slice(0, 4) + "-" +
					sBool.slice(4, 6) + "-" +
					sBool.slice(6, 8) + " , " +
					sBool.slice(8, 10) + ":" +
					sBool.slice(10, 12) + ":" +
					sBool.slice(12, 14);
				return time;
			}
		},
	dateFormat: function(value) {

			if (value == null) {
				return null;
			}
			var _smonth = value.getMonth() + 1;
			var _sdate = value.getDate();
			if (_smonth.toString().length < 2) {

				_smonth = "0" + _smonth.toString();
			}
			if (_sdate.toString().length < 2) {

				_sdate = "0" + _sdate.toString();
			}
			var formatDate = value.getFullYear() + '-' + _smonth + '-' + _sdate + "T00:00:00";

			return formatDate;
		},
		myColor: function(sValue) {
			var bValue = "Success";
			switch (sValue) {
				case "OPEN":
					bValue = "Success";
					break;
				case "PEND":
					bValue = "Warning";
					break;
				case "DCLN":
					bValue = "Error";
					break;
				case "SCLS":
					bValue = "Success";
					break;
				case "HCLS":
					bValue = "Success";
					break;
				default:
			}
			return bValue;
		},
	myBooleanBDOD: function(sBool) {
			var bValue = false;
			if (sBool === "X") {
				bValue = true;
			}
			return bValue;
		},
  myBooleanAC: function(sBool) {
    var bValue = true;
    if (sBool === "N") {
      bValue = false;
    }
    return bValue;
  },myVisibleGD: function(sBool) {
    var bValue = true;
    if (sBool === "S") {
      bValue = false;
    }
    return bValue;
  },

  myVisiblePhEm: function(sBool) {
    var bValue = true;
    if (sBool === "") {
      bValue = false;
    }
    return bValue;
  },
  	getAlterKeyField: function(Desc) {
			var key = "",
				keyDesc = [{
					key: "vAlternatepayer",
					Desc: "Alternatepayer"
				},{
					key: "vAlternatepayerName",
					Desc: "Altpayername"
				}, {
					key: "vAltpayeraddr1",
					Desc: "Altpayeraddr1"
				}, {
					key: "vAltpayerstate",
					Desc: "Altpayerstate"
				}, {
					key: "vAltpayercityk",
					Desc: "Altpayercityk"
				}, {
					key: "vAltpayerzip",
					Desc: "Altpayerzip"
				}, {
					key: "vAltpayercountry",
					Desc: "Altpayercountry"
				}, {
					key: "vAltpayerphone",
					Desc: "Altpayerphone"
				}];
			$.each(keyDesc, function(i, kd) {
				if (kd.Desc === Desc) {
					key = kd.key;
					return;
				}
			});
			return key;

		}

		};

	}
);