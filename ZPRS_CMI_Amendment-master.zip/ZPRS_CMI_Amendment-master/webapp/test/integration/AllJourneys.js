jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"cmiamendmentnew/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"cmiamendmentnew/test/integration/pages/Worklist",
		"cmiamendmentnew/test/integration/pages/Object",
		"cmiamendmentnew/test/integration/pages/NotFound",
		"cmiamendmentnew/test/integration/pages/Browser",
		"cmiamendmentnew/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cmiamendmentnew.view."
	});

	sap.ui.require([
		"cmiamendmentnew/test/integration/WorklistJourney",
		"cmiamendmentnew/test/integration/ObjectJourney",
		"cmiamendmentnew/test/integration/NavigationJourney",
		"cmiamendmentnew/test/integration/NotFoundJourney",
		"cmiamendmentnew/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});