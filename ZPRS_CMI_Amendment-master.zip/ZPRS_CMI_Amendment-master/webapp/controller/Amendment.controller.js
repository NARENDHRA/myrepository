/*globals PDFJS getOutputScale TextLayerBuilder CustomStyle*/
sap.ui.define([
	"cmiamendmentnew/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cmiamendmentnew/model/formatter",
	"cmiamendmentnew/model/JsonData",
	"cmiamendmentnew/model/minimal",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"cmiamendmentnew/util/xmlToJSON",
	"sap/ui/richtexteditor/RichTextEditor"
], function(BaseController, JSONModel, History, formatter, JsonData, minimal, Filter, FilterOperator, GroupHeaderListItem) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView, oOPSideContentBtn;
	return BaseController.extend("cmiamendmentnew.controller.Amendment", {
		formatter: formatter,
		JsonData: JsonData,
		minimal: minimal,
		onInit: function() {
			// window.that = this;
			var oViewModel = new JSONModel({
				busy: true,
				delay: 0,
				tableBusyDelay: 0,
				isEditable: false,
				isConEdit: false,
				PrimaryContact: "",
				Email: "",
				Phone: "",
				BillOfc: "",
				LeadPartner: "",
				LPPhone: "",
				LPEmail: "",
				LPName: "",
				TermTitle: "",
				headerTrueFalse: true,
				headerIcon: true,
				tooltipText: "Hide",
				clientVisiable: true,
				matterVisiable: false,
				Name: "",
				btnEnabled: false,
				falg: true,
				CmiId: "",
				isLPEditable: false,
				ClientName: "",
				userId: "",
				userName: "",
				Clientk: "",
				editTerm: true,
				editButtonSubmit: false,
				EditBtn: true,
				isReview: true,
				isSaveBtn: false,
				RadioCA: true,
				RadioMA: false,
				shwBtnVisible: false
			});
			this.setModel(oViewModel, "AmendmentViewMod");
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.attachRoutePatternMatched(this.handleRouteMatched, this);
			this.displayCategoryData();
			// this.displayContacttypeData();
			// this.displayClientpartnerData();
			this.bindMandateField();
			oDynamicSideView = this.getView().byId("DynamicSideContent");
		},
		handleSideContentHide: function() {
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(false);
			}
		},
		handleSCBtnPress: function(oEvent) {
			var BtnHComments = this.getResourceBundle().getText("BtnHComments"),
				BtnSComments = this.getResourceBundle().getText("BtnSComments");

			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					oEvent.getSource().setText(BtnHComments);
				} else {
					oEvent.getSource().setText(BtnSComments);
				}
			}
		},
		handleStep: function(evt) {

			var model = this.getModel("AmendmentViewMod");
			if (model.getProperty("/isEditable")) {
				if (evt.getParameter("index") === 2) {
					this.postCmiData("Step");
				}
				if (evt.getParameter("index") === 3) {
					model.setProperty("/isSaveBtn", true);
				}
			}
		},
		handleRouteMatched: function(oEvent) {
			var oParameters = oEvent.getParameters(),
				oVMod = this.getModel("AmendmentViewMod");
			if ((oParameters.name !== "ClientAmendment" && oParameters.name !== "Amendment" && oParameters.name !== "ClientAmendmentcmi" &&
					oParameters.name !== "ClientAmendmentmyRequest" && oParameters.name !== "AmendmentReq")) {
				return;
			} else {
				var bCmino = $.isEmptyObject(oParameters.arguments);
				// Changes by BG
				this.setCmino = true;
				if (bCmino) {
					// Changes by BG
					this.setCmino = false;
					this._amendmentRequestDialog();
				} else if (oParameters.name === "AmendmentReq") {
					this._amendmentRequestDialog(oParameters.arguments);
				} else {
					oVMod.setProperty("/EditBtn", false);
					var data = oParameters.arguments,
						Cmino = data.Cmino,
						clientk = data.clientId,
						sEditable = data.isEditable,
						bInbox = data.bInbox;
					if (Cmino) {
						this._Cmino = Cmino;
					} else {
						this._Cmino = "";
					}
					if (bInbox === "0") {
						oVMod.setProperty("/isReview", false);
					} else {
						oVMod.setProperty("/isReview", true);
					}

					// if (sEditable === "0") {
					// 	oVMod.setProperty("/isEditable", false);

					// } else {
					// 	oVMod.setProperty("/isEditable", true);
					// }

					// this._onObjectMatched1(clientk);
					var oModel = this.getOwnerComponent().getModel();
					oModel.metadataLoaded().then(function() {
						var sObjectPath = oModel.createKey("Cmihdrs", {
							Cmino: this._Cmino,
							Clientk: clientk,
							Cmirequesttype: "CA",
							Matterk: ""
						});
						this._bindView("/" + sObjectPath);
					}.bind(this));

				}
			}
		},
		_onObjectMatched1: function(value) {

			this.getModel("AmendmentViewMod").setProperty("/Clientk", value);

			var oModel = this.getOwnerComponent().getModel();

			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: "",
					Clientk: value,
					Cmirequesttype: "CA",
					Matterk: ""
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));

		},
		_bindView1: function(sObjectPath) {

			var oModel = this.getOwnerComponent().getModel(),
				that = this;

			oModel.read(sObjectPath, {
				urlParameters: {
					"$expand": "Clients,Clientcontacts,Leadpartners,Ocgs,Clientdetails,Clientcorrespondence,Wtax,Clientbp,Comments,Documents"
				},
				success: function(oData, oResp) {
					that.getModel("jsonAmendModel").setData(oData);
				},
				error: function(oError) {
					that.getView("jsonAmendModel").setBusy(false);
				}
			});
		},
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("AmendmentViewMod");
			// oViewModel.setProperty("/busy", true);
			this.getView().setBusy(true);
			this._sObjectPath = sObjectPath;
			var oModel = this.getOwnerComponent().getModel(),
				that = this,
				jsonModel = new sap.ui.model.json.JSONModel();
			oModel.read(sObjectPath, {
				urlParameters: {
					"$expand": "Clients,Clientcontacts,Leadpartners,Ocgs,Clientdetails,Clientcorrespondence,Wtax,Clientbp,Comments,Documents"
				},
				success: function(oData, oResp) {
					oViewModel.setProperty("/userId", oData.Requestuserk);
					oViewModel.setProperty("/userName", oData.Requestuser);
					if (oData.Clients.results.length) {
						oViewModel.setProperty("/ClientName", oData.Clients.results[0].Client);
					}

					if (oData.Edit === "X") {
						oViewModel.setProperty("/isEditable", true);

					} else {
						oViewModel.setProperty("/isEditable", false);
					}
					// Changes by BG
					if (that.setCmino) {
						that._Cmino = oData.Cmino;
						oViewModel.setProperty("/shwBtnVisible", true);
					} else {
						that._Cmino = "";
					}
					that.getView().setBusy(false);
					jsonModel.setData(oData);
					that.getView().setModel(jsonModel, "jsonAmendModel");
					// Create Entity for Client
					var client = that.byId("SimpFormClient");
					var oContextClient = oModel.createEntry("/Cmiclients", {
						properties: oData.Clients.results[0]
					});
					client.setBindingContext(oContextClient);
					// Create Entity for Client Details
					var ClientGeneralid = that.byId("ClientDetailStep");
					// var oContextCGid;
					if (oData.Clientdetails.results.length) {
						var oContextCGid = oModel.createEntry("/Cmiclientdetails", {
							properties: oData.Clientdetails.results[0]
						});
					} else {
						var ClientDetailsData = that.handleClientInDetails();
						oContextCGid = oModel.createEntry("/Cmiclientdetails", {
							properties: ClientDetailsData
						});
						oData.Clientdetails.results.push(ClientDetailsData);
					}
					ClientGeneralid.setBindingContext(oContextCGid);

					// Create Entity for Legal Entry Correspondence
					// var ClientCorrespondind = that.byId("FormChange354CD");
					// var oContextCCorrid = oModel.createEntry("/Cmiclientcorrespondence", {
					// 	properties: oData.Clientcorrespondence.results[0]
					// });
					// ClientCorrespondind.setBindingContext(oContextCCorrid);

					//Display Comments
					var data = oData.Comments;
					var oJsonComModel = new sap.ui.model.json.JSONModel();
					if (data) {
						oJsonComModel.setData({
							CommentSet: data.results
						});
						that.getView().setModel(oJsonComModel, "CommentsModel");
					} else {
						oJsonComModel.setData({
							CommentSet: []
						});
						that.getView().setModel(oJsonComModel, "CommentsModel");
					}
					// Display Attachments
					var dataD = oData.Documents.results;
					var aFileData = [];
					var host = window.location.host;
					var protocol = window.location.protocol;
					var urlprefix = protocol + "//" + host;
					var serviceUrl = that.getOwnerComponent().getModel().sServiceUrl;
					for (var d = 0; d < dataD.length; d++) {
						var obj = dataD[d];
						obj.url = urlprefix + serviceUrl + "/Cmidocuments(Matterk='" + obj.Matterk + "',Clientk='" + obj.Clientk + "',Cmino='" + dataD.Cmino + "',Docseq='" + obj.Docseq + "',Doctype='" + obj.Doctype +
							"')/$value";
						aFileData.push(obj);
					}
					var oJsonModel = new sap.ui.model.json.JSONModel({
						FileDataSet: aFileData
					});
					that.getView().setModel(oJsonModel, "AttachmentModel");
					that._readContactObject();
					that.bindLeadPartner();
					// that.bindBillingPartner();
					// that.bindTaxData();
				},
				error: function(oError) {
					that.getView().setBusy(false);
				}
			});
		},
		bindMandateField: function() {
			var oViewModel = new JSONModel({
				vClientName: "None",
				vClassification: "None",
				vAddress1: "None",
				vCity: "None",
				vState: "None",
				vZipCode: "None",
				vCountry: "None",
				vOffice: "None",
				vEmail: "None",
				vContactName: "None",
				vContactPhone: "None",
				vContactEmail: "None"
			});
			this.setModel(oViewModel, "ErrorShow");
		},
		onChangeEditMode: function() {
			var oVMod = this.getModel("AmendmentViewMod"),
				iseditable = oVMod.getProperty("/isEditable");
			if (iseditable) {
				oVMod.setProperty("/isEditable", false);
			} else {
				oVMod.setProperty("/isEditable", true);
			}
		},
		onAddressEdit: function() {
			var iddisplay = this.byId("displayAddress"),
				idEdit = this.byId("editAddress");
			iddisplay.setVisible(false);
			idEdit.setVisible(true);
		},
		onAddressDisplay: function() {
			var iddisplay = this.byId("displayAddress"),
				idEdit = this.byId("editAddress");
			iddisplay.setVisible(true);
			idEdit.setVisible(false);
		},
		handelOfcFieldChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				idLeadPartner = this.byId("idLeadPartner"),
				objLead = idLeadPartner.getBindingContext().getModel(),
				path = idLeadPartner.getBindingContext().getPath();
			objLead.setProperty(path + "/Office", value);
		},
		handelLeadPartnerFieldChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				idLeadPartner = this.byId("idLeadPartner"),
				objLead = idLeadPartner.getBindingContext().getModel(),
				path = idLeadPartner.getBindingContext().getPath();
			objLead.setProperty(path + "/Leadpartnerk", value);
		},
		handelClntFieldChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				t = this.getView().byId("SimpFormClient"),
				oClientContext = t.getBindingContext();
			// set Value for Client Details Context
			// var oClientContext = this.getBindingContextbyId("SimpFormClient");
			var sPath = oClientContext.getPath(),
				oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
			if (path === "Countryk") {
				oClientModel.setProperty(sPath + "/" + "Statek", "");
				oClientModel.setProperty(sPath + "/" + "State", "");
			}
		},
		handelClntFieldChangeDD: function(evt) {
			var source = evt.getSource(),
				value = source.getValue(),
				path = source.getBindingPath("value"),
				oControl = source.getAggregation("_content"),
				oClientV = this.getView().byId("SimpFormClient"),
				oClientContext = oClientV.getBindingContext(),
				oClientInModel = oClientContext.getModel(),
				sPath = oClientContext.getPath(),
				oItem, selData,
				obj = this.JsonData.handleKeyDescription(path);
			if (oControl) {
				oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oClientInModel.setProperty(sPath + "/" + path, selData[obj.description]);
					oClientInModel.setProperty(sPath + "/" + obj.id, selData[obj.key]);
					source.getAggregation("_content").setValue(selData[obj.description]);
				} else {
					oClientInModel.setProperty(sPath + "/" + path, value);
					oClientInModel.setProperty(sPath + "/" + obj.id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
		},
		changeInClientDetails: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			// set Value for Client Details Context
			var t = this.getView().byId("ClientDetailStep"),
				oClientInContext = t.getBindingContext(),
				sPath = oClientInContext.getPath(),
				oMatterInModel = oClientInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeInClientDetailsLECD: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value");
			var value = source.getValue();
			if (evt.getParameter("valid") !== undefined) {
				if (!evt.getParameter("valid")) {
					value = null;
					source.setValue(value);
				}
			}
			// set Value for Client Details Context
			var t = this.getView().byId("FormChange354CD"),
				oClientInContext = t.getBindingContext(),
				sPath = oClientInContext.getPath(),
				oMatterInModel = oClientInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		// Lead Partner Add, Delete, Bind Data to Table
		onAddbindLeadPartner: function() {
			
			var data = this.getTableData("LeadPartnerTbl");
				for (var w = 0; w < data.length; w++) {
					var vPath = data[w];
					if (!vPath.Firstname || !vPath.Parvwdesc || !vPath.Phone || !vPath.Email || !vPath.Office) {
						var msg = this.getResourceBundle().getText("manClientpartner");
						sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
						return;

					}
				}
			var qtc = this.getModel(),
				obj = {
					"Cmino": this._Cmino,
					"Rank": "",
					"Officek": "",
					"Office": "",
					"Leadpartnerk": "",
					"Leadpartner": "",
					"Phone": "",
					"Email": "",
					"isLPEditable": true,
					"Parvw": "",
					"Percentage": "",
					"Firstname": "",
					"Lastname": "",
					"Parvwdesc": "",
					"Partnertype": "CIC"
				};
			obj.Partnertype = "CIC";
			var oContextLeadPartner = qtc.createEntry("/Cmileadpartners", {
				properties: obj
			});

			this.bindLPTable(oContextLeadPartner);

		},
		bindLeadPartner: function(evt) {
			var idLeadPartner = this.byId("LeadPartnerTbl");
			idLeadPartner.destroyItems();
			
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data,
					objArray = [],
					obj = {
						"Cmino": that._Cmino,
						"Rank": "",
						"Officek": "",
						"Office": "",
						"Leadpartnerk": "",
						"Leadpartner": "",
						"Phone": "",
						"Email": "",
						"isLPEditable": true,
						"Parvw": "",
						"Percentage": "",
						"Firstname": "",
						"Lastname": "",
						"Parvwdesc": "",
						"Partnertype": "CIC"
					};
				objArray.push(obj);
				obj.Partnertype = "CIC";
				var aLeadPartner = that.getModel("jsonAmendModel").getProperty("/Leadpartners/results");
				//	that.getModel("jsonAmendModel").setProperty("/Leadpartners", objArray.concat(aLeadPartner));
				data = aContact.concat(objArray, aLeadPartner);
				var qtc = that.getModel();
				//		var rank = aKnownParties.length + 1;
				for (var k = 0; k < data.length; k++) {

					var oContextLeadPartner = qtc.createEntry("/Cmileadpartners", {
						properties: data[k]
					});
					that.bindLPTable(oContextLeadPartner);
				}

			});
		},
		bindLPTable: function(oContextLeadPartner) {
			var idLeadPartner = this.byId("LeadPartnerTbl");
			var addButton = new sap.m.Button({
					icon: "sap-icon://add",
					type: "Emphasized",
					enabled: "{AmendmentViewMod>/isEditable}",
					press: this.onAddbindLeadPartner.bind(this)
				}),
				maskInput = new sap.m.MaskInput({
					value: "{Phone}",
					enabled: "{AmendmentViewMod>/isEditable}",
					mask: "999999999999999",
					placeholderSymbol: " ",
					change: this.changeInClientAdd.bind(this)
				});

			// var a = new sap.ui.comp.smartfield.Configuration({
			// 	controlType: "dropDownList",
			// 	displayBehaviour: "idOnly"
			// });
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
				var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
				var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			//  var a= new sap.ui.comp.smartfield.Configuration({controlType:"dropDownList"}); addAggregation("configuration",a,false)
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
						text: "{Rank}",
						change: this.changeLPDetails.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						// change: this.changeLPDPDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}",
						valueListChanged: this.changeLPDPDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Office}",
						change: this.changeLPDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(b),
					// new sap.ui.comp.smartfield.SmartField({
					// 	value: "{Leadpartner}",
					// 	change: this.changeLPDetails.bind(this),
					// 	editable: "{AmendmentViewMod>/isEditable}"
					// }),

					new sap.m.HBox({
						justifyContent: "Center",
						items: [new sap.ui.comp.smartfield.SmartField({
								value: "{Firstname}",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this),
								placeholder: "First Name"
							}).setConfiguration(c).addStyleClass("sapUiTinyMarginEnd"),
							new sap.ui.comp.smartfield.SmartField({
								value: "{Lastname}",
								placeholder: "Last Name",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this)
							})
						]
					}).addStyleClass("sapUiTinyMarginEnd"),
					maskInput,
					// new sap.m.Input({
					// 	value: "{Phone}",
					// 	change: this.changeLPDetails.bind(this),
					// 	editable: "{AmendmentViewMod>/isEditable}"
					// }),
					new sap.m.Input({
						value: "{Email}",
						change: this.changeLPDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}",
						valueState: {
							path: "Email",
							formatter: formatter.emailValidation
						},
						valueStateText: "Invalid EmailId"
					}),
					new sap.m.Input({
						value: "{Percentage}",
						visible: {
							path: 'Parvw',
							formatter: formatter.checkCPPerc
						},
						liveChange: this.liveClientPercent.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextLeadPartner);
			idLeadPartner.addItem(oColumnListItem);
			this.upDateLPButtons(idLeadPartner);
		},
		 changeLPDPDetails: function(evt) {
   var source = evt.getSource(),
    model = source.getModel(),
    path = source.getBindingPath("value"),
    i18n = this.getResourceBundle(),
    value = source.getValue(),
    sPath = source.getBindingContext().getPath(),
    selData,
    msg,
    oItem = source.getAggregation("_content");
   if (oItem) {
    selData = evt.getParameter("changes");
    /* var bcType = this.checkClientType(selData.Parvw);
     if (!bcType) {
      msg = i18n.getText("allowClientRel");
      model.setProperty(sPath + "/Parvw", "");
      model.setProperty(sPath + "/Parvwdesc", "");
      model.setProperty(sPath + "/Percentage", "");
      oItem.setValue("");
      sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
      return;
     }*/
    model.setProperty(sPath + "/Parvw", selData.Parvw);
    model.setProperty(sPath + "/Parvwdesc", value);
    source.getAggregation("_content").setValue(value);

    if (selData.Parvw === "CS") {
     model.setProperty(sPath + "/Percentage", "0.00");
    }
    if (this.getTotalPerCent(source.getBindingContext().getObject()) >= 100) {
     msg = i18n.getText("selectPert", value);
     model.setProperty(sPath + "/Parvw", "");
     model.setProperty(sPath + "/Parvwdesc", "");
     model.setProperty(sPath + "/Percentage", "");
     sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
     return;
    }
    var bcType = this.checkClientType(selData.Parvw);
    if (selData.Parvw === "ZK" && bcType) {
     model.setProperty(sPath + "/Percentage", "100");
     return;
    } else {
     model.setProperty(sPath + "/Percentage", "0.00");
    }
   } else {
    model.setProperty(sPath + "/" + path, value);
   }
  },
		checkClientType: function() {
			var aClientData = this.fetchLeadPartnerData(),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === "ZK") {
						count++;
					}
				}
			});
			return count > 1 ? false : true;
		},
		liveClientPercent: function(oEvent) {
			var src = oEvent.getSource(),
				obj = src.getBindingContext().getObject(),
				that = this;
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);

					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
			var sPercent = this.getTotalPerCent(obj);

			function validTotalPercent(pert, Phone) {
				var val = oFloatFormat.format(pert);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);
					sPercent = that.getTotalPerCent(obj);
					validTotalPercent(sPercent, oPhone);
				} else {
					return oPhone;
				}
			}
			validTotalPercent(sPercent, oPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		changeInClientAdd: function(oEvent) {
			var src = oEvent.getSource(),
				vPhone, validPh,
				path, matterPath, matterModel;
			if (src.getBindingContext()) {
				path = src.getBindingPath("value");
				matterPath = src.getBindingContext().sPath;
				matterModel = src.getBindingContext().getModel();
			}
			vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			validPh = /^[0-9]{1,30}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
		},
		getTotalPerCent: function(client) {
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var data = this.getTableData("LeadPartnerTbl");
			var percent = 0;
			data.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === client.Parvw) {
						val = oFloatFormat.format(sData.Percentage);
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
					}
				}
			});
			return percent;
		},
		getTableData: function(sTableId) {
			var aTableData = [],
				obj,
				oTable = this.getView().byId(sTableId);
			$.each(oTable.getItems(), function(rindex, row) {
				obj = row.getBindingContext().getObject();
				delete(obj.__metadata);
				aTableData.push(obj);
			});
			return aTableData;
		},
		fetchLeadPartnerData: function() {
			var idLeadPartner = this.byId("LeadPartnerTbl"),
				leadData = [];
			for (var iL = 0; iL < idLeadPartner.getItems().length; iL++) {
				var oLItem = idLeadPartner.getItems()[iL];
				var sLSequence = this.formatter.sequenceRankNumber(iL + 1);
				var LeadPath = oLItem.getBindingContext().sPath,
					LeadModel = oLItem.getBindingContext().getModel();
				var objL = {
					"Cmino": "",
					"Rank": sLSequence,
					"Office": LeadModel.getProperty(LeadPath + "/" + "Office"),
					"Officek": LeadModel.getProperty(LeadPath + "/" + "Officek"),
					"Leadpartnerk": LeadModel.getProperty(LeadPath + "/" + "Leadpartnerk"),
					"Leadpartner": LeadModel.getProperty(LeadPath + "/" + "Leadpartner"),
					"Parvw": LeadModel.getProperty(LeadPath + "/" + "Parvw"),
					"Parvwdesc": LeadModel.getProperty(LeadPath + "/" + "Parvwdesc"),
					"Phone": LeadModel.getProperty(LeadPath + "/" + "Phone"),
					"Email": LeadModel.getProperty(LeadPath + "/" + "Email"),
					"Percentage": LeadModel.getProperty(LeadPath + "/" + "Percentage"),
					"Partnertype": LeadModel.getProperty(LeadPath + "/" + "Partnertype"),
					"Firstname": LeadModel.getProperty(LeadPath + "/" + "Firstname"),
					"Lastname": LeadModel.getProperty(LeadPath + "/" + "Lastname")
				};
				leadData.push(objL);
			}
			return leadData;
		},
		upDateLPButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
				var oItem = oTable.getItems()[i],
					sSequence = i + 1,
					LeadPath = oItem.getBindingContext().sPath,
					LeadModel = oItem.getBindingContext().getModel();
				LeadModel.setProperty(LeadPath + "/" + "Rank", sSequence.toString());
			}
		},
		handleDeleteLPartner: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem"),
				oTable = this.byId("LeadPartnerTbl"),
				ind = oTable.indexOfItem(oItmSel);
			oItmSel.destroy();
			if (oTable.getModel().getProperty("/Leadpartners") !== undefined) {
				oTable.getModel().getProperty("/Leadpartners").splice(ind, 1);
			}

			oTable.getModel().refresh();
			this._removeConditionLP(oTable);
		},
		_removeConditionLP: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddbindLeadPartner();
			}
			this.upDateLPButtons(oTable);
		},
		changeLPDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		changeLeadAllocation: function(evt) {

		},
		displayClientpartnerData: function() {
			var that = this,
				oModel = this.getOwnerComponent().getModel(),
				path = "/Cmipartnertype",
				oJsonModel = new sap.ui.model.json.JSONModel(),
				aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, "CIC")];
			oModel.read(path, {
				filters: aFilter,
				success: function(oData) {
					oJsonModel.setData({
						CmiPartnertype: oData.results
					});
					that.getView().setModel(oJsonModel, "oSelectPartnerType");
				},
				error: function(oResponse) {

				}
			});

		},
		tableControlType: function() {
			var ControlType = {
				a: new sap.ui.comp.smartfield.Configuration({
					controlType: "dropDownList",
					displayBehaviour: "idOnly"
				}),
				b: new sap.ui.comp.smartfield.Configuration({
					preventInitialDataFetchInValueHelpDialog: false
				})
			};
			return ControlType;
		},
		// Add Client Contact 

		displayContacttypeData: function() {
			var that = this,
				oModel = this.getOwnerComponent().getModel(),
				path = "/Cmipartnertype",
				oJsonModel = new sap.ui.model.json.JSONModel(),
				aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, "CEC")];
			oModel.read(path, {
				filters: aFilter,
				success: function(oData) {
					oJsonModel.setData({
						CmiContacttype: oData.results
					});
					that.getView().setModel(oJsonModel, "oSelectClientCType");
				},
				error: function(oResponse) {

				}
			});
		},
		templateContacts: function(e) {
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var addButton = new sap.m.Button({
				text: "",
				icon: "sap-icon://add",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddContact.bind(this),
				type: "Emphasized"
			});
			var maskInput = new sap.m.MaskInput({
				value: "{Phone}",
				enabled: "{AmendmentViewMod>/isEditable}",
				mask: "999999999999999",
				placeholderSymbol: " ",
				change: this.changeContacts.bind(this)
			});
			// 	var oItemTemplate = new sap.ui.core.Item({
			// 	key: "{oSelectClientCType>Parvw}",
			// 	text: "{oSelectClientCType>Parvwdesc}"
			// });
			// var oSelect = new sap.m.Select({
			// 	selectedKey: "{Partnertype}",
			// 	items: {
			// 		path: "oSelectClientCType>/CmiContacttype",
			// 		template: oItemTemplate
			// 	}
			// });
			// this.setModel("oSelectIntPartner", oSelect);
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Contacttypedesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeContacts.bind(this)
					}).setConfiguration(b),
					new sap.m.HBox({
							justifyContent: "Center",
						items: [new sap.ui.comp.smartfield.SmartField({
								value: "{Firstname}",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeContacts.bind(this),
								placeholder: "First Name",
								valueState: "{ErrorShow>/vContactFName}"
									// 		valueState: {
									// 	path: "Firstname",
									// 		formatter: formatter.checkValidCC
									// },
									// valueStateText: "Invalid Entry"

							}).addStyleClass("sapUiTinyMarginEnd"),
							new sap.ui.comp.smartfield.SmartField({
								value: "{Lastname}",
								placeholder: "Last Name",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeContacts.bind(this)
							})
						]
					}).addStyleClass("sapUiTinyMarginEnd"),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Functiondesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeContacts.bind(this)
					}),
					maskInput,
					/*new sap.ui.comp.smartfield.SmartField({
						value: "{Phone}",
						editable: "{worklistView>/editScreen}",
						change: this.changeContacts.bind(this)
					}),*/
					new sap.ui.comp.smartfield.SmartField({
						value: "{Email}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeContacts.bind(this),
						valueState: {
							path: "Email",
							formatter: formatter.emailValidation
						},
						valueStateText: "Invalid EmailId"
					}),
					new sap.ui.core.Icon({
						color: "{=${Contacttype} === 'P' ? 'green' : 'black'}",
						src: "{=${Contacttype} === 'P' ? 'sap-icon://accept' : 'sap-icon://circle-task'}",
						size: "{=${Contacttype} === 'P' ? '20px' : '1rem'}",
						enabled: "{AmendmentViewMod>/isEditable}",
						press: this.handlePrimaryContact.bind(this)
					}),
					new sap.m.TextArea({
						value: "{Comments}",
						enabled: "{AmendmentViewMod>/isEditable}",
						placeholder: "{i18n>CommentsPlaceholder}",
						cols: 50,
						rows: 1,
						maxLength: 241,
						change: this.onContactComment.bind(this)
					}),
					/*new sap.m.Button({
						icon : "sap-icon://message-popup",
						type : "{=${Comments} ? 'Emphasized':'Default'}",
						press : this.onPressContactComments.bind(this)
					}),*/
					addButton
				]
			});
			oColumnListItem.addButton = addButton;
			return oColumnListItem;
		},
		changeContacts: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		onContactComment: function(evt) {
			var oEvt = evt.getSource(),
				sPath = oEvt.getBindingContext().sPath,
				path = oEvt.getBindingPath("value"),
				value = oEvt.getValue(),
				oMatterModel = oEvt.getBindingContext().getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
		},
		_readContactObject: function() {
			var idClientContact = this.getView().byId("ClientContactTable");
			idClientContact.destroyItems();
			var that = this;

			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that._Cmino,
					"Contactseq": "",
					"Contacttype": "",
					"Email": "",
					"Name": "",
					"Phone": "",
					"Comments": "",
					"Firstname": "",
					"Lastname": "",
					"Functiondesc": "",
					"Function": "",
					"Partnertype": "CEC"
				};
				objArray.push(obj);
				obj.Partnertype = "CEC";
				var aClientCon = that.getModel("jsonAmendModel").getProperty("/Clientcontacts/results"),
					newData = aContact.concat(objArray, aClientCon);
				var qtc = that.getModel();

				for (var k = 0; k < newData.length; k++) {
					var oContextClinCnt = qtc.createEntry("/Cmiclntcontacts", {
						properties: newData[k]
					});

					that.bindClientContactTable(oContextClinCnt);

				}
			});
			// oViewNewModel.setProperty("/Clientcontacts", aData);
			// var idCContact = this.byId("ClientContactTable");
			// this.upDateCCButtons(idCContact);
		},
		/**
		 * Function to bind Client Contact
		 */
		bindClientContactTable: function(oContextCleintContaxt) {
			var idClientContact = this.byId("ClientContactTable"),
				oColumnListItem = this.templateContacts();
			oColumnListItem.setBindingContext(oContextCleintContaxt);
			idClientContact.addItem(oColumnListItem);
			this.upDateCCButtons(idClientContact);
		},
		upDateCCButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		onAddContact: function(evt) {
			var that = this;
			if (evt) {
				// var	oContext = evt.getSource().getBindingContext(),
				// 	sPath = oContext.getPath(),
				// 	oContactModel = oContext.getModel(),
				// 	vPath = oContactModel.getProperty(sPath);

				// 	if(!vPath.Firstname || !vPath.Lastname || !vPath.Phone || !vPath.Email || !vPath.Contacttype)
				// {
				// 	sap.m.MessageToast.show("Please fill all fields");
				// 	return;
				// }

					var data = this.getTableData("ClientContactTable");
				for (var w = 0; w < data.length; w++) {
					var vPath = data[w];
					if (!vPath.Firstname || !vPath.Functiondesc || !vPath.Phone || !vPath.Email || !vPath.Contacttypedesc) {
					var msg = this.getResourceBundle().getText("manClientContacts");
						sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
						return;

					}
				}
			}

			var aContact = [],
				data;
			var objArray = [];
			var obj = {
				"Cmino": that._Cmino,
				"Contactseq": "",
				"Contacttype": "",
				"Email": "",
				"Name": "",
				"Phone": "",
				"Comments": "",
				"Firstname": "",
				"Lastname": "",
				"Functiondesc": "",
				"Function": "",
				"Partnertype": "CEC"
			};
			// obj.Partnertype = "CEC";
			objArray.push(obj);

			var qtc = that.getModel();
			// for (var k = 0; k < newData.length; k++) {
			var oContextContact = qtc.createEntry("/Cmiclntcontacts", {
				properties: obj
			});

			that.bindClientContactTable(oContextContact);
		},
		handleClientFinish: function(oEvent) {
			var oSrc = oEvent.getSource(),
				sTotal = oEvent.getParameter("total"),
				oClientcontactsModel = oSrc.getModel("jsonAmendModel");
			for (var i = 0; i < sTotal; i++) {
				oClientcontactsModel.setProperty("/Clientcontacts/" + i + "/Contactseq", this.formatter.sequenceNumber(i + 1));
			}
		},
		handlePrimaryContact: function(evt) {
			var oControl = evt.getSource(),
				oContext = oControl.getBindingContext("jsonAmendModel"),
				sPath = oContext.sPath,
				allContext = oContext.getModel().mContexts,
				oContexts = Object.getOwnPropertyNames(allContext);
			oContexts.map(function(sPathItem) {
				if (sPathItem.indexOf("/Clientcontacts") !== -1) {
					oContext.getModel().setProperty(sPathItem + "/Contacttype", "S");
				}
			});
			oContext.getModel().setProperty(sPath + "/Contacttype", "P");
		},
		handleDeleteContacts: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem"),
				oTable = this.byId("ClientContactTable");
			this.getModel().deleteCreatedEntry(oItmSel.getBindingContext());
			oItmSel.destroy();
			this._removeClientContactCondition(oTable);
		},
		_removeClientContactCondition: function(oTable) {
			var n = oTable.getItems().length;
			if (n < 1) {
				this.onAddContact();
			}
			this.upDateCCButtons(oTable);
		},
		handleAttchRequest: function() {
			var OcgFNText = this.getResourceBundle().getText("OcgFNText");
			if (!this._UploadA) {
				this._UploadA = sap.ui.xmlfragment("cmiamendmentnew.fragments.fileupload", this);
				this.getView().addDependent(this._UploadA);
			}
			var oJsonModel = new sap.ui.model.json.JSONModel({
				results: [{
					"AttachmentNo": "",
					"Filename": OcgFNText
				}]
			});
			var proto = window.location.protocol,
				host = window.location.host,
				service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmiocgs";
			this._UploadA.getContent()[0].setUploadUrl(service);
			this._UploadA.getContent()[0].bindAggregation("items", "upLoadData>/results", new sap.m.UploadCollectionItem({
				documentId: "{upLoadData>AttachmentNo}",
				fileName: "{upLoadData>Filename}",
				url: "{upLoadData>url}",
				visibleDelete: false,
				visibleEdit: false
			}));
			this._UploadA.getContent()[0].setModel(oJsonModel, "upLoadData");
			this._UploadA.open();
		},
		handleCloseAttachment: function() {
			this._UploadA.close();
		},
		onAfterRendering: function() {
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
		},
		displayCategoryData: function() {
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_ADMIN_TABS_SRV/"),
				path = "Terms",
				oJsonModel = new sap.ui.model.json.JSONModel();
			//	oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			oModel.read(path, null, null, true, function(oData, oResponse) {
				oJsonModel.setData({
					modelData: oData.results
				});
				that.getView().setModel(oJsonModel, "jsonAmendOcgModel");
			}, function(oResponse) {

			});
		},
		displayOcgsList: function() {
			var cmiId = this._Cmino,
				that = this,
				aFilter = [new Filter("Cmino", sap.ui.model.FilterOperator.EQ, cmiId)],
				uriParameter = {
					"$select": "Cmino,Error,Cmiocgseq,Message,Ostatusk,Ostatus,Filename,Filesize,Uploadeddate,Uploadedbyk,Uploadedby",
					"$expand": "OcgTerms"
				},
				filesPath = "/Cmiocgs",
				oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: uriParameter,
				success: function(oData, OResponse) {
					// debugger;
					that.getModel("jsonAmendModel").setProperty("/Ocgs/results", oData.results);
				},
				error: function(err) {
					// debugger;
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},

		onSubmitAddTermsDialog: function(e) {
			var aImportedTermsList = this.getView().byId("idListImportedTerms").getItems(),
				cmiNo = this._Cmino,
				array = [],
				that = this;
			//	var sPath = "/Cmiocgs";
			//	var batchChanges = [];
			for (var i = 0; i < aImportedTermsList.length; i++) {
				var obj = {};
				var context = aImportedTermsList[i].getBindingContext().getObject();
				obj.Termitem = (context.SubcategoryidDesc || context.Termitem);
				obj.Terms = aImportedTermsList[i].getContent()[0].getContent()[0].getValue();
				obj.Cmiocgseq = this.formatter.sequenceNumber(i + 1);
				obj.Cmino = cmiNo;
				obj.Termhdrk = (context.Categoryid || context.Termhdrk);
				obj.Termhdr = (context.CategoryidDesc || context.Termhdr);
				obj.Termitemk = (context.Subcategoryid || context.Termitemk);
				obj.Status = "";
				array.push(obj);
				//	batchChanges.push(that.oModel.createBatchOperation("Cmiocgterms", "POST", obj));
			}
			var sArrayLength = array.length;
			for (var j = 0; j < sArrayLength; j++) {
				delete(array[j].__metadata);
			}
			this.OcgData.OcgTerms = array;

			this.OcgData.Cmiocgseq = this.formatter.sequenceNumber(this.OcgData.Cmiocgseq);
			this.OcgData.Cmino = cmiNo;
			this.OcgData.Ostatus = "";
			if (this.attachEdit) {
				var sPath = this.OcgContext.sPath;
				this.getModel("jsonAmendModel").setProperty(sPath, this.OcgData);
			} else {
				if (this.addDocument) {
					this.OcgData.Ostatus = "";
					var aTermsData = [];
					var ocgTermsData = this.getModel("jsonAmendModel").getProperty("/Ocgs/results");
					// ocgTermsData.push(this.OcgData);
					aTermsData.push(this.OcgData);
					this.getModel("jsonAmendModel").setProperty("/Ocgs/results", aTermsData.concat(ocgTermsData));
				} else {
					this.getModel("jsonAmendModel").setProperty("/Ocgs/results/0", this.OcgData);
				}

			}
			if (e !== "WF") {
				that.handleSaveDataForTerms();
			}
			// that._oDialog.close();

		},
		handleSaveDataForTerms: function() {
			var oModel = this.getOwnerComponent().getModel(),
				oBusy = new sap.m.BusyDialog();

			var clientData = this._readpostData(""),
				that = this;
			oBusy.open();
			oModel.create("/Cmihdrs", clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					// that.getModel("jsonAmendModel").setData(oData);
					var sObjectPath = that.getModel().createKey("Cmihdrs", {
						Cmino: oData.Cmino,
						Clientk: oData.Clientk,
						Cmirequesttype: oData.Cmirequesttype,
						Matterk: oData.Matterk
					});
					that._bindView1("/" + sObjectPath);
					that.addDocument = false;
					that.getModel("AmendmentViewMod").setProperty("/editButtonSubmit", true);
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		
		onSelectCategories: function() {
		if (!this._oCListDialog) {
			this._oCListDialog = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.CategoriesList", this);
			}
			this._oCListDialog.open();
			this.getView().byId("idCategoriesList").setModel(this.getView().getModel("jsonAmendOcgModel"), "jsonAmendOcgModel");

		},
		handleZoom: function() {
			this.byId("idImport").setVisible(!this.byId("idImport").getVisible());
			if (!this.byId("idImport").getVisible()) {
				this.byId("idPdf").setLayoutData(new sap.ui.layout.GridData({
					span: "L12 M12 S12"
				}));
				this.byId("idFullOut").setIcon("sap-icon://exit-full-screen");
				this.scaleT = 1.9;
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				this.byId("idPdf").setLayoutData(new sap.ui.layout.GridData({
					span: "L8 M8 S8"
				}));
				this.byId("idFullOut").setIcon("sap-icon://full-screen");
				this.scaleT = 1.3;
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}

			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		handleZoomIn: function() {
			this.scaleT = this.scaleT + 0.5;
			if (!this.byId("idImport").getVisible()) {
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}
			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		handleZoomOut: function() {
			this.scaleT = this.scaleT - 0.5;
			if (!this.byId("idImport").getVisible()) {
				if (this.scaleT <= 1.3) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 2.5) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			} else {
				if (this.scaleT <= 0.8) {
					this.byId("idZoomOut").setEnabled(false);
				} else {
					this.byId("idZoomOut").setEnabled(true);
				}
				if (this.scaleT > 1.8) {
					this.byId("idZoomin").setEnabled(false);
				} else {
					this.byId("idZoomin").setEnabled(true);
				}
			}
			this.onAddTermReview(this.OcgData.Filecontent, this.scaleT);
		},
		handleLinkTrem: function(evt) {
			this.attachEdit = true;
			var src = evt.getSource(),
				ocxt = src.getBindingContext("jsonAmendModel"),
				sPath = ocxt.sPath,
				fPath = ocxt.getModel().getProperty(sPath + "/Filecontent");
			this.OcgData = evt.getSource().getBindingContext("jsonAmendModel").getObject();

			// var spath = "/Cmiocgs(Cmino='" + Cmino + "',Cmiocgseq='" + seq + "')";
			// this.OcgData = evt.getSource().getBindingContext("jsonAmendModel").getObject();
			this.OcgContext = evt.getSource().getBindingContext("jsonAmendModel");
			this.getModel("AmendmentViewMod").setProperty("/editButtonSubmit", false);
			var that = this;
			if (this.OcgData.OcgTerms.__deferred) {
				var Cmino = evt.getSource().getBindingContext("jsonAmendModel").getObject().Cmino;
				var seq = evt.getSource().getBindingContext("jsonAmendModel").getObject().Cmiocgseq;
				var spath = "/Cmiocgs(Cmino='" + Cmino + "',Cmiocgseq='" + seq + "')";
				this.OcgData = evt.getSource().getBindingContext("jsonAmendModel").getObject();
				if (this._oDialog) {
					this._oDialog.destroy();
				}
				this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.TermReviews", this);
				that.getView().addDependent(this._oDialog);

				var model = this.getModel("AmendmentViewMod");

				if (model.getProperty("/isEditable")) {
					this.getModel("AmendmentViewMod").setProperty("/editTerm", true);
					//that.byId("submitTerm").setEnabled(true);
					this.byId("ID_FRAME").setVisible(true);
				}
				var $pdfContainer = jQuery("#pdfContainer");
				if ($pdfContainer) {
					$pdfContainer.empty();
					$pdfContainer.css("height", "0px").css("width", "0px");
				}
				this._oDialog.open();
				var oModel = this.getModel();
				var oBusy = new sap.m.BusyDialog();
				var urlParam = {
					"$expand": "OcgTerms"
				};
				oBusy.open();
				oModel.read(spath, {
					urlParameters: urlParam,
					success: function(oData, OResponse) {
						oBusy.close();
						that.onAddTermReview(that.OcgData.Filecontent, 1.3);
						that.OcgData.OcgTerms = oData.OcgTerms.results;
						that.displayAllTerms(that.OcgData);
					},
					error: function(err) {
						oBusy.close();
						var errmessage = JSON.parse(err.response.body).error.message.value;
						sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					}
				});
			} else {
				if (this._oDialog) {
					this._oDialog.destroy();
				}
				this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.TermReviews", this);
				that.getView().addDependent(this._oDialog);
				var model = this.getModel("AmendmentViewMod");
				if (model.getProperty("/isEditable")) {
					this.getModel("AmendmentViewMod").setProperty("/editTerm", true);
					//that.byId("submitTerm").setEnabled(true);
				}
				this.byId("ID_FRAME").setVisible(true);
				var $pdfContainer = jQuery("#pdfContainer");
				if ($pdfContainer) {
					$pdfContainer.empty();
					$pdfContainer.css("height", "0px").css("width", "0px");
				}
				that.onAddTermReview(this.OcgData.Filecontent, 1.3);
				that.displayAllTerms(this.OcgData);
			}
			this._oDialog.open();

		},
		displayAllTerms: function(oData) {
			var oListTemplate = new sap.ui.core.Item({
				key: "{Name}",
				text: "{Name}"
			});
			var data = oData.OcgTerms;

			var oSelect = new sap.m.Select().bindAggregation("items", "/RouteToCollection", oListTemplate).addStyleClass(
				"sapUiTinyMarginBegin");
			var that = this;
			for (var i = 0; i < data.length; i++) {
				var qtc = this.getModel();
				var oContextOcgTerms = qtc.createEntry("/Cmiocgterms", {
					properties: data[i]
				});
				var oCustomListItem = new sap.m.CustomListItem({
					content: new sap.m.Panel({
						expandable: true,
						expanded: true,
						width: "auto",
						headerToolbar: new sap.m.Toolbar({
							content: [
								new sap.m.Title({
									text: "Category: " + data[i].Termitem
								}),
								new sap.m.ToolbarSpacer(),
								new sap.m.Button({
									visible: "{AmendmentViewMod>/isEditable}",
									tooltip: "Delete Item",
									icon: "sap-icon://sys-cancel",
									press: function(oEvt) {
										that.onITDeletePress(oEvt);
									}
								})
							]
						}),
						content: [
							new sap.ui.richtexteditor.RichTextEditor({
								editable: "{AmendmentViewMod>/isEditable}",
								editorType: sap.ui.richtexteditor.EditorType.TinyMCE4,
								width: "100%",
								height: "200px",
								customToolbar: false,
								showGroupFont: false,
								showGroupStructure: false,
								showGroupFontStyle: false,
								showGroupClipboard: false,
								showGroupTextAlign: false,
								tooltip: "My RTE Tooltip",
								value: data[i].Terms
							}),
							new sap.m.HBox({
								justifyContent: "SpaceBetween",
								items: [
									new sap.m.Text({
										text: "{Status}"
									}),
									new sap.m.Button({
										icon: "sap-icon://save",
										type: "Emphasized",
										text: "Submit",
										enabled: {
											parts: [{
												path: 'Status'
											}, {
												path: 'AmendmentViewMod>/isEditable'
											}, {
												path: 'AmendmentViewMod>/editButtonSubmit'
											}],
											formatter: formatter.checkStatusSave
										},
										press: function(oEvt) {
											that.onSubmitPress(oEvt);
										}
									}).addStyleClass("sapUiTinyMarginBegin")
								]
							}).addStyleClass("sapUiSmallMargin")
						]
					}).addStyleClass("sapUiNoContentPadding")
				}).setBindingContext(oContextOcgTerms);
				this.getView().byId("idListImportedTerms").addItem(oCustomListItem);
			}
		},
		onAddTermReview: function(base64, scale) {
			this.scaleT = scale;
			var that = this;
			this.byId("ID_FRAME").setVisible(true);
			var tag = "<div id='pdfContainer' class='pdf-content'></div>";
			this.getView().byId("idFrame").setContent(tag);
			var $pdfContainer = jQuery("#pdfContainer");
			$pdfContainer.empty();
			jQuery.sap.delayedCall(500, this, function() {

				// var scale = 1.6; //Set this to whatever you want. This is basically the "zoom" factor for the PDF.

				/**
				 * Converts a base64 string into a Uint8Array
				 */
				function base64ToUint8Array(base64) {
					var raw = atob(base64); //This is a native function that decodes a base64-encoded string.
					var uint8Array = new Uint8Array(new ArrayBuffer(raw.length));
					for (var i = 0; i < raw.length; i++) {
						uint8Array[i] = raw.charCodeAt(i);
					}

					return uint8Array;
				}

				function loadPdf(pdfData) {
					PDFJS.disableWorker = true; //Not using web workers. Not disabling results in an error. This line is
					//missing in the example code for rendering a pdf.

					var pdf = PDFJS.getDocument(pdfData);
					pdf.then(renderPdf);
				}

				function renderPdf(pdf) {
					for (var i = 0; i < pdf.numPages; i++) {
						pdf.getPage(i + 1).then(renderPage);
					}
				}

				function renderPage(page) {
					var viewport = page.getViewport(scale);
					var $canvas = jQuery("<canvas></canvas>");

					//Set the canvas height and width to the height and width of the viewport
					var canvas = $canvas.get(0);
					var context = canvas.getContext("2d");
					canvas.height = viewport.height;
					canvas.width = viewport.width;
					//canvas.width = document.getElementById("__xmlview0--ID_FRAME").offsetWidth;

					//Append the canvas to the pdf container div
					var $pdfContainer = jQuery("#pdfContainer");
					var $pdfDiv = jQuery("<div></div>");
					$pdfContainer.append($pdfDiv);
					$pdfDiv.css("height", canvas.height + "px").css("width", canvas.width + "px");
					$pdfDiv.append($canvas);

					//The following few lines of code set up scaling on the context if we are on a HiDPI display
					var outputScale = getOutputScale();

					var canvasOffset = $canvas.offset();
					var $textLayerDiv = jQuery("<div />")
						.addClass("textLayer")
						.css("height", viewport.height + "px")
						.css("width", viewport.width + "px")
						.offset({
							top: "-" + canvas.height,
							left: 0
								//  top: 0,
								//  left: 0
						});

					$pdfDiv.append($textLayerDiv);

					if (outputScale.scaled) {
						var cssScale = 'scale(' + (1 / outputScale.sx) + ', ' +
							(1 / outputScale.sy) + ')';
						CustomStyle.setProp('transform', canvas, cssScale);
						CustomStyle.setProp('transformOrigin', canvas, '0% 0%');

						if ($textLayerDiv.get(0)) {
							CustomStyle.setProp('transform', $textLayerDiv.get(0), cssScale);
							CustomStyle.setProp('transformOrigin', $textLayerDiv.get(0), '0% 0%');
						}
					}

					context._scaleX = outputScale.sx;
					context._scaleY = outputScale.sy;
					if (outputScale.scaled) {
						context.scale(outputScale.sx, outputScale.sy);
					}

					page.getTextContent().then(function(textContent) {
						var textLayer = new TextLayerBuilder($textLayerDiv.get(0), 0); //The second zero is an index identifying
						//the page. It is set to page.number - 1.
						textLayer.setTextContent(textContent);

						var renderContext = {
							canvasContext: context,
							viewport: viewport,
							textLayer: textLayer
						};

						page.render(renderContext);
					});
				}

				var pdfData = base64ToUint8Array(base64);
				loadPdf(pdfData);
				if (!window.x) {
					var x = {};
				}

				x.Selector = {};
				x.Selector.getSelected = function() {
					var t = "";
					if (window.getSelection) {
						t = window.getSelection();
					} else if (document.getSelection) {
						t = document.getSelection();
					} else if (document.selection) {
						t = document.selection.createRange().text;
					}
					return t;
				};

				$("#pdfContainer")[0].addEventListener("mouseup", function() {
					/*	var mytext = x.Selector.getSelected();
						if (mytext !== "") {
							that.mytxt = mytext.toString();
						}*/
					var sel = window.getSelection();
					var textBody = document.createElement("div");
					var container = jQuery("<div />").addClass("textLayers");
					//	container[0].style="height: 752.4px; width: 581.4px; top: -752px; left: 0px;";
					container[0].appendChild(sel.getRangeAt(0).cloneContents());
					//		textBody.appendChild(container[0]);
					var arr = [];
					for (var i = 0; i < container[0].children.length; i++) {
						if (!arr.includes(container[0].children[i].style.top)) {
							arr.push(container[0].children[i].style.top);
						}
					}

					for (var j = 0; j < arr.length; j++) {
						var textV = document.createElement("div");
						textV.style.fontSize = "12px";
						textV.style.paddingLeft = "4px";
						var text = "";
						for (var k = 0; k < container[0].children.length; k++) {
							if (arr[j] == container[0].children[k].style.top) {
								text = text + " " + container[0].children[k].innerText;
							}
						}
						textV.append(text);
						textBody.appendChild(textV);
					}
					var containerHTML = jQuery("<div />");
					textBody.style = "width: 581.4px;";
					containerHTML[0].appendChild(textBody);
					var html = containerHTML[0].innerHTML;
					that.mytxt = html;
					// if (!container[0].children.length) {
					// 	that.mytxt = container[0].innerText;
					// }
					// if (that.mytxt !== "") {
					// 	if (that._oCListDialog) {
					// 		that._oCListDialog.destroy();
					// 	}
					// 	that._oCListDialog = sap.ui.xmlfragment(that.getView().getId(), "cmiamendmentnew.fragments.CategoriesList", that);
					// 	that._oCListDialog.open();
					// 	that.getView().byId("idCategoriesList").setModel(that.getView().getModel("jsonAmendOcgModel"), "jsonAmendOcgModel");
					// }

				}, false);
			});
		},
		handleClientInDetails: function() {
			// var data = this.getModel("TempModel").getData();
			var obj = {
				"Clientk": "",
				"Client": "",
				"Vkorg": "",
				"Vkorgdesc": "",
				"Cmino": this._Cmino,
				"Msgfn": "",
				"Langu": "",
				"Land1": "",
				"Sptxt": "",
				"Kukla": "",
				"Kukladesc": "",
				"Zzclntgrp": "",
				"Zzglobalultimate": "",
				"Zzdunsnumber": "",
				"Zzopendate": null,
				"Zzoutput": "",
				"Zzexpcodeset": "",
				"Zzexpcodedesc": "",
				"Zzcolco": "",
				"Zzcolcot": "",
				"Zzpriconf": "",
				"Zzpriconft": "",
				"Stcd1": "",
				"Stcd2": "",
				"Stcd3": "",
				"Stcd4": "",
				"Stcd5": "",
				"Stceg": "",
				"Stcd1v": "",
				"Stcd2v": "",
				"Stcd3v": "",
				"Stcd4v": "",
				"Stcd5v": "",
				"Stcegv": "",
				"Auth": "",
				"Zzownoffice": "",
				"Zzenddt": null,
				"Zzengpar": "",
				"Zzengpoff": "",
				"Zzclntoff": "",
				"Zzbustype": "",
				"Zzassgntyp": "",
				"Zzstatus": "",
				"Zzestwork": "",
				"ZzYrEmon": "",
				"Txjcd": "",
				"Txjcddesc": "",
				"Udmbp": "",
				"Etag": "",
				"Zzclnttradeas": "",
				"Zzsiccd": "",
				"Zzsiccddesc": "",
				"Zzvatvaldt": null,
				"Zzclosedate": null,
				"Zzclntprg": "",
				"Zzclntprgdesc": "",
				"Zzebillvendor": "",
				"Zzporqrd": "",
				"Zzsanction": "",
				"Zzphaseset": "",
				"Zzactset": "",
				"Zzphasesetdesc": "",
				"Zzactsetdesc": "",
				"Zzphbegda": null,
				"Zzactbegda": null,
				"Name1": "",
				"Line1": "",
				"Line2": "",
				"Line3": "",
				"Line4": "",
				"Phone": "",
				"Fax": "",
				"Email": "",
				"AddressNote": "",
				"Iname1": "",
				"Iline1": "",
				"Iline2": "",
				"Iline3": "",
				"Iline4": "",
				"Zzdrftformat": "",
				"Zzfnalformat": "",
				"Dbvtext": "",
				"Fbvtext": "",
				"Zztmdtl": "",
				"Zztksumry": "",
				"Zzcstdtsumry": "",
				"Tdtext": "",
				"Tstext": "",
				"Cdtext": "",
				"Zzpageno": "",
				"Zzsumwo": "",
				"Zzremit": ""
			};

			return obj;
		},

		onPostCommnets: function(evt) {

			var cType = "CI";

			var text = evt.getParameter("value"),
				userId = this.getModel("AmendmentViewMod").getProperty("/userId"),
				name = this.getModel("AmendmentViewMod").getProperty("/userName"),
				obj = {
					Cmino: this._Cmino,
					CommentType: cType,
					Sequence: "",
					UserComment: text,
					Addedby: name,
					Addedbyk: userId,
					Addedon: new Date()
				};
			var oRemarks = this.getView().getModel("CommentsModel"),
				oRemarkData = oRemarks.getProperty("/CommentSet");
			oRemarkData.push(obj);
			oRemarks.setProperty("/CommentSet", oRemarkData);
			this.onFilterComments(cType);
			if (this._oCommentsForSteps) {
				this._oCommentsForSteps.close();
			}

		},
		onFilterComments: function(val) {
			var cType = "CI",
				aFilters = [],
				oFilterCommentType = new sap.ui.model.Filter("CommentType", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oList = this.getView().byId("idCommentsList"),
				oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		handleDeleteComments: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oItmSel.getBindingContext("CommentsModel").getObject().Sequence;
			oTable.getModel("CommentsModel").getProperty("/CommentSet").splice(ind, 1);
			oTable.getModel("CommentsModel").refresh();
		},
		OnpressSubmit: function(oEvt) {
			var src = oEvt.getSource(),
				ActionCode = src.data().ActionCode;
			this.postCmiData(ActionCode);
		},
		OnpressSave: function(oEvt) {
			var src = oEvt.getSource(),
				ActionCode = src.data().ActionCode;
			this.postCmiData(ActionCode);
		},
		_readpostData: function(ActionCode) {
			var oModel = this.getOwnerComponent().getModel(),
				oBusy = new sap.m.BusyDialog();

			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var dateTimeFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddhhmmss"
			});

			var CMIMod = this.getModel("jsonAmendModel"),
				clientData = CMIMod.getData(),
				clientdata = this.getView().byId("ClientContactTable"),
				ClntConItems = clientdata.getItems(),
				ContData = [],
				that = this;
			ClntConItems.forEach(function(i, ind, arr) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.Firstname) {
					var sdata = {
						"Cmino": that._Cmino,
						"Contactseq": that.formatter.sequenceNumber(ind + 1),
						"Firstname": odata.Firstname,
						"Contacttype": odata.Contacttype,
						"Contacttypedesc": odata.Contacttypedesc,
						"Phone": odata.Phone,
						"Email": odata.Email,
						"Clientk": clientData.Clientk,
						"Function": odata.Function,
						"Lastname": odata.Lastname,
						"Functiondesc": odata.Functiondesc,
						"Partnertype": odata.Partnertype
					};
					ContData.push(sdata);
				}
			});
			var Lpdata = this.getView().byId("LeadPartnerTbl"),
				LPItems = Lpdata.getItems(),
				LPDataObj = [];
			LPItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata1 = o.getObject();
				if (odata1.Office) {
					var sdata1 = {
						"Cmino": that._Cmino,
						"Rank": odata1.Rank,
						"Officek": odata1.Officek,
						"Office": odata1.Office,
						"Leadpartnerk": odata1.Leadpartnerk,
						"Leadpartner": odata1.Leadpartner,
						"Phone": odata1.Phone,
						"Email": odata1.Email,
						"Firstname": odata1.Firstname,
						"Lastname": odata1.Lastname,
						"Percentage": odata1.Percentage,
						"Parvw": odata1.Parvw,
						"Parvwdesc": odata1.Parvwdesc,
						"Partnertype": odata1.Partnertype
					};
					LPDataObj.push(sdata1);
				}
			});

			// var CWDTax = this.getView().byId("FormChange354WD"),
			// 	CWDTaxItems = CWDTax.getItems(),
			// 	CWDTaxData = [];

			// CWDTaxItems.forEach(function(i, o) {
			// 	var o = i.getBindingContext(),
			// 		odata = o.getObject();
			// 	if (odata.Agtdf !== null) {
			// 		if (typeof(odata.Agtdf) !== "string") {
			// 			odata.Agtdf = dateFormat.format(odata.Agtdf) + "T00:00:00";
			// 		} else {
			// 			odata.Agtdf = odata.Agtdf + "T00:00:00";
			// 		}
			// 	} else {
			// 		odata.Agtdf = null;
			// 	}
			// 	if (odata.Agtdt !== null) {
			// 		if (typeof(odata.Agtdt) !== "string") {
			// 			odata.Agtdt = dateFormat.format(odata.Agtdt) + "T00:00:00";
			// 		} else {
			// 			odata.Agtdt = odata.Agtdt + "T00:00:00";
			// 		}
			// 	} else {
			// 		odata.Agtdt = null;
			// 	}
			// 	// if(odata.Name){
			// 	var sdata1 = {
			// 		"Cmino": that._Cmino,
			// 		"Witht": odata.Witht,
			// 		"Withcd": odata.Withcd,
			// 		"Text40": odata.Text40,
			// 		"Agent": odata.Agent,
			// 		"Agtdf": odata.Agtdf,
			// 		"Agtdt": odata.Agtdt

			// 	};
			// 	CWDTaxData.push(sdata1);
			// 	// }
			// });

			// var CBP = this.getView().byId("handleCellClickChgBPBP"),
			// 	CBPItems = CBP.getItems(),
			// 	CBPData = [];

			// CBPItems.forEach(function(i, o) {
			// 	var o = i.getBindingContext(),
			// 		odata = o.getObject();
			// 	// if(odata.Name){
			// 	var sdata1 = {
			// 		"Cmino": that._Cmino,
			// 		"Parvw": odata.Parvw,
			// 		"Parvwdesc": odata.Parvwdesc,
			// 		"Parnr": odata.Parnr,
			// 		"Client": odata.Client,
			// 		"Addr1": odata.Addr1,
			// 		"Bpseq": odata.Bpseq

			// 	};
			// 	CBPData.push(sdata1);
			// 	// }
			// });
			var CMIMod = this.getModel("jsonAmendModel"),
				clientData = CMIMod.getData();
			clientData.Clientcontacts = null;
			clientData.Clientcontacts = ContData;
			clientData.Leadpartners = null;
			clientData.Leadpartners = LPDataObj;
			clientData.Clientbp = [];
			// clientData.Clientbp = CBPData;
			clientData.Wtax = [];
			// clientData.Wtax = CWDTaxData;
			clientData.Clientcorrespondence = [];

			if (!clientData.Matters.results) {
				clientData.Matters = [];
			} else {
				for (var i = 0; i < clientData.Matters.results.length; i++) {
					delete(clientData.Matters.results[i].__metadata);
				}
				clientData.Matters = clientData.Matters.results;
			}
			if (!clientData.Clients.results) {
				clientData.Clients = [];
			} else {
				for (var j = 0; j < clientData.Clients.results.length; j++) {
					delete(clientData.Clients.results[j].__metadata);
				}
				clientData.Clients = clientData.Clients.results;
			}
			var ocgsdata = [];
			if (!clientData.Ocgs.results) {
				// clientData.Ocgs = [];
			} else {
				for (var k = 0; k < clientData.Ocgs.results.length; k++) {
					delete(clientData.Ocgs.results[k].__metadata);
					clientData.Ocgs.results[k].Filecontent = "";
					clientData.Ocgs.results[k].Uploadeddate = null;
					clientData.Ocgs.results[k].Ostatusk = clientData.Ocgs.results[k].Ostatusk.toString();
					// delete(clientData.Ocgs.results[k].OcgTerms.__metadata);
					for (var oc = 0; oc < clientData.Ocgs.results[k].OcgTerms.length; oc++) {
						delete(clientData.Ocgs.results[k].OcgTerms[oc].__metadata);
					}
				}
				ocgsdata = clientData.Ocgs.results;
			}
			if (!clientData.Knownparties.results) {
				clientData.Knownparties = [];
			} else {
				for (var l = 0; l < clientData.Knownparties.results.length; l++) {
					delete(clientData.Knownparties.results[l].__metadata);
				}
				clientData.Knownparties = clientData.Knownparties.results;
			}
			if (!clientData.Altpayers.results) {
				clientData.Altpayers = [];
			} else {
				for (var m = 0; m < clientData.Altpayers.results.length; m++) {
					delete(clientData.Altpayers.results[m].__metadata);
				}
				clientData.Altpayers = clientData.Altpayers.results;
			}
			if (!clientData.Offices.results) {
				clientData.Offices = [];
			} else {
				for (var n = 0; n < clientData.Offices.results.length; n++) {
					delete(clientData.Offices.results[n].__metadata);
				}
				clientData.Offices = clientData.Offices.results;
			}
			if (!clientData.Matterdetails.results) {
				clientData.Matterdetails = [];
			} else {
				for (var o = 0; o < clientData.Matterdetails.results.length; o++) {
					delete(clientData.Matterdetails.results[o].__metadata);
				}
				clientData.Matterdetails = clientData.Matterdetails.results;
			}

			if (!clientData.Clientdetails.results) {
				clientData.Clientdetails = [];
			} else {
				for (var q = 0; q < clientData.Clientdetails.results.length; q++) {
					delete(clientData.Clientdetails.results[q].__metadata);
				}
				clientData.Clientdetails = clientData.Clientdetails.results;
			}
			// if (!clientData.Clientcorrespondence.results) {
			// 	clientData.Clientcorrespondence = [];
			// } else {
			// 	for (var p = 0; p < clientData.Clientcorrespondence.results.length; p++) {
			// 		delete(clientData.Clientcorrespondence.results[p].__metadata);
			// 	}
			// 	clientData.Clientcorrespondence = clientData.Clientcorrespondence.results;
			// }
			var AttachData = this.getModel("AttachmentModel").getProperty("/FileDataSet");
			for (var c = 0; c < AttachData.length; c++) {
				AttachData[c].Cmino = that._Cmino;
				AttachData[c].Filecontent = "";
				AttachData[c].Clientk = clientData.Clientk;
				delete(AttachData[c].__metadata);
				delete(AttachData[c].url);
			}

			if (!clientData.ConsiderationsN.results) {
				clientData.ConsiderationsN = [];
			} else {
				for (var cn = 0; cn < clientData.ConsiderationsN.results.length; cn++) {
					delete(clientData.ConsiderationsN.results[cn].__metadata);
				}
				clientData.ConsiderationsN = clientData.ConsiderationsN.results;
			}
			var commentData = this.getModel("CommentsModel").getProperty("/CommentSet");
			for (var co = 0; co < commentData.length; co++) {
				commentData[co].Cmino = that._Cmino;

				commentData[co].Addedon = typeof(commentData[co].Addedon) === "string" ? commentData[co].Addedon : dateTimeFormat.format(
					commentData[co].Addedon);
				delete(commentData[co].__metadata);

				// if (commentData[co].Addedon !== null) {
				// 		if (typeof(commentData[co].Addedon) !== "string") {
				// 			commentData[co].Addedon = dateFormat.format(commentData[co].Addedon) +
				// 				"T00:00:00";
				// 		} else {
				// 			commentData[co].Addedon = commentData[co].Addedon + "T00:00:00";
				// 		}

				// 	} else {
				// 		commentData[co].Addedon = null;
				// 	}

			}
			// Date Formating 

			var userId = parent.sap.ushell.Container.getUser().getId(),
				LName = parent.sap.ushell.Container.getUser().getLastName(),
				FName = parent.sap.ushell.Container.getUser().getFirstName(),
				userName = FName + " " + LName;
			var clientData1 = {
				Action: ActionCode,
				Cmino: this._Cmino,
				Clientk: clientData.Clientk,
				Matterk: clientData.Matterk,
				Requestuserk: clientData.Requestuserk,
				Requestuser: clientData.Requestuser,
				Requesttime: clientData.Requesttime,
				Cmirequesttype: "CA",
				Changedbyk: userId,
				Changedby: userName,
				Changedtime: "0",
				Clients: clientData.Clients,
				Clientcontacts: ContData,
				Leadpartners: LPDataObj,
				Knownparties: clientData.Knownparties,
				Matters: clientData.Matters,
				Altpayers: clientData.Altpayers,
				Ocgs: clientData.Ocgs,
				ConsiderationsN: clientData.ConsiderationsN,
				Matterdetails: clientData.Matterdetails,
				Comments: commentData,
				Offices: clientData.Offices,
				Clientdetails: clientData.Clientdetails,
				Clientcorrespondence: clientData.Clientcorrespondence,
				Clientbp: clientData.Clientbp,
				Wtax: clientData.Wtax,
				Documents: AttachData
			};
			return clientData1;
		},
		postCmiData: function(ActionCode) {
			var oModel = this.getOwnerComponent().getModel(),
				oBusy = new sap.m.BusyDialog();
			
			var that = this;
			
			// leadpartner per alloction validation
			if(ActionCode !=="Step"){
	var validLP = that.checkValidationforLPAllocation();
   if (validLP) {
    var msgClient = "";
    if (validLP === "Error") {
     msgClient = that.getResourceBundle().getText("manClientpartner");
    } else {
     msgClient = that.getResourceBundle().getText("clientAllocationPerct");
    }
    sap.m.MessageBox.show(msgClient, {
     icon: sap.m.MessageBox.Icon.ERROR,
     title: "Error",
     actions: [sap.m.MessageBox.Action.OK]
    });
    return;
   }
			}
		oBusy.open();
			var clientData = that._readpostData(ActionCode);
			oModel.create("/Cmihdrs", clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var sMsg;
					if (oData.Action === "Step") {
						that.setCmino = true;
						var sObjectPath = that.getModel().createKey("Cmihdrs", {
							Cmino: oData.Cmino,
							Clientk: oData.Clientk,
							Cmirequesttype: oData.Cmirequesttype,
							Matterk: oData.Matterk
						});
						that._bindView("/" + sObjectPath);
					} else {

						if (oData.Action === "SUBM") {
							sMsg = that.getResourceBundle().getText("ClientAmendSubmitMsg", oData.Cmino);
						} else {
							sMsg = that.getResourceBundle().getText("ClientAmendSucessMsg", oData.Cmino);
						}
						sap.m.MessageBox.show(sMsg, {
							icon: "SUCCESS",
							title: "Success",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function() {
								that.setCmino = true;
								var sObjectPath = that.getModel().createKey("Cmihdrs", {
									Cmino: oData.Cmino,
									Clientk: oData.Clientk,
									Cmirequesttype: oData.Cmirequesttype,
									Matterk: oData.Matterk
								});
								that._bindView("/" + sObjectPath);

							}
						});
					}

				},
				error: function(oData, oResponse) {
					oBusy.close();
					// var obj = oData.responseText;
					// var msg = obj.error.message.value;
					var msg = oData.message;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},

		onPressContactComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oEvt = evt.getSource();
			var sPath = oEvt.getBindingContext("jsonAmendModel").sPath;
			if (!this.ContactComment) {
				this.ContactComment = sap.ui.xmlfragment("cmiamendmentnew.fragments.ContactComment", this);
				oView.addDependent(this.ContactComment);
			}
			//		this.ContactComment.setBindingContext(oEvt.getBindingContext());
			//	this.ContactComment.bindElement(sPath);
			this.ContactComment.bindElement("jsonAmendModel>" + sPath);
			// jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPNotes);
			this.ContactComment.openBy(evt.getSource());
		},
		_amendmentRequestDialog: function(data) {
			var oViewModel = this.getModel("AmendmentViewMod");
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.AmendmentRequest", this);
			var oModel = this.getOwnerComponent().getModel();
			// var Rid = this.byId("radioBtnGrpId");
			if (!data) {
				oViewModel.setProperty("/RadioCA", true);
				oViewModel.setProperty("/RadioMA", false);
				oViewModel.setProperty("/clientVisiable", true);
				oViewModel.setProperty("/matterVisiable", false);
			} else {
				if (data.Request === "MA") {
					oViewModel.setProperty("/RadioCA", false);
					oViewModel.setProperty("/RadioMA", true);
					oViewModel.setProperty("/clientVisiable", false);
					oViewModel.setProperty("/matterVisiable", true);

				} else {
					oViewModel.setProperty("/RadioCA", true);
					oViewModel.setProperty("/RadioMA", false);
					oViewModel.setProperty("/clientVisiable", true);
					oViewModel.setProperty("/matterVisiable", false);
				}
			}

			oModel.metadataLoaded().then(function() {
				var ClientList = this.byId("idClientList");
				var oContextClientList = oModel.createEntry("/Cmiclients", {
					properties: {
						Client: "",
						Clientk: ""
					}
				});
				ClientList.setBindingContext(oContextClientList);
			}.bind(this));
			oModel.metadataLoaded().then(function() {
				var MatterList = this.byId("idMatterList");
				var oContextlMatterList = oModel.createEntry("/Cmimatters", {
					properties: {
						Matter: "",
						Mattername: ""
					}
				});
				MatterList.setBindingContext(oContextlMatterList);
			}.bind(this));
			this.getView().addDependent(this._oDialog);
			this._oDialog.open();
		},

		onSelect: function(oEvent) {
			var oViewModel = this.getModel("AmendmentViewMod"),
				pSelectedText = oEvent.getSource().getText(),
				oComboBoxClient = this.getView().byId("idClientList"),
				oComboBoxMatter = this.getView().byId("idMatterList");
			if (pSelectedText === "Client") {
				oViewModel.setProperty("/clientVisiable", true);
				oViewModel.setProperty("/matterVisiable", false);
			} else {
				oViewModel.setProperty("/clientVisiable", false);
				oViewModel.setProperty("/matterVisiable", true);
			}
			oViewModel.setProperty("/btnEnabled", false);
			// oComboBoxClient.setSelectedKey("");
			// oComboBoxMatter.setSelectedKey("");

		},
		onChangeClient: function(oEvent) {
			var idLeadPartner = this.byId("idClientList"),
				objLead = idLeadPartner.getBindingContext().getModel(),
				path = idLeadPartner.getBindingContext().getPath();
			objLead.setProperty(path + "/Client", oEvent.getSource().getValue());
			var oModel = this.getModel("AmendmentViewMod");
			oModel.setProperty("/btnEnabled", true);
		},
		onChangeMatter: function(oEvent) {

			var idMatterList = this.byId("idMatterList"),
				objLead = idMatterList.getBindingContext().getModel(),
				path = idMatterList.getBindingContext().getPath();
			objLead.getProperty(path + "/Mattername", oEvent.getSource().getValue());
			var oModel = this.getModel("AmendmentViewMod");
			oModel.setProperty("/btnEnabled", true);
		},
		onSubmitDialog: function(oEvt) {
			var oModel = this.getOwnerComponent().getModel();
			// var oModel = this.getView().getModel("jsonAmendModel");
			var oViewModel = this.getModel("AmendmentViewMod"),
				vBool = oViewModel.getProperty("/clientVisiable");
			// var sPath = encodeURIComponent(this.oPath);
			this.getView().setBusy(true);
			if (!vBool) {
				var idMatterList = this.byId("idMatterList"),
					objLead = idMatterList.getBindingContext().getModel(),
					path = idMatterList.getBindingContext().getPath(),
					CmiNo = objLead.getProperty(path + "/Cmino"),
					Matterk = objLead.getProperty(path + "/Matter");
				this.getRouter().navTo("MatterAmendment", {
					Matterk: Matterk,
					isEditable: "2",
					bInbox: "1"
				}, true);
			} else {
				// this.getRouter().navTo("Amendment", {}, true);
				var idClientData = this.byId("idClientList"),
					objLead1 = idClientData.getBindingContext().getModel(),
					path1 = idClientData.getBindingContext().getPath(),
					cdata1 = objLead1.getProperty(path1 + "/Clientk");
				var CliValue = this.byId("idClientList").getValue();
				oViewModel.setProperty("/ClientName", CliValue);

				this._onObjectMatched1(cdata1);
			}
			// oModel.refresh();
			this._oDialog.close();
			oViewModel.setProperty("/busy", false);
			this.getView().setBusy(false);
		},
		onCloseDialog: function() {
			this._oDialog.close();
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.backToPreviousApp();
		},
		onCloseUploadDialog: function() {
			this._oDialog.close();
		},
		handleEditBtnPress: function() {
			var oViewModel = this.getModel("AmendmentViewMod"),
				flag = oViewModel.getProperty("/isEditable");
			if (flag) {
				oViewModel.setProperty("/isEditable", false);
			} else {
				oViewModel.setProperty("/isEditable", true);
			}
			// var oViewModel = this.getModel("AmendmentViewMod");

		},
		handleDeleteTerms: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem");
			oTable.removeItem(oItmSel);
			// var ind = oTable.indexOfItem(oItmSel);
			// oTable.getModel("jsonAmendModel").getProperty("/AddTerms").splice(ind, 1);
			oTable.getModel("jsonAmendModel").refresh();
		},
		onAddTerms: function(oEvt) {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment("cmiamendmentnew.fragments.UploadTerms", this);
			this.getView().addDependent(this._oDialog);
			this._oDialog.open();
		},
		onCListDialogClose: function() {
			this._oCListDialog.close();
		},
		onChange: function(oEvent) {
			var files = oEvent.getParameter("files")[0],
				obj = {
					"AttachmentNo": files.lastModified,
					"FileName": files.name,
					"MimeType": files.type,
					"url": "https://",
					"DocumentTitle": files.name,
					"Date": files.lastModified,
					"Status": "Pending",
					"FileSize": "19.68 KB"

				},
				oModel = this.getView().getModel("jsonAmendModel"),
				oData = oModel.getProperty("/AddTerms");
			oData.push(obj);
			oModel.refresh();
		},
		onAddTermsDialog: function() {
			var oViewModel = this.getModel("AmendmentViewMod"),
				oModel = this.getView().getModel("jsonAmendModel"),
				oData = oModel.getProperty("/AddTerms");
			this.obj.DocumentTitle = oViewModel.getProperty("/TermTitle");
			oData.push(this.obj);
			oModel.refresh();
			this.getModel("AmendmentViewMod").setProperty("/TermTitle", "");
			this._oDialog.close();
		},

		onShowHideClientDetail: function(evt) {
			var oViewModel = this.getModel("AmendmentViewMod");
			if (evt.getSource().getPressed()) {
				oViewModel.setProperty("/headerTrueFalse", false);
				oViewModel.setProperty("/headerIcon", false);
				oViewModel.setProperty("/tooltipText", "show");
			} else {
				oViewModel.setProperty("/headerTrueFalse", true);
				oViewModel.setProperty("/headerIcon", true);
				oViewModel.setProperty("/tooltipText", "Hide");
			}
		},

		getGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.key,
				upperCase: false
			});
		},
		//-------------------------------- Start File Upload------------------------------------------------------------------------------//

		onAttachmentChange: function(oEvent) {
			// debugger;
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			for (var i = 0; i < oEvent.mParameters.files.length; i++) {
				this.ContentData = oEvent.mParameters.files[i];
				// var cmiNo = this.getModel("AmendmentViewMod").getProperty("/CmiId");
				//	var cmiNo = "1000000036";
				var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
					name: "slug",
					value: this._Cmino + "|" + oEvent.mParameters.files[i].name + "|" + oEvent.mParameters.files[i].size
				});
				oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
			}
		},
		onUploadTerminated: function(oEvent) {

			oEvent.getSource().bindAggregation("items", "/results", new sap.m.UploadCollectionItem({
				documentId: "{AttachmentNo}",
				fileName: "{Filename}",
				url: "{url}",
				enableDelete: true,
				visibleEdit: false
			}));
		},
		onUploadComplete: function(oEvent) {
			if (oEvent.getParameter("files")[0].status === 201) {
				this._UploadA.close();
				this.byId("submitTerm").setEnabled(true);
				this.OcgData = {};
				var sUploadedFile = oEvent.getParameter("files")[0].fileName,
					response = oEvent.getParameter("files")[0].responseRaw,
					resJson = xmlToJSON.parseString(response);
				this.OcgData.Cmino = this._Cmino;
				this.OcgData.Cmiocgseq = resJson.entry[0].properties[0].Cmiocgseq[0]._text;
				this.OcgData.Ostatusk = resJson.entry[0].properties[0].Ostatusk[0]._text;
				this.OcgData.Ostatus = resJson.entry[0].properties[0].Ostatus[0]._text;
				this.OcgData.Filename = resJson.entry[0].properties[0].Filename[0]._text;
				this.OcgData.Filesize = String(resJson.entry[0].properties[0].Filesize[0]._text);
				this.OcgData.Uploadeddate = resJson.entry[0].properties[0].Uploadeddate[0]._text;
				this.OcgData.Uploadedbyk = resJson.entry[0].properties[0].Uploadedbyk[0]._text;
				this.OcgData.Uploadedby = resJson.entry[0].properties[0].Uploadedby[0]._text;
				this.OcgData.Filecontent = resJson.entry[0].properties[0].Filecontent[0]._text;
				this.byId("idListImportedTerms").destroyItems();
				this.byId("idZoomin").setEnabled(true);
				this.byId("idZoomOut").setEnabled(true);
				this.byId("idFullOut").setEnabled(true);
				//
				//	this.displayOcgsList();
				var fileData = this.ContentData;
				var buf = function getBuffer(resolve) {
					var reader = new FileReader();
					reader.readAsBinaryString(fileData);
					reader.onload = function() {
						var arrayBuffer = reader.result;
						resolve(arrayBuffer);
					};
				};
				var that = this;
				var promise = new Promise(buf);
				// Wait for promise to be resolved, or log error.
				promise.then(function(data) {
					var base64 = btoa(data);
					that.onAddTermReview(base64, 1.3);
				}).catch(function(err) {});

			} else {
				var erresponse = oEvent.getParameter("files")[0];
				if (erresponse.responseRaw) {
					var resText = xmlToJSON.parseString(erresponse.responseRaw);
					var errmessage = resText.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		onTypeMissmatch: function() {
			var errmessage = "Allowed file types are : PDF, DOC, DOCX, XLX, XLSX, JPEG, GIF, TIF MP4";
			sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
		},

		onTermReviewPress: function() {
			this.attachEdit = false;
			this.addDocument = true;
			// var that = this;
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.TermReviews", this);
			this.getView().addDependent(this._oDialog);
			// this.byId("ID_FRAME").setVisible(false);
			this.getModel("AmendmentViewMod").setProperty("/editTerm", false);
			this.getModel("AmendmentViewMod").setProperty("/editButtonSubmit", false);
			this.byId("idZoomin").setEnabled(false);
			this.byId("idZoomOut").setEnabled(false);
			this.byId("idFullOut").setEnabled(false);
			var $pdfContainer = jQuery("#pdfContainer");
			if ($pdfContainer) {
				$pdfContainer.empty();
				$pdfContainer.css("height", "0px").css("width", "0px");
			}
			this._oDialog.open();

		},

		onDialogClose: function() {
			this._oDialog.close();
		},

		onListItemPress: function(oEvent) {
			var that = this,
				sCategoryText = oEvent.getParameters().listItem.getTitle(),
				oContextTerm = oEvent.getParameters().listItem.getBindingContext("jsonAmendOcgModel"),
				aImportedTermsList = this.getView().byId("idListImportedTerms").getItems(),
				qtc = this.getModel(),
				obj = oContextTerm.getObject();
			if (!sCategoryText.trim()) {
				return;
			}
			for (var i = 0; i < aImportedTermsList.length; i++) {
				if ("Category: " + sCategoryText === aImportedTermsList[i].getContent()[0].getHeaderToolbar().getContent()[0].getText()) {
					// sap.m.MessageToast.show(sCategoryText + " Already Exists");
						sap.m.MessageBox.show(sCategoryText + " Already Exists", sap.m.MessageBox.Icon.INFORMATION, "Information");
					return;
				}
				this.getView().byId("idListImportedTerms").getItems()[i].getContent()[0].setExpanded(false);
			}
			var oContext = qtc.createEntry("/Cmiocgterms", {
				properties: {
					"Categoryid": obj.Categoryid,
					"CategoryidDesc": obj.CategoryidDesc,
					"Subcategoryid": obj.Subcategoryid,
					"SubcategoryidDesc": obj.SubcategoryidDesc,
					"Status": ""
				}
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.Panel({
					expandable: true,
					expanded: true,
					width: "auto",
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Title({
								text: "Category: " + sCategoryText
							}),
							new sap.m.ToolbarSpacer(),
							new sap.m.Button({
								tooltip: "Delete Item",
								icon: "sap-icon://sys-cancel",
								press: function(oEvt) {
									that.onITDeletePress(oEvt);
								}
							})
						]
					}),
					content: [
						/*	new sap.m.TextArea({
								growing: true,
								width: "100%",
								value: this.mytxt
							}),*/
						new sap.ui.richtexteditor.RichTextEditor({
							editorType: sap.ui.richtexteditor.EditorType.TinyMCE4,
							width: "100%",
							height: "200px",
							customToolbar: false,
							showGroupFont: false,
							showGroupStructure: false,
							showGroupFontStyle: false,
							showGroupClipboard: false,
							showGroupTextAlign: false,
							tooltip: "My RTE Tooltip",
							value: this.mytxt
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Text({
									text: "{Status}"
								}),
								new sap.m.Button({
									icon: "sap-icon://save",
									type: "Emphasized",
									text: "Submit",
									enabled: {
										parts: [{
											path: 'Status'
										}, {
											path: 'AmendmentViewMod>/isEditable'
										}, {
											path: 'AmendmentViewMod>/editButtonSubmit'
										}],
										formatter: formatter.checkStatusSave
									},
									press: function(oEvt) {
										that.onSubmitPress(oEvt);
									}
								}).addStyleClass("sapUiTinyMarginBegin")
							]
						}).addStyleClass("sapUiTinyMargin")
					]
				}).addStyleClass("sapUiNoContentPadding")
			}).setBindingContext(oContext);
			this.getView().byId("idListImportedTerms").addItem(oCustomListItem);
			this.mytxt = "";
			that._oCListDialog.close();
		},
		onITDeletePress: function(oEvent) {
			var that = this,
				DelItemTxt = that.getResourceBundle().getText("DelItemTxt"),
				sPanelHeaderText = oEvent.getSource().getParent().getContent()[0].getText();
			var dialog = new sap.m.Dialog({
				title: "Confirm",
				type: "Message",
				content: new sap.m.Text({
					text: DelItemTxt + sPanelHeaderText + "?"
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {
						that.onITDeleteDialogOK(sPanelHeaderText);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onITDeleteDialogOK: function(sPanelHeaderText) {
			var that = this,
				aImportedTermsList = that.getView().byId("idListImportedTerms").getItems();

			for (var i = 0; i < aImportedTermsList.length; i++) {
				if (sPanelHeaderText === aImportedTermsList[i].getContent()[0].getHeaderToolbar().getContent()[0].getText()) {
					aImportedTermsList.splice(i, 1);
				}
			}

			that.getView().byId("idListImportedTerms").removeAllItems();
			for (i = 0; i < aImportedTermsList.length; i++) {
				that.getView().byId("idListImportedTerms").addItem(aImportedTermsList[i]);
			}
		},

		onSubmitPress: function(oEvent) {
			//	var sPanelHeaderText = oEvent.getSource().getParent().getParent().getHeaderToolbar().getContent()[0].getText();
			//	sap.m.MessageToast.show(sPanelHeaderText + " submit button pressed");
			var cmiNo = this._Cmino;
			var data = oEvent.getSource().getBindingContext().getObject();
			var oModel = this.getModel();
			var oSource = oEvent.getSource();
			var oSModel = oSource.getBindingContext().getModel();
			var sPath = oSource.getBindingContext().sPath;
			var that = this,
				msg, status, statusk;
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: (data.Subcategoryid || data.Termitemk),
						Termhdrk: (data.Categoryid || data.Termhdrk),
						Cmino: cmiNo,
						Cmiocgsequence: String(that.OcgData.Cmiocgseq)
					},
					success: function(oData, response) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									msg = oData.results[0].Message;
									if (msg.indexOf("|") !== -1) {
										statusk = msg.split("|")[0];
										status = msg.split("|")[1];
										// sap.m.MessageToast.show(status);
											sap.m.MessageBox.show(status, sap.m.MessageBox.Icon.INFORMATION, "Information");
										oSModel.setProperty(sPath + "/Statusk", statusk);
										oSModel.setProperty(sPath + "/Status", status);
									}
									that.onSubmitAddTermsDialog("WF");
								}
							} else {
								// sap.m.MessageToast.show("");
								sap.m.MessageBox.show("", sap.m.MessageBox.Icon.INFORMATION, "Information");
							}
						} else {
							// sap.m.MessageToast.show("");
							sap.m.MessageBox.show("", sap.m.MessageBox.Icon.INFORMATION, "Information");
						}

					},
					error: function(oError) {}
				});

		},
		onSubmitTerms: function(oEvent) {
			var cmiNo = this._Cmino,
				data = oEvent.getSource().getBindingContext("jsonAmendModel").getObject(),
				oModel = this.getModel(),
				oSource = oEvent.getSource(),
				oSModel = oSource.getBindingContext("jsonAmendModel").getModel(),
				sPath = oSource.getBindingContext("jsonAmendModel").getPath(),
				msg, status, statusk;
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: "",
						Termhdrk: "",
						Cmino: cmiNo,
						Cmiocgsequence: data.Cmiocgseq
					},
					success: function(oData, response) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									msg = oData.results[0].Message;
									if (msg.indexOf("|") !== -1) {
										statusk = msg.split("|")[0];
										status = msg.split("|")[1];
										// sap.m.MessageToast.show(status);
										sap.m.MessageBox.show(status, sap.m.MessageBox.Icon.INFORMATION, "Information");
										oSModel.setProperty(sPath + "/Ostatus", status);
										oSModel.setProperty(sPath + "/Ostatusk", statusk);
									}
									oSModel.setProperty(sPath + "/Uploadeddate", new Date());
									oSModel.refresh();

								}

							} else {
								// sap.m.MessageToast.show("");
									sap.m.MessageBox.show("", sap.m.MessageBox.Icon.INFORMATION, "Information");
							}
						} else {
							// sap.m.MessageToast.show("");
								sap.m.MessageBox.show("", sap.m.MessageBox.Icon.INFORMATION, "Information");
						}
					},
					error: function(oError) {}
				});
		},

		// Billing Partner table 
		bindBillingPartner: function() {
			var idBillPartenr = this.byId("handleCellClickChgBPBP");
			idBillPartenr.destroyItems();

			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that._Cmino,
					"Parvwdesc": "",
					"Parnr": "",
					"Partnername": "",
					"Clientk": "",
					"Vkorgdesc": "",
					"Vkorg": "",
					"Parvw": "",
					"Bpseq": "",
					"Msgfn": "",
					"Vtext": "",
					"Client": "",
					"Addr1": "",
					"Addr2": "",
					"Phone": "",
					"Cityk": "",
					"State": "",
					"Statek": "",
					"Zip": "",
					"Countryk": "",
					"Country": ""
				};
				objArray.push(obj);
				var aBPartner = that.getModel("jsonAmendModel").getProperty("/Clientbp/results");
				data = aContact.concat(objArray, aBPartner);
				var qtc = that.getModel();
				for (var k = 0; k < data.length; k++) {
					// var qtc = that.getModel();
					var oContextWOFC = qtc.createEntry("/CmiclientBP", {
						properties: data[k]
					});
					that.bindBillPartnerTable(oContextWOFC);
				}
			});

		},
		onAddBusinessPartner: function() {
			var that = this,
				objArray = [],
				// var aBusinessPartner = that.getModel("jsonAmendModel").getProperty("/Cllientbp");
				qtc = that.getModel(),
				obj = {
					"Cmino": that._Cmino,
					"Parvwdesc": "",
					"Parnr": "",
					"Partnername": "",
					"Clientk": "",
					"Vkorgdesc": "",
					"Vkorg": "",
					"Parvw": "",
					"Bpseq": "",
					"Msgfn": "",
					"Vtext": "",
					"Client": "",
					"Addr1": "",
					"Addr2": "",
					"Phone": "",
					"Cityk": "",
					"State": "",
					"Statek": "",
					"Zip": "",
					"Countryk": "",
					"Country": ""
				};
			objArray.push(obj);
			// that.getModel("jsonAmendModel").setProperty("/Cllientbp", aBusinessPartner.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/CmiclientBP", {
				properties: obj
			});
			that.bindBillPartnerTable(oContextKnownParties);
		},
		bindBillPartnerTable: function(oContextKnownParties) {
			var idBillPartenr = this.byId("handleCellClickChgBPBP");
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddBusinessPartner.bind(this)
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						change: this.changeBillPartnerDDDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parnr}",
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedClientBP.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnername}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Addr1} {Addr2}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idBillPartenr.addItem(oColumnListItem);
			this.upDateCBPButtons(idBillPartenr);
		},
		upDateCBPButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		changeBillPartnerDDDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Partnertypedesc") {
					id = "Partnertype";
					description = "VTEXT";
					key = "PARVW";
				}
				if (path === "Parvwdesc") {
					id = "Parvw";
					description = "VTEXT";
					key = "PARVW";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		valueListChangedClientBP: function(evt) {
			var that = this,
				data = evt.getSource().getBindingContext().getObject(),
				source = evt.getSource(),
				model = source.getModel(),
				sPath = source.getBindingContext().getPath();
			var sPartnertype = data.Parvw;
			var sAlternatepayer = data.Parnr;
			var aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, sPartnertype), new Filter("Alternatepayer", sap.ui.model.FilterOperator
				.EQ, sAlternatepayer)];
			var filesPath = "/Cmialtpayers";
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Addr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Addr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Cityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Statek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Countryk", obj.Altpayercountryk);

						}
					}

				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		changeBillPartnerDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},

		handleBillPartnerDelete: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem"),
				oTable = this.byId("handleCellClickChgBPBP");
			oItmSel.destroy();

			// ind = oTable.indexOfItem(oItmSel);
			this._removeConditionCBP(oTable);
		},
		_removeConditionCBP: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddBusinessPartner();
			}
			this.upDateCBPButtons(oTable);
		},
		// Tax Data binding
		bindTaxData: function(evt) {
			var idTaxData = this.byId("FormChange354WD");
			idTaxData.destroyItems();
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that._Cmino,
					"Vkorg": "",
					"Clientk": "",
					"Client": "",
					"Msgfn": "",
					"Qland": "",
					"Witht": "",
					"Withcd": "",
					"Agtdf": null,
					"Agtdt": null,
					"Agent": "",
					"Wtstcd": "",
					"Text40": "",
					"Withdesc": ""
				};
				objArray.push(obj);
				var NTData = that.getModel("jsonAmendModel").getProperty("/Wtax/results");
				//	that.getModel("jsonAmendModel").setProperty("/Leadpartners", objArray.concat(aLeadPartner));
				data = aContact.concat(objArray, NTData);
				var qtc = that.getModel();
				//		var rank = aKnownParties.length + 1;
				for (var k = 0; k < data.length; k++) {

					var oContextWOFC = qtc.createEntry("/Cmiwtax", {
						properties: data[k]
					});
					that.bindTaxDataTable(oContextWOFC);
				}

			});
		},

		onAddTaxData: function() {
			var that = this,
				objArray = [],
				// var aBusinessPartner = that.getModel("jsonAmendModel").getProperty("/Cmiwtax");
				qtc = that.getModel(),
				obj = {
					"Cmino": that._Cmino,
					"Vkorg": "",
					"Clientk": "",
					"Client": "",
					"Msgfn": "",
					"Qland": "",
					"Witht": "",
					"Withcd": "",
					"Agtdf": null,
					"Agtdt": null,
					"Agent": "",
					"Wtstcd": "",
					"Text40": "",
					"Withdesc": ""
				};
			objArray.push(obj);
			// that.getModel("jsonAmendModel").setProperty("/Cllientbp", aBusinessPartner.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmiwtax", {
				properties: obj
			});
			that.bindTaxDataTable(oContextKnownParties);
		},
		bindTaxDataTable: function(oContextKnownParties) {
			var model = this.getModel("AmendmentViewMod"),
				bEdit = model.getProperty("/isEditable"),
				idBillPartenr = this.byId("FormChange354WD");
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddTaxData.bind(this)
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Withdesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeTaxDataDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Text40}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeTaxDataDetails.bind(this)
					}).setConfiguration(c),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Text40}",
						change: this.changeTaxDataDetails.bind(this),
						editable: false
					}),
					new sap.m.Switch({
						state: {
							path: 'Agent',
							formatter: formatter.myBooleanV
						},
						enabled: "{AmendmentViewMod>/isEditable}",
						change: this.handleSwitchTaxChange.bind(this)
					}),
					new sap.m.DatePicker({
						value: {
							path: 'Agtdf',
							formatter: formatter.myDate1
						},
						valueFormat: "yyyy-MM-dd",
						displayFormat: "yyyy-MM-dd",
						enabled: "{AmendmentViewMod>/isEditable}",
						change: this.changeTaxDataDetails.bind(this)
					}),
					new sap.m.DatePicker({
						value: {
							path: 'Agtdt',
							formatter: formatter.myDate1
						},
						valueFormat: "yyyy-MM-dd",
						displayFormat: "yyyy-MM-dd",
						enabled: "{AmendmentViewMod>/isEditable}",
						change: this.changeTaxDataDetails.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idBillPartenr.addItem(oColumnListItem);
			this.upDateButtons(idBillPartenr);
		},
		upDateButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleSwitchTaxChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBinding("state").getPath(),
				value = "",
				state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var oMatterInContext = source.getBindingContext(),
				sPath = oMatterInContext.getPath(),
				oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeTaxDataDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		handleTaxDataDelete: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormChange354WD");
			// ind = oTable.indexOfItem(oItmSel);
			this._removeConditionWTX(oTable);
		},
		_removeConditionWTX: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddTaxData();
			}
			this.upDateButtons(oTable);
		},
		handleAddRowChgCPD: function() {
			var that = this,
				objArray = [],
				// var oCollectionProfile = that.getModel("jsonAmendModel").getProperty("/Clientcorrespondence");
				qtc = that.getModel();
			var obj = {
				"Partner": "",
				"CollSegment": "",
				"CollGroup": "",
				"CollGroupText": "",
				"CollSpecialist": "",
				"Fullname": ""
			};
			objArray.push(obj);
			// that.getModel("jsonAmendModel").setProperty("/Clientcorrespondence", oCollectionProfile.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmiclientcorrespondence", {
				properties: obj
			});
			that.bindCollectionProfileTable(oContextKnownParties);
		},
		bindCollectionProfileTable: function(oContextKnownParties) {
			var idBillPartenr = this.byId("FormChange354CP");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Partner}",
						width: "65%"
					}),
					new sap.m.Input({
						value: "{CollSegment}",
						width: "65%"
					}),
					new sap.m.Input({
						value: "{CollGroup}",
						width: "65%"
					}),
					new sap.m.Input({
						value: "{CollGroupText}",
						width: "65%"
					}),
					new sap.m.Input({
						value: "{CollSpecialist}",
						width: "65%"
					}),
					new sap.m.Input({
						value: "{Fullname}",
						width: "65%"
					})
				]
			});
			oColumnListItem.setBindingContext(oContextKnownParties);
			idBillPartenr.addItem(oColumnListItem);
		},
		handleDeleteCollectionProfile: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();

		},

		//Documents Upload
		onDocumentClick: function(e) {
			var proto = window.location.protocol,
				host = window.location.host,
				k = this.byId("idAttachment").getSelectedKey();
			if (k === "CD") {
				var service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmidocuments";
				this.byId(k).getContent()[0].setUploadUrl(service);
				// this.fileattachmentFilter(this.byId(k).getContent()[0], k);
			}
		},

		onChangeDocuments: function(oEvent) {
			var ClientK = this.getModel("AmendmentViewMod").getProperty("/Clientk"),
				MatterK = "",
				oUploadCollection = oEvent.getSource(),
				// Header Token
				cmiNo = this._Cmino;

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = this.byId("idAttachment").getSelectedKey();
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + ClientK + "|" + MatterK + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size +
					"|" + key
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [],
					resText = xmlToJSON.parseString(response.responseRaw),
					key = this.byId("idAttachment").getSelectedKey(),
					host = window.location.host,
					protocol = window.location.protocol,
					urlprefix = protocol + "//" + host,
					serviceUrl = this.getModel().sServiceUrl,
					url = "";
						var matterk = "";
					var clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk");
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": clientk,
					"Matterk": matterk
				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Cmino='" + obj.Cmino + "',Clientk='" + obj.Clientk + "',Matterk='"+ obj.Matterk +"',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
				this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", arr.concat(data));
				// this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId,
				FileDeleteMsgTxt = this.getResourceBundle().getText("FileDeleteMsgTxt"),
				that = this,
				data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet"),
				Cmino = "",
				Docseq = "",
				Doctype = "";
				var matterk = "";
					var clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos) {
					Cmino = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", data);
			var path = "/Cmidocuments(Matterk='" + matterk + "',Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData, oResponse) {
					sap.m.MessageBox.show(FileDeleteMsgTxt, sap.m.MessageBox.Icon.SUCCESS, "Success");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},

		onAttachmentDeleteConfirm: function() {
			var that = this,
				DelAttachMsgTxt = that.getResourceBundle().getText("DelAttachMsgTxt"),
				items = that.byId("idListImportedTerms").getItems();
			if (items.length > 0) {
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: DelAttachMsgTxt
					}),
					beginButton: new sap.m.Button({
						text: "Yes",
						press: function() {
							that.handleAttchRequest();
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				that.handleAttchRequest();
			}
		},

		// date formate change
		ondatechange: function(oEvt) {
			var s = oEvt.getSource(),
				bPath = s.getBindingPath('value'),
				bc = s.getBindingContext(),
				m = bc.getModel(),
				pDate = s.getInnerControls()[0].getDateValue();
			var delayInvk = (function(pD, bP, that) {
				return function() {

					m.setProperty(bc.getPath() + "/" + bPath, pDate);
				};
			})(m, bPath, this);

			jQuery.sap.delayedCall(100, this, delayInvk);

		},
		
		// parcentage allocation check 06-03-18
		
		checkValidationforLPAllocation: function() {
   var oTableLead = this.getTableData("LeadPartnerTbl");
   var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
    decimals: 2
   });
   var val;
   var percent = 0;
   var count = 0;
    // for (var j = 0; j < oTableLead.length; j++) {
    //  var iItem = oTableLead[j];
    //  if ($.isEmptyObject(iItem.Parvwdesc) || $.isEmptyObject(iItem.Firstname) || $.isEmptyObject(oTableLead[j].Office) ||
    //   $.isEmptyObject(oTableLead[j].Phone) || $.isEmptyObject(oTableLead[j].Email) ||
    //   $.isEmptyObject(oTableLead[j].Percentage)) {
    //   return "Error";
    //  }
    // }
    oTableLead.filter(function(sData) {
     if (sData.Parvw === "ZK") {
      val = oFloatFormat.format(sData.Percentage);
      if (!val) {
       val = "0.00";
      }
      val = oFloatFormat.parse(val);
      percent = percent + val;
      count++;
     }
    });
    if (count > 0 && percent < 100) {
     return "None";
    }
   return false;
  }

	});
});