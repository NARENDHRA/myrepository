/*global location*/
sap.ui.define([
	"cmiamendmentnew/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cmiamendmentnew/model/formatter",
	"cmiamendmentnew/model/JsonData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"cmiamendmentnew/util/xmlToJSON",
	"sap/ui/richtexteditor/RichTextEditor"
], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	JsonData,
	Filter, FilterOperator, GroupHeaderListItem
) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView, oOPSideContentBtn;
	return BaseController.extend("cmiamendmentnew.controller.MatterAmendment", {

		formatter: formatter,
		JsonData: JsonData,
		onInit: function() {
			var oViewModel = new JSONModel({
				altVisible: false,
				tableBusyDelay: 0,
				isEditable: false,
				PrimaryContact: "",
				Email: "",
				Phone: "",
				BillOfc: "",
				LeadPartner: "",
				LPPhone: "",
				LPEmail: "",
				TermTitle: "",
				headerTrueFalse: true,
				headerIcon: true,
				tooltipText: "Hide",
				clientVisiable: true,
				matterVisiable: false,
				enanledMd: true,
				KPName: "",
				userId: "",
				userName: "",
				EditCon: "",
				Clientk: "",
				idisplayapprove01: false,
				EditBtn: true,
				isReview: true,
				isSaveBtn: false,
				ClientName: "",
				Matterk: "",
				shwBtnVisible: false
			});
			this.setModel(oViewModel, "AmendmentViewMod");
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;
			router.attachRoutePatternMatched(this._onObjectMatched1, this);
			this.bindMandateField();
			// this.displayMatterPartnerData();
			// this.displayPartnerData();
			this.getConsiderationModel();
			oDynamicSideView = this.getView().byId("DynamicSideContent");
		},
		onAfterRendering: function() {
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
		},
		handleSideContentHide: function() {
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(false);
			}
			//oOPSideContentBtn.setVisible(true);
		},
		handleSCBtnPress: function(oEvent) {
			var BtnHComments = this.getResourceBundle().getText("BtnHComments"),
				BtnSComments = this.getResourceBundle().getText("BtnSComments");
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					oEvent.getSource().setText(BtnHComments);
				} else {
					oEvent.getSource().setText(BtnSComments);
				}
			}
			//oOPSideContentBtn.setVisible(false);
		},
		handleStep: function(evt) {
			var model = this.getModel("AmendmentViewMod");
			if (model.getProperty("/isEditable")) {
				if (evt.getParameter("index") === 2) {
					this.postCmiData("Step");
				}
				if (evt.getParameter("index") === 3) {
					model.setProperty("/isSaveBtn", true);
				}
			}
		},
		bindMandateField: function() {
			var oViewModel = new JSONModel({
				KPName: "None",
				KPClassification: "None",
				KPRole: "None",
				KPDesignation: "None"
			});
			var oViewMatterModel = new JSONModel({
				vMatterMN: "None",
				vMatterSA: "None",
				vMatterMMA: "None",
				vMatterMD: "None",
				vMatterPG: "None",
				vMatterO: "None",
				vMatterEF: "None"
			});
			this.setModel(oViewMatterModel, "ShowMatterError");
			this.setModel(oViewModel, "ErrorShow");

			var Altpayers = {
				"vAlternatepayer": "None",
				"vAltpayercityk": "None",
				"vAltpayeraddr1": "None",
				"vAltpayerstate": "None",
				"vAltpayerzip": "None",
				"vAltpayercountry": "None",
				"vAltpayerphone": "None"
			};
			var oViewAltModel = new JSONModel(Altpayers);
			this.setModel(oViewAltModel, "ShowAlterError");

			var internalcontact = {
				"Phone": "None",
				"Parvwdesc": "None",
				"OfficeName": "None",
				"Firstname": "None",
				"Lastname": "None",
				"Email": "None",
				"vAltpayerphone": "None"
			};
			var oViewInternalPayerModel = new JSONModel(internalcontact);
			this.setModel(oViewInternalPayerModel, "ShowInternalPayerError");
		},

		handelClntFieldChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				t = this.getView().byId("SimpFormClient"),
				oClientContext = t.getBindingContext("jsonAmendModel"),
				sPath = oClientContext.getPath(),
				oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
			if (path === "Countryk") {
				oClientModel.setProperty(sPath + "/" + "Statek", "");
				oClientModel.setProperty(sPath + "/" + "State", "");
			}
		},
		changeMatterDetails: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				t = this.getView().byId("idMatterDetails"),
				oClientContext = t.getBindingContext(),
				sPath = oClientContext.getPath(),
				oClientModel = oClientContext.getModel();
			oClientModel.setProperty(sPath + "/" + path, value);
		},
		changeInMatterDetails: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				cxt = this.getView().byId("MatterInDetailsStep"),
				oMatterInContext = cxt.getBindingContext(),
				sPath = oMatterInContext.getPath(),
				oMatterInModel = oMatterInContext.getModel();
			oMatterInModel.setProperty(sPath + "/" + path, value);
		},
		changeInMatterDetailsDD: function(evt) {
			var source = evt.getSource(),
				value = source.getValue(),
				path = source.getBindingPath("value"),
				oControl = source.getAggregation("_content"),
				t = this.getView().byId("MatterInDetailsStep"),
				oMatterInContext = t.getBindingContext(),
				oMatterInModel = oMatterInContext.getModel(),
				sPath = oMatterInContext.getPath(),
				id, description, key;
			if (path === "Zzbillfreqdesc") {
				id = "Zzbillfreq";
				description = "ZZDESC";
				key = "ZZBILLFREQ";
			}
			if (path === "Zzbillmthddesc") {
				id = "Zzbillmthd";
				description = "ZZDESC";
				key = "ZZBILLMTHD";
			}
			if (path === "Zzmanspdesc") {
				id = "Zzmansp";
				description = "TEXT1";
				key = "MANSP";
			}
			if (path === "Zzmattertypedesc") {
				id = "Zzmattertype";
				description = "DESCRIPTION";
				key = "MATTERTYPE";
			}
			if (path === "Zzpracticegroupdesc") {
				id = "Zzpracticegroup";
				description = "ZZDESC";
				key = "ZZPGP";
			}

			if (path === "Classification") {
				id = "Classificationk";
				description = "STEXT";
				key = "CLASSIFICATIONK";
			}
			if (oControl) {
				var oItem = source.getAggregation("_content").getSelectedItem();
				if (oItem) {
					var selData = source.getAggregation("_content").getSelectedItem().getBindingContext().getObject();
					oMatterInModel.setProperty(sPath + "/" + path, selData[description]);
					oMatterInModel.setProperty(sPath + "/" + id, selData[key]);
					source.getAggregation("_content").setValue(selData[description]);
				} else {
					oMatterInModel.setProperty(sPath + "/" + path, value);
					oMatterInModel.setProperty(sPath + "/" + id, "");
				}
			} else {
				oMatterInModel.setProperty(sPath + "/" + path, value);
			}
		},
		handleMatterInDetails: function() {
			var obj = {
				"Auth": "",
				"BillInstDate": "",
				"CheckNoLock": "",
				"Cmino": "",
				"Error": "",
				"Errormessage": "",
				"Etag": "",
				"Txjcd": "",
				"Txjcddesc": "",
				"Werks": "",
				"Werksdesc": "",
				"Zcontinue": "",
				"Zzactcodeset": "",
				"Zzactcodesetdesc": "",
				"ZzacsetValidfrom": null,
				"Zzaol": "",
				"Zzaoldesc": "",
				"Zzbillfreq": "",
				"Zzbillfreqdesc": "",
				"Zzbillinst": "",
				"Zzbillmthd": "",
				"Zzbillmthddesc": "",
				"Zzbillteam": "",
				"Zzbillteamdesc": "",
				"Zzbspras": "",
				"Zzbsprasdesc": "",
				"Zzcap": "0.00",
				"Zzcapctrl": "",
				"Zzcapcurr": "",
				"Zzcasecatcd": "",
				"Zzcasecatcddesc": "",
				"Zzclcasename": "",
				"Zzclcasenamedesc": "",
				"Zzclcasenbr": "",
				"Zzclcasenbrdesc": "",
				"Zzclntaol": "",
				"Zzclntaoldesc": "",
				"Zzclntbusarea": "",
				"Zzclntbusareadesc": "",
				"Zzclntccenter": "",
				"Zzclntccenterdesc": "",
				"Zzclntjursd": "",
				"Zzclntjursddesc": "",
				"Zzclntsrvcat": "",
				"Zzclntsrvcatdesc": "",
				"Zzclntstatus": "",
				"Zzclntstatusdesc": "",
				"Zzclntsubenty": "",
				"Zzclntsubentydesc": "",
				"Zzclntwrktype": "",
				"Zzclntwrktypedesc": "",
				"Zzcolco": "",
				"Zzcolcodesc": "",
				"Zzcompldate": null,
				"Zzcompletion": "0.00",
				"Zzcourtnum": "",
				"Zzcourtnumdesc": "",
				"Zzcstdtsumry": "",
				"Zzcstdtsumrydesc": "",
				"Zzdrftformat": "",
				"Zzdrftformatdesc": "",
				"Zzecost": "0.00",
				"Zzefees": "0.00",
				"Zzenttype": "",
				"Zzenttypedesc": "",
				"Zzetotal": "0.00",
				"Zzexpcodeset": "",
				"Zzexpcodesetdesc": "",
				"Zzfftcset": "",
				"Zzfftcsetdesc": "",
				"ZztcsetValidfrom": null,
				"Zzfnalformat": "",
				"Zzfnalformatdesc": "",
				"Zzgrpbill": "",
				"Zzgrpbilldesc": "",
				"Zzintver": "",
				"Zzintverdesc": "",
				"Zziob": "",
				"Zziobdesc": "",
				"Zzipanuyear": "",
				"Zzipappldate": null,
				"Zzipapplnum": "",
				"Zzipapplnumdesc": "",
				"Zzipjurisdcd": "",
				"Zzipjurisdcddesc": "",
				"Zzipponum": "",
				"Zzipponumdesc": "",
				"Zziprefrtypecd": "",
				"Zziprefrtypecddesc": "",
				"Zzipregdt": null,
				"Zzipregnum": "",
				"Zzipregnumdesc": "",
				"Zzipsort1": "",
				"Zzipsort1desc": "",
				"Zzipsort2": "",
				"Zzipsort2desc": "",
				"Zzipsort3": "",
				"Zzipsort3desc": "",
				"Zzipsort4": "",
				"Zzipsort4desc": "",
				"Zzipsort5": "",
				"Zzipsort5desc": "",
				"Zzmansp": "",
				"Zzmanspdesc": "",
				"Zzmatpageno": "",
				"Zzmatpagenodesc": "",
				"Zzmatremit": "",
				"Zzmatremitdesc": "",
				"Zzmatrptgrp": "",
				"Zzmatrptgrpdesc": "",
				"Zzmattercat": "",
				"Zzmattercatdesc": "",
				"Zzmattertype": "",
				"Zzmattertypedesc": "",
				"Zzmcurr": "",
				"Zzmcurrdesc": "",
				"Zzmonlau": "",
				"Zzmonlaudesc": "",
				"Zzmprgrp": "",
				"Zzmprgrpdesc": "",
				"Zznatureprocd": "",
				"Zznatureprocddesc": "",
				"Zzpassthru": "",
				"Zzpracticegroup": "",
				"Zzpracticegroupdesc": "",
				"Zzpriconf": "",
				"Zzpriconfdesc": "",
				"Zzsubindcode": "",
				"Zzsubindcodedesc": "",
				"Zzsumwo": "",
				"Zzsumwodesc": "",
				"Zzsyndlomat": "",
				"Zztaskcodeset": "",
				"Zztaskcodesetdesc": "",
				"Zztax": "",
				"Zztaxdesc": "",
				"Zztecharea": "",
				"Zztechareadesc": "",
				"Zztimeentryunit": "",
				"Zztimeentryunitdesc": "",
				"Zztksumry": "",
				"Zztksumrydesc": "",
				"Zztmdtl": "",
				"Zztmdtldesc": "",
				"Zzwipprovpercent": ""
			};
			return obj;
		},
		_onObjectMatched1: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments"),
				oParameters = oEvent.getParameters(),
				oVMod = this.getModel("AmendmentViewMod");
			if ((oParameters.name !== "MatterAmendment" && oParameters.name !== "MatterAmendmentmyRequest" && oParameters.name !==
					"MatterAmendmentcmi")) {
				return;
			} else {
				this.Cmino = sObjectId.Cmino;
				this.Matterk = sObjectId.Matterk;
				oVMod.setProperty("/Matterk", sObjectId.Matterk);
				var sEditable = sObjectId.isEditable,
					inbox = sObjectId.bInbox;
				if (sObjectId.Matterk === "0") {
					sObjectId.Matterk = "";
				} else {
					sObjectId.Matterk = sObjectId.Matterk;
				}

				if (inbox === "0") {
					oVMod.setProperty("/isReview", false);
				} else {
					oVMod.setProperty("/isReview", true);
				}

				// var rShow;
				// if (inbox === "0") {
				// 	inbox = false;
				// 	rShow = true;
				// } else {
				// 	inbox = true;
				// 	rShow = false;
				// }
				// oVMod.setProperty("/idisplayapprove01", rShow);
				// if (sEditable === "2") {
				// 	oVMod.setProperty("/EditBtn", true);
				// } else if (sEditable === "0") {
				// 	oVMod.setProperty("/EditBtn", false);
				// 	oVMod.setProperty("/isEditable", false);
				// } else {
				// 	oVMod.setProperty("/EditBtn", false);
				// 	oVMod.setProperty("/isEditable", true);
				// }
			}
			var oModel = this.getOwnerComponent().getModel();
			this.setCmino = true;
			oModel.metadataLoaded().then(function() {
				var cmino = this.Cmino;
				if (!this.Cmino) {
					cmino = "";
					this.setCmino = false;
				}
				var sObjectPath = this.getModel().createKey("Cmihdrs", {
					Cmino: cmino,
					Clientk: "",
					Cmirequesttype: "MA",
					Matterk: sObjectId.Matterk
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));

		},
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("AmendmentViewMod");
			this.sObjectPath = sObjectPath;
			this.getView().setBusy(true);

			var oModel = this.getOwnerComponent().getModel(),
				that = this,
				jsonModel = new sap.ui.model.json.JSONModel(),
				oVMod = that.getModel("AmendmentViewMod");
			oModel.read(sObjectPath, {
				urlParameters: {
					"$expand": "Clients,Matters,Knownparties,ConsiderationsN,Matterdetails,Offices,Altpayers,Documents,Comments"
				},
				success: function(oData, oResp) {
					if (oData.Edit === "X") {
						oViewModel.setProperty("/isEditable", true);

					} else {
						oViewModel.setProperty("/isEditable", false);
					}
					if (that.setCmino) {
						that.Cmino = oData.Cmino;
						oVMod.setProperty("/shwBtnVisible", true);
					} else {
						that.Cmino = "";
					}
					that.setQuetData(oData.Consideration);
					that.getView().setBusy(false);
					oVMod.setProperty("/userId", oData.Requestuserk);
					oVMod.setProperty("/userName", oData.Requestuser);
					oVMod.setProperty("/EditCon", oData.Edit);
					oVMod.setProperty("/Clientk", oData.Clientk);
					oVMod.setProperty("/Matterk", oData.Matterk);

					if (oData.Clients.results.length) {
						oVMod.setProperty("/ClientName", oData.Clients.results[0].Client);
					}

					jsonModel.setData(oData);
					that.getView().setModel(jsonModel, "jsonAmendModel");
					that.bindKnownParties(oData.Knownparties.results);
					that.bindWOffice(oData.Offices.results);
					that.bindMatterBP(oData.Altpayers.results);
					that.bindAlterPayer(oData.Altpayers.results);
					that.bindIPData(oData.Altpayers.results);
					// create entry for Client
					var client = that.byId("SimpFormClient");
					var oContextClient = oModel.createEntry("/Cmiclients", {
						properties: oData.Clients.results[0]
					});
					client.setBindingContext(oContextClient);
					// create entry for Matter
					var Matter = that.byId("idMatterDetails");
					var oContextMatter;

					oContextMatter = oModel.createEntry("/Cmimatters", {
						properties: oData.Matters.results[0]
					});

					Matter.setBindingContext(oContextMatter);
					// create entry for Matter Details
					var Matterid = that.byId("MatterInDetailsStep");
					if (oData.Matterdetails.results.length) {
						var oContextMatterid = oModel.createEntry("/Cmimatterdetails", {
							properties: oData.Matterdetails.results[0]
						});
					} else {
						var MatterDetailsData = that.handleMatterInDetails();
						oContextMatterid = oModel.createEntry("/Cmimatters", {
							properties: MatterDetailsData
						});
						oData.Matterdetails.results.push(MatterDetailsData);
					}
					Matterid.setBindingContext(oContextMatterid);
					// Considration
					var dataC = oData.ConsiderationsN,
						businessData = [],
						riskData = [];
					for (var j = 0; j < dataC.results.length; j++) {

						if (dataC.results[j].Attributetypek === "02") {
							riskData.push(dataC.results[j]);
						} else {
							businessData.push(dataC.results[j]);
						}
					}
					var oJsonBModel = new sap.ui.model.json.JSONModel();
					var oJsonRModel = new sap.ui.model.json.JSONModel();
					oJsonBModel.setData({
						ConsiData: businessData
					});
					that.getView().setModel(oJsonBModel, "jsonConsiModel");
					oJsonRModel.setData({
						RiskData: riskData
					});
					that.getView().setModel(oJsonRModel, "riskConsiModel");

					// Comments
					var data1 = oData.Comments;
					var oJsonComModel = new sap.ui.model.json.JSONModel();
					if (data1) {
						oJsonComModel.setData({
							CommentSet: data1.results
						});
						that.getView().setModel(oJsonComModel, "CommentsModel");
					} else {
						oJsonComModel.setData({
							CommentSet: []
						});
						that.getView().setModel(oJsonComModel, "CommentsModel");
					}

					var dataD = oData.Documents.results;
					var aFileData = [];
					var aFileKPData = [];
					var host = window.location.host;
					var protocol = window.location.protocol;
					var urlprefix = protocol + "//" + host;
					var serviceUrl = that.getOwnerComponent().getModel().sServiceUrl;
					for (var d = 0; d < dataD.length; d++) {
						var obj = dataD[d];
						obj.url = urlprefix + serviceUrl + "/Cmidocuments(Matterk='" + obj.Matterk + "',Clientk='" + obj.Clientk + "',Cmino='" +
							obj.Cmino + "',Docseq='" + obj.Docseq + "',Doctype='" + obj.Doctype +
							"')/$value";
						if (obj.Doctype === "KP") {
							aFileKPData.push(obj);
						} else {
							aFileData.push(obj);
						}
					}
					var oJsonModel = new sap.ui.model.json.JSONModel({
						FileDataSet: aFileData
					});
					that.getView().setModel(oJsonModel, "AttachmentModel");

					var oJsonKPModel = new sap.ui.model.json.JSONModel({
						KPDataSet: aFileKPData
					});
					that.getView().setModel(oJsonKPModel, "KPModel");
				},
				error: function(oError) {
					that.getView().setBusy(false);
				}
			});
		},
		BusinessListFactory: function(sId, oContext) {
			var qType = oContext.getProperty("Questiontypek");
			var oControl = null;
			var mData = {
				selected: [],
				items: [{
					key: "0",
					text: "Answer 1"
				}, {
					key: "1",
					text: "Answer 2"
				}, {
					key: "2",
					text: "Answer 3"
				}, {
					key: "3",
					text: "Answer 4"
				}]
			};
			var oItemTemplate = new sap.ui.core.Item({
				key: "{key}",
				text: "{text}"
			});
			var oModel = new sap.ui.model.json.JSONModel(mData);
			oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'jsonConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchConsiChange.bind(this),
				enabled: "{AmendmentViewMod>/isEditable}"
			});
			/*	switch (qType) {
					case "01":
						oControl = new sap.m.Switch({
							state:"{jsonConsiModel>Answer}"
						});
						break;
					case "02":
						oControl = new sap.m.MultiComboBox({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							},
							selectedKeys: {
								path: "/selected",
								template: "{selected}"
							}
						});
						oControl.setModel(oModel);
						break;
					case "03":
						oControl = new sap.m.Select({
							width: "12rem",
							items: {
								path: "/items",
								template: oItemTemplate
							}
						});
						oControl.setModel(oModel);
						break;
					case "04":
						oControl = new sap.m.RangeSlider({
							width: "20rem",
							height: "3rem",
							min: 0,
							max: 30,
							range: [5, 20],
							enableTickmarks: true
								//	scale: new sap.m.ResponsiveScale({tickmarksBetweenLabels: 3})
						});
						break;
					default:
						oControl = new sap.m.Input({
							width: "12rem"
						});
				}*/
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'jsonConsiModel>QuestionText'}, {path: 'jsonConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		handleSwitchConsiChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBinding("state").getPath(),
				value = "",
				state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("jsonConsiModel").getPath(),
				ConsiInModel = source.getBindingContext("jsonConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		//Risk Consideration
		riskListFactory: function() {
			var oControl = new sap.m.Switch({
				customTextOn: "Yes",
				customTextOff: "No",
				state: {
					path: 'riskConsiModel>Answer',
					formatter: formatter.myBooleanV
				},
				change: this.handleSwitchRiskChange.bind(this),
				enabled: "{AmendmentViewMod>/isEditable}"
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: new sap.m.HBox({
					justifyContent: "SpaceBetween",
					items: [
						new sap.m.Text({
							text: "{parts:[{ path: 'riskConsiModel>QuestionText'}, {path: 'riskConsiModel>Requiredquestion'}], formatter:'myFormatter.requiredQuestion'}"
						}).addStyleClass("sapUiTinyMarginTop sapUiTinyMarginBegin"),
						oControl.addStyleClass("sapUiTinyMarginBottom sapUiTinyMarginEnd")
					]
				}).addStyleClass("sapUiTinyMarginTop")
			});

			return oCustomListItem;
		},
		handleSwitchRiskChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBinding("state").getPath(),
				value = "",
				state = evt.getParameter("state");
			if (state) {
				value = "X";
			}
			var sPath = source.getBindingContext("riskConsiModel").getPath(),
				ConsiInModel = source.getBindingContext("riskConsiModel").getModel();
			ConsiInModel.setProperty(sPath + "/" + path, value);
		},
		onPressAddParty: function() {
			var oViewModel = this.getModel("AmendmentViewMod"),
				odata = {
					Name: oViewModel.getProperty("/Name"),
					Rolek: oViewModel.getProperty("/Role"),
					Designation: oViewModel.getProperty("/Designation"),
					Classificationk: oViewModel.getProperty("/classfication")
				};
			var viewMod = this.getModel("jsonAmendModel"),
				CCMod = viewMod.getProperty("/KnownParties");
			CCMod.push(odata);
			viewMod.refresh();
			oViewModel.setProperty("/Name", "");
			oViewModel.setProperty("/Role", "");
			oViewModel.setProperty("/Designation", "");
			oViewModel.setProperty("/classfication", "");
		},
		bindKnownParties: function(newData) {
			var aKPCntx = [{
				"Cmino": this.Cmino,
				"Designation": "",
				"Knownpartyseq": "",
				"Classification": "",
				"Rolek": "",
				"Designationk": "",
				"Classificationk": "",
				"Role": "",
				"Name": "",
				"Comments": ""
			}];
			var aData = aKPCntx.concat(newData);
			var idKnownParty = this.byId("idKnownPartyNew");
			idKnownParty.destroyItems();
			for (var k = 0; k < aData.length; k++) {
				var qtc = this.getModel();
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: aData[k]
				});
				this.bindKnownTable(oContextKnownParties);
			}
			this.getModel("jsonAmendModel").setProperty("/Knownparties", newData);
		},

		bindKnownTable: function(oContextKnownParties) {
			var idKnownParty = this.byId("idKnownPartyNew");
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				press: this.addKnownParties.bind(this),
				enabled: "{AmendmentViewMod>/isEditable}"
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Name}",
						change: this.changeKnownDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Classification}",
						change: this.changeKnownDetails.bind(this),
						enabled: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Role}",
						change: this.changeKnownDetails.bind(this),
						enabled: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Designation}",
						change: this.changeKnownDetails.bind(this),
						enabled: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(c),
					new sap.m.Button({
						icon: "sap-icon://bell",
						type: "Reject",
						visible: {
							path: 'Hasconflict',
							formatter: formatter.myBooleanBDOD
						},
						press: this.onPressViewConfilt.bind(this)
					}),
					new sap.m.Button({
						enabled: "{AmendmentViewMod>/isEditable}",
						icon: "sap-icon://message-popup",
						type: "{=${Comments} ? 'Emphasized':'Default'}",
						press: function(evt) {
							this.onPressComments(evt);
						}.bind(this)
					}),
					new sap.m.Button({
						enabled: "{AmendmentViewMod>/isEditable}",
						icon: "sap-icon://attachment",
						type: {
							path: 'Hasdocument',
							formatter: formatter.HasdocumentsBtn
						},
						press: this.addAttachments.bind(this)

					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);

			idKnownParty.addItem(oColumnListItem);
			this.upDateButtons(idKnownParty);
		},
		onSubmitView: function() {
			var oTable = this.getView().byId("idViewConflictsTable");
			var aResults = this.getTableConflictSelectedData(oTable);
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CMI_CONFLICTS_SRV/");
			var batchChanges = [];
			var that = this;
			var rFlag = false;
			var batchModel = new sap.ui.model.odata.ODataModel(oModel.sServiceUrl);
			this.selectedRowIndices = oTable._oTable.getSelectedContexts();
			if (!this.selectedRowIndices.length) {
				sap.m.MessageBox.error(
					"Please select a row to submit for review", {}
				);
				return;
			}
			$.each(aResults, function(i, oRowData) {
				if (oRowData.Wfstatk !== "") {
					rFlag = true;
					sap.m.MessageBox.information(
						"Conflict is already submitted for review", {}
					);
					oTable._oTable.removeSelections();
					return;
				}
				batchChanges.push(batchModel.createBatchOperation("/Searchresults", "POST", oRowData));
			}.bind(that));
			if (rFlag) {
				return;
			}
			batchModel.addBatchChangeOperations(batchChanges);
			batchModel.setUseBatch(true);
			batchModel.submitBatch(function() {
				oTable._oTable.removeSelections();
				sap.m.MessageBox.success("Submitted for Review", {});
				oTable.rebindTable();
				// that.getViewConflicts();
			}, function(oError) {
				sap.m.MessageBox.error(oError.message, {});
			});

			// this._oKnownParties.close();
		},
		getTableConflictSelectedData: function(oTable) {
			var aResults = [];
			if (oTable) {
				var aIndices = oTable._oTable.getSelectedContexts();
				jQuery.each(aIndices, function(i, index) {
					var obj = oTable._oTable.getSelectedContexts()[i].getObject();
					if (obj.hasOwnProperty("__metadata")) {
						delete obj.Conflictsequenceno;
						delete obj.__metadata;
					}
					aResults.push(obj);
				});
			}
			return aResults;
		},
		changeKnownDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);

			var oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Classification") {
					id = "Classificationk";
					description = "STEXT";
					key = "CLASSIFICATIONK";
				}
				if (path === "Role") {
					id = "Rolek";
					description = "STEXT";
					key = "ROLEK";
				}
				if (path === "Designation") {
					id = "Designationk";
					description = "LTEXT";
					key = "DESIGNATIONK";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		addKnownParties: function(evt) {
			var data = this.getTableData("idKnownPartyNew");
			for (var w = 0; w < data.length; w++) {
				var vPath = data[w];
				if (!vPath.Designation || !vPath.Classification || !vPath.Name || !vPath.Role) {

					var msg = this.getResourceBundle().getText("manKnownParties");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;

				}
			}
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var objArray = [],
					aKnownParties = that.getModel("jsonAmendModel").getProperty("/Knownparties"),
					qtc = that.getModel();
				var aKPCntx = [{
					"Cmino": that.Cmino,
					"Designation": "",
					"Knownpartyseq": "",
					"Classification": "",
					"Rolek": "",
					"Designationk": "",
					"Classificationk": "",
					"Role": "",
					"Name": "",
					"Comments": ""
				}];
				var aData = aKPCntx.concat(aKnownParties);
				// that.getModel("jsonAmendModel").setProperty("/Knownparties", aKnownParties.concat(objArray));
				var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
					properties: aData
				});
				that.bindKnownTable(oContextKnownParties);
			});
			// that.bindKnownParties();
		},

		conflictRequestDialog: function() {
			if (!this._ConflictReqest) {
				this._ConflictReqest = sap.ui.xmlfragment("cmiamendmentnew.fragments.NMConflictReqest", this);
				this.getView().addDependent(this._ConflictReqest);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._ConflictReqest);
			this._ConflictReqest.open();
		},
		onPressViewConfilt: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			if (!this._oKnownParties) {
				this._oKnownParties = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.ViewConflicts", this);
				oView.addDependent(this._oKnownParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKnownParties);
			var that = this,
				source = evt.getSource(),
				obj = source.getBindingContext().getObject(),
				cmino = obj.Cmino,
				name = obj.Name;
			this.KPCmino = cmino;
			this.KPName = name;
			var aFilter = [new Filter("Cmino", sap.ui.model.FilterOperator.EQ, cmino), new Filter("Name", sap.ui.model.FilterOperator
				.EQ, name)];
			var filesPath = "/Cmigetconflicts",
				jsonModel = new sap.ui.model.json.JSONModel();
			var oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData, OResponse) {
					var idViewConflictsTable = that.getView().byId("idViewConflictsTable");
					idViewConflictsTable.setEnableAutoBinding(true);
					idViewConflictsTable.rebindTable();
					jsonModel.setData(oData.results);
					if (oData.results) {
						jsonModel.setData({
							ConflictsSet: oData.results
						});
						that.getView().setModel(jsonModel, "ConflictsModel");
					} else {
						jsonModel.setData({
							ConflictsSet: []
						});
						that.getView().setModel(jsonModel, "ConflictsModel");
					}

					that._oKnownParties.open();
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});

		},
		onClosevConflicts: function() {
			this._oKnownParties.close();
		},
		onExpandConflicts: function(oEvent) {
			var oSrc = oEvent.getSource(),
				sId = oSrc.getBindingContext("NRequestView").getProperty("ID"),
				aFilter = [new Filter("ClientID", "EQ", sId)],

				oTable = oSrc.getContent()[0],
				oTemplate = this.getView().byId("columnListItemTemplate");

			//if (oTable.data().isTableBound === "no") {
			oTable.bindItems({
				path: "NRequestView>/Conflicts",
				filters: aFilter,
				template: oTemplate
			});
			//	oTable.data().isTableBound = "yes";
			//	}
		},
		updateFinishedTableResult: function(oEvent) {
			var oSrc = oEvent.getSource(),
				sTotal = oEvent.getParameter("total"),
				oKwnPartiesModel = oSrc.getModel("jsonAmendModel");
			for (var i = 0; i < sTotal; i++) {
				oKwnPartiesModel.setProperty("/Knownparties/results/" + i + "/Knownpartyseq", this.formatter.sequenceNumber(i + 1));
			}
		},
		upDateButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		handleUpload: function() {
			var file,
				oFileUpId = this.byId("fileUploader"),
				domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = this.getResourceBundle().getText("uploadMsgTxt");
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = this.getResourceBundle().getText("uploadInvMsgTxt");
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file);

			}
		},
		_import: function(file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					//	xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					var msgF1 = that.getResourceBundle().getText("uploadInvMsgTxt1");
					if (sheetData === undefined) {
						sap.m.MessageBox.show(msgF1, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					if (sheetData[0].Name === undefined && sheetData[0].Notes === undefined && sheetData[0].Classification === undefined &&
						sheetData[0].Role === undefined && sheetData[0].Designation === undefined && sheetData[0].Classificationk === undefined &&
						sheetData[0].Rolek === undefined && sheetData[0].Designationk === undefined) {
						sap.m.MessageBox.show(msgF1, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i].Classification === undefined) {
							sheetData[i].Classification = "";
						}
						if (sheetData[i].Role === undefined) {
							sheetData[i].Role = "";
						}
						if (sheetData[i].Designation === undefined) {
							sheetData[i].Designation = "";
						}
						if (sheetData[i].Classificationk === undefined) {
							sheetData[i].Classificationk = "";
						}
						if (sheetData[i].Rolek === undefined) {
							sheetData[i].Rolek = "";
						}
						if (sheetData[i].Designationk === undefined) {
							sheetData[i].Designationk = "";
						}
						if (sheetData[i].Name === undefined) {
							sheetData[i].Name = "";
						}
						if (sheetData[i].Notes === undefined) {
							sheetData[i].Notes = "";
						}
					}
					that.abd(sheetData);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		abd: function(newData) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k],
					Designation = data.Designation.trim(),
					Name = data.Name.trim(),
					Notes = data.Notes.trim(),
					Classification = data.Classification.trim(),
					Role = data.Role.trim(),
					Classificationk = data.Classificationk.trim(),
					Rolek = data.Rolek.trim(),
					Designationk = data.Designationk.trim();
				var obj = {
					"Cmino": this.Cmino,
					"Designation": Designation,
					"Knownpartyseq": "",
					"Classification": Classification,
					"Rolek": Rolek,
					"Designationk": Designationk,
					"Classificationk": Classificationk,
					"Role": Role,
					"Name": Name,
					"Comments": "",
					"Hasconflict": ""
						//"Notes": Notes,
						//"Action": "M"
				};
				if (Designation === "" && Name === "" && Role === "" && Classification) {
					continue;
				} else {
					objArray.push(obj);
					var qtc = this.getModel();
					var oContextKnownParties = qtc.createEntry("/Cmiknownparties", {
						properties: obj
					});
					this.bindKnownTable(oContextKnownParties);
				}
			}

			var aKnownParties = this.getModel("jsonAmendModel").getProperty("/Knownparties");
			this.getModel("jsonAmendModel").setProperty("/Knownparties", aKnownParties.concat(objArray));

		},
		onChangeEditMode: function() {
			var oVMod = this.getModel("AmendmentViewMod"),
				iseditable = oVMod.getProperty("/isEditable");
			if (iseditable) {
				oVMod.setProperty("/isEditable", false);
			} else {
				oVMod.setProperty("/isEditable", true);
			}
		},
		bindWOffice: function(newData) {
			var idWorkingOFC = this.byId("FormDisplay354WO");
			idWorkingOFC.destroyItems();
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that.Cmino,
					"OfficeCode": "",
					"OfficeName": "",
					"CompCode": "",
					"CompanyName": "",
					"Country": "",
					"CountryName": ""
				};
				objArray.push(obj);
				var aOffices = that.getModel("jsonAmendModel").getProperty("/Offices/results");

				data = aContact.concat(objArray, aOffices);
				var qtc = that.getModel();

				for (var k = 0; k < data.length; k++) {
					// var qtc = this.getModel();
					var oContextWOFC = qtc.createEntry("/Cmimatteroffices", {
						properties: data[k]
					});
					that.bindWOOfficeTable(oContextWOFC);
				}
			});
			// this.getModel("jsonAmendModel").setProperty("/Offices", newData);
		},
		bindWOOfficeTable: function(oContextKnownParties) {
			var idWorkingOFC = this.byId("FormDisplay354WO");

			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.addWOOffice.bind(this)
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{OfficeName}",
						width: "65%",
						change: this.changeOfficeTableDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CompanyName}",
						width: "65%",
						change: this.changeOfficeTableDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{CountryName}",
						width: "65%",
						change: this.changeOfficeTableDetails.bind(this),
						editable: "{AmendmentViewMod>/isEditable}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextKnownParties);
			idWorkingOFC.addItem(oColumnListItem);
			this.upDateWOButtons(idWorkingOFC);
		},
		upDateWOButtons: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		changeOfficeTableDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		addWOOffice: function() {
			var that = this;
			var objArray = [];
			// var aKnownParties = that.getModel("jsonAmendModel").getProperty("/Offices");
			var qtc = that.getModel();
			var obj = {
				"Cmino": that.Cmino,
				"OfficeCode": "",
				"OfficeName": "",
				"CompCode": "",
				"CompanyName": "",
				"Country": "",
				"CountryName": ""
			};
			objArray.push(obj);
			// that.getModel("jsonAmendModel").setProperty("/Offices", aKnownParties.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmimatteroffices", {
				properties: obj
			});
			that.bindWOOfficeTable(oContextKnownParties);
		},
		handleDeleteWOPayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormDisplay354WO");
			// ind = oTable.indexOfItem(oItmSel);
			this._removeConditionWO(oTable);
		},
		_removeConditionWO: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addWOOffice();
			}
			this.upDateButtons(oTable);
		},
		onAddKnownParies: function(oEvt) {
			var oViewModel = this.getModel("AmendmentViewMod"),
				idKnownParies = this.byId("idKnownParies"),
				objLead = idKnownParies.getBindingContext().getModel(),
				path = idKnownParies.getBindingContext().getPath(),
				oError = this.getModel("ErrorShow");
			oError.setProperty("/KPName", "None");
			oError.setProperty("/KPClassification", "None");
			oError.setProperty("/KPRole", "None");
			oError.setProperty("/KPDesignation", "None");
			// if (!objLead.getProperty(path + "/Classificationk") || !oViewModel.getProperty("/KPName") || !objLead.getProperty(path +
			// 		"/Designationk") || !
			// 	objLead.getProperty(path + "/Rolek")) {
			// 	if (!oViewModel.getProperty("/KPName")) {
			// 		oError.setProperty("/KPName", "Error");
			// 	}
			// 	if (!objLead.getProperty(path + "/Classificationk")) {
			// 		oError.setProperty("/KPClassification", "Error");
			// 	}
			// 	if (!objLead.getProperty(path + "/Designationk")) {
			// 		oError.setProperty("/KPDesignation", "Error");
			// 	}
			// 	if (!objLead.getProperty(path + "/Rolek")) {
			// 		oError.setProperty("/KPRole", "Error");
			// 	}
			// 	return;
			// }
			var odata = {
				Name: oViewModel.getProperty("/KPName"),
				Knownpartyseq: "",
				Classificationk: objLead.getProperty(path + "/Classificationk"),
				Classification: objLead.getProperty(path + "/Classification"),
				Rolek: objLead.getProperty(path + "/Rolek"),
				Role: objLead.getProperty(path + "/Role"),
				Cmino: this.Cmino,
				Designationk: objLead.getProperty(path + "/Designationk"),
				Designation: objLead.getProperty(path + "/Designation")
			};
			var viewMod = this.getModel("jsonAmendModel");
			var CCMod = viewMod.getProperty("/Knownparties");
			CCMod.results.push(odata);

			viewMod.refresh();
			oViewModel.setProperty("/KPName", "");
			objLead.setProperty(path + "/Classificationk", "");
			objLead.setProperty(path + "/Classification", "");
			objLead.setProperty(path + "/Rolek", "");
			objLead.setProperty(path + "/Role", "");
			objLead.setProperty(path + "/Designationk", "");
			objLead.setProperty(path + "/Designation", "");
		},
		changeKnownParty: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				idKnownParies = this.byId("idKnownParies"),
				objLead = idKnownParies.getBindingContext().getModel(),
				sPath = idKnownParies.getBindingContext().getPath();
			objLead.setProperty(sPath + "/" + path, value);
			// var oLeadPartnerContext = this.getBindingContextbyId("idLeadPartner");
			// var sPath = oLeadPartnerContext.getPath();
			// var oLeadPartnerModel = oLeadPartnerContext.getModel();
			// oLeadPartnerModel.setProperty(sPath + "/" + path, value);
		},
		handleDeleteKnownParties: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem");
			oTable.removeItem(oItmSel);
			// var ind = oTable.indexOfItem(oItmSel);
			// oTable.getModel("jsonAmendModel").getProperty("/AddTerms").splice(ind, 1);
			oTable.getModel("jsonAmendModel").refresh();
			this._removeConditionKP(oTable);
		},
		_removeConditionKP: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addKnownParties();
			}
			this.upDateButtons(oTable);
		},

		//same method  calling from NewRequest.controller.js

		onShowHideClientDetail: function(evt) {
			var oViewModel = this.getModel("AmendmentViewMod");
			if (evt.getSource().getPressed()) {
				oViewModel.setProperty("/headerTrueFalse", false);
				oViewModel.setProperty("/headerIcon", false);
				oViewModel.setProperty("/tooltipText", "show");
			} else {
				oViewModel.setProperty("/headerTrueFalse", true);
				oViewModel.setProperty("/headerIcon", true);
				oViewModel.setProperty("/tooltipText", "Hide");
			}
		},
		OnpressSubmit: function(oEvt) {
			var src = oEvt.getSource(),
				ActionCode = src.data().ActionCode;
			this.postCmiData(ActionCode);
		},
		OnpressSave: function(oEvt) {
			var src = oEvt.getSource(),
				ActionCode = src.data().ActionCode;
			this.postCmiData(ActionCode);
		},
		_readpostData: function(ActionCode) {
			var sPath = "/Cmihdrs",
				oModel = this.getModel(),
				// oBusy = new sap.m.BusyDialog(),

				KPdata = this.getView().byId("idKnownPartyNew"),
				KPItems = KPdata.getItems(),
				KPData = [],
				that = this;
			KPItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.Name) {
					var sdata1 = {
						"Cmino": that.Cmino,
						"Designation": odata.Designation,
						"Knownpartyseq": odata.Knownpartyseq,
						"Classification": odata.Classification,
						"Rolek": odata.Rolek,
						"Designationk": odata.Designationk,
						"Classificationk": odata.Classificationk,
						"Role": odata.Role,
						"Name": odata.Name,
						"Comments": odata.Comments
					};
					KPData.push(sdata1);
				}
			});

			var WOOfc = this.getView().byId("FormDisplay354WO"),
				WOOfcItems = WOOfc.getItems(),
				WOOfcData = [];

			WOOfcItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.CompanyName !== "") {
					var sdata1 = {
						"Cmino": that.Cmino,
						"OfficeCode": odata.OfficeCode,
						"OfficeName": odata.OfficeName,
						"CompCode": odata.CompCode,
						"CompanyName": odata.CompanyName,
						"Country": odata.Country,
						"CountryName": odata.OfficeCode
					};
					WOOfcData.push(sdata1);
				}
			});
			//internal partner
			var IPartner = this.getView().byId("FormChange354IP"),
				IPartnerItems = IPartner.getItems(),
				IPartnerData = [];
			IPartnerItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.Parvwdesc !== "") {
					var sdata1 = {
						"Cmino": that.Cmino,
						"Altpayerseq": odata.Altpayerseq,
						"Alternatepayer": odata.Alternatepayer,
						"Altpayeraddr1": odata.Altpayeraddr1,
						"Altpayeraddr2": odata.Altpayeraddr2,
						"Altpayercityk": odata.Altpayercityk,
						"Altpayerperc": odata.Altpayerperc,
						"Partnertype": odata.Partnertype,
						"Parvw": odata.Parvw,
						"Parvwdesc": odata.Parvwdesc,
						"Isnew": odata.Isnew,
						"Altpayerphone": odata.Altpayerphone,
						"Altpayerstate": odata.Altpayerstate,
						"Altpayerstatek": odata.Altpayerstatek,
						"Altpayerzip": odata.Altpayerzip,
						"Altpayercountryk": odata.Altpayercountryk,
						"Altpayercountry": odata.Altpayercountry,
						"Nrart": odata.Nrart,
						"Firstname": odata.Firstname,
						"Lastname": odata.Lastname,
						"Teams": odata.Teams,
						"Teamsdesc": odata.Teamsdesc,
						"Comments": odata.Comments,
						"OfficeName": odata.OfficeName,
						"Preferred": odata.Preferred,
						"Phone": odata.Phone,
						"Email": odata.Email,
						"Allocation": odata.Allocation

					};
					IPartnerData.push(sdata1);
				}
			});
			// matter partner
			var BPartner = this.getView().byId("FormChange354BP"),
				BPartnerItems = BPartner.getItems(),
				BPartnerData = [];
			BPartnerItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.Parvwdesc !== "") {
					var sdata1 = {
						"Cmino": that.Cmino,
						"Altpayerseq": odata.Altpayerseq,
						"Alternatepayer": odata.Alternatepayer,
						"Altpayeraddr1": odata.Altpayeraddr1,
						"Altpayeraddr2": odata.Altpayeraddr2,
						"Altpayercityk": odata.Altpayercityk,
						"Altpayerperc": odata.Altpayerperc,
						"Partnertype": odata.Partnertype,
						"Parvw": odata.Parvw,
						"Parvwdesc": odata.Parvwdesc,
						"Isnew": odata.Isnew,
						"Altpayerphone": odata.Altpayerphone,
						"Altpayerstate": odata.Altpayerstate,
						"Altpayerstatek": odata.Altpayerstatek,
						"Altpayerzip": odata.Altpayerzip,
						"Altpayercountryk": odata.Altpayercountryk,
						"Altpayercountry": odata.Altpayercountry,
						"Nrart": odata.Nrart,
						"Firstname": odata.Firstname,
						"Lastname": odata.Lastname,
						"Teams": odata.Teams,
						"Teamsdesc": odata.Teamsdesc,
						"Comments": odata.Comments,
						"OfficeName": odata.OfficeName,
						"Allocation": odata.Allocation

					};
					BPartnerData.push(sdata1);
				}
			});
			// businness parnert
			var BPartnerMulti = this.getView().byId("FormChange354BF1"),
				BPartnerMultiItems = BPartnerMulti.getItems(),
				BPartnerDataMulti = [];
			BPartnerMultiItems.forEach(function(i, o) {
				var o = i.getBindingContext();
				var odata = o.getObject();
				if (odata.IsMulti === "X" && odata.Firstname) {
					var sdata1 = {
						"Cmino": that.Cmino,
						"Altpayerseq": odata.Altpayerseq,
						"Alternatepayer": odata.Alternatepayer,
						"Altpayeraddr1": odata.Altpayeraddr1,
						"Altpayeraddr2": odata.Altpayeraddr2,
						"Altpayercityk": odata.Altpayercityk,
						"Altpayerperc": odata.Altpayerperc,
						"Partnertype": odata.Partnertype,
						"Parvw": odata.Parvw,
						"Parvwdesc": odata.Parvwdesc,
						"Isnew": odata.Isnew,
						"IsMulti": odata.IsMulti,
						"Altpayerphone": odata.Altpayerphone,
						"Altpayerstate": odata.Altpayerstate,
						"Altpayerstatek": odata.Altpayerstatek,
						"Altpayerzip": odata.Altpayerzip,
						"Altpayercountryk": odata.Altpayercountryk,
						"Altpayercountry": odata.Altpayercountry,
						"Nrart": odata.Nrart,
						"Firstname": odata.Firstname,
						"Lastname": odata.Lastname,
						"Teams": odata.Teams,
						"Teamsdesc": odata.Teamsdesc,
						"Comments": odata.Comments,
						"OfficeName": odata.OfficeName,
						"Allocation": odata.Allocation
					};
					BPartnerDataMulti.push(sdata1);
				}
			});
			var AtlPayerObl = [],
				AtlPayerData = AtlPayerObl.concat(BPartnerDataMulti, BPartnerData, IPartnerData),

				CMIMod = this.getModel("jsonAmendModel"),
				clientData = CMIMod.getData();
			clientData.Knownparties = null;
			clientData.Knownparties = KPData;
			clientData.Offices = null;
			clientData.Offices = WOOfcData;
			clientData.Altpayers = null;
			clientData.Altpayers = AtlPayerData;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var dateTimeFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddhhmmss"
			});
			// if (!clientData.Knownparties.results) {
			// 	clientData.Knownparties = [];
			// } else {
			// 	for (var b = 0; b < clientData.Knownparties.results.length; i++) {
			// 		delete(clientData.Knownparties.results[b].__metadata);
			// 	}
			// 	clientData.Knownparties = clientData.Knownparties.results;
			// }
			if (!clientData.Matters.results) {
				clientData.Matters = [];
			} else {
				for (var i = 0; i < clientData.Matters.results.length; i++) {
					delete(clientData.Matters.results[i].__metadata);
				}
				clientData.Matters = clientData.Matters.results;
			}
			if (!clientData.Clients.results) {
				clientData.Clients = [];
			} else {
				for (var j = 0; j < clientData.Clients.results.length; j++) {
					delete(clientData.Clients.results[j].__metadata);
				}
				clientData.Clients = clientData.Clients.results;
			}
			if (!clientData.Ocgs.results) {
				clientData.Ocgs = [];
			} else {
				for (var k = 0; k < clientData.Ocgs.results.length; k++) {
					delete(clientData.Ocgs.results[k].__metadata);
					delete(clientData.Ocgs.results[k].Filecontent);
				}
				clientData.Ocgs = clientData.Ocgs.results;
			}
			if (!clientData.Leadpartners.results) {
				clientData.Leadpartners = [];
			} else {
				for (var l = 0; l < clientData.Leadpartners.results.length; l++) {
					delete(clientData.Leadpartners.results[l].__metadata);
				}
				clientData.Leadpartners = clientData.Leadpartners.results;
			}
			if (!clientData.Matterdetails.results) {
				clientData.Matterdetails = [];
			} else {
				for (var o = 0; o < clientData.Matterdetails.results.length; o++) {
					delete(clientData.Matterdetails.results[o].__metadata);

				}
				clientData.Matterdetails = clientData.Matterdetails.results;
			}
			if (!clientData.Clientcontacts.results) {
				clientData.Clientcontacts = [];
			} else {
				for (var p = 0; p < clientData.Clientcontacts.results.length; p++) {
					delete(clientData.Clientcontacts.results[p].__metadata);
				}
				clientData.Clientcontacts = clientData.Clientcontacts.results;
			}
			var consiData = [],
				bconsiData = this.getModel("jsonConsiModel").getProperty("/ConsiData");
			for (var c = 0; c < bconsiData.length; c++) {
				bconsiData[c].Cmino = that.Cmino;
				delete(bconsiData[c].__metadata);
			}

			var riskData = this.getModel("riskConsiModel").getProperty("/RiskData");
			for (var r = 0; r < riskData.length; r++) {
				riskData[r].Cmino = that.Cmino;
				delete(riskData[r].__metadata);
			}
			consiData = bconsiData.concat(riskData);

			var AttachData = this.getModel("AttachmentModel").getProperty("/FileDataSet");
			for (var a = 0; a < AttachData.length; a++) {
				AttachData[a].Cmino = that.Cmino;
				AttachData[a].Filecontent = "";
				AttachData[a].Clientk = clientData.Clientk;
				delete(AttachData[a].__metadata);
				delete(AttachData[a].url);
			}

			var KPDataS = that.getModel("KPModel").getProperty("/KPDataSet");
			for (var kp = 0; kp < KPDataS.length; kp++) {
				delete(KPDataS[kp].__metadata);
				delete(KPDataS[kp].url);
			}
			var DocAttachData = [];
			// DocAttachData = AttachData;
			DocAttachData = AttachData.concat(KPDataS);

			var commentData = this.getModel("CommentsModel").getProperty("/CommentSet");
			for (var co = 0; co < commentData.length; co++) {
				commentData[co].Cmino = that.Cmino;
				commentData[co].Addedon = commentData[co].Addedon = typeof(commentData[co].Addedon) === "string" ? commentData[co].Addedon :
					dateTimeFormat.format(commentData[co].Addedon);
				delete(commentData[co].__metadata);
				delete(commentData[co].url);

				// if (commentData[co].Addedon !== null) {
				// 		if (typeof(commentData[co].Addedon) !== "string") {
				// 			commentData[co].Addedon = dateFormat.format(commentData[co].Addedon) +
				// 				"T00:00:00";
				// 		} else {
				// 			commentData[co].Addedon = commentData[co].Addedon + "T00:00:00";
				// 		}

				// 	} else {
				// 		commentData[co].Addedon = null;
				// 	}

			}
			var userId = parent.sap.ushell.Container.getUser().getId(),
				LName = parent.sap.ushell.Container.getUser().getLastName(),
				FName = parent.sap.ushell.Container.getUser().getFirstName(),
				userName = FName + " " + LName;

			var clientData1 = {
				Consideration: this.getQuetData(),
				Action: ActionCode,
				Cmino: this.Cmino,
				Matterk: clientData.Matterk,
				Requestuserk: clientData.Requestuserk,
				Requestuser: clientData.Requestuser,
				Requesttime: clientData.Requesttime,
				Cmirequesttype: "MA",
				Changedbyk: userId,
				Changedby: userName,
				Changedtime: "0",
				Clients: clientData.Clients,
				Clientcontacts: clientData.Clientcontacts,
				Leadpartners: clientData.Leadpartners,
				Knownparties: clientData.Knownparties,
				Matters: clientData.Matters,
				Altpayers: clientData.Altpayers,
				Ocgs: clientData.Ocgs,
				ConsiderationsN: [],
				Matterdetails: clientData.Matterdetails,
				Comments: commentData,
				Offices: clientData.Offices,
				Documents: DocAttachData
			};
			return clientData1;
		},

		postCmiData: function(ActionCode) {
			var oModel = this.getOwnerComponent().getModel(),
				oBusy = new sap.m.BusyDialog();

			var that = this;

			//Check Matter PArtner and Multi Partner Allocation
			if (ActionCode !== "Step") {
				var itemMPAllocation = that.checkValidationforMPAllocation();
				if (itemMPAllocation) {
					var msgmatrpart = "";
					if (itemMPAllocation === "Error") {
						msgmatrpart = that.getResourceBundle().getText("manMatterpartner");
						sap.m.MessageBox.show(msgmatrpart, sap.m.MessageBox.Icon.ERROR, "Error");
						return;
					}
					if (itemMPAllocation.Teamsdesc) {
						msgmatrpart = that.getResourceBundle().getText("msgmatrpartAllocationPerct", [itemMPAllocation.Parvwdesc, itemMPAllocation.OfficeName,
							itemMPAllocation.Teamsdesc
						]);
					} else {
						msgmatrpart = that.getResourceBundle().getText("msgmatrpartAllocationMPerct", [itemMPAllocation.Parvwdesc]);
					}
					sap.m.MessageBox.show(msgmatrpart, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					// oBusy.close();
					return;

				}
				if (!this.checkValidationforMultiAllocation()) {
					var msgmultiPayer = that.getResourceBundle().getText("multiAllocationPerct");
					sap.m.MessageBox.show(msgmultiPayer, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					// oBusy.close();
					return;
				}
			}
			oBusy.open();
			var clientData = that._readpostData(ActionCode);

			// oBusy.open();
			oModel.create("/Cmihdrs", clientData, {
				success: function(oData, oResponse) {
					oBusy.close();
					var sMsg;
					if (oData.Action === "Step") {
						that.setCmino = true;
						var sObjectPath = that.getModel().createKey("Cmihdrs", {
							Cmino: oData.Cmino,
							Clientk: oData.Clientk,
							Cmirequesttype: oData.Cmirequesttype,
							Matterk: oData.Matterk
						});
						that._bindView("/" + sObjectPath);
					} else {
						if (oData.Action === "SUBM") {
							sMsg = that.getResourceBundle().getText("MatterAmendSubmitMsg", oData.Cmino);
						} else {
							sMsg = that.getResourceBundle().getText("MatterAmendSucessMsg", oData.Cmino);
						}

						sap.m.MessageBox.show(sMsg, {
							icon: "SUCCESS",
							title: "Success",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function() {
								that.setCmino = true;
								var sObjectPath = that.getModel().createKey("Cmihdrs", {
									Cmino: oData.Cmino,
									Clientk: oData.Clientk,
									Cmirequesttype: oData.Cmirequesttype,
									Matterk: oData.Matterk
								});
								that._bindView("/" + sObjectPath);
							}
						});
					}
				},
				error: function(oData, oResponse) {
					oBusy.close();
					var obj = JSON.parse(oData.responseText);
					var msg = obj.error.message.value;
					sap.m.MessageBox.show(msg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				},
				async: true
			});
		},
		onPressComments: function(evt, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oEvt = evt.getSource();
			if (!this._oKPNotes) {
				this._oKPNotes = sap.ui.xmlfragment("cmiamendmentnew.fragments.KPNotes", this);
				oView.addDependent(this._oKPNotes);
			}
			this._oKPNotes.setBindingContext(oEvt.getBindingContext());
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oKPNotes);
			this._oKPNotes.openBy(evt.getSource());
		},
		onMultiComment: function(evt) {
			var oEvt = evt.getSource(),
				sPath = this._oKPNotes.getBindingContext().sPath,
				path = oEvt.getBindingPath("value"),
				value = oEvt.getValue(),
				// set Value for Client Details Context
				oMatterModel = oEvt.getBindingContext().getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
		},
		handleCommentAdd: function() {
			this._oKPNotes.close();
		},

		onPressAddLeadPartner: function(evt) {
			var oViewModel = this.getModel("AmendmentViewMod"),
				odata = {
					office: oViewModel.getProperty("/BillOfc"),
					Email: oViewModel.getProperty("/LPEmail"),
					Phone: oViewModel.getProperty("/LPPhone"),
					LeadPartner: oViewModel.getProperty("/LeadPartner")
				};
			var viewMod = this.getModel("jsonAmendModel");
			var CCMod = viewMod.getProperty("/LeadPartner");
			CCMod.push(odata);
			viewMod.refresh();
			oViewModel.setProperty("/BillOfc", "");
			oViewModel.setProperty("/LPEmail", "");
			oViewModel.setProperty("/LPPhone", "");
			oViewModel.setProperty("/LeadPartner", "");
		},
		handleDeleteContacts: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oTable.indexOfItem(oItmSel);
			oTable.getModel("jsonAmendModel").getProperty("/ClientContacts").splice(ind, 1);
			oTable.getModel("jsonAmendModel").refresh();
		},
		handleDeleteLeadPartner: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oTable.indexOfItem(oItmSel);
			oTable.getModel("jsonAmendModel").getProperty("/LeadPartner").splice(ind, 1);
			oTable.getModel("jsonAmendModel").refresh();
		},
		onAddContact: function(oEvt) {
			var oViewModel = this.getModel("AmendmentViewMod"),
				odata = {
					PrimaryContact: oViewModel.getProperty("/PrimaryContact"),
					Email: oViewModel.getProperty("/Email"),
					Phone: oViewModel.getProperty("/Phone")
				},
				viewMod = this.getModel("jsonAmendModel"),
				CCMod = viewMod.getProperty("/ClientContacts");
			CCMod.push(odata);
			viewMod.refresh();
			oViewModel.setProperty("/PrimaryContact", "");
			oViewModel.setProperty("/Email", "");
			oViewModel.setProperty("/Phone", "");
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("NewRequest", {}, true);
			}
		},

		onAlterChange: function(evt) {
			var selected = evt.getParameter("state"),
				model = this.getModel("AmendmentViewMod");
			if (selected) {
				model.setProperty("/altVisible", selected);
			} else {
				model.setProperty("/altVisible", selected);
			}
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.CategoryID,
				sObjectName = oObject.CategoryID;

			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		// Billing Partner
		addBP: function() {
			var oViewNewModel = this.getModel("jsonAmendModel"),
				aClientData = oViewNewModel.getProperty("/Altpayers");
			var obj = {
				"Addrln": "",
				"Name1": "",
				"ParnrNew": "",
				"Parvw": "",
				"Update": true,
				"Cmino": this.Cmino,
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "Payer",
				"Altpayeraddr2": "",
				"Altpayerphone": "",
				"Altpayercityk": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerperc": "0.00",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": ""
			};
			aClientData.push(obj);
			oViewNewModel.refresh();
		},
		addNewBP: function() {
			this.addNewAltPayer();
		},
		onEditBusinessPartner: function(evt) {
			this.editPayer = true;
			this.oAltContext = evt.getSource();
			var qtc = this.getModel(),
				obj,
				idAltPayer, model, oContextAltPayers, sPath, oIconTabBarKey, ln, key;
			if (!this._oAltPayer) {
				this._oAltPayer = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.Matters.AltPayer", this);
				this.getView().addDependent(this._oAltPayer);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAltPayer);
			idAltPayer = this.byId("idAlterDetails");
			obj = evt.getSource().getBindingContext().getObject();
			this._oAltPayer.setTitle("Add New Payer");
			this._oAltPayer.open();
			//	model = idAltPayer.getModel();
			//	sPath = idAltPayer.getBindingContext().getPath();
			//	model.setProperty(sPath + "/Isnew", "X");
			oContextAltPayers = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			idAltPayer.setBindingContext(oContextAltPayers);
			var oAlterData = this.byId("idAlterDetails").getBindingContext().getObject(),
				oError, Field;
			for (var key1 in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key1 === "__metadata") {
						continue;
					}
					oError = this.getModel("ShowAlterError");
					Field = formatter.getAlterKeyField(key1);
					if (Field) {
						oError.setProperty("/" + Field, "None");
					}
				}
			}

			oIconTabBarKey = this.getView().byId("MatterInDetailsStep").getSelectedKey();
			ln = oIconTabBarKey.split("--").length;
			key = oIconTabBarKey.split("--")[ln - 1];
			if (key === "BP") {
				this.byId("idPayerSelect").setEnabled(true);
			} else {
				this.byId("idPayerSelect").setEnabled(false);
			}
		},
		templateAltPayers: function() {
			var addButton = new sap.m.Button({
					text: "",
					icon: "sap-icon://add",
					//	press: this.addAltPayer.bind(this),
					press: this.addNewAltPayer.bind(this),
					enabled: "{AmendmentViewMod>/enablePercent}",
					tooltip: "{i18n>detailBFLabelTooltip1}",
					type: "Emphasized"
				}),
				editButton = new sap.m.Button({
					icon: "sap-icon://edit",
					text: "",
					press: this.onEditBusinessPartner.bind(this),
					type: "Emphasized",
					enabled: "{AmendmentViewMod>/isEditable}"
				});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oTemplate = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						change: this.changeBillPartnerDDDetails.bind(this),
						value: "{Parvwdesc}",
						editable: false
					}).setConfiguration(b),
					new sap.m.HBox({
						justifyContent: "Center",
						items: [
							new sap.ui.comp.smartfield.SmartField({
								change: this.changeAltTableDetails.bind(this),
								value: "{Firstname}",
								editable: "{AmendmentViewMod>/isEditable}",
								valueListChanged: this.valueListChangedBP.bind(this)
							}).setConfiguration(this.tableControlType().b).addStyleClass("sapUiTinyMarginEnd"),
							new sap.ui.comp.smartfield.SmartField({
								change: this.changeAltTableDetails.bind(this),
								value: "{Lastname}",
								editable: "{AmendmentViewMod>/isEditable}"
							})
						]
					}),
					// new sap.ui.comp.smartfield.SmartField({
					// 	change: this.changeAltTableDetails.bind(this),
					// 	value: "{Firstname}",
					// 	editable: "{AmendmentViewMod>/isEditable}",
					// 	valueListChanged: this.valueListChangedBP.bind(this)
					// 		/*	editable: {
					// 				parts: [{
					// 					path: 'Isnew'
					// 				}, {
					// 					path: 'worklistView>/editScreen'
					// 				}],
					// 				formatter: formatter.checkStatus
					// 			}*/
					// }).setConfiguration(this.tableControlType().b),
					// new sap.ui.comp.smartfield.SmartField({
					// 	change: this.changeAltTableDetails.bind(this),
					// 	value: "{Lastname}",
					// 	editable: "{AmendmentViewMod>/isEditable}"
					// }),
					new sap.m.Text({
						maxLines: 3,
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					new sap.m.Input({
						value: "{Altpayerperc}",
						enabled: "{AmendmentViewMod>/isEditable}",
						liveChange: this.liveChangePercent.bind(this)
					}),
					editButton,
					addButton
				]
			});
			oTemplate.addButton = addButton;
			return oTemplate;
		},
		onSubmitAltData: function(evt) {
			if (!this.editPayer) {
				var qtc = this.getModel(),
					oContextMatterBP,
					cObj = this.getBindingContextbyId("idAlterDetails").getObject(),
					oIconTabBarKey = this.getView().byId("MatterInDetailsStep").getSelectedKey(),
					ln = oIconTabBarKey.split("--").length,
					key = oIconTabBarKey.split("--")[ln - 1];

				oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
					properties: cObj
				});
				if (key === "BP") {
					this.bindMatterBPTable1(oContextMatterBP, "New");
				} else {
					this.bindAlterTable(oContextMatterBP, "New");
				}
			} else {
				var oAlt = this.byId("idAlterDetails");
				this.oAltContext.getParent().setBindingContext(oAlt.getBindingContext());
			}
			this._oAltPayer.close();
		},
		// added 27-05
		onAddressMatterValidate: function(evt) {
			if (!this.onAlterMandatory()) {
				return;
			}
			var data = this.getBindingContextbyId("idAlterDetails").getObject(),
				oModel = this.getModel(),
				bAddress = true,
				source = evt.getSource(),
				that = this,
				msg = "",
				oBusy = new sap.m.BusyDialog();
			oBusy.open();
			oModel.callFunction(
				"/ValidateAddress", {
					method: "GET",
					urlParameters: {
						Address1: "",
						Address2: "",
						City: data.Altpayercityk,
						Region: data.Altpayerstatek,
						Postalcode: data.Altpayerzip,
						Country: data.Altpayercountryk,
						Billingoffice: "",
						Email: ""
					},
					success: function(oData, response) {
						oBusy.close();
						if (oData.results) {
							if (oData.results.length) {
								for (var i = 0; i < oData.results.length; i++) {
									if (oData.results[i].Type === "E") {
										msg += oData.results[i].Message + "\n";
										bAddress = false;
									}
								}
								if (!bAddress) {
									sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									that.onSubmitAltData(source);
								}
							}
						}
					},
					error: function(oError) {
						oBusy.close();
						return false;
					}
				});
		},

		addAltPayer: function() {
			var data = this.getTableData("FormChange354BF1");
			for (var w = 0; w < data.length; w++) {
				var vPath = data[w];
				if (!vPath.Firstname || !vPath.Parvwdesc || !vPath.Altpayerperc) {
					var msg = this.getResourceBundle().getText("manAltPayer");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;

				}
			}
			var that = this,
				objArray = [],
				// var aKnownParties = that.getModel("jsonAmendModel").getProperty("/Altpayers1");
				qtc = that.getModel(),
				obj = {
					"Cmino": that.Cmino,
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Parvw": "PY",
					"Parvwdesc": "Payer",
					"Isnew": "",
					"IsMulti": "X",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				};
			objArray.push(obj);
			// that.getModel("jsonAmendModel").setProperty("/Altpayers1", aKnownParties.concat(objArray));
			var oContextKnownParties = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindAlterTable(oContextKnownParties, "Add");
		},
		bindAlterPayer: function(newData) {

			var idMultiPayer = this.byId("FormChange354BF1");
			idMultiPayer.destroyItems();
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that.Cmino,
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Parvw": "PY",
					"Parvwdesc": "Payer",
					"Isnew": "",
					"IsMulti": "X",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": ""
				};
				objArray.push(obj);
				var aMatterBP = that.getModel("jsonAmendModel").getProperty("/Altpayers/results"),
					data1 = aContact.concat(objArray, aMatterBP);
				var qtc = that.getModel();
				for (var k = 0; k < data1.length; k++) {
					var oContextMBP = qtc.createEntry("/Cmialtpayers", {
						properties: data1[k]
					});
					if (data1[k].IsMulti === "X") {
						that.bindAlterTable(oContextMBP);
					}
				}
			});
		},
		bindAlterTable: function(oContextKnownParties, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var idAlterPayer = this.byId("FormChange354BF1"),
				oColumnListItem = this.templateAltPayers();
			oColumnListItem.setBindingContext(oContextKnownParties);
			idAlterPayer.addItem(oColumnListItem);
			this.upDateButtonsMBF(idAlterPayer);
		},
		upDateButtonsMBF: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		liveChangePercent: function(oEvent) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();
			var idBFinance = this.byId("FormChange354BF1");

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
			var total;

			function validTotalPercent() {
				total = 0.00;
				for (var b = 0; b < idBFinance.getItems().length; b++) {
					var oBItem = idBFinance.getItems()[b];
					var oBFinancePath = oBItem.getBindingContext().sPath,
						oBFinanceModel = oBItem.getBindingContext().getModel();
					var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + path);
					var oTVal = oFloatFormat.format(oTPercent);
					if (!oTVal) {
						oTVal = "0.00";
					}
					total = total + oFloatFormat.parse(oTVal);
				}
			}
			validTotalPercent();

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100 || total > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);
					validTotalPercent();
					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			var valPercent = oFloatFormat.format(oPhone);
			var model = this.getModel("AmendmentViewMod");
			if (valPercent >= 100 || total >= 100) {
				model.setProperty("/enablePercent", false);
			} else {
				model.setProperty("/enablePercent", true);
			}
			//	vPhone = oFloatFormat.format(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		liveMatterPercent: function(oEvent) {
			var src = oEvent.getSource(),
				oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
					decimals: 2
				}),
				oPhone;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value"),
					matterPath = src.getBindingContext().sPath,
					matterModel = src.getBindingContext().getModel();
			}
			var vPhone = oEvent.getSource().getValue();

			vPhone = vPhone.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
					//	oEvent.getSource().setValueState("Error");
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}

			function validPercent(Phone) {
				var val = oFloatFormat.format(Phone);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				oPhone = Phone;
				if (val > 100) {
					oPhone = Phone.substring(0, Phone.length - 1);
					matterModel.setProperty(matterPath + "/" + path, oPhone);

					validPercent(oPhone);
				} else {
					return oPhone;
				}
			}
			validPercent(vPhone);
			oEvent.getSource().setValue(oPhone);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, oPhone);
			}
		},
		addNewAltPayer: function() {
			if (!this._oAltPayer) {
				this._oAltPayer = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.Matters.AltPayer", this);
				this.getView().addDependent(this._oAltPayer);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAltPayer);
			this._oAltPayer.open();
		},
		beforeAltPayer: function() {
			var idAltPayer = this.byId("idAlterDetails");
			if (this.editPayer === true) {
				//
			} else {
				this.addAltPayerDialog();
				var oAlterData = this.byId("idAlterDetails").getBindingContext().getObject(),
					oIconTabBarKey, ln, keyI, oContextAltPayer, a, oError, Field;
				for (var key in oAlterData) {
					if (oAlterData.hasOwnProperty(key)) {
						if (key === "__metadata") {
							continue;
						}
						oError = this.getModel("ShowAlterError");
						Field = formatter.getAlterKeyField(key);
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}
				}
				oIconTabBarKey = this.getView().byId("MatterInDetailsStep").getSelectedKey();
				ln = oIconTabBarKey.split("--").length;
				keyI = oIconTabBarKey.split("--")[ln - 1];

				oContextAltPayer = idAltPayer.getBindingContext();
				a = oContextAltPayer.getModel();
				if (keyI === "BP") {
					this._oAltPayer.setTitle("Add New Business Partner");
					a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
					a.setProperty(oContextAltPayer.getPath() + "/Parvw", "");
					a.setProperty(oContextAltPayer.getPath() + "/Parvwdesc", "");
					a.setProperty(oContextAltPayer.getPath() + "/Partnertype", "MP");
					a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
				} else {
					this._oAltPayer.setTitle("Add New Payer");
					a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
					a.setProperty(oContextAltPayer.getPath() + "/Parvw", "PY");
					a.setProperty(oContextAltPayer.getPath() + "/Parvwdesc", "Payer");
					a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "X");
				}
				idAltPayer.setBindingContext(oContextAltPayer);
			}
		},
		addAltPayerDialog: function() {
			var qtc = this.getModel(),
				idAltPayer = this.byId("idAlterDetails"),
				oContextAltPayer = qtc.createEntry("/Cmialtpayers", {}),
				a = oContextAltPayer.getModel();
			a.setProperty(oContextAltPayer.getPath() + "/Alternatepayer", "");
			a.setProperty(oContextAltPayer.getPath() + "/Firstname", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr1", "Payer");

			a.setProperty(oContextAltPayer.getPath() + "/Altpayerzip", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercityk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerperc", "0.00");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountryk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstate", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountry", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerphone", "");
			a.setProperty(oContextAltPayer.getPath() + "/Cmino", this.Cmino);
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerseq", "0001");
			var oIconTabBarKey = this.getView().byId("MatterInDetailsStep").getSelectedKey(),
				ln = oIconTabBarKey.split("--").length,
				key = oIconTabBarKey.split("--")[ln - 1];
			if (key === "BP") {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", true);
			} else {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", false);
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		changeAltTableDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},

		changeInClientAdd: function(oEvent) {
			var src = oEvent.getSource(),
				vPhone, validPh,
				path, matterPath, matterModel;
			if (src.getBindingContext()) {
				path = src.getBindingPath("value");
				matterPath = src.getBindingContext().sPath;
				matterModel = src.getBindingContext().getModel();
			}
			vPhone = oEvent.getSource().getValue();
			vPhone = vPhone.replace(/[^0-9]+/g, "");
			validPh = /^[0-9]{1,30}$/;
			if (vPhone) {
				if (vPhone.match(validPh)) {
					oEvent.getSource().setValue(vPhone);
					oEvent.getSource().setValueState("None");
				} else {
					vPhone = vPhone.substring(0, vPhone.length - 1);
					oEvent.getSource().setValue(vPhone);
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			} else {
				oEvent.getSource().setValue(vPhone);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, vPhone);
				}
			}
		},
		getBindingContextbyId: function(sId) {
			var oContext = this.getView().byId(sId).getBindingContext();
			return oContext;
		},
		onAlterMandatory: function(e) {
			var that = this,
				oAlterData = that.byId("idAlterDetails").getBindingContext().getObject(),
				sFlag = true,
				oError, Field;
			for (var key in oAlterData) {
				if (oAlterData.hasOwnProperty(key)) {
					if (key === "__metadata" || key === "Altpayeraddr1" || key === "Altpayeraddr2" || key === "Alternatepayer") {
						continue;
					}
					oError = this.getModel("ShowAlterError");
					Field = formatter.getAlterKeyField(key);
					if (oAlterData[key] === "" || oAlterData[key] === undefined) {
						if (Field) {
							if (!e) {
								oError.setProperty("/" + Field, "Error");
							}
							sFlag = false;
						}
					} else {
						if (Field) {
							oError.setProperty("/" + Field, "None");
						}
					}

				}
			}
			return sFlag;
		},
		handleDeletePayer: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormChange354BF1");

			this._removeConditionMBF(oTable);
			// var total = 0.00;
			// var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
			// 	decimals: 2
			// });
			// var idBFinance = this.byId("FormChange354BF1");
			// for (var b = 0; b < idBFinance.getItems().length; b++) {
			// 	var oBItem = idBFinance.getItems()[b];
			// 	var oBFinancePath = oBItem.getBindingContext().sPath,
			// 		oBFinanceModel = oBItem.getBindingContext().getModel();
			// 	var oTPercent = oBFinanceModel.getProperty(oBFinancePath + "/" + "Altpayerperc");
			// 	var oTVal = oFloatFormat.format(oTPercent);
			// 	if (!oTVal) {
			// 		oTVal = "0.00";
			// 	}
			// 	total = total + oFloatFormat.parse(oTVal);
			// }
			// var model = this.getModel("objectView");
			// if (total >= 100) {
			// 	model.setProperty("/enablePercent", false);
			// } else {
			// 	model.setProperty("/enablePercent", true);
			// }
		},

		_removeConditionMBF: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.addAltPayer();
			}
			this.upDateButtonsMBF(oTable);
		},
		onCloseAltData: function() {
			this._oAltPayer.close();
		},
		bindMatterBP: function() {
			var idBillPartenr = this.byId("FormChange354BP");
			idBillPartenr.destroyItems();
			// var newData = this.getModel("jsonAmendModel").getProperty("/Altpayers/results");
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that.Cmino,
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "MP",
					"Parvw": "",
					"Parvwdesc": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": "",
					"Nrart": "",
					"Firstname": "",
					"Lastname": "",
					"Allocation": "0.00",
					"Teams": "",
					"Teamsdesc": ""
				};
				objArray.push(obj);
				var aMatterBP = that.getModel("jsonAmendModel").getProperty("/Altpayers/results"),
					newData = aContact.concat(objArray, aMatterBP);
				var qtc = that.getModel();
				for (var k = 0; k < newData.length; k++) {
					var oContextMBP = qtc.createEntry("/Cmialtpayers", {
						properties: newData[k]
					});
					if (newData[k].IsMulti === "" && newData[k].Nrart === "") {
						that.bindMatterBPTable1(oContextMBP);
					}
				}
			});

			// this.getModel("jsonAmendModel").setProperty("/Cllientbp", newData);
		},
		//Matter Detail Section - BP Tab
		bindMatterBPTable1: function(oContextMatterBP, e) {
			var idBillPartner = this.byId("FormChange354BP"),
				oColumnListItem = this.templateMatterBusinessPartner(e);
			oColumnListItem.setBindingContext(oContextMatterBP);
			idBillPartner.addItem(oColumnListItem);
			this.updateMatterBP(idBillPartner);
		},
		updateMatterBP: function(oTable) {
			var oAddBtn,
				n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		onAddMatterBP: function() {
			var data = this.getTableData("FormChange354BP");
			for (var w = 0; w < data.length; w++) {
				var vPath = data[w];
				if (!vPath.Firstname || !vPath.Parvwdesc || !vPath.Allocation || !vPath.OfficeName) {
					var msg = this.getResourceBundle().getText("manMatterpartner");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;

				}
			}
			var that = this,
				objArray = [],
				qtc = that.getModel(),
				obj = {
					"Cmino": that.Cmino,
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "MP",
					"Parvwdesc": "",
					"Parvw": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": "",
					"Nrart": "",
					"Firstname": "",
					"Lastname": "",
					"Allocation": "0.00",
					"Teams": "",
					"Teamsdesc": ""
				};
			objArray.push(obj);
			obj.Partnertype = "MP";
			obj.Nrart = "";
			var oContextMatterBP = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});
			that.bindMatterBPTable1(oContextMatterBP);
		},
		bindMatterBPTable: function(oContextMatterBP, e) {
			var bEdit = true;
			if (e === "New") {
				bEdit = false;
			}
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				type: "Emphasized",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddMatterBP.bind(this)
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				controlType: "dropDownList",
				displayBehaviour: "idOnly"
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var idBillPartenr = this.byId("FormChange354BP");
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Partnertypedesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Alternatepayer}",
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'AmendmentViewMod>/isEditable'
							}],
							formatter: formatter.checkStatus
						},
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedBP.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Firstname}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),
					addButton
				]
			});
			oColumnListItem["addButton"] = addButton;
			oColumnListItem.setBindingContext(oContextMatterBP);
			idBillPartenr.addItem(oColumnListItem);
			this.upDateButtonsMBP(idBillPartenr);
		},
		upDateButtonsMBP: function(oTable) {
			var n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				var oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		changeBillPartnerDDDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				oItem = source.getAggregation("_content");
			if (oItem) {
				var id, description, key,
					selData = oItem.getSelectedItem().getBindingContext().getObject();
				if (path === "Partnertypedesc") {
					id = "Partnertype";
					description = "VTEXT";
					key = "PARVW";
				}
				if (path === "Parvwdesc") {
					id = "Parvw";
					description = "VTEXT";
					key = "PARVW";
				}
				model.setProperty(sPath + "/" + path, selData[description]);
				model.setProperty(sPath + "/" + id, selData[key]);
				source.getAggregation("_content").setValue(selData[description]);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		valueListChangedBP: function(evt) {
			var data = evt.getSource().getBindingContext().getObject(),
				source = evt.getSource(),
				model = source.getModel(),
				sPath = source.getBindingContext().getPath(),
				sParvw = data.Parvw,
				sAlternatepayer = data.Alternatepayer,
				aFilter = [new Filter("Parvw", sap.ui.model.FilterOperator.EQ, sParvw), new Filter("Alternatepayer", sap.ui.model
					.FilterOperator
					.EQ, sAlternatepayer)],
				filesPath = "/Cmialtpayers",
				oModel = this.getModel();
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Altpayeraddr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Altpayeraddr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Altpayercityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Altpayerstatek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Altpayercountryk", obj.Altpayercountryk);
							model.setProperty(sPath + "/Altpayerphone", obj.Altpayerphone);
							model.setProperty(sPath + "/Altpayerstate", obj.Altpayerstate);
							model.setProperty(sPath + "/Altpayercountry", obj.Altpayercountry);
							model.setProperty(sPath + "/Altpayerzip", obj.Altpayerzip);
						}
					}
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		onReset: function() {
			var oIconTabBarKey, ln, keyI, idAltPayer, oContextAltPayer, a;
			oIconTabBarKey = this.getView().byId("MatterInDetailsStep").getSelectedKey();
			ln = oIconTabBarKey.split("--").length;
			keyI = oIconTabBarKey.split("--")[ln - 1];
			idAltPayer = this.byId("idAlterDetails");
			oContextAltPayer = idAltPayer.getBindingContext();
			a = oContextAltPayer.getModel();
			a.setProperty(oContextAltPayer.getPath() + "/Alternatepayer", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountry", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercountryk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstate", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerstatek", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerzip", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayername", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayercityk", "");
			a.setProperty(oContextAltPayer.getPath() + "/Altpayerphone", "");
			a.setProperty(oContextAltPayer.getPath() + "/Firstname", "");
			a.setProperty(oContextAltPayer.getPath() + "/Lastname", "");
			if (keyI === "BP") {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Parvwdesc", "");
				a.setProperty(oContextAltPayer.getPath() + "/Parvw", "");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "");
			} else {
				a.setProperty(oContextAltPayer.getPath() + "/Altpayeraddr2", "");
				a.setProperty(oContextAltPayer.getPath() + "/Parvw", "PY");
				a.setProperty(oContextAltPayer.getPath() + "/Parvwdesc", "Payer");
				a.setProperty(oContextAltPayer.getPath() + "/IsMulti", "X");
			}
			idAltPayer.setBindingContext(oContextAltPayer);
		},
		handleDeleteBP: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem");
			oItmSel.destroy();
			var oTable = this.byId("FormChange354BP");
			// ind = oTable.indexOfItem(oItmSel);
			this._removeConditionMBP(oTable);
		},
		_removeConditionMBP: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddMatterBP();
			}
			this.upDateButtonsMBP(oTable);
		},
		changeBillPartnerDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		// Post Comments
		onPostCommnets: function(evt) {

			var cType = "CI",
				text = evt.getParameter("value"),
				userId = this.getModel("AmendmentViewMod").getProperty("/userId"),
				name = this.getModel("AmendmentViewMod").getProperty("/userName"),
				obj = {
					Cmino: this.Cmino,
					CommentType: cType,
					Sequence: "",
					UserComment: text,
					Addedby: name,
					Addedbyk: userId,
					Addedon: new Date()
				},
				oRemarks = this.getView().getModel("CommentsModel"),
				oRemarkData = oRemarks.getProperty("/CommentSet");
			oRemarkData.push(obj);
			oRemarks.setProperty("/CommentSet", oRemarkData);
			this.onFilterComments(cType);
			if (this._oCommentsForSteps) {
				this._oCommentsForSteps.close();
			}

		},
		onFilterComments: function(val) {

			var cType = "CI",
				aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("CommentType", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oList = this.getView().byId("idCommentsList");
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		handleDeleteComments: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem"),
				ind = oItmSel.getBindingContext("CommentsModel").getObject().Sequence;
			oTable.getModel("CommentsModel").getProperty("/CommentSet").splice(ind, 1);
			oTable.getModel("CommentsModel").refresh();
		},
		//Documents Upload
		onDocumentClick: function(e) {
			var proto = window.location.protocol,
				host = window.location.host,
				k = this.byId("idAttachment").getSelectedKey();
			if (k === "MD") {
				var service = proto + "//" + host + "/sap/opu/odata/sap/ZPRS_CMI_SRV/Cmidocuments";
				this.byId(k).getContent()[0].setUploadUrl(service);
				// this.fileattachmentFilter(this.byId(k).getContent()[0], k);
			}
		},

		onChangeDocuments: function(oEvent) {
			var ClientK = this.getModel("AmendmentViewMod").getProperty("/Clientk"),
				MatterK = this.getModel("AmendmentViewMod").getProperty("/Matterk"),

				oUploadCollection = oEvent.getSource(),
				// Header Token
				cmiNo = this.Cmino;

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = this.byId("idAttachment").getSelectedKey();
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + ClientK + "|" + MatterK + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size +
					"|" + key
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [],
					resText = xmlToJSON.parseString(response.responseRaw),
					key = this.byId("idAttachment").getSelectedKey(),
					host = window.location.host,
					protocol = window.location.protocol,
					urlprefix = protocol + "//" + host,
					serviceUrl = this.getModel().sServiceUrl,
					url = "",
					Clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk"),
				Matterk = this.getModel("AmendmentViewMod").getProperty("/Matterk"),
					obj = {
						"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
						"Doctype": key,
						"url": url,
						"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
						"Filename": resText.entry[0].properties[0].Filename[0]._text,
						"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
						"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
						"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
						"Clientk": Clientk,
						"Matterk": Matterk
					};
				url = urlprefix + serviceUrl + "/Cmidocuments(Cmino='" + obj.Cmino + "',Clientk='" + Clientk + "',Matterk='" + Matterk +
					"',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet");
				this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", arr.concat(data));
				// this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw),
						errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId,
				that = this,
				data = this.getView().getModel("AttachmentModel").getProperty("/FileDataSet"),
				Cmino = "",
				Docseq = "",
				Doctype = "";
			var clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk"),
				matterk = this.getModel("AmendmentViewMod").getProperty("/Matterk");

			for (var i = 0; i < data.length; i++) {
				if (data[i].Docseq === srNos) {
					Cmino = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("AttachmentModel").getData().FileDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("AttachmentModel").setProperty("/FileDataSet", data);
			var path = "/Cmidocuments(Matterk='" + matterk + "',Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq +
				"',Doctype='" + Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData, oResponse) {
					var FileDeleteMsgTxt = this.getResourceBundle().getText("FileDeleteMsgTxt");
					sap.m.MessageBox.show(FileDeleteMsgTxt, sap.m.MessageBox.Icon.INFORMATION, "Information");
					// sap.m.MessageToast.show("Document deleted successfully.");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},
		/// KP Attachments
		addAttachments: function(evt, oView) {
			var cmiId = this.Cmino,
				i18n = this.getResourceBundle();
			if (!cmiId) {
				sap.m.MessageBox.show(i18n.getText("attachKPMsg"), {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (!oView) {
				oView = this.getView();
			}
			this.seqno = evt.getSource().getBindingContext().getObject().Knownpartyseq;
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragments.KPUpload", this);
				oView.addDependent(this._attchParties);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._attchParties);
			this._attchParties.open();
		},
		onCloseKPDialog: function() {
			this._attchParties.close();
		},
		onChangeKPDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var cmiNo = this.Cmino;
			var clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk"),
				Matterk = this.getModel("AmendmentViewMod").getProperty("/Matterk");
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var key = "KP";
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: cmiNo + "|" + clientk + "|" + Matterk + "|" + oEvent.mParameters.files[0].name + "|" + oEvent.mParameters.files[0].size +
					"|" + key + "|" +
					this.seqno

			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadCompleteKPDocuments: function(oEvent) {
			var response = oEvent.getParameter("files")[0];
			if (oEvent.getParameter("files")[0].status === 201) {
				var arr = [];
				var resText = xmlToJSON.parseString(response.responseRaw);
				var key = "KP";
				var host = window.location.host;
				var protocol = window.location.protocol;
				var urlprefix = protocol + "//" + host;
				var serviceUrl = this.getModel().sServiceUrl;
				var url = "";
				var Clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk");
				var Matterk = this.getModel("AmendmentViewMod").getProperty("/Matterk");
				var obj = {
					"Cmino": resText.entry[0].properties[0].Cmino[0]._text.toString(),
					"Doctype": key,
					"url": url,
					"Docseq": resText.entry[0].properties[0].Docseq[0]._text.toString(),
					"Filename": resText.entry[0].properties[0].Filename[0]._text,
					"Filesize": resText.entry[0].properties[0].Filesize[0]._text.toString(),
					"Uploadedbyk": resText.entry[0].properties[0].Uploadedbyk[0]._text,
					"Uploadedby": resText.entry[0].properties[0].Uploadedby[0]._text,
					"Clientk": Clientk,
					"Matterk":Matterk

				};
				url = urlprefix + serviceUrl + "/Cmidocuments(Clientk='" + Clientk + "',Matterk='" + Matterk + "',Cmino='" + obj.Cmino +
					"',Docseq='" + obj.Docseq +
					"',Doctype='" + obj.Doctype +
					"')/$value";
				obj.url = url;
				arr.push(obj);
				var data = this.getView().getModel("KPModel").getProperty("/KPDataSet");
				this.getView().getModel("KPModel").setProperty("/KPDataSet", arr.concat(data));
				this.fileattachmentFilter(oEvent.getSource(), key);
			} else {
				if (response.responseRaw) {
					var resTextErr = xmlToJSON.parseString(response.responseRaw);
					var errmessage = resTextErr.error[0].message[0]._text;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
				} else {
					oEvent.getSource().fireUploadTerminated();
				}
			}
		},
		fileattachmentKPFilter: function(oList, cType) {
			var aFilters = [];
			var oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.Contains, cType);
			aFilters.push(oFilterCommentType);
			var oFinalFilterApply = new sap.ui.model.Filter(aFilters, false);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onFileKPDeleted: function(oControlEvent) {
			var srNos = oControlEvent.mParameters.documentId,
				type = "KP",
				data = this.getView().getModel("KPModel").getProperty("/KPDataSet"),
				Cmino = "",
				Docseq = "",
				Doctype = "",
				sLength = data.length,
				path,
				matterk = this.getModel("AmendmentViewMod").getProperty("/Matterk"),
				clientk = this.getModel("AmendmentViewMod").getProperty("/Clientk");
			for (var i = 0; i < sLength; i++) {
				if (data[i].Docseq === srNos && data[i].Doctype === type) {
					Cmino = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Cmino;
					Docseq = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Docseq;
					Doctype = oControlEvent.getParameters().item.getModel("KPModel").getData().KPDataSet[i].Doctype;
					data.splice(i, 1);
				}
			}
			this.getView().getModel("KPModel").setProperty("/KPDataSet", data);
			path = "/Cmidocuments(Matterk='" + matterk + "',Clientk='" + clientk + "',Cmino='" + Cmino + "',Docseq='" + Docseq + "',Doctype='" +
				Doctype + "')";
			this.getModel().remove(path, {
				success: function(oData) {
					sap.m.MessageBox.show("Document deleted successfully.", sap.m.MessageBox.Icon.INFORMATION, "Information");
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},
		// Matter Detail Section - IP Tab
		bindMatterIPTable: function(oContextMatterBP, e) {
			var idBillPartner = this.byId("FormChange354IP"),
				oColumnListItem = this.templateMatterIntPartner(e);
			oColumnListItem.setBindingContext(oContextMatterBP);
			idBillPartner.addItem(oColumnListItem);
			this.updateMatterIP(idBillPartner);
		},
		/**
		 * bind Table for matter business partner
		 */
		onAddMatterIPBtn: function() {
			var idIPdatatbl = this.byId("FormChange354IP");
			idIPdatatbl.destroyItems();
			var that = this;
			this.getModel().metadataLoaded().then(function() {
				var aContact = [],
					data;
				var objArray = [];
				var obj = {
					"Cmino": that.Cmino,
					"Altpayerseq": "",
					"Alternatepayer": "",
					"Altpayername": "",
					"Altpayeraddr1": "",
					"Altpayeraddr2": "",
					"Altpayercityk": "",
					"Altpayerperc": "0.00",
					"Partnertype": "",
					"Partnertypedesc": "",
					"Parvw": "",
					"Parvwdesc": "",
					"Isnew": "",
					"IsMulti": "",
					"Altpayerphone": "",
					"Altpayerstate": "",
					"Altpayerstatek": "",
					"Altpayerzip": "",
					"Altpayercountryk": "",
					"Altpayercountry": "",
					"Comments": "",
					"Lastname": "",
					"OfficeCode": "",
					"OfficeName": "",
					"Phone": "",
					"Email": "",
					"Preferred": "",
					"Nrart": "PE",
					"Teams": "",
					"Teamsdesc": ""
				};
				objArray.push(obj);
				obj.Partnertype = "MIC";
				obj.Nrart = "PE";

				var aMatterBP = that.getModel("jsonAmendModel").getProperty("/Altpayers/results"),
					newData = aContact.concat(objArray, aMatterBP);
				var qtc = that.getModel();
				for (var k = 0; k < newData.length; k++) {
					var oContextMIP = qtc.createEntry("/Cmialtpayers", {
						properties: newData[k]
					});
					if (newData[k].IsMulti === "" && newData[k].Nrart === "PE") {
						that.bindMatterIPTable(oContextMIP);
					}

				}
			});
		},
		onAddMatterIP: function() {
			var data = this.getTableData("FormChange354IP");
			for (var w = 0; w < data.length; w++) {
				var vPath = data[w];
				if (!vPath.Firstname || !vPath.Parvwdesc || !vPath.Phone || !vPath.Email || !vPath.OfficeName) {
					var msg = this.getResourceBundle().getText("manIntpartner");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;

				}
			}
			var that = this;
			// this.getModel().metadataLoaded().then(function() {
			var aContact = [],
				data;
			var objArray = [];
			var obj = {
				"Cmino": that.Cmino,
				"Altpayerseq": "",
				"Alternatepayer": "",
				"Altpayername": "",
				"Altpayeraddr1": "",
				"Altpayeraddr2": "",
				"Altpayercityk": "",
				"Altpayerperc": "0.00",
				"Partnertype": "MIC",
				"Partnertypedesc": "",
				"Parvw": "",
				"Parvwdesc": "",
				"Isnew": "",
				"IsMulti": "",
				"Altpayerphone": "",
				"Altpayerstate": "",
				"Altpayerstatek": "",
				"Altpayerzip": "",
				"Altpayercountryk": "",
				"Altpayercountry": "",
				"Comments": "",
				"Lastname": "",
				"OfficeCode": "",
				"OfficeName": "",
				"Phone": "",
				"Email": "",
				"Preferred": "",
				"Nrart": "PE",
				"Teams": "",
				"Teamsdesc": ""
			};
			objArray.push(obj);
			obj.Partnertype = "MIC";
			obj.Nrart = "PE";
			// var aMatterBP = that.getModel("jsonAmendModel").getProperty("/Altpayers/results"),
			// 	newData = aContact.concat(objArray, aMatterBP);
			var qtc = that.getModel();
			// for (var k = 0; k < newData.length; k++) {
			var oContextMIP = qtc.createEntry("/Cmialtpayers", {
				properties: obj
			});

			that.bindMatterIPTable(oContextMIP);

			// }
			// });
		},
		/**
		 * update add button visibility for matter business partner
		 */
		updateMatterIP: function(oTable) {
			var oAddBtn,
				n = oTable.getItems().length;
			for (var i = 0; i < n; i++) {
				oAddBtn = oTable.getItems()[i].addButton;
				if ((i === 0)) {
					oAddBtn.removeStyleClass("displayNone");
				} else {
					oAddBtn.addStyleClass("displayNone");
				}
			}
		},
		/**
		 * function to delete Business Partner
		 */
		handleDeleteIP: function(oEvt) {
			var oItmSel = oEvt.getParameter("listItem"),
				oTable = this.byId("FormChange354IP");
			oItmSel.destroy();
			this._removeMatterIPCondition(oTable);
		},
		/**
		 * function to show atleast one row for Matter BP
		 */
		_removeMatterIPCondition: function(oTable) {
			if (oTable.getItems().length < 1) {
				this.onAddMatterIP();
			}
			this.updateMatterIP(oTable);
		},
		changeIPDPDetails: function(evt) {
			//
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				var bcType = this.checkMatterPType(selData.Parvw);
				if (!bcType) {
					msg = i18n.getText("allowSignOff");
					model.setProperty(sPath + "/Parvw", "");
					model.setProperty(sPath + "/Parvwdesc", "");
					model.setProperty(sPath + "/Allocation", "");
					source.getAggregation("_content").setValue("");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
				model.setProperty(sPath + "/Parvw", selData.Parvw);
				model.setProperty(sPath + "/Parvwdesc", value);
				source.getAggregation("_content").setValue(value);

			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		checkMatterPType: function() {
			var aClientData = this.getTableData("FormChange354IP"),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === "ZS") {
						count++;
					}
				}
			});
			return count > 1 ? false : true;
		},
		getTableData: function(sTableId) {
			var aTableData = [],
				obj,
				oTable = this.getView().byId(sTableId);
			$.each(oTable.getItems(), function(rindex, row) {
				obj = row.getBindingContext().getObject();
				delete(obj.__metadata);
				aTableData.push(obj);
			});
			return aTableData;
		},
		// date formate change
		ondatechange: function(oEvt) {
			var s = oEvt.getSource(),
				bPath = s.getBindingPath('value'),
				bc = s.getBindingContext(),
				m = bc.getModel(),
				pDate = s.getInnerControls()[0].getDateValue();
			var delayInvk = (function(pD, bP, that) {
				return function() {

					m.setProperty(bc.getPath() + "/" + bPath, pDate);
				};
			})(m, bPath, this);

			jQuery.sap.delayedCall(100, this, delayInvk);

		},
		//for Int partner
		displayPartnerData: function() {
			var that = this,
				oModel = this.getOwnerComponent().getModel(),
				path = "/Cmipartnertype",
				oJsonModel = new sap.ui.model.json.JSONModel(),
				aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, "MIC")];
			oModel.read(path, {
				filters: aFilter,
				success: function(oData) {
					oJsonModel.setData({
						Cmigetpartnertype: oData.results
					});
					that.getView().setModel(oJsonModel, "oSelectIntPartner");
				},
				error: function(oResponse) {

				}
			});
		},
		/// fro matter partner
		displayMatterPartnerData: function() {
			var that = this,
				oModel = this.getOwnerComponent().getModel(),
				path = "/Cmipartnertype",
				oJsonModel = new sap.ui.model.json.JSONModel(),
				aFilter = [new Filter("Partnertype", sap.ui.model.FilterOperator.EQ, "MP")];
			oModel.read(path, {
				filters: aFilter,
				success: function(oData) {
					oJsonModel.setData({
						Cmigetpartnertype: oData.results
					});
					that.getView().setModel(oJsonModel, "oSelectMatterPartner");
				},
				error: function(oResponse) {

				}
			});
		},
		changeIPDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		templateMatterIntPartner: function(e) {
			var addButton = new sap.m.Button({
				text: "",
				icon: "sap-icon://add",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddMatterIP.bind(this),
				type: "Emphasized"
			});
			var maskInput = new sap.m.MaskInput({
				value: "{Phone}",
				enabled: "{AmendmentViewMod>/isEditable}",
				mask: "999999999999999",
				placeholderSymbol: " ",
				change: this.changeIPDetails.bind(this)
			});
			// var oItemTemplate = new sap.ui.core.Item({
			// 	key: "{oSelectIntPartner>Partnertype}",
			// 	text: "{oSelectIntPartner>Partnertypedesc}"
			// });
			// var oSelect = new sap.m.Select({
			// 	selectedKey: "{Partnertype}",
			// 	change: this.changeIPDPDetails.bind(this),
			// 	items: {
			// 		path: "oSelectIntPartner>/Cmigetpartnertype",
			// 		template: oItemTemplate
			// 	}
			// });
			// this.setModel("oSelectIntPartner", oSelect);
			var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeIPDetails.bind(this),
						valueListChanged: this.changeIPDPDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{OfficeName}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeIPDetails.bind(this)
					}).setConfiguration(b),

					/*new sap.ui.comp.smartfield.SmartField({
						value: "",
						editable: "{worklistView>/editScreen}",
						change: this.changeContacts.bind(this)
					}),*/
					/*new sap.ui.comp.smartfield.SmartField({
						value: "{Lastname}",
						editable: "{worklistView>/editScreen}",
						change: this.changeIPDetails.bind(this)
					}),*/
					new sap.m.HBox({
						justifyContent: "Center",
						items: [new sap.ui.comp.smartfield.SmartField({
								value: "{Firstname}",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this),
								placeholder: "First Name"
							}).setConfiguration(c).addStyleClass("sapUiTinyMarginEnd"),
							new sap.ui.comp.smartfield.SmartField({
								value: "{Lastname}",
								placeholder: "Last Name",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this)
							})
						]
					}).addStyleClass("sapUiTinyMarginEnd"),
					// new sap.ui.core.Icon({
					// 	color: "{=${Preferred} === 'P' ? 'green' : 'black'}",
					// 	src: "{=${Preferred} === 'P' ? 'sap-icon://accept' : 'sap-icon://circle-task'}",
					// 	size: "{=${Preferred} === 'P' ? '20px' : '1rem'}",
					// 	enabled: "{AmendmentViewMod>/isEditable}",
					// 	press: this.handlePrimaryInt.bind(this)
					// }),
					maskInput,
					/*new sap.ui.comp.smartfield.SmartField({
						value: "{Phone}",
						editable: "{worklistView>/editScreen}",
						change: this.changeContacts.bind(this)
					}),*/
					new sap.ui.comp.smartfield.SmartField({
						value: "{Email}",
						editable: "{AmendmentViewMod>/isEditable}",
						change: this.changeIPDetails.bind(this),
						valueState: {
							path: "Email",
							formatter: formatter.emailValidation
						},
						valueStateText: "Invalid EmailId"
					}),
					new sap.m.TextArea({
						value: "{Comments}",
						enabled: "{AmendmentViewMod>/isEditable}",
						placeholder: "{i18n>CommentsPlaceholder}",
						cols: 50,
						rows: 1,
						maxLength: 241,
						change: this.changeIPDetails.bind(this)
					}),
					/*new sap.m.Button({
						icon : "sap-icon://message-popup",
						type : "{=${Comments} ? 'Emphasized':'Default'}",
						press : this.onPressContactComments.bind(this)
					}),*/
					addButton
				]
			});
			oColumnListItem.addButton = addButton;
			return oColumnListItem;
		},
		handlePrimaryInt: function(evt) {
			/* var oControl = evt.getSource(),
			  oContext = oControl.getBindingContext("NRequestView"),
			  sPath = oContext.sPath,
			  allContext = oContext.getModel().mContexts,
			  oContexts = Object.getOwnPropertyNames(allContext);
			 oContexts.map(function(sPathItem) {
			  if (sPathItem.indexOf("/Clientcontacts") !== -1) {
			   oContext.getModel().setProperty(sPathItem + "/Contacttype", "S");
			  }
			 });
			 oContext.getModel().setProperty(sPath + "/Contacttype", "P");*/

			var source = evt.getSource(),
				model = source.getModel(),
				allContext = this.getModel().mContexts,
				oContexts = Object.getOwnPropertyNames(allContext),
				path = source.getBindingPath("src"),
				sPath = source.getBindingContext().getPath();
			oContexts.map(function(sPathItem) {
				if (sPathItem.indexOf("/Cmialtpayers") !== -1) {
					model.setProperty(sPathItem + "/Preferred", "S");
				}
			});
			model.setProperty(sPath + "/" + path, "P");
		},

		changeContacts: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
		},
		onContactComment: function(evt) {
			var oEvt = evt.getSource(),
				sPath = oEvt.getBindingContext().sPath,
				path = oEvt.getBindingPath("value"),
				value = oEvt.getValue(),
				oMatterModel = oEvt.getBindingContext().getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
		},
		templateMatterBusinessPartner: function(e) {
			var addButton = new sap.m.Button({
				text: "",
				icon: "sap-icon://add",
				enabled: "{AmendmentViewMod>/isEditable}",
				press: this.onAddMatterBP.bind(this),
				type: "Emphasized"
			});
			var a = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var b = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var c = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var d = new sap.ui.comp.smartfield.Configuration({
				preventInitialDataFetchInValueHelpDialog: false
			});
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Parvwdesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						valueListChanged: this.changeMPDPDetails.bind(this)
					}).setConfiguration(a),
					new sap.ui.comp.smartfield.SmartField({
						value: "{OfficeName}",
						editable: "{AmendmentViewMod>/isEditable}",
						valueListChanged: this.changeMPOfficeDetails.bind(this)
					}).setConfiguration(b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Teamsdesc}",
						editable: "{AmendmentViewMod>/isEditable}",
						valueListChanged: this.changeMPTeamsDetails.bind(this),
						visible: {
							path: "Parvw",
							formatter: formatter.checkTeamButton
						}
					}).setConfiguration(d),
					new sap.m.HBox({
						justifyContent: "Center",
						items: [new sap.ui.comp.smartfield.SmartField({
								value: "{Firstname}",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this),
								placeholder: "First Name"
							}).setConfiguration(c).addStyleClass("sapUiTinyMarginEnd"),
							new sap.ui.comp.smartfield.SmartField({
								value: "{Lastname}",
								placeholder: "Last Name",
								editable: "{AmendmentViewMod>/isEditable}",
								change: this.changeBillPartnerDetails.bind(this)
							})
						]
					}).addStyleClass("sapUiTinyMarginEnd"),

					// oSelect,
					/*new sap.ui.comp.smartfield.SmartField({
						value: "{Partnertypedesc}",
						editable: bEdit,
						change: this.changeBillPartnerDDDetails.bind(this)
					}).setConfiguration(this.tableControlType().a),*/
					new sap.ui.comp.smartfield.SmartField({
						value: "{Alternatepayer}",
						editable: {
							parts: [{
								path: 'Isnew'
							}, {
								path: 'AmendmentViewMod>/isEditable'
							}],
							formatter: formatter.checkStatus
						},
						change: this.changeBillPartnerDetails.bind(this),
						valueListChanged: this.valueListChangedBP.bind(this)
					}).setConfiguration(this.tableControlType().b),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Firstname}",
						editable: false,
						change: this.changeBillPartnerDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{Altpayeraddr1} {Altpayeraddr2} {Altpayercountry}"
					}),

					new sap.m.Input({
						value: "{Allocation}",
						enabled: {
							path: 'Parvw',
							formatter: formatter.checkCPPerc
						},
						liveChange: this.liveMatterPercent.bind(this)
					}),
					addButton
				]
			});
			oColumnListItem.addButton = addButton;
			return oColumnListItem;
		},
		changeMPOfficeDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				model.setProperty(sPath + "/OfficeCode", selData.OfficeCode);
				model.setProperty(sPath + "/OfficeName", value);
				source.getAggregation("_content").setValue(value);
				if (this.getTotalMPPerCent(source.getBindingContext().getObject()) >= 100 && (source.getBindingContext().getObject().Parvw !==
						"ZL")) {
					msg = i18n.getText("selectPert", source.getBindingContext().getObject().Parvwdesc);
					model.setProperty(sPath + "/OfficeCode", "");
					model.setProperty(sPath + "/OfficeName", "");
					model.setProperty(sPath + "/Allocation", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		changeMPTeamsDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				model.setProperty(sPath + "/Teams", selData.Teams);
				model.setProperty(sPath + "/Teamsdesc", value);
				source.getAggregation("_content").setValue(value);
				if (this.getTotalMPPerCent(source.getBindingContext().getObject()) >= 100 && (source.getBindingContext().getObject().Parvw !==
						"ZL")) {
					msg = i18n.getText("selectPert", source.getBindingContext().getObject().Parvwdesc);
					model.setProperty(sPath + "/Teams", "");
					model.setProperty(sPath + "/Teamsdesc", "");
					model.setProperty(sPath + "/Allocation", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		changeMPDPDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				var bcType = this.checkMatterMPType(selData.Parvw);
				if (!bcType) {
					msg = i18n.getText("allowMatterPart");
					model.setProperty(sPath + "/Parvw", "");
					model.setProperty(sPath + "/Parvwdesc", "");
					model.setProperty(sPath + "/Allocation", "");
					source.getAggregation("_content").setValue("");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
				model.setProperty(sPath + "/Parvw", selData.Parvw);
				model.setProperty(sPath + "/Parvwdesc", value);
				source.getAggregation("_content").setValue(value);
				if (this.getTotalMPPerCent(source.getBindingContext().getObject()) >= 100) {
					msg = i18n.getText("selectPert", value);
					model.setProperty(sPath + "/Parvw", "");
					model.setProperty(sPath + "/Parvwdesc", "");
					model.setProperty(sPath + "/Allocation", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		getTotalMPPerCent: function(client) {
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var data = this.getTableData("FormChange354BP");
			var percent = 0;
			data.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === client.Parvw && sData.OfficeCode === client.OfficeCode && sData.Teams === client.Teams) {
						val = oFloatFormat.format(sData.Allocation);
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
					}
				}
			});
			return percent;
		},
		checkMatterMPType: function() {
			var aClientData = this.getTableData("FormChange354BP"),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === "ZL") {
						count++;
					}
				}
			});
			return count > 1 ? false : true;
		},
		/**
		 * change event for Alt Payer Details
		 */
		changeAltDetails: function(evt) {
			var source = evt.getSource(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				oMatterContext = this.getBindingContextbyId("idAlterDetails"),
				sPath = oMatterContext.getPath(),
				oMatterModel = oMatterContext.getModel();
			oMatterModel.setProperty(sPath + "/" + path, value);
			this.onAlterMandatory("ch");
		},
		/**
		 * function to set control type for smart fields
		 */
		tableControlType: function() {
			var ControlType = {
				a: new sap.ui.comp.smartfield.Configuration({
					controlType: "dropDownList",
					displayBehaviour: "idOnly"
				}),
				b: new sap.ui.comp.smartfield.Configuration({
					preventInitialDataFetchInValueHelpDialog: false
				})
			};
			return ControlType;
		},

		// Bind Inter PArtner
		bindIPData: function() {
			var qtc = this.getModel(),
				oContextIP,
				//sLength = newData.length,
				idIPBP = this.byId("FormChange354IP");
			// if (idIPBP.getItems().length < 1) {
			this.onAddMatterIPBtn();
			// }

		},
		/// business Consideration 
		getConsiderationModel: function() {
			var that = this,
				sPath = jQuery.sap.getModulePath("cmiamendmentnew.model", "/ClientModel.json"),
				oModel = new JSONModel();
			this.getView().setModel(oModel, "viewModel");
			$.ajax({
				url: sPath
			}).then(function(data) {
				oModel.setData(data);
				that.onInitializeBC();
			});
		},
		setQuetData: function(encodedURIString) {
			var sModelData = decodeURIComponent(encodedURIString);
			this.getModel("viewModel").setJSON(sModelData);
			this.onInitializeBC();
		},

		getQuetData: function() {
			var sModelData = this.getModel("viewModel").getJSON();
			return encodeURIComponent(sModelData);
		},
		onInitializeBC: function() {
			var oList = this.byId("listID"),
				aItems = oList.getItems(),
				that = this;
			jQuery.each(aItems, function(i, oItem) {
				var content = oItem.getContent()[0],
					oSwitch = content.getItems()[1];
				if (oSwitch.getState()) {
					if (oItem.getContent()[1].getContent().length > 0) {
						return;
					}
					that.layoutDesign(oItem);
				}
			});
		},
		onChangeConsi: function(evt) {
			//	debugger
			var bState = evt.getParameter("state"),
				oSrc = evt.getSource(),
				oItem = oSrc.getParent().getParent(),
				oGrid = oItem.getContent()[1];

			if (bState === false) {
				return;
			} else {
				if (oGrid.getContent().length > 0) {
					return;
				}
			}
			this.layoutDesign(oItem);
		},
		layoutDesign: function(oItem) {
			var sPath = oItem.getBindingContextPath(),
				oModel = this.getModel("viewModel"),
				oGrid = oItem.getContent()[1],
				oAnswer = oModel.getProperty(sPath);

			var subQuestion = oModel.getProperty(sPath + "/subQuestion");
			var that = this;
			if (subQuestion.length > 0) {
				jQuery.each(subQuestion, function(i, Quet) {

					oGrid.addContent(new sap.m.Label({
						text: Quet.QuestionText
					}));
					var content = that.createContent(Quet, sPath + "/subQuestion/" + i, oModel.getProperty(sPath + "/subQuestion/" + i +
						"/ID"));
					oGrid.addContent(content);
				});
			} else {
				oGrid.addContent(new sap.m.Label({
					text: oAnswer.AnswerText
				}));
				var content = this.createContent(oAnswer, sPath, oModel.getProperty(sPath + "/ID"));
				oGrid.addContent(content);
			}
		},

		createContent: function(control, sPath, ID) {
			var oModel = this.getModel("viewModel");
			//oAnsModel = this.getModel("ansModel");
			//oAnsModel.setProperty("/" + ID, "");
			switch (control.ControlType) {
				case "TextArea":
					return new sap.m.TextArea({
						value: '{viewModel>' + sPath + '/Answer}',
						layoutData: new sap.ui.layout.GridData({
							span: "XL6 L6 M6 S12"
						})
					});
				case "Input":
					return new sap.m.Input({
						value: '{viewModel>' + sPath + '/Answer}'
					});
				case "SingleSelect":
					var oBindingInfo = {
						path: sPath + "/Values",
						template: new sap.ui.core.Item({
							text: "{text}",
							key: "{text}"
						})
					};
					var oSel = new sap.m.Select({
						selectedKey: '{viewModel>' + sPath + '/Answer}'
					});
					oSel.setModel(oModel);
					return oSel.bindItems(oBindingInfo);
				case "MultiSelect":
					var oBindingInfoM = {
						path: sPath + "/Values",
						template: new sap.ui.core.Item({
							text: "{text}"
						})
					};
					var oMultiCombo = new sap.m.MultiComboBox({});
					oMultiCombo.setModel(oModel);
					return oMultiCombo.bindItems(oBindingInfoM);
				case "RadioButton":
					var oBindingInfoRadio = {
						path: sPath + "/Values",
						template: new sap.m.RadioButton({
							text: "{text}"
						})
					};
					var oRadioButtonGroup = new sap.m.RadioButtonGroup({
						columns: 5
					});
					oRadioButtonGroup.setModel(oModel);
					return oRadioButtonGroup.bindButtons(oBindingInfoRadio);
			}
		},
		/// for Mp
		checkValidationforMPAllocation: function(rType) {
			//var wizrd = this.getView().byId("NRWizard");
			var oTableLead = this.getTableData("FormChange354BP");
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;

			function filterAllocation(item, percent) {
				oTableLead.filter(function(sData) {
					if (sData.Parvw) {
						if (sData.Parvw === item.Parvw && sData.OfficeCode === item.OfficeCode) {
							val = oFloatFormat.format(sData.Allocation);
							if (!val) {
								val = "0.00";
							}
							val = oFloatFormat.parse(val);
							percent = percent + val;
						}
					}
				});
				return percent;
			}

			for (var j = 0; j < oTableLead.length; j++) {
				var iItem = oTableLead[j];
				if ($.isEmptyObject(iItem.Parvwdesc) || $.isEmptyObject(oTableLead[j].OfficeName) ||
					$.isEmptyObject(oTableLead[j].Firstname) ||
					$.isEmptyObject(oTableLead[j].Allocation)) {
					return "Error";
				}
			}
			for (var i = 0; i < oTableLead.length; i++) {
				var item = oTableLead[i];
				var percent = 0;
				var totPercent = filterAllocation(item, percent);
				if (totPercent < 100) {
					return item;
				}
			}
			return "";
		},
		// Multi Alt Payer
		checkValidationforMultiAllocation: function(rType) {
			var oTableMultiPayer = this.getTableData("FormChange354BF1");
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var percent = 0;
			var count = 0;
			// var wizrd = this.getView().byId("NRWizard");
			//if (rType === "NCNM" ? wizrd.getProgress() > 3 : wizrd.getProgress() > 1) {
			oTableMultiPayer.filter(function(sData) {
				if (sData.Firstname) {
					val = oFloatFormat.format(sData.Altpayerperc);
					if (!val) {
						val = "0.00";
					}
					val = oFloatFormat.parse(val);
					percent = percent + val;
					count++;
				}
			});
			if (count > 0 && percent < 100) {
				return false;
			}
			return true;
		},

		handlebeforeRebindTable: function(OEVT) {
			var oBindingParams = OEVT.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};

			if (this.KPCmino) {
				//aFilter.push(new Filter("Matter", "EQ", this.oMatterVal));
				oBindingParams.filters.push(new Filter("Cmino", "EQ", this.KPCmino));
			}
			if (this.KPName) {
				oBindingParams.filters.push(new Filter("Name", "EQ", this.KPName));
			}

			//getting office and matter filter values 
			this.filter = OEVT.getParameters().bindingParams.filters[0];

		}

	});

});
myFormatter = {
	requiredQuestion: function(sValue1, sValue2) {

		if (sValue2 === "X") {
			this.addStyleClass("sapMLabelRequired");
			return " " + sValue1;
		} else {
			return " " + sValue1;
		}
	}
};