sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function(Filter, FilterOperator) {
	"use strict";
	return {
		sPath: "",
		onMasterFscreen: function(evt) {
			var middlePanel = this.getSplitter().getContentAreas()[1].getLayoutData(),
				leftPanel = this.getSplitter().getContentAreas()[0].getLayoutData(),
				rightPanel = this.getSplitter().getContentAreas()[2].getLayoutData();
			if (rightPanel.getSize("0px") !== "0px") {
				middlePanel.setSize("auto");
				rightPanel.setSize("0px");
				leftPanel.setSize("275px");

			} else {
				this.onResetScreen();
			}
		},
		onPressMaster: function(evt) {
			var src = evt.getSource(),
				expanded;

			if (src.getIcon() === "sap-icon://collapse-group") {
				expanded = false;
				src.setIcon("sap-icon://expand-group");
			} else {
				expanded = true;
				src.setIcon("sap-icon://collapse-group");
			}
			this.leftColumn._expandOrCollapseMaster.call(this, expanded);
		},
		_expandOrCollapseMaster: function(flg) {
			var list = this.byId("Tree");
			list.getItems().forEach(function(obj) {
				obj.getContent()[0].setExpanded(flg);
			});
		},
		stateCheck: function(val) {
			var state;
			if (val === "02") {
				state = "Success";
			} else {
				state = "Warning";
			}
			return state;
		},
		onfilter: function(oEvent) {

			if (!this._filterDialog) {
				this._filterDialog = sap.ui.xmlfragment(this.getView().getId(), "fgtdbworklist.fragments.leftPanel.filterList", this);
				this.getView().addDependent(this._filterDialog);
			}
			this._filterDialog.open();

		},
		onCloseFilterDialog: function(evt) {
			this._filterDialog.close();
		},

		_selectAllByGroup: function(evt) {

			if ((this.getTime() - this.changeEvtTime) <= 15) {
				return false;
			} else {
				this.selectedRowIdx = evt.getParameter("rowIndex");

				this.changeEvtTime = this.getTime();

				//alert("RowSelHappendon+===="+this.selectedRowIdx);
				if (evt.getParameter("rowContext") && evt.getParameter("rowContext").getObject().Level == 0) {

					this.selectedRowIdx = evt.getParameter("rowIndex");
					var rows = evt.getSource().getRows();
					var i;
					for (i = this.selectedRowIdx + 1; i < rows.length; i++) {

						if (!rows[i].getBindingContext() || rows[i].getBindingContext().getObject().Level == 0) {
							break;
						}
					}

					if (evt.getSource().isIndexSelected(this.selectedRowIdx)) {
						evt.getSource().addSelectionInterval(this.selectedRowIdx + 1, i - 1);
					} else {
						evt.getSource().removeSelectionInterval(this.selectedRowIdx, i - 1);
					}

				}
			}
		},

		onRowRender: function(Parent, level) {
			return Parent;
		},
		toggleOpenState: function(evt) {
			var s = evt.getSource(),
				that = this,
				gn,
				ri = evt.getParameter("rowIndex");
			if (!evt.getParameter("expanded")) {
				if (this.defaultMstrRowHeight === 35) {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight + 1;
				} else {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight - 1;
				}
				evt.getSource().setRowHeight(this.defaultMstrRowHeight);
			} else {
				gn = "gp-" + s.getContextByIndex(ri).getObject("Parentkmap");
				if (this.selIndexs[gn]) {
					setTimeout(function() {
						for (var gi = 0; gi < this.selIndexs[gn].length; gi++) {
							this.leftColumn._setPrevSelectedRow.call(this, s, this.selIndexs[gn][gi]);
						}
					}.bind(this), 500);
				}
			}
		},
		_setPrevSelectedRow: function(s, db) {
			var rows = s.getRows();
			for (var i = 0; i < rows.length; i++) {
				if (rows[i].getBindingContext() && rows[i].getBindingContext().getObject("Draftbill") == db) {
					if (rows[i].getBindingContext().getObject("Draftbill")) {
						s.addSelectionInterval(i, i);
					}
				}
			}
		},

		statusPrevreviewed: function(prev) {
			return (prev == "X") ? "Success" : "Error";
		},
		dispPrevreviewed: function(prev) {
			var r;
			if (prev == "X") {
				r = "Yes";
			} else if (prev == "N") {
				r = "None";
			} else {
				r = "No";
			}

			return r;
		},
		setVisibility: function(v) {
			return (v) ? true : false;
		},
		modelContextChange: function() {
			//	alert(123);
		},

		onMasterChange: function(evt) {
			var item,
				iCtxt,
				allSelItems;

			if (evt) {
				item = (evt.getParameter("selected")) ? evt.getParameter("listItem") : "";
				this.leftColumn._isAllAreSelected.call(this, evt.getSource());
			}
			allSelItems = this.leftColumn._getAllselectedItemsMaster.call(this)

			if (allSelItems.length) {
				item = allSelItems[0];
			}

			if (!allSelItems.length && this.selectedItemContext) {
				item = this._emptyDetails();
			}

			if (item) {
				var iCtxt = item.getBindingContext();

				if (!this._isSameContext.call(this, iCtxt)) {
					this.leftColumn._loadDetails.call(this, iCtxt);
				} else {
					this.leftColumn._addDbActions.call(this, iCtxt);
				}
			}

		},
		_loadDetails: function(iCtxt) {
			this.leftColumn._addDbActions.call(this, iCtxt);
			this._isActionsAreactive(1);
			this._resetDetail();
			//this.middleColumn._addNarrativeTab.call(this, iCtxt.getObject("Draftbill"));
			this.leftColumn._fireSelectionChang.call(this, iCtxt);
			//Add by Naresh for to get the binding Context of Draft Bill No from List
			this.selectedItemContext = iCtxt;
			// this.leftColumn._bindAttachement.call(this, this.selectedItemContext);
			this.leftColumn._bindView.call(this, this.selectedItemContext);

		},
		// Add by Naresh for bind the data to attachment and comment  and Audit trail
		_bindView: function(context) {
			//	var tbl = this.getView().byId("AuditTrailId");
			var oCtx = context.getObject(),

				oCmtModel = new sap.ui.model.json.JSONModel(),
				oAttachModel = new sap.ui.model.json.JSONModel();
			var oModel = this.getOwnerComponent().getModel();

			var urlToRead = this.getModel().createKey("/Dbheaders", {
				Draftbill: oCtx.Draftbill,
				Id: ''
			});
			// Billindg Section 
			var that = this;

		},
		_bindAttachement: function(ctx) {
			var ofilter = [],
				oAttaJsonModel = new sap.ui.model.json.JSONModel(),
				atthModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_FILE_ATTACHMENT_UI_SRV");
			ofilter.push(new Filter("Vbeln", FilterOperator.EQ, ctx.getObject("Draftbill")));
			var that = this;
			atthModel.read("/FileListSet", {
				filters: ofilter,
				success: function(odata) {
					oAttaJsonModel.setData(odata);
					that.getView().setModel(oAttaJsonModel, "AttachJson");
				},
				error: function(odata) {}
			});

		},
		_isAllAreSelected: function(s) {
			var ckBx = s.getParent().getHeaderToolbar().getContent()[0];
			if (s.isAllSelectableSelected()) {
				ckBx.setSelected(true);
			} else {
				ckBx.setSelected(false);
			}
		},
		_fireSelectionChang: function(iCtxt) {
			var tbl = this.byId("idProductsTable3"),
				path;
			path = iCtxt.getPath();
			var topInfoBar = this.byId("topInfoBar");
			topInfoBar.setSelectedSection(topInfoBar.getSections()[0]);
			this.byId("middlePanel").bindElement(path + "/Itemheader");
			// tbl.bindItems(path + "/Itemdetail", this.dbLitemTemplate);
			this.sPath = path + "/Itemdetail";
			tbl.rebindTable();
			// tbl.bindContext("items").setProperty("tableBindingPath", path + "/Itemdetail");
			this.byId("rightPanel").bindElement(path + "/DbheaderToAdditionalDetails");

		},
		onMasterExpand: function(evt) {
			var binding;
			if (evt.getParameter("expand")) {
				binding = this.byId("Tree").getBinding("items");
				var innerList = evt.getSource().getContent()[0],
					applnFilter = binding.aApplicationFilters;

				if (binding.aFilters.length) {
					applnFilter = applnFilter.concat(binding.aFilters)
				}
				//	applnFilter = this.byId("Tree").getBinding("items").oCombinedFilter;
				innerList.setBusy(true);
				if (!this.masterTemplate) {
					this.masterTemplate = innerList.getItems()[0].clone();
				}
				if (innerList.getBinding("items")) {

					innerList.getBinding("items").filter(applnFilter, "Application");
				} else {
					innerList.bindItems({
						path: "Expandhierarchy",
						filters: applnFilter,
						//template : listTmpl
						template: this.masterTemplate
					});
				}

			}
			this.openByDefault = true;
		},
		selectAllClientGroup: function(evt) {
			var list = evt.getSource().getParent().getParent().getContent()[0];
			if (evt.getParameter("selected")) {
				list.selectAll();
			} else {
				list.removeSelections(true);
			}
			this.leftColumn.onMasterChange.call(this);
			this.leftColumn._validateLeftPnlActions.call(this);
		},
		onMasterFilterChange: function(evt) {
			this.leftColumn._resetAllMasterList.call(this);
			var key = evt.getSource().getSelectedKey(),
				mastList = this.byId("Tree"),
				f;
			key = (key === "AL") ? " " : key;

			this.masterGlobalFilter = f = new sap.ui.model.Filter("Filterby", "EQ", key);
			if (this.masterSmartFilter) {
				f = this.masterSmartFilter.concat([this.masterGlobalFilter]);
			}
			mastList.setBusy(true);
			mastList.getBinding("items").filter(f, "Application");
		},
		onSmartSearch: function(evt) {

			var list = this.byId("Tree"),
				DbList = this.byId("oListItem"),
				si = this.byId("masterSmartFilterIcon"),
				binding = list.getBinding("items"),
				f;
			var oFilter = [];
			this.masterSmartFilter = evt.getSource().getFilters();
			if (this.masterSmartFilter.length) {
				si.setType("Emphasized");
			} else {
				si.setType("Default");
			}
			f = this.masterSmartFilter.concat([this.masterGlobalFilter]);
			binding.filter(f, sap.ui.model.FilterType.Application);
			this._filterDialog.close();
			//alert(123);
		},
		onSearch: function(oEvt) {

			var aFilters = [],
				sQuery = oEvt.getSource().getValue(),
				list = this.byId("Tree"),
				binding = list.getBinding("items");

			if (sQuery && sQuery.length > 0) {
				aFilters.push(new sap.ui.model.Filter("Searchterm", sap.ui.model.FilterOperator.EQ, sQuery));
			}
			binding.filter(aFilters, sap.ui.model.FilterType.Control);
		},
		innerListUpdateFinished: function(evt) {

			var list = evt.getSource(),
				fItem;
			evt.getSource().setBusy(false);
			this.byId("Tree").setBusy(false);
			if (this.initialMasterLoad) {

				fItem = evt.getSource().getItems()[0];
				//	setTimeout(function(evt) {
				/*	list.fireSelectionChange({
						listItem: fItem,
						selected: true
					});*/

				if (fItem && fItem.setSelected) {

					this.leftColumn._loadDetails.call(this, fItem.getBindingContext());

					fItem.setSelected(true);
				}
				this._isActionsAreactive(1);
				this.initialMasterLoad = false;
				return false;
			}

			if (evt.getSource().getParent().getHeaderToolbar().getContent()[0].getSelected()) {
				list.selectAll();
				this.leftColumn.onMasterChange.call(this);
			}
		},
		masterListUpdateFinished: function(evt) {
			var panel, masterItems = evt.getSource().getItems();

			if (!this.openByDefault) {
				evt.getSource().setBusy(false);
			}

			if (!this.openByDefault) {
				//	this.openByDefault = true;
				return
			};
			if (masterItems.length && masterItems[0].getContent().length) {
				masterItems.forEach(function(mitem, idx) {
					panel = mitem.getContent()[0];
					if (this.srcFromActionSuccess) {
						if (panel.getExpanded()) {
							panel.fireExpand({
								expand: true
							});
							panel.setExpanded(true);
						}

					} else {
						if (idx === 0) {
							panel.fireExpand({
								expand: true
							});
							panel.setExpanded(true);
						} else {
							if (panel.getExpanded()) {
								panel.fireExpand({
									expand: true
								});
								panel.setExpanded(true);
							}
						}
					}
				}.bind(this));

			} else {
				evt.getSource().setBusy(false);
			}

			this.srcFromActionSuccess = false;
		},
		_getAllselectedItemsMaster: function() {
			var list = this.byId("Tree"),
				allItems = [];
			list.getItems().forEach(function(obj) {
				allItems = allItems.concat(obj.getContent()[0].getContent()[0].getSelectedItems());
			});

			return allItems;
		},
		_checkAllMasterStatusSame: function() {
			var allItems = this.leftColumn._getAllselectedItemsMaster.call(this),
				retSt = "true",
				obj, st = "__",
				ist;

			for (obj of allItems) {
				ist = obj.getBindingContext().getObject("Draftbillstatusk");
				if (st === "__" || st === ist) {
					st = ist;
				} else {
					retSt = false;
					break;
				}
			}

			return retSt;
		},
		_validateLeftPnlActions() {
			var i18n = this.getResourceBundle();

			var lbtPanel = this.byId("leftFooter");
			if (!this.leftColumn._checkAllMasterStatusSame.call(this)) {
				lbtPanel.removeAllContent();
				sap.m.MessageToast.show(i18n.getText("MsgMasterStatusSame"));

			}
		},
		_addDbActions: function(iCtxt) {
			var bt, roles = this.getView().getModel("roleModel").getData(),
				btPanel = this.byId("middleFooter"),
				lbtPanel = this.byId("leftFooter"),
				staticBtn, leftBtn;
			btPanel.removeAllContent();
			lbtPanel.removeAllContent();

			bt = new sap.m.ToolbarSpacer();
			btPanel.addContent(bt);
			lbtPanel.addContent(bt.clone());

			roles.forEach(function(obj) {
				if (obj.Role === iCtxt.getObject("Role")) {
					bt = new sap.m.Button({
						tooltip: obj.DecisionText,
						icon: "sap-icon://" + obj.InconIndicator,
						press: [this.leftColumn.routeDraftBillActions, this]
					});
					bt.data("ActionCode", obj.Action);
					bt.data("type", "single");
					btPanel.addContent(bt);
					leftBtn = bt.clone();
					leftBtn.data("type", "batch");
					lbtPanel.addContent(leftBtn);

				}
			}.bind(this));

			staticBtn = new sap.m.Button({
				tooltip: "Save Changes",
				icon: "sap-icon://save",
				enabled: "{appSettings>/actionEnabled}",
				press: [this.leftColumn.routeDraftBillActions, this]
			});
			staticBtn.data("ActionCode", "SAVEITEMS");
			btPanel.addContent(staticBtn);

			staticBtn = new sap.m.Button({
				tooltip: "Next Draft Bill",
				icon: "sap-icon://BusinessSuiteInAppSymbols/icon-next-open-item",
				press: [this.leftColumn.routeDraftBillActions, this]
			});
			staticBtn.data("ActionCode", "NEXTDB");
			btPanel.addContent(staticBtn);

			this.leftColumn._validateLeftPnlActions.call(this);

		},
		_nextDraftBillQueue: function(evt) {
			var selectItems = this.leftColumn._getAllselectedItemsMaster.call(this),
				fItem, nxtItem;
			var i18n = this.getResourceBundle();
			if (selectItems.length > 1) {

				if (this.getModel().hasPendingChanges()) {

					sap.m.MessageBox.confirm(
						i18n.getText("confirmMsgUnsaved"), 
						{
							actions: ["Yes", "No"],
							onClose: function(evt) {
								if (evt === "Yes") {
									this.leftColumn._moveToNextBill.call(this, selectItems);
								}
							}.bind(this)
						}
					);
					//this.getModel().resetChanges();
				}else{
					this.leftColumn._moveToNextBill.call(this, selectItems);
				}

				

			} else {
				sap.m.MessageToast.show(i18n.getText("MsgnextDraftBillQueue"), {
					duration: 1000
				});
			}
		},
		_moveToNextBill: function(selectItems) {
			var fItem, nxtItem;
			fItem = selectItems.shift();
			fItem.setSelected(false);
			this.leftColumn._isAllAreSelected.call(this, fItem.getParent());

			if (selectItems.length) {
				nxtItem = selectItems[0];
				this.leftColumn._loadDetails.call(this, nxtItem.getBindingContext());
				/*nxtItem.getParent().fireSelectionChange({
					listItem: nxtItem,
					selected: true
				});*/
			}
		},
		_performDraftBillActions: function(evt) {
			var selectItems = this.leftColumn._getAllselectedItemsMaster.call(this),
				itemData, batchChanges = [],
				oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DB_WORKLIST_SRV/"),
				userAction = evt.getSource().data("ActionCode"),
				listToRefresh = this.byId("Tree"),
				actionType;

			if (evt.getSource().data("type") && evt.getSource().data("type") === "single") {
				actionType = evt.getSource().data("type");
				selectItems = [selectItems[0]];
				//listToRefresh = selectItems[0].getParent();
			} else {
				actionType = evt.getSource().data("type");
				//	listToRefresh = this.byId("Tree");
			}

			selectItems.forEach(function(obj) {
				obj.setSelected(false);
				itemData = obj.getBindingContext().getObject();
				this.leftColumn._cleanDraftBillDataToPost.call(this, itemData);
				itemData.Action = userAction;
				batchChanges.push(oModel.createBatchOperation("/Dbheaders", "POST", itemData));

			}.bind(this));

			oModel.addBatchChangeOperations(batchChanges);
			oModel.setUseBatch(true);
			var that = this;
			oModel.submitBatch(function(data) {
				var resObj = data.__batchResponses[0].__changeResponses[0].data;
				if (resObj.Error === "X") {
					sap.m.MessageBox.error(resObj.Message);
				} else {
					sap.m.MessageToast.show(that._oResourceBundle.getText("successText"));
					listToRefresh.getBinding("items").refresh(true);
					that.leftColumn._resetAllMasterCheckBoxes.call(that);
					that.leftColumn.onMasterChange.call(that);
					that.srcFromActionSuccess = true;
					if (actionType !== "single") {
						that.initialMasterLoad = true;
					}

				}
				that.getView().setBusy(false);
			}, function(err) {
				that.getView().setBusy(false);
				sap.m.MessageBox.error(that._oResourceBundle.getText("errorText"));
			});

		},
		_cleanDraftBillDataToPost: function(item) {
			delete(item.DbHeaderToAuditTrail);
			delete(item.DbHeaderToDbAttachments);
			delete(item.DbHeaderToDbComments);
			delete(item.DbheaderToAdditionalDetails);
			delete(item.Expandhierarchy);
			delete(item.Itemdetail);
			delete(item.Itemheader);
			delete(item.__metadata);
		},
		_resetAllMasterCheckBoxes: function(evt) {
			var list = this.byId("Tree");
			list.getItems().forEach(function(obj) {
				obj.getContent()[0].getHeaderToolbar().getContent()[0].setSelected(false);

			});
			//that.leftColumn._resetAllMasterCheckBoxes.call(that);
		},
		_resetAllMasterList: function(evt) {
			var list = this.byId("Tree"),
				allItems = [];
			this.initialMasterLoad = true;
			this._setAppSettings("panelAnimation", false);
			list.getItems().forEach(function(obj) {
				obj.getContent()[0].getHeaderToolbar().getContent()[0].setSelected(false);
				obj.getContent()[0].getContent()[0].unbindItems();
				//obj.getContent()[0].getContent()[0].removeSelections(true);
				obj.getContent()[0].setExpanded(false);
				//obj.getContent()[0].getContent()[0].removeAllItems();
			});
			this._setAppSettings("panelAnimation", true);
		},

		routeDraftBillActions: function(evt) {
			switch (evt.getSource().data("ActionCode")) {

				case "NEXTDB":
					this.leftColumn._nextDraftBillQueue.call(this, evt);
					break;
				case "SAVEITEMS":
					this.onPostTblData.call(this, evt);
					break;
				default:
					this.leftColumn._performDraftBillActions.call(this, evt);
			}
			//	alert(this.byId("dbMBtnPanel"));
		}

	};

});