sap.ui.define([], function() {
	"use strict";

	return {

		onNarrativeExpand: function(evt) {
			var src = evt.getSource(),
				oTable = this.byId("idProductsTable3").getTable(),
				oColumns = oTable.getColumns();
			var oViewModel = this.getModel("appSettings");
			if (src.getIcon() === "sap-icon://expand-group") {
				// oColumns[oColumns.length - 1].setVisible(true);
				oViewModel.setProperty("/narrativeCol", true);
				src.setIcon("sap-icon://collapse-group");
					this.detTblExpanded=true;
			} else {
				// oColumns[oColumns.length - 1].setVisible(false);
				oViewModel.setProperty("/narrativeCol", false);
				src.setIcon("sap-icon://expand-group");
				this.detTblExpanded=false;
			}
		},
		onMoveMainUp: function(evt) {
			var t = this.byId("topInfoBar").getHeaderContent()[0];
			if (t.getVisible()) {
				t.setVisible(false);
			} else {
				t.setVisible(true);
			}

		},
		onMiddleFscreen: function(evt, src) {
			var leftPanel = this.getSplitter().getContentAreas()[0].getLayoutData(),
				rightPanel = this.getSplitter().getContentAreas()[2].getLayoutData();
			if (src === "ot" || leftPanel.getSize("0px") !== "0px") {
				leftPanel.setSize("0px");
				rightPanel.setSize("0px");

			} else {
				this.onResetScreen();
			}
		},
		onResetScreen: function() {
			var spliter = this.getSplitter();
			spliter.getContentAreas()[1].getLayoutData().setSize("auto");
			spliter.getContentAreas()[0].getLayoutData().setSize("275px");
			spliter.getContentAreas()[2].getLayoutData().setSize("255px");
		},
		commentCheck: function(cmnt) {
			return (cmnt === "X") ? "Success" : "None";
		},
		changeSections: function(evt) {
			this.middleColumn.onMiddleFscreen.call(this, evt, "ot");
		},
		getNextQueueItem: function(evt) {
			//alert(this.selectedRowIdx + 1);
		},
		_addNarrativeTab: function(db) {
			var h = this.byId("NarrativeTabSub");
			h.removeAllBlocks();
			h.addBlock(new sap.ui.core.HTML({
				preferDOM: true,
				content: "<iframe height='500px'width = '100%' src = 'http://bmgdcd2883.bakernet.com:8000/sap/bc/ui5_ui5/sap/ZPRS_NAR_APP/index.html#/narrative/" +
					db + "' > < /iframe>"
			}));
		}

	};

});