sap.ui.define([], function() {
	"use strict";

	return {
		onMasterFscreen: function(evt) {
			var middlePanel = this.getSplitter().getContentAreas()[1].getLayoutData(),
				leftPanel = this.getSplitter().getContentAreas()[0].getLayoutData(),
				rightPanel = this.getSplitter().getContentAreas()[2].getLayoutData();
			if (rightPanel.getSize("0px") !== "0px") {
				middlePanel.setSize("auto");
				rightPanel.setSize("0px");
				leftPanel.setSize("300px");

			} else {
				this.onResetScreen();
			}
		},
		onPressMaster: function(evt) {
			var t = this.byId("Tree"),
				src = evt.getSource();

			if (src.getIcon() === "sap-icon://collapse-group") {
				t.collapseAll();
				if (this.defaultMstrRowHeight === 35) {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight + 1;
				} else {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight - 1;
				}
				t.setRowHeight(this.defaultMstrRowHeight);
				src.setIcon("sap-icon://expand-group");
			} else {
				//	t.setRowHeight(80);
				t.expandToLevel(1);
				src.setIcon("sap-icon://collapse-group");
			}

		},
		stateCheck: function(val) {
			var state;
			if (val === "02") {
				state = "Success";
			} else {
				state = "Warning";
			}
			return state;
		},
		onfilter: function(oEvent) {

			if (!this._filterDialog) {
				this._filterDialog = sap.ui.xmlfragment(this.getView().getId(), "fgtdbworklist.fragments.leftPanel.filterList", this);
				this.getView().addDependent(this._filterDialog);
			}
			this._filterDialog.open();

		},
		onCloseFilterDialog: function(evt) {
			this._filterDialog.close();
		},
		search: function(evt) {
			//alert(123);
		},
		onMasterChange: function(evt) {
			var s = evt.getSource(),
				gn, db,
				ri = evt.getParameter("rowIndex");
			// if(s.isIndexSelected(evt.getParameter("rowIndex")) && 	this.selIndexs.indexOf(evt.getParameter("rowIndex")) < 0){
			// 	this.selIndexs.push(evt.getParameter("rowIndex"));
			// }else if(!s.isIndexSelected(evt.getParameter("rowIndex"))){
			// 	this.selIndexs = this.selIndexs.splice(this.selIndexs.indexOf(evt.getParameter("rowIndex")));
			// }
			if (s.getContextByIndex(ri)) {
				gn = "gp-" + s.getContextByIndex(ri).getObject("Parentkmap");
				db = s.getContextByIndex(ri).getObject("Draftbill");
				if (evt.getSource().isIndexSelected(ri)) {

					if (!this.selIndexs[gn]) {
						this.selIndexs[gn] = [db];
					} else {
						if ($.inArray(db, this.selIndexs[gn]) < 0) {
							this.selIndexs[gn].push(db);

						}
					}

					//this.selIndexs[gn] = evt.getParameter("rowIndices");

					/*if(!this.selIndexs[gn]){
					this.selIndexs[gn]=evt.getParameter("rowIndices");
				
					}
					this.selIndexs = evt.getParameter("rowIndices");*/
				} else {
					if (this.selIndexs[gn]) {
						this.selIndexs[gn].splice($.inArray(db, this.selIndexs[gn]), 1);
					}
				}
			}
			if (evt.getParameter("rowContext") && evt.getParameter("rowContext").getObject().Level != 0) {
				this.leftColumn._fireSelectionChang.call(this, evt);
			}
			if (evt.getParameter("rowContext") && evt.getParameter("rowContext").getObject().Level == 0) {
				this.leftColumn._selectAllByGroup.call(this, evt);
			}
		},
		_selectAllByGroup: function(evt) {

			if ((this.getTime() - this.changeEvtTime) <= 15) {
				return false;
			} else {
				this.selectedRowIdx = evt.getParameter("rowIndex");

				this.changeEvtTime = this.getTime();

				//alert("RowSelHappendon+===="+this.selectedRowIdx);
				if (evt.getParameter("rowContext") && evt.getParameter("rowContext").getObject().Level == 0) {

					this.selectedRowIdx = evt.getParameter("rowIndex");
					var rows = evt.getSource().getRows();
					var i;
					for (i = this.selectedRowIdx + 1; i < rows.length; i++) {

						if (!rows[i].getBindingContext() || rows[i].getBindingContext().getObject().Level == 0) {
							break;
						}

					}

					//	evt.getSource().setSelectedIndex(3);
					//	evt=0;

					if (evt.getSource().isIndexSelected(this.selectedRowIdx)) {
						evt.getSource().addSelectionInterval(this.selectedRowIdx + 1, i - 1);
					} else {
						evt.getSource().removeSelectionInterval(this.selectedRowIdx, i - 1);
					}

				}
			}
		},
		_fireSelectionChang: function(evt) {
			if ((this.getTime() - this.changeEvtTime) <= 15) {
				return false;
			} else {

				// data to populate detailed area
				var tbl = this.byId("idProductsTable3"),
					path;
				if (!this.masterTemplate) {
					this.masterTemplate = tbl.getItems()[0].clone();
				} else {
					this.masterTemplate = this.masterTemplate.clone();
				}
				if (evt.getParameter("rowContext")) {
					path = evt.getParameter("rowContext").getPath();
					this.byId("middlePanel").bindElement(path + "/Itemheader");
					tbl.bindItems(path + "/Itemdetail", this.masterTemplate);
					this.byId("rightPanel").bindElement(path + "/DbheaderToAdditionalDetails");

				}
			}

		},
		onRowRender: function(Parent, level) {

			if (level == 1) {
				if (!this.initialLoad) {

					setTimeout(function() {
						this.byId("Tree").setSelectedIndex(1);
	this.initialLoad = true;
					}.bind(this), 500);

					//setTimeout(function(){ this.byId("Tree").setSelectedIndex(5); }.bind(this), 3000);
				
				}

			}
			return Parent;
			//	var mastList = this.byId("Tree");
			//alert(Parent);

			/*setTimeout(function() {
				mastList.fireToggleOpenState({itemIndex:1,itemContext:mastList.getItems()[0].getBindingContext(),expanded:true});
			      	mastList.expandToLevel(1);
				}, 300);*/
			//	mastList.expandToLevel(1);
			//	mastList.fireToggleOpenState({itemIndex:1,itemContext:mastList.getItems()[1].getBindingContext(),expanded:true});
			/*	setTimeout(function() {
				//	mastList.fireToggleOpenState({itemIndex:1,itemContext:mastList.getItems()[0].getBindingContext(),expanded:true});
			      mastList.expand(1);
				}, 300);*/
			//	evt.getSource().expandToLevel(1);
		},
		toggleOpenState: function(evt) {
			var s = evt.getSource(),
				that = this,
				gn,
				ri = evt.getParameter("rowIndex");
			//s.getRows()[1].getBindingContext().getObject("Draftbill")
			//setTimeout(function() {
			// gn = "gp-" + s.getContextByIndex(evt.getParameter("rowIndex")).getObject("Parentkmap");
			// if (that.selIndexs[gn] && that.selIndexs[gn].length) {
			// 	$.each(that.selIndexs[gn], function(i, selInd) {
			// 		s.addSelectionInterval(selInd, selInd);
			// 	});
			// }

			//},100);
			if (!evt.getParameter("expanded")) {
				if (this.defaultMstrRowHeight === 35) {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight + 1;
				} else {
					this.defaultMstrRowHeight = this.defaultMstrRowHeight - 1;
				}
				evt.getSource().setRowHeight(this.defaultMstrRowHeight);
			} else {
				gn = "gp-" + s.getContextByIndex(ri).getObject("Parentkmap");
				if (this.selIndexs[gn]) {
					setTimeout(function() {

						for (var gi = 0; gi < this.selIndexs[gn].length; gi++) {

							this.leftColumn._setPrevSelectedRow.call(this, s, this.selIndexs[gn][gi]);
							//	alert(this.selIndexs[gn][gi]);
						}

						//alert(s.getRows()[1].getBindingContext().getObject("Draftbill"));
					}.bind(this), 500);
				}
			}

			//	alert(123);
			//setRowHeight
		},
		_setPrevSelectedRow: function(s, db) {
			var rows = s.getRows();
			for (var i = 0; i < rows.length; i++) {
				if (rows[i].getBindingContext() && rows[i].getBindingContext().getObject("Draftbill") == db) {
					if (rows[i].getBindingContext().getObject("Draftbill")) {
						s.addSelectionInterval(i, i);
					}
				}
			}
		},

		onMasterFilterChange: function(evt) {
			var key = evt.getSource().getSelectedKey(),
				mastList = this.byId("Tree");
			key = (key === "AL") ? " " : key;
			this.initialLoad = false;
			mastList.bindRows({
				path: '/Dbheaders',
				filters: [new sap.ui.model.Filter("Filterby", "EQ", key)]

			});
			/*	mastList.getBinding("rows").filter([new sap.ui.model.Filter("Filterby", "EQ", key)]);
				mastList.refreshRows();*/
		},
		dispPrevreviewed: function(prev) {
			return (prev) ? "Yes" : "No";
		},
		setVisibility: function(v) {
			return (v) ? true : false;
		},
		modelContextChange: function() {
			alert(123);
		}

	};

});