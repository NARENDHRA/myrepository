sap.ui.define([], function() {
	"use strict";

	return {

		onRightPanelFscreen: function(evt) {

			var middlePanel = this.getSplitter().getContentAreas()[1].getLayoutData(),
				leftPanel = this.getSplitter().getContentAreas()[0].getLayoutData(),
				rightPanel = this.getSplitter().getContentAreas()[2].getLayoutData();
			if (leftPanel.getSize("0px") !== "0px") {
				middlePanel.setSize("auto");
				leftPanel.setSize("0px");
				rightPanel.setSize("255px");

			} else {
				this.onResetScreen();
			}
		}

	};

});