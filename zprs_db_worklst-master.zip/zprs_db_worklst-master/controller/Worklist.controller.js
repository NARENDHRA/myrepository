sap.ui.define([
	"fgtdbworklist/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"fgtdbworklist/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"fgtdbworklist/controller/mainColumns/leftColumn",
	"fgtdbworklist/controller/mainColumns/middleColumn",
	"fgtdbworklist/controller/mainColumns/rightColumn",
	'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV'
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, leftColumn, middleColumn, rightColumn, Export,
	ExportTypeCSV) {
	"use strict";

	return BaseController.extend("fgtdbworklist.controller.Worklist", {

		formatter: formatter,
		leftColumn: leftColumn,
		middleColumn: middleColumn,
		rightColumn: rightColumn,
		changeEvtTime: 30,
		defaultMstrRowHeight: 35,
		masterTopSearchFilters: [],
		selIndexs: {},
		masterGlobalFilter: new sap.ui.model.Filter("Filterby", "EQ", " "),
		initialMasterLoad: true,
		openByDefault: false,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {

			if (!this.byId("Tree")) {
				return false;
			}
			this._oResourceBundle = this.getResourceBundle();
			var appSettings = new JSONModel({
				actionEnabled: false,
				narrativeCol: true,
				masterDefaultFilterKey: "AL",
				panelAnimation: true
			});
			this.setModel(appSettings, "appSettings");

			this.getOwnerComponent().getModel().attachBatchRequestSent(function(oEvent) {
				if (this.itemAutosaveCall) {
					this.byId("idProductsTable3Inner").setBusy(false);
					sap.m.MessageToast.show("Saving...", {
						at: sap.ui.core.Popup.Dock.EndBottom,
						duration: 500,
						width: "10em"
					});
				}
				//	alert(123);
			}, this);

			this.getOwnerComponent().getModel().attachBatchRequestCompleted(function(oEvent) {
				this.itemAutosaveCall = false;
				//	alert(123);
			}, this);

			// Add  by Naresh for Attachment Service Model
			var attachmentModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_FILE_ATTACHMENT_UI_SRV/");
			this.setModel(attachmentModel, "atthModel");

			this._setRoleModel();

			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.attachRoutePatternMatched(this._onUrlMatch.bind(this), this);

			this.byId("headerCommentBox").attachBrowserEvent("change", function() {
				this.firePost(this);

			});

		},
		_onUrlMatch: function(oEvent) {
			var oParameters = oEvent.getParameters();

			if (oParameters.name === "DBILL") {
				//	?&/70057330
				var m = this.getModel("appSettings"),
					list = this.byId("Tree"),
					binding = list.getBinding("items"),
					f = [new sap.ui.model.Filter("Draftbill", sap.ui.model.FilterOperator.EQ, oParameters.arguments.DBILL)].concat([new sap.ui.model.Filter(
						"Filterby", "EQ", " ")]);
				m.getData().masterDefaultFilterKey = "AL";
				m.refresh();
				binding.filter(f, sap.ui.model.FilterType.Application);
				this.openByDefault = true;
				this.initialMasterLoad = true;
			}
		},

		_setRoleModel: function() {
			var that = this;
			this.getOwnerComponent().getModel().read("/Roleactionlist", {
				success: function(oData) {
					var roleModel = new JSONModel(oData.results);
					that.getView().setModel(roleModel, "roleModel");
					//	that._addDbActions();
				},
				error: function(oData) {

				}
			});
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		onPressMainExpand: function(evt) {

			var m = this.getModel("generalSetting"),
				md = m.getData(),
				src = evt.getSource();
			if (src.getIcon() === "sap-icon://expand-group") {
				md.showRowDetail = false;
				src.setIcon("sap-icon://collapse-group");
			} else {
				md.showRowDetail = true;
				src.setIcon("sap-icon://expand-group");
			}
			m.refresh();
		},
		getSplitter: function() {
			if (!this.oSplitter) {
				this.oSplitter = this.byId("mainSplitter");
			}

			return this.oSplitter;
		},
		onResetScreen: function() {
			var spliter = this.getSplitter();
			spliter.getContentAreas()[1].getLayoutData().setSize("auto");
			spliter.getContentAreas()[0].getLayoutData().setSize("275px");
			spliter.getContentAreas()[2].getLayoutData().setSize("255px");

		},

		addFocusin: function(evt, e) {
			//	alert(e);
		},
		openCommentPopUp: function(evt) {

			if (!this._commentPopover) {
				this._commentPopover = sap.ui.xmlfragment("fgtdbworklist.fragments.commentBox", this);
				this.getView().addDependent(this._commentPopover);

			}
			this._commentPopover.openBy(evt.getSource());

		},
		onNarrativeMore: function(evt) {
			if (!this._narrativePopover) {
				this._narrativePopover = sap.ui.xmlfragment("fgtdbworklist.fragments.NarrativePopup", this);
				this.getView().addDependent(this._narrativePopover);

			}
			this._narrativePopover.open(evt.getSource());
		},
		onNarrativeClose: function() {
			this._narrativePopover.close();
		},
		onMoveMainUp: function(evt) {

			var t = this.byId("MainHeaderContent"),
				src = evt.getSource();

			if (t.getVisible()) {
				t.setVisible(false);
			} else {
				t.setVisible(true);
			}

		},

		tabselect: function(oEvent) {

			var selText = oEvent.getParameters().selectedItem.getText();

			if (selText === "Narrative") {
				//	window.open("http://fgtappg4b.fulcrum-gt.com:8000/sap/bc/ui5_ui5/sap/ZPRS_wrkflw/index.html#/narrative/70001033", "_blank");
			}

		},
		getTime: function() {
			return new Date().getTime();
		},
		// Added by Naresh For Attachement Section and Binding for attachemnt 
		onUploadComplete: function(oEvent) {
			var atthModel, tobind;
			tobind = this.byId("UploadCollection");
			atthModel = this.getView().getModel("AttachJson");
			var i18n = this.getResourceBundle();
			// atthModel.setDefaultBindingMode("TwoWay");
			// atthModel.refresh();
			var oStatus = oEvent.getParameters().getParameters().status;
			/*	var urlToRead = "/Dbheaders(Draftbill='" + this.selectedItemContext.getObject("Draftbill") + "'" + ",Id=''" + ")";
				var oPath = urlToRead + "/DbHeaderToDbAttachments";
				var oModel = this.getOwnerComponent().getModel();*/
			var that = this;
			//that._bindItems(tobind, that.selectedItemContext.getPath() + "/DbHeaderToDbAttachments", that.hAttachmentTemplate);
			if (oStatus === 201) {
				tobind.getBinding("items").refresh();
				that._refreshMiddleHeader();
				sap.m.MessageToast.show(i18n.getText("MsgUploadSuccess"));
			} else {
				sap.m.MessageToast.show(i18n.getText("MsgUploadError"));
			}

		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: this.selectedItemContext.getObject("Draftbill") + '|' + oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			this.oUploadCollection = oUploadCollection;
			oUploadCollection.setUploadUrl("/sap/opu/odata/SAP/ZPRS_DB_WORKLIST_SRV/DbAttachmentsSet");
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oUploadCollection.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		},
		onFileDeleted: function(oEvent) {
			var i18n = this.getResourceBundle();
			var docId, delUrl, atthModel, source, tobind;
			source = oEvent.getSource();
			tobind = this.byId("UploadCollection");
			docId = source.getProperty("documentId");
			// delUrl = "/DbAttachmentsSet(Draftbill='" + this.selectedItemContext.getObject("Draftbill") +
			// 	"',LoioId='" + docId + "')";
			var url = "/DbAttachmentsSet(Draftbill='" + this.selectedItemContext.getObject("Draftbill") + "'" +
				",Objkey='" + this.selectedItemContext.getObject("Id") + "'" +
				",LoioId='" + docId + "'" + ")";
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			sap.m.MessageBox.show(i18n.getText("MsgDeleteConfirm"), {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirm",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function(oAction) {
					if (oAction === "YES") {
						oModel.remove(url, {
							success: function(data) {
								tobind.getBinding("items").refresh();
								that._refreshMiddleHeader();
								//that._bindItems(tobind, that.selectedItemContext.getPath() + "/DbHeaderToDbAttachments", that.hAttachmentTemplate);
								// oModel.refresh();
								// source.setBusy(false);
							},
							error: function(data) {
								// source.setBusy(false);
							}
						});
					}
				}.bind(this)
			});
		},
		onFileUrlPress: function(evt) {
			var oLoioId = evt.getSource().getProperty("documentId");
			var sRead = "/sap/opu/odata/sap/ZPRS_DB_WORKLIST_SRV/DbAttachmentsSet(Draftbill='" + this.selectedItemContext.getObject("Draftbill") +
				"'" +
				",Objkey='" + this.selectedItemContext.getObject("Id") + "'" +
				",LoioId='" + oLoioId + "'" + ")" + "/$value";
			var mainUri = sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");
		},
		onPostHeaderComments: function(evt) {
			var oObjectParm;
			var sValue = evt.getSource().getValue();
			evt.getSource().setValue("");
			var oModel = this.getOwnerComponent().getModel();
			var oDbBillNo = this.selectedItemContext.getObject("Draftbill");
			var i18n = this.getResourceBundle();
			var that = this;
			oObjectParm = {
				Draftbill: oDbBillNo,
				Itemcomments: sValue,
				Roleid: this.selectedItemContext.getObject("Role")

			};
			var that = this;
			oModel.create("/DbCommentsSet", oObjectParm, {
				success: function(oData, response) {
					that._refreshMiddleHeader();
					sap.m.MessageToast.show(i18n.getText("MsgCommentsSuccess"));

				},
				error: function(oData) {
					sap.m.MessageToast.show("error");
				}
			});
		},
		/*	RebindComments: function() {
				var oModel = this.getOwnerComponent().getModel();
				// var oDbBillNo = this.selectedItemContext.getObject("Draftbill");
				var urlToRead = "/Dbheaders(Draftbill='" + this.selectedItemContext.getObject("Draftbill") + "'" + ",Id=''" + ")";
				var oPathcmt = urlToRead + "/DbHeaderToDbComments",
					oCmtModel = new sap.ui.model.json.JSONModel(),
					that = this;
				oModel.read(oPathcmt, {
					success: function(odata) {
						oCmtModel.setData(odata);
						that.getView().setModel(oCmtModel, "CmtModel");
					},
					error: function(odata) {}
				});
			},*/
		//changes done by murali on 30th Nov comments display, lineitem post
		openCommentDisplayPopUp: function(evt) {

			var oContext = evt.getSource().getBindingContext(),
				cSrc, prevCtxt;

			if (!this._commentPopover) {
				this._commentPopover = sap.ui.xmlfragment(this.getView().getId(), "fgtdbworklist.fragments.commentBox", this);
				this.getView().addDependent(this._commentPopover);
				this.commentList = this._commentPopover.getContent()[0].getContent()[1];
				this.commentListTemplate = this._commentPopover.getContent()[0].getContent()[1].getItems()[0].clone();

				this._commentPopover.attachAfterOpen(function() {
					prevCtxt = this.cmtoContext;
					//	this.disablePointerEvents();
				}, this);

				this._commentPopover.attachAfterClose(function(ievt) {
					cSrc = ievt.getSource().getContent()[0].getContent()[0];
					if (cSrc) {
						//alert(prevCtxt);
						this.onPostComments("", cSrc.getValue(), prevCtxt);
						cSrc.setValue("");
					}
				}, this);

			}
			this.cmtoContext = oContext;
			this.commentList.bindItems(this.cmtoContext.getPath() + "/DbItemToDbComments", this.commentListTemplate);
			this._commentPopover.openBy(evt.getSource());
		},
		_displayComments: function(cmtoContext) {

			//	cmtoContext.getPath();
			this.cmtoContext = cmtoContext;
			var Draftbill = cmtoContext.getObject().Draftbill,
				lineItem = cmtoContext.getObject().Lineitem;
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			var urlToRead = "/" + oModel.createKey("Dbdetails", {
				Draftbill: Draftbill,
				Lineitem: lineItem
					// Draftbill: "70037689",
					// Lineitem: "000010"		
			}) + "/DbItemToDbComments";
			oModel.read(urlToRead, {
				success: function(res) {
					var itemCommentsModel = new JSONModel(res);
					that.getView().setModel(itemCommentsModel, "itemCommentsModel");
				},
				error: function(res) {

				}
			});
		},
		onPostComments: function(oEvent, cVal, prevCtxt) {
			// 	var cxt = this.cmtoContext,
			// path =	cxt.getPath()+"/DbItemToDbComments";
			var sValue, Draftbill, lineItem, oPayload, batchModel, hascomments;
			if (oEvent) {
				sValue = oEvent.getParameter("value");
				Draftbill = this.cmtoContext.getObject().Draftbill;
				lineItem = this.cmtoContext.getObject().Lineitem;
				hascomments = this.cmtoContext.getObject().HasComments;
			} else {
				sValue = cVal;
				Draftbill = prevCtxt.getObject().Draftbill;
				lineItem = prevCtxt.getObject().Lineitem;
				hascomments = prevCtxt.getObject().HasComments;
			}
			batchModel = this.getView().getModel();

			oPayload = {
				Draftbill: Draftbill,
				Lineitem: lineItem,
				Itemcomments: sValue,
				Commentseq: ""
			};
			if (sValue) {
				batchModel.create("/DbCommentsSet", oPayload, {
					success: function(oData) {
						if (!hascomments) {
							this.byId("idProductsTable3").rebindTable();
						}
					}.bind(this),
					error: function(oError) {

					}
				});
			}
		},
		handelTblFieldChange: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath();
			model.setProperty(sPath + "/" + path, value);
			this._autoSaveDBill(evt, "iCall");
		},
		onPostTblData: function(evt, type) {
			this._submitChanges(evt, type || "");

		},
		_submitChanges: function(evt, type) {
			var i18n = this.getResourceBundle();
			var oModel = this.getModel(),
				sMsgFlag = true,
				respObj,
				smg = i18n.getText("MsgSuccessUpdate");
			// var that = this;
			if (!$.isEmptyObject(oModel.getPendingChanges())) {
				oModel.submitChanges({
					success: function(res) {
						res.__batchResponses = res.__batchResponses || [];
						for (var i = 0; i < res.__batchResponses.length; i++) {
							if (res.__batchResponses[i].response) {
								respObj = JSON.parse(res.__batchResponses[i].response.body);
								if (respObj.error && respObj.error.code === "DBDETAIL/000") {
									sMsgFlag = false;
									smg = respObj.error.message.value;
								}

							}

							if (!sMsgFlag) {
								break;
							}
						}

						// oModel.refresh();
						if ((sMsgFlag)) {
							if (type !== "iCall") {
								sap.m.MessageToast.show(smg);
							}
						} else {
							//alert("error");
							sap.m.MessageBox.error(smg);
						}
					}.bind(this),
					error: function(res) {

					}.bind(this)
				});
			} else {
				if (type !== "iCall") {
					sap.m.MessageToast.show(i18n.getText("MsgNoChanges"));
				}
			}

		},
		onPressPrint: function(oEvt) {
			var mainUri,
				i18n = this.getResourceBundle();
			if (!this.selectedItemContext || this.leftColumn._getAllselectedItemsMaster.call(this).length === 0) {
				sap.m.MessageToast.show(i18n.getText("MsgSelectDBill"), {
					duration: 1000
				});
				return false;
			}
			mainUri = "/sap/opu/odata/sap/ZPRS_DB_WORKLIST_SRV/PrintDraftbillCollection('" + this.selectedItemContext.getObject("Draftbill") +
				"')" +
				"/$value";
			sap.m.URLHelper.redirect(mainUri, "_blank");
		},
		onBeforeRebindTable: function(evt) {

			// leftColumn.sPath
			var oSrc = evt.getSource(),
				m = this.getModel("appSettings");
			if (this.detTblExpanded !== undefined) {
				m.getData().narrativeCol = this.detTblExpanded;
				m.refresh();
			}
			oSrc.setTableBindingPath(this.sPath);
		},
		// setting inoutparameter  while converting samrt field to dropdown
		smartDpDwnCahnge: function(evt) {
			var src = evt.getSource(),
				dp = src.getInnerControls()[0],
				allCells, actcodekDpDwn,
				inOutParams = JSON.parse('{' + src.data().inOutParams + '}');
			this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[0], dp.getSelectedItem().getKey());
			this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[1], dp.getSelectedItem().getText());
			dp.setValue(dp.getSelectedItem().getKey());

			if (src.data("src") === "Fftaskcodek") {
				//var tcells = src.getParent().getCells()[12].getInnerControls()[0];
				allCells = src.getParent().getCells();
				allCells.forEach(function(obj) {
					if (obj.data && obj.data("src") === "Ffactcodek") {
						obj.setValueState("Error");
						obj.setValueStateText("Enter valid FF Activity Code");
						actcodekDpDwn = obj.getInnerControls()[0];
					}
				});
				actcodekDpDwn.destroyItems();
				this.getModel().setProperty(src.getBindingContext().getPath() + "/Ffactcodek", "");
				this.getModel().setProperty(src.getBindingContext().getPath() + "/Ffactcode", "");

			} else if (src.data("src") === "Ffactcodek") {
				src.setValueState("None");
				this._autoSaveDBill(evt, "iCall");
			} else {
				this._autoSaveDBill(evt, "iCall");
			}
		},
		samrtDpDwnCreated: function(evt) {
			var src = evt.getSource().getInnerControls()[0],
				obj = evt.getSource().getBindingContext().getObject(),
				data = evt.getSource().data(),
				inOutParams = JSON.parse('{' + data.inOutParams + '}');
			src.setValue(obj[inOutParams.local[0]]);
			src.detachLoadItems(this.attachAfterOpenDialog);
			src.attachLoadItems(evt.getSource(), this.attachAfterOpenDialog);
		},
		attachAfterOpenDialog: function(evt, src) { // binding change while converting samrt field to dropdown
			try {
				var dp = src,
					bi = dp.getBindingInfo("items"),
					data = src.data(),
					inOutParams = JSON.parse('{' + data.inOutParams + '}');
				var oItem = dp.getAggregation("_content"),
					obj = dp.getBindingContext().getObject();
				evt.getSource().bindAggregation("items", "/" + data.entitySet, new sap.ui.core.Item({
					key: "{" + inOutParams.vList[0] + "}",
					text: "{" + inOutParams.vList[1] + "}"
				}));
				evt.getSource().getBinding("items")
					.filter([new sap.ui.model.Filter("DRAFTBILL", sap.ui.model.FilterOperator.EQ, obj.Draftbill),
						new sap.ui.model.Filter("LINEITEM", sap.ui.model.FilterOperator.EQ, obj.Lineitem),
						new sap.ui.model.Filter("MATTERK", sap.ui.model.FilterOperator.EQ, obj.Matterk)
					]).attachDataReceived(function() {
						this.getAggregation("picker").getAggregation("content")[0].setBusy(false);
					}.bind(this));

				//	oItem.setValue(obj[inOutParams.local[1]]);

			} catch (e) {
				sap.m.MessageBox.show(e.message, sap.m.MessageBox.Icon.ERROR, "Error");
			}
		},
		samrtDpDwnCreatedFFAct: function(evt) {
			var src = evt.getSource().getInnerControls()[0],
				obj = evt.getSource().getBindingContext().getObject(),
				data = evt.getSource().data(),
				inOutParams = JSON.parse('{' + data.inOutParams + '}');
			src.setValue(obj[inOutParams.local[0]]);
			src.detachLoadItems(this.attachAfterOpenDialogFFAct);
			src.attachLoadItems(evt.getSource(), this.attachAfterOpenDialogFFAct);
		},
		attachAfterOpenDialogFFAct: function(evt, src) {
			//	var i18n = this.getResourceBundle();
			var ffact = src.getBindingContext().getObject().Fftaskcodek;
			if (ffact === "" || ffact === null) {
				sap.m.MessageBox.warning("Please select Flat Fee Task Code", sap.m.MessageBox.Icon.WARNING, "Warning");
			} else {
				try {
					var dp = src,
						bi = dp.getBindingInfo("items"),
						data = src.data(),
						inOutParams = JSON.parse('{' + data.inOutParams + '}');
					var oItem = dp.getAggregation("_content"),
						obj = dp.getBindingContext().getObject();
					evt.getSource().bindAggregation("items", "/" + data.entitySet, new sap.ui.core.Item({
						key: "{" + inOutParams.vList[0] + "}",
						text: "{" + inOutParams.vList[1] + "}"
					}));
					evt.getSource().getBinding("items")
						.filter([new sap.ui.model.Filter("DRAFTBILL", sap.ui.model.FilterOperator.EQ, obj.Draftbill),
							new sap.ui.model.Filter("LINEITEM", sap.ui.model.FilterOperator.EQ, obj.Lineitem),
							new sap.ui.model.Filter("MATTERK", sap.ui.model.FilterOperator.EQ, obj.Matterk),
							new sap.ui.model.Filter("FFTASKCODEK", sap.ui.model.FilterOperator.EQ, obj.Fftaskcodek)
						]).attachDataReceived(function() {
							this.getAggregation("picker").getAggregation("content")[0].setBusy(false);
						}.bind(this));

					oItem.setValue(obj[inOutParams.local[1]]);

				} catch (e) {
					sap.m.MessageBox.show(e.message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			}
		},
		handelAmendedhoursChange: function(evt) {
			var i18n = this.getResourceBundle();
			var source = evt.getSource(),
				ctx = source.getBindingContext().getObject(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				value = source.getValue(),
				Acthours = ctx.Quantity,
				sPath = source.getBindingContext().getPath();
			var array = value.split(".");
			if (array[1] > 59) {
				sap.m.MessageToast.show(i18n.getText("MsgInvalidminutes"), {
					duration: 1000
				});
				source.setValue("");
				source.focus(true);
				return false;
			}
			var smg = i18n.getText("MsgAmendedhoursCheck");
			if (parseFloat(value) > parseFloat(Acthours)) {
				sap.m.MessageToast.show(smg, {
					duration: 1000
				});
				source.setValue("");
				source.focus(true);
			} else if (parseFloat(value) > 8.1) {
				sap.m.MessageToast.show(smg, {
					duration: 1000
				});
				source.setValue("");
				source.focus(true);
			} else {
				value = parseFloat(source.getValue()).toFixed(2);
				source.setValue(value);
				model.setProperty(sPath + "/" + path, value);
			}
		},
		_refreshMiddleHeader: function() {
			//this.byId("middlePanel").getModel().updateBindings(true);
			this.byId("middlePanel").bindElement(this.selectedItemContext.getPath() + "/Itemheader");
		},
		_isActionsAreactive: function(len) {
			var m = this.getModel("appSettings");
			m.getData().actionEnabled = (len) ? true : false;
			m.refresh();
		},

		_setAppSettings: function(p, v) {
			var m = this.getModel("appSettings");
			m.getData()[p] = v;
			m.refresh();
		},

		_bindItems: function(toBind, bPath, template) {
			toBind.setBusy(true);
			toBind.bindItems({
				path: bPath,
				template: template,
				events: {
					dataRequested: function() {
						//	toBind.setBusy(true);
					},
					dataReceived: function() {
						toBind.setBusy(false);
					}

				}
			});
		},

		_bindElement: function(toBind, bPath) {
			toBind = this.byId(toBind);
			toBind.setBusy(true);
			toBind.bindElement({
				path: bPath,
				events: {
					dataRequested: function() {
						//	toBind.setBusy(true);
					},
					dataReceived: function() {
						toBind.setBusy(false);
					}

				}
			});
		},
		onDetailTabChnage: function(evt) {
			var i18n = this.getResourceBundle(),
				p, toBind;
			if (!this.selectedItemContext || this.leftColumn._getAllselectedItemsMaster.call(this).length === 0) {
				evt.getSource().setSelectedSection(evt.getSource().getSections()[0].getId());
				sap.m.MessageToast.show(i18n.getText("MsgSelectDBill"), {
					duration: 1000
				});
				return false;
			}
			p = this.selectedItemContext.getPath();

			switch (evt.getParameter("section").data("key")) {
				case "headerNarrative":
					var arr = window.location.href.split("/"),
						burl = arr[0] + "//" + arr[2];
					window.open(burl + "/sap/bc/ui5_ui5/sap/ZPRS_NAR_APP/index.html#/narrative/" + this.selectedItemContext
						.getObject("Draftbill"), "_blank");
					break;
				case "billingInst":
					this._bindElement("BillingTab", p + "/DbheaderToBillingInstructions");
					break;
				case "auditTrial":
					toBind = this.byId("AuditTrailId");
					if (!this.AudittblTemplate) {
						this.AudittblTemplate = toBind.getItems()[0].clone();
					}
					// comment fro testing with empty data with section error 
					// else {
					// 	this.AudittblTemplate = this.AudittblTemplate.clone();
					// }
					if (toBind.getBindingPath("items") !== p + "/DbHeaderToAuditTrail") {
						this._bindItems(toBind, p + "/DbHeaderToAuditTrail", this.AudittblTemplate);
					}
					break;
				case "headerComments":
					toBind = this.byId("headerCommentsList");
					if (!this.hCommentsTemplate) {
						this.hCommentsTemplate = toBind.getItems()[0].clone();
					} else {
						this.hCommentsTemplate = this.hCommentsTemplate.clone();
					}
					if (toBind.getBindingPath("items") !== p + "/DbHeaderToDbComments") {
						this.byId("headerCommentBox").setValue("");
						this._bindItems(toBind, p + "/DbHeaderToDbComments", this.hCommentsTemplate);
					}
					break;
				case "attachment":
					toBind = this.byId("UploadCollection");
					if (!this.hAttachmentTemplate || toBind.getItems().length) {
						this.hAttachmentTemplate = toBind.getItems()[0].clone();
					} else {
						this.hAttachmentTemplate = this.hAttachmentTemplate.clone();
					}
					if (toBind.getBindingPath("items") !== p + "/DbHeaderToDbAttachments") {
						this._bindItems(toBind, p + "/DbHeaderToDbAttachments", this.hAttachmentTemplate);
					}
					break;

				default:
			}
			//alert(evt);
		},
		_emptyDetails: function() {
			return this.byId("Tree").getItems()[0];
		},
		_isSameContext: function(iCtxt) {
			var retFlag = false;
			if (this.selectedItemContext) {
				retFlag = (this.selectedItemContext.getPath() === iCtxt.getPath());
			}
			return retFlag;
		},
		_numHourFormat: function(val) {
			return sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				minFractionDigits: 2
					//decimalSeparator: ","
			});
		},
		_resetDetail: function() {
			var paths = [],
				m = this.getModel(),
				chgs;
			if (this.getModel().hasPendingChanges()) {
				chgs = this.getModel().getPendingChanges();
				//	resetChanges(aPath?\)
				$.each(chgs, function(p) {
					paths.push("/" + p);
					//	console.log(o);
				});
				this.getModel().resetChanges(paths);
			}
			//this.getModel().resetChanges();
		},
		onAmndHourChange: function(evt) {
			var s = evt.getSource(),
				av = ($.trim(s.getValue()) === "") ? "" : s.getValue(),
				v = (av === "") ? "" : Number(av.replace(",", ".")),

				ctx = s.getBindingContext().getObject(),
				//Acthours = ctx.Quantity,
				//path = s.getBindingPath("value"),
				hFormat = this._numHourFormat(),
				sPath = s.getBindingContext().getPath(),
				model = s.getModel(),
				fv = (v === "") ? "" : hFormat.format(v);
			/*	smg = "Ameneded Hours should not be greater than the Actual hours";
			if (parseFloat(v) > parseFloat(Acthours)) {
				sap.m.MessageToast.show(smg, {
					duration: 1000
				});
				v = 0;
				s.focus(true);
			}*/

			if (fv === "") {
				model.setProperty(sPath + "/AhoursS", fv);
				//model.setProperty(sPath + "/AhoursQ", hFormat.format(0));
				model.setProperty(sPath + "/AhoursI", "X");
				s.setValue(fv);
			} else if ((!Number(fv.replace(",", ".")) && ctx.AhoursI === "")) {
				model.setProperty(sPath + "/AhoursS", "0");
				model.setProperty(sPath + "/AhoursI", "X");
				s.setValue(fv);
			} else {
				model.setProperty(sPath + "/AhoursQ", fv.replace(",", "."));
				model.setProperty(sPath + "/AhoursI", "X");
				s.setValue(fv);
			}

			this._autoSaveDBill(evt, "iCall");

		},
		onAmndHourKeyIn: function(evt) {
			//	return false;
			var i18n = this.getResourceBundle();
			var s = evt.getSource(),
				v = s.getValue(),
				sp = this._numHourFormat().oFormatOptions.decimalSeparator,
				ctx = s.getBindingContext().getObject(),
				Acthours = ctx.Quantity,
				sv = v.split(sp),
				msg = i18n.getText("MsgAmendedhoursCheck"),
				sPath = s.getBindingContext().getPath(),
				model = s.getModel();

			if ((parseFloat(v) > parseFloat(Acthours)) || parseFloat(v) < 0) {
				/*	sap.m.MessageToast.show(smg, {
						duration: 1000
					});*/
				s.setValue(this._numHourFormat().format(ctx.AhoursQ));

				model.setProperty(sPath + "/AhoursQ", ctx.AhoursQ);
				model.setProperty(sPath + "/AhoursI", "X");
				sap.m.MessageBox.error(msg);
				//	s.setValue(v);
				//s.focus(true);
			}
			/* else if (sv[0] > 24) {
						
							s.setValue(sv[0].substring(0, sv[0].length - 1) + sp + sv[1]);
							//s.focus(true);
							//return false;
						}*/
			else if (sv[1] && (sv[1].length > 2 || sv[1] > 59)) {
				s.setValue(sv[0] + sp + sv[1].substring(0, sv[1].length - 1));
			}
			/*
						else if( ( isNaN(sv[0]) && isNaN(sv[0]))    ){
							  if(sv[0].length>1){
								s.setValue(sv[0].substring(0, sv[0].length - 1) );}else{
									s.setValue("");
								}
						}*/

		},
		amndHrsDefaultFormat: function(ahrs, changed) {
			return (changed === "X") ? this._numHourFormat().format(ahrs) : "";
		},
		hrsDefaultFormat: function(ahrs) {
			return this._numHourFormat().format(ahrs);
		},
		rowHighlight: function(Matnr) {
			var rv;
			if (Matnr === "FEE") {
				rv = "Success";
			} else if (Matnr === "HARDCOST") {
				rv = "Information";
			} else {
				rv = "Warning";
			}
			return rv;
		},
		onBeforeExportExcel: function(evt) {
			// Columns ( removing Comment Comment Column)
			var c = evt.mParameters.exportSettings.workbook.columns;
			c.splice(0, 1);
			// Filtersetting In excel sheet and Setting SplitCells in excel sheet.
			if (evt.mParameters.userExportSettings) {
				evt.mParameters.userExportSettings.includeFilterSettings = true;
				evt.mParameters.userExportSettings.splitCells = true;
			} else {
				evt.mParameters.exportSettings.includeFilterSettings = true;
				evt.mParameters.exportSettings.splitCells = true;
			}
			this._setColumnFormater(c);
			// setting  FileName  Excel sheet.
			evt.mParameters.exportSettings.fileName = "Draft Bill(" + this.selectedItemContext.getObject("Draftbill") + ")";

		},
		_setColumnFormater: function(columns) {
			//,"Baserate","Writeupdown","Quantity","AhoursQ"
			var currencyFields = ["Netvalue", "Baserate", "Writeupdown"],
				dateFields = ["Workdate"],
				hrsFields = ["Quantity", "AhoursQ"],
				df = new sap.ui.model.type.Date().getOutputPattern();
			$.each(columns, function(i, obj) {
				if (currencyFields.includes(obj.property)) {
					//obj.label = "currency";
					//	obj.displayUnit = true;
					//	obj.property = "AmtStr";
					//	obj.scale =2;
					obj.delimiter = true;
					obj.type = "currency";
					obj.unitProperty = "Currency";
					//obj.unit  = "%";

					//obj.unitProperty="##0.0E+0";

					//obj.format="1.234.567,89";
				} else if (hrsFields.includes(obj.property)) {
					obj.type = "number";

				} else if (dateFields.includes(obj.property)) {
					obj.type = "date";
					obj.format = df.toLowerCase();
					obj.width = 18;
				}

			});

		},
		onexport: function(evt) {
			//	this.byId("idProductsTable3Inner").getItems()[0].getCells()[1].getBindingPath("text")
			var oExport = new Export({

				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType: new ExportTypeCSV({
					separatorChar: ";"
				}),

				// Pass in the model created above
				models: evt.getSource().getModel(),

				// binding information for the rows aggregation
				rows: {
					path: this.selectedItemContext.getPath() + "/Itemdetail"
				},

				// column definitions with column name and binding info for the content

				columns: [

					{
						name: "Netvalue",
						template: {
							content: {
								parts: ["Netvalue"],
								formatter: function(Netvalue) {
									return this._numHourFormat().format(Netvalue);
								}.bind(this),
								state: "Warning"
							}
						}
					}

					/*{
						name: "Netvalue",
						template: {
							content: "{Netvalue}"
						}
					}*/

				]
			});

			// download exported file
			oExport.saveFile().catch(function(oError) {
				alert("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});

		},
		_autoSaveDBill: function(evt, type) {
			this.itemAutosaveCall = true;
			this.onPostTblData.call(this, evt, type);
		},
		_confirmPendingChnages: function() {

			if (this.getModel().hasPendingChanges()) {

				sap.m.MessageBox.confirm(
					"You have unsaved changes on this Draft Bill, Do you want to go next and discard your changes or stay on this Draft Bill?", {
						onClose: function(evt) {
							alert(evt);
						}
					}
				);
				//this.getModel().resetChanges();
			}
		},
		refreshDetails: function(evt) {
			this.byId("idProductsTable3").rebindTable();
		}

	});
});