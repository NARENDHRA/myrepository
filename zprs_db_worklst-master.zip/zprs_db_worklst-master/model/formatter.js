jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		checkRejText: function(rText){
		// var	rText = rText.toString();
				if (rText === "" || rText === null) {
					return true;
				}
				return false;
		},
		checkBillingInst: function(sValue) {
				if (sValue === "" || sValue === null) {
					// return this.getResourceBundle().getText("BillingInst");
					return "No Billing Instructions";
				}
				return sValue;
			}
			// utcDate: function(dt) {
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		style: "medium",
			// 		UTC: true
			// 	});

		// 	var dateStr = dateFormat.format(dt);
		// 	return dateStr;
		// }

	};

});