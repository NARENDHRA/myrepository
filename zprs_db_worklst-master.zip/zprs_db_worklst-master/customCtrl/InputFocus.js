sap.ui.define(["sap/ui/core/Control"],
	function(Control) {

		return sap.m.Input.extend('InputFocus', {
  metadata: {
    events: {
      focus: {},
       mouseover: {}
    } 
  },

  renderer: {},

  onAfterRendering: function() {
    if (sap.m.Input.onAfterRendering) {
      sap.m.Input.onAfterRendering.apply(this, arguments);
    }

    this.$().find('input').focus(function() {
      this.fireEvent('focus');
    }.bind(this));
    
      this.$().find('input').mouseover(function() {
      this.fireEvent('mouseover');
    }.bind(this));
    
    
  } 
});

	}
);