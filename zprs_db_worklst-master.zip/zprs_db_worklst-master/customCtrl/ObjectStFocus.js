sap.ui.define(["sap/ui/core/Control"],
	function(Control) {

		return sap.m.ObjectStatus.extend('ObjectStFocus', {
  metadata: {
    events: {
      focus: {},
       mouseover: {}
    } 
  },

  renderer: {},

  onAfterRendering: function() {
    if (sap.m.Input.onAfterRendering) {
      sap.m.Input.onAfterRendering.apply(this, arguments);
    }

    this.$().find('span').focus(function() {
      this.fireEvent('focus');
    }.bind(this));
    
      this.$().find('span').mouseover(function() {
      this.fireEvent('mouseover');
    }.bind(this));
    
    
  } 
});

	}
);