jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"fgtdbworklist/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"fgtdbworklist/test/integration/pages/Worklist",
		"fgtdbworklist/test/integration/pages/Object",
		"fgtdbworklist/test/integration/pages/NotFound",
		"fgtdbworklist/test/integration/pages/Browser",
		"fgtdbworklist/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "fgtdbworklist.view."
	});

	sap.ui.require([
		"fgtdbworklist/test/integration/WorklistJourney",
		"fgtdbworklist/test/integration/ObjectJourney",
		"fgtdbworklist/test/integration/NavigationJourney",
		"fgtdbworklist/test/integration/NotFoundJourney",
		"fgtdbworklist/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});