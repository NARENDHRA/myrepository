# Documentation for BCD PNR app

## DisplaySettings
I'm using a seperate model DisplaySettings to determine which fields need to be displayed in the Article- and Segments view.

Please see {@link com.bcdtravel.pnr.model.DisplaySettings}

## ODataModel
Instead of using the sap.ui.model.odata.v2.ODataModel I've created my own model (extend)

Please see {@link com.bcdtravel.pnr.model.BCDGateway}

## Error Codes
On this moment these are all possible error codes
* 01 Mandatory field missing
 * 02 Billback - Document references missing
 * 03 Missing master data / mapping data
 * 04 Booking without article data
 * 05 No segment data but necessary
 * 06 Missing reference data
 * 07 Wrong refernce data
 * 08 Currency cannot be derived form article
 * 09 Missing Bundle Product Reference data
 * 10 Amount has wrong number of decimals
 
The only error codes that are being used in the fiori app are 01, 02, 03, 06, 07, 08, 10
If a new error code is added in the backend and we need to display it in the app
Simply add the new code to aOnlyErrorCodes array in the model/BCDGateway.js file method oModel.readFieldErrors 

## Billback release
In the Article view the user can realease the billback only when:
- article.BillbackNotReleased === "X" (else the button is hidden)
- ArticleView.BillBackReleaseAmount === article.Totalamount
- The article.DpDocid, article..DtelGefInvnr and article.Supplier are set
- The article.Salespriceamount >= article.Totalamount

## Touch events bug IconTabBar
Chrome 55+ introduces TouchEvents and PointerEvents and this causes problems with the sap.m.IconTabBar (Items could not be selected). This problem was "Solved" by SAP in ui5 version 1.38.14 or higher but unfortunately we've still experience the same problems running on 1.44.1 (which is the version on the D T and P systems). Since updating the ui5 version didn't solved the issue, we fixed the problem ourselfs by extending the sap.m.IconTabBar. Please see {@link nl.barrydam.m.IconTabBar} for our solution


<!-- jsdoc -c jsdoc.json -->