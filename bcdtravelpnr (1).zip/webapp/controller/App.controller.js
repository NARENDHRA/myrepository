/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"com/bcdtravel/pnr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History"
], function(BaseController, JSONModel, History) {
	"use strict";
	/**
	 * Controller for the App View
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.controller.App
	 * @extends 	com.bcdtravel.pnr.controller.BaseController
	 * 
	 * @constructor
	 * @public
	 */
	var oAppController = BaseController.extend("com.bcdtravel.pnr.controller.App", /** @lends com.bcdtravel.pnr.controller.App */ {
		
		/**
		 * Called when the App.view is initiazed
		 */
		onInit: function() {
			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			// attach route matched on Booking
			this._getRouter().getTarget("Booking").attachDisplay($.proxy(this.onRouteMatched, this));
		},
		
		/**
		 * RouteMatched method called when the app is loaded
		 * @param {sap.ui.base.Event} e -
		 */
		onRouteMatched: function(e) {
			// on a mobile device: hide the masterList 
			var mData = e.getParameter("data");
			if ("bookingId" in mData) {
				this.getView().byId("idAppControl").hideMaster();
			}
		}
	});
	return oAppController;
});