/* global _ */
/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
		"com/bcdtravel/pnr/controller/BaseController",
		"com/bcdtravel/pnr/model/BCDGateway",
		"com/bcdtravel/pnr/model/I18n",
		"com/bcdtravel/pnr/controller/ValueHelp"

	], function (BaseController, BCDGateway, I18n, ValueHelp) {
		"use strict";

		/**
		 * Controller for the App View
		 * 
		 * @class 		
		 * @alias 		com.bcdtravel.pnr.controller.ListBooking
		 * @extends 	com.bcdtravel.pnr.controller.BaseController
		 * 
		 * @constructor
		 * @public
		 */

		var oListBookingController = BaseController.extend("com.bcdtravel.pnr.controller.ListBooking", /** @lends com.bcdtravel.pnr.controller.ListBooking.prototype */ {

			/**
			 * Called when the ListBooking View is Initiazed
			 */
			onInit: function () {
				// attach route matched
				this._getRouter().getTarget("ListBooking").attachDisplay($.proxy(this._handleRouteMatched, this));
				$.proxy(this.filter.init, this)();
				this.oScrollId = this.getView().byId("onBookingScroolId");
				this.oScrollId.setHeight("71%");
			},
			// expaned event for panel for scroll width dynamically by Naresh Ponnad on 05/05/2020
			onPressExpandSearchsection: function (evt) {
				var expd = evt.getParameters().expand;
				if (expd) {
					this.oScrollId.setHeight("71%");
				} else {
					this.oScrollId.setHeight("96%");
				}
			},

			/**
			 * Route Matched Callback function
			 * @param {sap.ui.base.Event} e -
			 **/
			_handleRouteMatched: function (e) {
				// select the first item on load TODO
				var mRouteMatchedData = e.getParameter("data"),
					oList = this.getView().byId("BookingList"),
					that = this;
				this.getView().setModel(new sap.ui.model.json.JSONModel({
					// 11-01-18 Henk would be able to filter on ApplicationsId for testing purposes
					filterApplicationId: (this._getURLParameter("testing")) ? true : false
				}), "ListView");
				// Select the first item on PageLoad or model change
				oList.attachEventOnce("updateFinished", function () {
					var oItemToSelect = null,
						aItems = oList.getItems();
					for (var i = 0; i < aItems.length; i++) {
						var oItem = aItems[i],
							oCntx = oItem.getBindingContext("BCDGateway");
						if (!oCntx) {
							continue;
						}
						var sItemBookingId = oCntx.getModel().getProperty(oCntx.getPath() + "/BookingsId");
						// Id set in hash
						if ("bookingId" in mRouteMatchedData) {
							if (sItemBookingId.toString() === mRouteMatchedData.bookingId.toString()) {
								// We only need to highlight the item
								oItemToSelect = oItem;
								break;
							} else {
								continue;
							}
						} else { // Id not set, we need to select the first item and navigate to the booking
							oItemToSelect = oItem;
							that._navToBookingById(sItemBookingId);
							break;
						}
					}
					// Highlight the item
					if (oItemToSelect) {
						oList.setSelectedItem(oItemToSelect);
					}
				});
			},

			/**
			 * Navigates to the Booking view
			 * @param {string} id - The booking id
			 **/
			_navToBookingById: function (id) {
				this._navTo(
					"Booking", {
						bookingId: id
					}
				);
			},

			/**
			 * Event handler for BookingList item press
			 * Navigates to the bookings view
			 * @param {sap.ui.base.Event} e -
			 */
			onItemPress: function (e) {
				var oCntx = e.getParameter("listItem").getBindingContext("BCDGateway"),
					sPath = oCntx.getPath(),
					oModel = oCntx.getModel();
				this._navToBookingById(oModel.getProperty(sPath + "/BookingsId"));
			},

			/**
			 * @namespace com.bcdtravel.pnr.controller.ListBooking.filter
			 */
			filter: /** @lends com.bcdtravel.pnr.controller.ListBooking.filter.prototype */ {
				// filter combi's

				// BookingsId
				// Bookingreference
				// HasError

				// BookingsId
				// Bookingreference

				// BookingsId
				// HasError

				// Bookingreference
				// HasError

				// BookingsId

				// Bookingreference

				// HasError

				init: function () {
					var aApplicationIds = [{
							value: "",
							description: I18n.getText("ListBooking.AllApplicationIds")
						}],
						oApplicationIds = new sap.ui.model.json.JSONModel(aApplicationIds);
					this.getView().setModel(oApplicationIds, "ApplicationIds");
					BCDGateway.read(
						"/AppIdSet", {
							success: function (mData) {
								// mData has multiple results 
								if ("results" in mData && _.size(mData.results)) {
									for (var i in mData.results) {
										if (!("ApplicationsId" in mData.results[i])) {
											continue;
										}
										aApplicationIds.push({
											value: mData.results[i].ApplicationsId,
											description: mData.results[i].ApplicationsId
										});
									}
									// Add Fiori
									aApplicationIds.push({
										value: "FIORI",
										description: "FIORI"
									});
									// set ApplicationIds property and sort by description
									oApplicationIds.setProperty("/", _.sortBy(aApplicationIds, "value"));
									oApplicationIds.refresh(true); // refresh for the expression bindings to recalculate
								}
							}
						}
					);
				},

				_mCurrentFilter: {
					BookingsId: false,
					AgentCode: false,
					ApplicationsId: false,
					HasError: "X",
					IsBillback: false,
					Invoicenumber: false,
					PassengerName: false,
					Ticket: false,
					Account: false,
					BookingCode: false
				},
				/**
				 * Event handler for searching on bookings id
				 * @param {sap.ui.base.Event} e -
				 */
				onSearchBookingsId: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.BookingsId = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},
				/**
				 * Event handler for searching on bookings reference
				 * @param {sap.ui.base.Event} e -
				 */
				onSearchAgentCode: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.AgentCode = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},
				/**
				 * Event handler for searching on applicationsId
				 * @param {sap.ui.base.Event} e -
				 */
				onSearchApplicationsId: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.ApplicationsId = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},
				/**
				 * 
				 */
				onSearchInvoice: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.Invoicenumber = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},

				onSearchBookingCode: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.BookingCode = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},

				onSearchAccount: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.Account = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},

				onSearchPassenger: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.PassengerName = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},

				onSearchTicket: function (e) {
					var mParams = e.getParameters(),
						sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
							null);
					this.filter._mCurrentFilter.Ticket = (sSearch !== null && sSearch !== "") ? sSearch : false;
					$.proxy(this.filter._apply, this)();
				},

				/**
				 * Event handler if the error switch is toggled
				 * @param {sap.ui.base.Event} e -
				 */
				onErrorSwitch: function (e) {
					this.filter._mCurrentFilter.HasError = (e.getParameter("state")) ? "X" : false;
					$.proxy(this.filter._apply, this)();
				},
				/**
				 * Event handler if the Billback switch is toggled
				 * @param {sap.ui.base.Event} e -
				 */
				onBillBackSwitch: function (e) {
					this.filter._mCurrentFilter.IsBillback = (e.getParameter("state")) ? "X" : false;
					//this.filter._mCurrentFilter.HasError	= false;
					//this.getView().byId("errorSwitch").setState(false);
					$.proxy(this.filter._apply, this)();
				},
				/**
				 * Event handler if the application select box has changed
				 * @param {sap.ui.base.Event} e -
				 */
				onChangeApplicationsId: function (e) {
					var oCntx = e.getParameter("selectedItem").getBindingContext("ApplicationIds"),
						sApplicationsId = oCntx.getModel().getProperty(oCntx.getPath() + "/value");
					this.filter._mCurrentFilter.ApplicationsId = sApplicationsId;
					$.proxy(this.filter._apply, this)();
				},

				/**
				 * Executes the filter
				 */
				_apply: function () {
					var aFilter = [];
					// Add BookingsId Filter
					if (this.filter._mCurrentFilter.BookingsId) {
						// Add by naresh ponnada: H0050 - Booking ID Search on Booking Reference
						var oBookingRefrence = 20;
						var oLength = this.filter._mCurrentFilter.BookingsId.length;
						// if (oLength <= oBookingRefrence) {
						aFilter.push(new sap.ui.model.Filter(
							[
								new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.BookingsId),
								new sap.ui.model.Filter("Bookingreference", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.BookingsId)
							],
							true
						));
						// } else {
						// 	aFilter.push(new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.BookingsId));
						// }

						//aFilter.push(new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.BookingsId));
					}
					// Add AgentCodeFilter
					if (this.filter._mCurrentFilter.AgentCode) {
						aFilter.push(new sap.ui.model.Filter("AgentCode", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.AgentCode));
					}
					// Add ApplicationsId filter
					if (this.filter._mCurrentFilter.ApplicationsId) {
						aFilter.push(new sap.ui.model.Filter("ApplicationsId", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.ApplicationsId));
					}
					// Add HasError filter
					if (this.filter._mCurrentFilter.HasError) {
						aFilter.push(new sap.ui.model.Filter("HasError", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.HasError));
					}
					// Add Billback filter
					if (this.filter._mCurrentFilter.IsBillback) {
						aFilter.push(new sap.ui.model.Filter("IsBillback", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.IsBillback));
					}
					// Add PassengerName filter
					if (this.filter._mCurrentFilter.PassengerName) {
						aFilter.push(new sap.ui.model.Filter("PassengerName", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.PassengerName));
					}
					// Add TicketReference filter
					if (this.filter._mCurrentFilter.Ticket) {
						aFilter.push(new sap.ui.model.Filter("Ticket", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.Ticket));
					}
					// Add Account filter
					if (this.filter._mCurrentFilter.Account) {
						aFilter.push(new sap.ui.model.Filter("Account", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.Account));
					}
					// Add BookingCode filter
					if (this.filter._mCurrentFilter.BookingCode) {
						aFilter.push(new sap.ui.model.Filter("BookingCode", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.BookingCode));
					}
					// if filter on Invoicenumber all other filters should not be set
					if (this.filter._mCurrentFilter.Invoicenumber) {
						//aFilter = [
						//	new sap.ui.model.Filter("Invoicenumber", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.Invoicenumber)
						//];						
						aFilter.push(new sap.ui.model.Filter("Invoicenumber", sap.ui.model.FilterOperator.EQ, this.filter._mCurrentFilter.Invoicenumber));
					}
					// apply filter
					this.getView().byId("BookingList").getBinding("items").filter(((aFilter.length) ? aFilter : null), sap.ui.model.FilterType.Application);
				}
			},

			/**
			 * Event handler for list search on PNR or Bookings Id
			 * @param {sap.ui.base.Event} e -
			 **/
			onSearch: function (e) {
				var mParams = e.getParameters(),
					sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
						null),
					oFilter = null;
				if (sSearch !== null && sSearch !== "") {
					oFilter = new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.Contains, sSearch);
				}
				this.getView().byId("BookingList").getBinding("items").filter(oFilter, sap.ui.model.FilterType.Application);
			},

			/**
			 * Event handler for list search on Agent
			 * @param {sap.ui.base.Event} e -
			 **/
			onSearchByAgentCode: function (e) {
				var mParams = e.getParameters(),
					sSearch = (typeof mParams.query !== "undefined") ? mParams.query : (typeof mParams.newValue !== "undefined" ? mParams.newValue :
						null),
					oFilter = null;
				if (sSearch !== null && sSearch !== "") {
					oFilter = new sap.ui.model.Filter("AgentCode", sap.ui.model.FilterOperator.Contains, sSearch);
				}
				this.getView().byId("BookingList").getBinding("items").filter(oFilter, sap.ui.model.FilterType.Application);
			},

			/**
			 * Only show bookings which contains an error
			 * @param {sap.ui.base.Event} e -
			 **/
			onFilterError: function (e) {
				var oFilter = null;
				if (e.getParameter("state")) {
					oFilter = new sap.ui.model.Filter("HasError", "EQ", "X");
				}
				this.getView().byId("BookingList").getBinding("items").filter(oFilter, sap.ui.model.FilterType.Application);
			},

			/**
			 * Format error values
			 * @param {string} sError=01|04
			 *	01 = Missing mandatory data
			 *	04 = No article data found
			 * @returns {string} - translated Error
			 */
			formatError: function (sError) {
				if (["01", "04"].indexOf(sError) === -1) {
					return "";
				}
				return I18n.getText("ListBooking.bookingSetError" + sError);
			},

			createBookingDialog: {
				_Dialog: null,
				open: function () {
					var oYear = new Date().getFullYear() - 1;
					var m = new Date().getUTCMonth();
					var d = new Date().getDate();
					var currDate = new Date();
					// Open the Dialog
					this.createBookingDialog._Dialog = this._openDialogByFragment(
						"com.bcdtravel.pnr.view.listBooking.CreateBookingDialog", // fragment
						{ // Dialog Model data
							BookingCreationdate: null,
							BookingCTminDate: new Date(oYear, m, d),
							BookingCTmaxDate: currDate,
							AgentCode: "",
							Bookingdestination: "",
							ApplicationsId: "", // default,
							BookRefLen: "", //Default Book reflenght for check to Booking refrence for first line item
							BookRefInp: "", //Default Book refinput type for check to Booking refrence for first line item
							ApplicationIds: [
								// Trello 0343 delete FIORI from selection list for create booking
								//{ value: "FIORI", description : "FIORI"}
							],
							ApplicationIdsLoaded: false,
							BookDstState: "false"
						}
					);
					var oDialogModel = this.createBookingDialog._Dialog.getModel("Dialog");
					this.getView().addDependent(this.createBookingDialog._Dialog);
					var that = this;
					// Load ApplicationsIdSet
					BCDGateway.read(
						"/AppIdSet", {
							success: function (mData) {
								oDialogModel.setProperty("/ApplicationIdsLoaded", true);
								// mData has multiple results 
								if ("results" in mData && _.size(mData.results)) {
									var aApplicationIds = oDialogModel.getProperty("/ApplicationIds");
									for (var i in mData.results) {
										if (!("ApplicationsId" in mData.results[i])) {
											continue;
										}
										if (!("BookRefLen" in mData.results[i])) {
											continue;
										}
										if (!("BookRefInp" in mData.results[i])) {
											continue;
										}
										// add by Naresh ponnada: H0052 - Booking Creation Enhancements
										if ((mData.results[i].BookRefLen) || (mData.results[i].BookRefInp)) {
											if (mData.results[i].ApplicationsId === "SabreUK01") {
												that.oBookRefLen = mData.results[i].BookRefLen;
												that.BookRefInp = mData.results[i].BookRefInp;
											}
											aApplicationIds.push({
												value: mData.results[i].ApplicationsId,
												description: mData.results[i].ApplicationsId,
												BookRefLen: mData.results[i].BookRefLen,
												BookRefInp: mData.results[i].BookRefInp
											});
										}

									}
									// set ApplicationIds property and sort by description
									oDialogModel.setProperty("/ApplicationIds", _.sortBy(aApplicationIds, "description"));
								}
							},
							error: function () {
								oDialogModel.setProperty("/ApplicationIdsLoaded", true);
							}
						}
					);
				},
				// added by Naresh Ponnada for Booking creation change: H0052 - Booking Creation Enhancements
				onChangeAppId: function (evt) {
					this.oBookRefLen = "";
					this.BookRefInp = "";
					var src = evt.getSource();
					var selectedItem = src.getSelectedItem();
					var oInputBookRefIp = evt.getSource().getParent().getContent()[5];
					var context = selectedItem.getBindingContext("Dialog");
					// get binding object (reference to an object of the original array)
					var SelctedarrayObject = context.oModel.getProperty(context.sPath);
					this.oBookRefLen = SelctedarrayObject.BookRefLen;
					this.BookRefInp = SelctedarrayObject.BookRefInp;
					var oBookignRefinputVal = oInputBookRefIp.getValue();
					if (oBookignRefinputVal) {
						oInputBookRefIp.setValue("");
						oInputBookRefIp.setValueState("None");
					}
				},
				// onChangeOBookingRefrence: function (evt) {
				// 	var src = evt.getSource();
				// 	var oVal = src.getValue();
				// },
				// add by Naresh ponnada: H0052 - Booking Creation Enhancements
				onChangeBookrefLivechange: function (evt) {
					var oSrc = evt.getSource();
					var val = oSrc.getValue();
					var letters = /^[A-Za-z]+$/;
					var oCharnumcstrng = "";
					if (val.trim()) {
						oSrc.setValue(val.toUpperCase());
						if (this.BookRefInp === "01") {
							oCharnumcstrng = "CHAR";
							if (val.match(letters) === null) {
								oSrc.setValueState("Error");
								oSrc.setValueStateText("Please only enter character values");
								return;
							} else {
								oSrc.setValueState("None");
								oSrc.setValueStateText("");
							}
						} else if (this.BookRefInp === "02") {
							oCharnumcstrng = "NUMC";
							var n = Number(val);
							if (isNaN(n)) {
								oSrc.setValueState("Error");
								oSrc.setValueStateText("Please only enter numeric values");
								return;
							} else {
								oSrc.setValueState("None");
								oSrc.setValueStateText("");
							}
						}
						if (val.length <= Number(this.oBookRefLen)) {
							oSrc.setValueState("None");
							oSrc.setValueStateText("");
						} else {
							oSrc.setValueState("Error");
							oSrc.setValueStateText("Length of Booking Reference must be" + " " + Number(this.oBookRefLen));
						}

					} else {
						oSrc.setValue("");
						oSrc.setValueState("None");
						oSrc.setValueStateText("");
					}

				},
				// add by Naresh ponnada: H0052 - Booking Creation Enhancements
				onChangeBookingDest: function (evt) {
					var src = evt.getSource();
					var state = src.getValueState();
					if (state === "Error") {
						src.setValueState("None");
						src.setValueStateText("");
					}
				},
				// add by Naresh ponnada: H0052 - Booking Creation Enhancements
				onChangeBookcreation: function (evt) {
					var oVal;
					this.oMaxdateCheck = false;
					this.oMindateCheck = false;
					var checkval = evt.getParameter("value");
					var osrc = evt.getSource();
					var maxdt = osrc.getMaxDate();
					var mindt = osrc.getMinDate();
					if (osrc._sUsedDisplayPattern === "dd.MM.yyyy") {
						var s = osrc.getValue().split(".");
						var df = s[1] + "/" + s[0] + "/" + s[2];
						oVal = new Date(df);
					} else {
						oVal = new Date(osrc.getValue());
					}
					var state = osrc.getValueState();
					if (checkval) {
						if (oVal > maxdt) {
							osrc.setValueState("Error");
							osrc.setValueStateText("Booking creation date can not be in the future");
						} else if (oVal < mindt) {
							osrc.setValueState("Error");
							osrc.setValueStateText("Booking creation date can not be older than one year");
						} else {
							osrc.setValueState("None");
							osrc.setValueStateText("");
						}
					} else {
						osrc.setValueState("None");
						osrc.setValueStateText("");
					}
				},
				/**
				 * Value Help for Bookingdestination 
				 * opens the cities value help dialog
				 * @param {object} e - event data
				 */
				onOpenBookingdestination: function (e) {
					ValueHelp.open("Airports", {
						source: e.getSource()
					});
				},
				/**
				 * Event handler when the dialogs close button is pressed
				 * 
				 * Closes the dialog
				 */
				onClose: function () {
					this.createBookingDialog._Dialog.close();
				},
				/**
				 * Event handler when the dialogs create booking button is pressed
				 * 
				 * Creates the booking and closes the dialog
				 */
				onCreateBooking: function (evt) {
					this.oValustate = false;
					var oDialogModel = this.createBookingDialog._Dialog.getModel("Dialog");
					var mDialog = this.createBookingDialog._Dialog.getModel("Dialog").getProperty("/"),
						mBooking = BCDGateway.getNewEntityData("booking");
					mBooking.BookingCreationdate = mDialog.BookingCreationdate;
					mBooking.AgentCode = mDialog.AgentCode;
					mBooking.Bookingdestination = mDialog.Bookingdestination;
					mBooking.ApplicationsId = mDialog.ApplicationsId;
					mBooking.Bookingreference = mDialog.Bookingreference;
					//	this.createBookingDialog._Dialog.close();
					// show a busy dialog
					// add by Naresh ponnada: H0052 - Booking Creation Enhancements(Mandatory check for create booking)
					if (!mDialog.Bookingdestination) {
						this.oValustate = true;
						this.createBookingDialog._Dialog.getContent()[7].setValueState("Error");
						this.createBookingDialog._Dialog.getContent()[7].setValueStateText("Enter a valid Value");
					}
					if (!mDialog.BookingCreationdate) {
						this.oValustate = true;
						this.createBookingDialog._Dialog.getContent()[1].setValueState("Error");
						this.createBookingDialog._Dialog.getContent()[1].setValueStateText("Enter a valid Value");
					}
					if (mDialog.Bookingreference) {
						var boofreflen = mDialog.Bookingreference.length;
						var exitboofref = Number(this.oBookRefLen);
					}
					if ((!mDialog.Bookingreference) || (boofreflen < exitboofref) || (boofreflen > exitboofref)) {
						this.oValustate = true;
						oDialogModel.setProperty("/showReferenceError", "Error");
						// oDialogModel.setProperty("/showReferenceError", "Error");
						this.createBookingDialog._Dialog.getContent()[5].setValueStateText("Length of Booking Reference must be" + " " + Number(this.oBookRefLen));
					}
					if (this.oValustate) {
						this.oValustate = false;
						return;
					}
					var oBusyDialog = new sap.m.BusyDialog({
							title: I18n.getText("ListBooking.CreatingNewBookingTitle"),
							text: I18n.getText("ListBooking.CreatingNewBookingText"),
							showCancelButton: false,
							showReferenceError: false
						}),
						that = this;

					oBusyDialog.open();
					// fire create
					BCDGateway.create(
						"/bookingSet",
						mBooking, {
							success: function (m) {
								// close loading dialog
								oBusyDialog.close();
								var oCreateBookingDialog = that.createBookingDialog._Dialog;
								if (m.BookingsId === "ERROR") {
									// If the service returns BookingsId 
									var oDialogModel = oCreateBookingDialog.getModel("Dialog");
									oDialogModel.setProperty("/showReferenceError", true);
								} else {
									// close booking dialog
									oCreateBookingDialog.close();
									// success > navigate to the new booking
									that._showMessage(I18n.getText("ListBooking.CreateNewBookingSuccess"));
									// navigate to the new booking
									that._navToBookingById(m.BookingsId);
								}
							},
							error: function (e) {
								// close dialogs
								that.createBookingDialog._Dialog.close();
								oBusyDialog.close();
								// show error
								that._showErrorByOdataResponse(e);
							}
						}
					);
				}
			}

			/**
			 * Event handler for when the Create booking button is pressed
			 *
			 * Creates a new booking direct and navigates to the bookings view if successfull
			 */
			// onCreateBooking: function(){
			// 	// show a busy dialog
			// 	var oBusyDialog = new sap.m.BusyDialog({
			// 			title				: I18n.getText("ListBooking.CreatingNewBookingTitle"),
			// 			text				: I18n.getText("ListBooking.CreatingNewBookingText"),
			// 			showCancelButton	: false
			// 		}),
			// 		that		= this;
			// 	oBusyDialog.open();
			// 	// fire create
			// 	BCDGateway.create(
			// 		"/bookingSet",
			// 		BCDGateway.getNewEntityData("booking"),
			// 		{
			// 			success: function(m) {
			// 				// close dialog
			// 				oBusyDialog.close();
			// 				// 
			// 				that._showMessage(I18n.getText("ListBooking.CreateNewBookingSuccess"));
			// 				// navigate to the new booking
			// 				that._navToBookingById(m.BookingsId);
			// 			},
			// 			error: function(e) {
			// 				// close dialog
			// 				oBusyDialog.close();
			// 				// show error
			// 				that._showErrorByOdataResponse(e);
			// 			}
			// 		}
			// 	);
			// }
		});
		return oListBookingController;
	},
	/* bExport= */
	true);