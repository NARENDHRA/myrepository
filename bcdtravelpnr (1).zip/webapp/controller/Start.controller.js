sap.ui.define([
	"com/bcdtravel/pnr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History"
], function(BaseController, JSONModel, History) {
	"use strict";
	return BaseController.extend("com.bcdtravel.pnr.controller.Start", {
		
	});
});