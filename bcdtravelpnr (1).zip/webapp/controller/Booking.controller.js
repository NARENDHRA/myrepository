/* global _ */
/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
		"com/bcdtravel/pnr/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"com/bcdtravel/pnr/model/BCDGateway",
		"com/bcdtravel/pnr/model/User",
		"com/bcdtravel/pnr/model/I18n",
		"com/bcdtravel/pnr/model/Mapping",
		"com/bcdtravel/pnr/model/Article",
		"com/bcdtravel/pnr/controller/ValueHelp",
		"../utils/FragmentDialog",
		"./ArticleCopy",
		"./Invoice",
		"com/bcdtravel/pnr/model/formatter",
		"../customType/Email" // loads the customData Email types needed in te EmailInvoice.fragment.xml
	], function (BaseController, JSONModel, BCDGateway, User, I18n, MappingModel, ArticleModel, ValueHelp, FragmentDialog, ArticleCopy,
		Invoice, formatter) {

		"use strict";
		/**
		 * Controller for the Booking View
		 * 
		 * @class 		
		 * @alias 		com.bcdtravel.pnr.controller.Booking
		 * @extends 	com.bcdtravel.pnr.controller.BaseController
		 * @requires 	underscore.js
		 * 
		 * @constructor
		 * @public
		 */
		var oBookingController = BaseController.extend("com.bcdtravel.pnr.controller.Booking", /** @lends com.bcdtravel.pnr.controller.Booking */ {

			/**
			 * Holds the current booking id set in models.loadByBookingId method
			 * @private
			 */
			_bookingId: null,

			/**
			 * Navigates to the Articles view
			 * using the booking id and article id
			 * @param {string} sArticleId - The article ID
			 */
			_navToArticleById: function (sArticleId, sApplicationId, sArticleCategory, sTabnameBs) {
				// values are passing  oApplicationId, oArticleCategory, oTabnameBs for to fetach ifarepcc data 
				this._navTo(
					"Article", {
						bookingId: this._bookingId,
						articleId: sArticleId,
						ApplicationId: sApplicationId,
						ArticleCategory: sArticleCategory,
						TabnameBs: sTabnameBs
					}
				);
			},

			/**
			 * Page loading indicator
			 * @param {boolean} b true shows the loading indicator.. false will hide it
			 */
			_showPageBusyIndicator: function (b) {
				this.getView().byId("BookingPage").setBusy(b);
			},

			/**
			 * onInit is called on view initialisation
			 */
			formatter: formatter,
			onInit: function () {
				// init Table Filter
				$.proxy(this.tableFilters.init, this)();
				// init models
				$.proxy(this.models.init, this)();

				// attach route matched
				this._getRouter().getTarget("Booking").attachDisplay($.proxy(this.onRouteMatched, this));
				// // mobile button for opening the list
				var oView = this.getView();
				oView.addEventDelegate({
					onBeforeShow: function () {
						if (sap.ui.Device.system.phone) {
							var oPage = oView.byId("BookingPage");
							if (oPage.getShowNavButton && !oPage.getShowNavButton()) {
								oPage.setShowNavButton(true);
							}
						}
					}
				});
			},

			/**
			 * this method is called when the route matches Booking target (check manifest)
			 * @param {object} e - event data
			 */
			onRouteMatched: function (e) {
				var oNotesListModel = new sap.ui.model.json.JSONModel();
				var aFilter = [];
				var mData = e.getParameter("data");
				if ("bookingId" in mData) {
					// open the first tab only if the bookingId or articleId has changed
					if (this._bookingsId !== null && this._bookingId !== mData.bookingId) {
						$.proxy(this.iconTabBar.openFirstTab, this)();
					}
					// Load model data
					$.proxy(this.models.loadByBookingId, this)(mData.bookingId);
					this.errorSummary._preventNavigate = false;
					aFilter.push(new sap.ui.model.Filter("Appid", sap.ui.model.FilterOperator.EQ, "ZHY_APP_PNR"));
					this.oBookigniD = mData.bookingId;
					// var c = s.split("-")[0] + "-" + s.split("-")[1] + "-" + s.split("-")[2];
					var that = this;
					BCDGateway.read("/NotesSet", {
						filters: aFilter,
						success: function (odata) {
							var ofilter = [];
							var res = odata.results;
							for (var i = 0; i < res.length; i++) {
								var oredid = res[i].Reqid.split("_")[0];
								if (oredid === that.oBookigniD) {
									delete(res[i].__metadata);
									ofilter.push(res[i]);
								}
							}
							oNotesListModel.setData(ofilter);
							that.getView().setModel(oNotesListModel, "NotesListModel");
						},
						error: function (error) {}
					});
				}
			},
			onUpdateCommestLists: function (evt) {
				var tot = evt.getParameter("total");
				var s = "Notes" + "(" + tot + ")";
				evt.getSource().getParent().setText(s);
			},
			/**
			 * Cancel the booking alterations and resets all page data
			 */
			onCancel: function () {
				this._allowRouterNavigation(I18n.getText("Booking.Title"));
				$.proxy(this.models.reload, this)();
			},

			/**
			 * This event is called when a CreditCard value changes
			 * If it has an error in the errorSet, the value state is changed to None to indicate that the error will be resolved on save 
			 * @param {sap.ui.base.Event} e - 
			 */
			onChangeCheckError: function (e) {
				var oSrc = e.getSource(),
					sPath = oSrc.getBindingPath("value"),
					oArticleErrors = this.getView().getModel("BookingView"),
					sVal;
				switch (oSrc.getMetadata().getName()) {
				case "sap.m.Input":
				case "sap.m.DatePicker":
					sVal = oSrc.getValue();
					break;
				case "sap.m.Select":
					sVal = oSrc.getSelectedKey();
					sPath = oSrc.getBindingPath("selectedKey");
					break;
				}
				// only change the value state if there was an error indication from the backend
				// (it could be a new article)
				if (oArticleErrors.getProperty("/CreditCardErrorFields" + sPath)) {
					oSrc.setValueState(((sVal) ? "None" : "Error"));
				}
			},

			invoice: Invoice,

			/**
			 * Event handler only for devices: navigate to the master list page
			 */
			onNavToListBooking: function () {
				this._navTo("ListBooking");
			},

			/**
			 * Save the booking data
			 */
			onSaveBooking: function () {
				var mBooking = this.getView().getModel("Booking").getProperty("/"),
					that = this;
				// show page loader
				that._showPageBusyIndicator(true);
				// allow navigation
				this._allowRouterNavigation(I18n.getText("Booking.Title"));
				/**
				 * On updating an article, the ErrorCode should be an whitespace
				 * The update function Martin created in the backend, then knows that all field-checks
				 * needs to be recalculated and the "error" table (errorSet) will be updated.
				 **/
				mBooking.ErrorCode = " ";
				// execute update
				BCDGateway.update(
					"/bookingSet('" + mBooking.BookingsId + "')",
					mBooking, {
						success: function () {
							// hide loader
							that._showPageBusyIndicator(false);
							// show success message
							that._showMessage(I18n.getText("SavedSuccefully"));
							// reload models
							$.proxy(that.models.reload, that)();
						},
						error: function (e) {
							// show error
							that._showErrorByOdataResponse(e);
						}
					}
				);
			},

			/**
			 * Save the credit card info
			 * note: the credit card tab is hidden atm (dec 17)
			 */
			onSaveCreditCard: function () {
				// first load the article data to make sure no previous updated fields are updated
				// than set the new credit card settings
				this._showPageBusyIndicator(true);
				var oView = this.getView(),
					mCreditCard = oView.getModel("CreditCard").getProperty("/"),
					that = this;
				var oArticle = new ArticleModel(
					this._bookingId,
					mCreditCard.ArticlesId, {
						success: function () {
							for (var sCol in mCreditCard) {
								if (mCreditCard.hasOwnProperty(sCol)) {
									oArticle.setProperty("/" + sCol, mCreditCard[sCol]);
								}
							}
							oArticle.saveData({
								success: function () {
									// hide loader 
									that._showPageBusyIndicator(false);
									// show success message
									that._showMessage(I18n.getText("SavedSuccefully"));
									// reload data
									$.proxy(that.models.reload, that)();
								},
								error: function (e) {
									that._showErrorByOdataResponse(e);
								}
							});
						},
						error: function (e) {
							// hide loader &nd show errro
							that._showPageBusyIndicator(false);
							that._showErrorByOdataResponse(e);
						}
					}
				);
			},

			/**
			 * Event handler when a article is clicked
			 * Navigates to tha Article Page
			 * @param {object} e - event data
			 */
			onSelectArticle: function (e) {
				var oTabnameBs = "";
				var oselkey = e.getSource().getParent().getParent().getParent().getProperty("selectedKey");
				if (this.errorSummary._preventNavigate) {
					return;
				}
				var oCntx = e.getSource().getBindingContext("Articles"),
					m = oCntx.getModel().getProperty(oCntx.getPath());
				// Added by Naresh Ponnada: H0048 - IFARE Dropdown
				var oApplicationId = this.getView().getModel("BookingView").getData()["header"].ApplicationsId;
				var oArticleCategory = m.ArticleCategory;
				this.oApplicationId = oApplicationId;
				if (oselkey === "Air") {
					oTabnameBs = "ZHY_ARTICLES";
				} else {
					oTabnameBs = "";
				}
				this._navToArticleById(m.ArticlesId, oApplicationId, oArticleCategory, oTabnameBs);
			},

			copy: {
				openScenarioSelectDialog: function (e) {
					var oCtx = e.getSource().getBindingContext("Articles"),
						mArticle = oCtx.getModel().getProperty(oCtx.getPath()),
						that = this;
					ArticleCopy.openScenarioSelectDialog(
						mArticle, {
							done: function () {
								$.proxy(that.models.reload, that)();
							},
							mappingModel: new MappingModel(that.getView().getModel("Booking").getProperty("/ApplicationsId"), mArticle.ArticleCategory)
						}
					);
				},
				formatButton: function (ArticlesId, CitId, CopiedArticleLine, CopiedFromArticlesId, CopiedWithScenario, CopyCreatedFromArticle) {
					var s = "";
					// Formatting article number prefix '0'
					for (var i = 0; i < (3 - ArticlesId.toString().length); i++) {
						s += "0";
					}
					s += ArticlesId + " ";

					// CitID not filled AND not filled (copycreated or copiedarticle or copiedwithscenario); in short all empty is return s.
					if (!CitId && !(CopyCreatedFromArticle || CopiedArticleLine || CopiedWithScenario)) {
						return s;
					}

					// // gekopieerd of gekopieerde lijn
					// s += (CopyCreatedFromArticle || CopiedArticleLine) ? "C" : "A";

					if (!(CopiedWithScenario === "00") && !(CopyCreatedFromArticle || CopiedArticleLine)) {
						s += "U";
					} else if (CopyCreatedFromArticle || CopiedArticleLine) {
						s += "C";
					}

					if (!(CopiedWithScenario === "00")) {
						s += " S" + CopiedWithScenario + " ";
						if (!(CopiedFromArticlesId === 0)) {
							for (var i2 = 0; i2 < (3 - CopiedFromArticlesId.toString().length); i2++) {
								s += "0";
							}
							s += CopiedFromArticlesId;
						}
					}

					return s;
				}
			},

			blockBooking: {
				_Dialog: null,
				openConfirmDialog: function () {
					// open dialog
					this.blockBooking._Dialog = this._openDialogByFragment("com.bcdtravel.pnr.view.booking.BlockBooking");
				},
				onClose: function () {
					this.blockBooking._Dialog.close();
				},
				onConfirm: function () {
					var mBooking = this.getView().getModel("Booking").getProperty("/");
					var oDialog = this.blockBooking._Dialog,
						that = this;
					var mText = ((oDialog.getDialogData("/text").text !== undefined) ? oDialog.getDialogData("/text").text : "");
					oDialog.setBusy(true);
					BCDGateway.callFunction(
						"/blockBooking", {
							urlParameters: {
								BookingsId: this._bookingId,
								Block: mBooking.Blocked ? "" : "X",
								text: mText
									//text: oDialog.getDialogData().text
							},
							method: "GET",
							success: function (m) {
								// If any error occurs, throw an error dialog
								var aErrors = [],
									bSuccefullyCreated = false; // Block is success with return type 'S'
								if (_.size(m) && _.size(m.results)) {
									for (var i in m.results) {
										if (m.results[i].Type !== "S") {
											aErrors.push(m.results[i].Message);
										} else {
											bSuccefullyCreated = true;
										}
									}
								}
								if (aErrors.length > 0) {
									that._showMessage(I18n.getText(
										"Booking.BlockBooking.Error",
										"\n- " + aErrors.join("\n- ")
									));
								} else if (bSuccefullyCreated) {
									that._showMessage(I18n.getText("Booking.BlockBooking.Success"));
								} else {
									that._showError(I18n.getText("Booking.BlockBooking.Error.CouldNotCreate"));
								}
								// close dialog and reload models
								oDialog.close();
								$.proxy(that.models.reload, that)();
							},
							error: function (e) {
								oDialog.close();
								$.proxy(that._showError, that)(e);
							}
						}
					);
				}
			},

			citCreate: {
				_Dialog: null,
				openConfirmDialog: function () {
					// open dialog
					this.citCreate._Dialog = this._openDialogByFragment("com.bcdtravel.pnr.view.booking.CitCreateConfirm");
				},
				onClose: function () {
					this.citCreate._Dialog.close();
				},
				onConfirm: function () {
					var oDialog = this.citCreate._Dialog,
						that = this;
					oDialog.setBusy(true);
					BCDGateway.callFunction(
						"/createCIT", {
							urlParameters: {
								BookingsId: this._bookingId
							},
							method: "GET",
							success: function (m) {
								// If any error occurs, throw an error dialog
								var aErrors = [],
									bSuccefullyCreated = false; // A cit is only succesfully created if a result is returning with number === 003
								if (_.size(m) && "results" in m && _.size(m.results)) {
									for (var i in m.results) {
										if (m.results[i].Type !== "S") {
											aErrors.push(m.results[i].Message);
										}
										if (m.results[i].Number === "003") {
											bSuccefullyCreated = true;
										}
									}
								}
								if (aErrors.length > 0) {
									that._showMessage(I18n.getText(
										"Booking.citCreateDialog.Error",
										"\n- " + aErrors.join("\n- ")
									));
								} else if (bSuccefullyCreated) {
									that._showMessage(I18n.getText("Booking.citCreateDialog.Success"));
								} else {
									that._showError(I18n.getText("Booking.citCreateDialog.Error.CouldNotCreate"));
								}
								// close dialog and reload models
								oDialog.close();
								$.proxy(that.models.reload, that)();
							},
							error: function (e) {
								oDialog.close();
								$.proxy(that._showError, that)(e);
							}
						}
					);
				}
			},

			/**
			 * Methods for the error summary popup
			 * @namespace com.bcdtravel.pnr.controller.Booking.errorSummary
			 */
			errorSummary: /** @lends com.bcdtravel.pnr.controller.Booking.iconTabBar.errorSummary */ {
				_Dialog: null,
				// needed to prevent the page onSelectArticle from navigation when clicking on the errorSummary.openDialog button (bug in ui5 version < 1.50 )
				_preventNavigate: false,
				/**
				 *  Creates and opens the Dialog
				 */
				openDialog: function (e) {
					var oSelKey = e.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getSelectedKey();
					var sArticleId = e.getSource().data("articleId"),
						aErrors = _.where(this.models._mErrors, {
							ArticlesId: sArticleId
						}),
						mErrors = {};
					if (aErrors.length === 0) {
						return;
					}
					// needed to prevent the page onSelectArticle from navigation when clicking on the errorSummary.openDialog button (bug in ui5 version < 1.50 )
					e.preventDefault();
					e.cancelBubble();
					this.errorSummary._preventNavigate = true;
					//
					var fnGetErorrMsg = function (sCode) {
						if (["05", "06", "07"].indexOf(sCode) === -1) {
							return;
						}
						var sMessage = false;
						switch (sCode) {
						case "05":
							sMessage = "05 Missing segment data";
							break;
						case "06":
							sMessage = "06 Missing reference data";
							break;
						case "07":
							sMessage = "07 Wrong reference data";
							break;
						}
						return sMessage;
					};
					for (var i in aErrors) {
						var mCurr = aErrors[i];
						if (!(mCurr.Tabname in mErrors)) {
							mErrors[mCurr.Tabname] = {
								Title: I18n.getText("Booking.errorSummary." + mCurr.Tabname),
								errors: {},
								message: fnGetErorrMsg(mCurr.ErrorCode)
							};
						}
						var sErrorField = mCurr.ErrorField;
						if (["ZHY_ARTICLES", "ZHY_SEGMENTS"].indexOf(mCurr.Tabname) !== -1) {
							sErrorField = BCDGateway.translateFieldSapToOdata(((mCurr.Tabname === "ZHY_ARTICLES") ? "articles" : "segment"), sErrorField);
							var sI18n = ((mCurr.Tabname === "ZHY_ARTICLES") ? "article." : "segment.") + sErrorField;
							// add by naresh for Label change in car type : H0051 - Cartype error shows as Roomtype on error info
							if ((oSelKey === "Car") && (mCurr.ErrorField === "CARHOTELROOMTYPE")) {
								sI18n = "article.Carhotelroomtype.CAR";
							}
							var sTranslatedErrorField = I18n.getText(sI18n);
							if (sI18n !== sTranslatedErrorField) {
								sErrorField = sTranslatedErrorField;
							}
						}
						mErrors[mCurr.Tabname].errors[sErrorField] = {
							Field: sErrorField,
							ErrorCode: mCurr.ErrorCode
						};
					}
					this.errorSummary._Dialog = this._openDialogByFragment("com.bcdtravel.pnr.view.booking.ErrorInfo", {
						Errors: mErrors
					});
				},
				onClose: function () {
					this.errorSummary._preventNavigate = false;
					this.errorSummary._Dialog.close();
				}
			},

			/**
			 * Methods for the icontabbar
			 * @namespace com.bcdtravel.pnr.controller.Booking.iconTabBar
			 */
			iconTabBar: /** @lends com.bcdtravel.pnr.controller.Booking.iconTabBar.prototype */ {

				/**
				 * Initialize the iconTabBar (on Page load)
				 */
				init: function () {
					$.proxy(this.iconTabBar.openFirstTab, this)();
					// fix
					//var oIconTabBar = this.getView().byId("BookingIconTabBar");

					// oIconTabBar.onAfterRendering = function() {
					// 	var	aItems		= oIconTabBar.getItems();
					// 	for (var i in aItems) {
					// 		if (aItems[i] instanceof sap.m.IconTabFilter === false) { continue; }
					// 		(function () { // private scope else the oIconTabFilter in the addEventListener will be overwritten each loop
					// 			var oIconTabFilter	= aItems[i],
					// 				oDomRef 		= oIconTabFilter.getDomRef();
					// 			console.log(oDomRef);
					// 			if(oDomRef !== null) { 
					// 				oDomRef.addEventListener("pointerdown", function() {
					// 					console.log("ast");
					// 					oIconTabBar.setSelectedItem(oIconTabFilter);
					// 				});
					// 			}
					// 		}());
					// 	}
					// }
				},

				/**
				 * Get the current open tab key
				 * @returns {string} - the selected key
				 */
				getOpenTab: function () {
					return this.getView().byId("BookingIconTabBar").getSelectedKey();
				},

				/**
				 * this event is triggered when the open iconTab changes
				 * @param {object} e - IconTabBar select event data
				 */
				onSelect: function (e) {
					var sOpen = e.getParameter("selectedKey");
					$.proxy(this.iconTabBar.tabChanged, this)(sOpen);
				},

				/**
				 * Open the first tab (used in onRouteMatched method)
				 */
				openFirstTab: function () {
					$.proxy(this.iconTabBar.openTab, this)("Air");
				},

				/**
				 * Open the tab according to the sTab
				 * @param {string} sTab - Tab to open
				 */
				openTab: function (sTab) {
					this.getView().byId("BookingIconTabBar").setSelectedKey(sTab);
					$.proxy(this.iconTabBar.tabChanged, this)(sTab);
				},

				/**
				 * Callback method for onSelect & openFirstTab 
				 * @param {string} sKey - key of the current open tab
				 */
				tabChanged: function (sKey) {
					this.getView().getModel("BookingView").setProperty("/currentOpenTab", sKey);
				}
			},

			/**
			 * Models
			 * note: all methods should be called by $.proxy(this.models.methodName, this)();
			 * @namespace com.bcdtravel.pnr.controller.Booking.models
			 */
			models: /** @lends com.bcdtravel.pnr.controller.Booking.models.prototype */ {
				_mErrors: [], // holds the errors 
				/**
				 * init only called on view load
				 * @private
				 */
				init: function () {
					$.proxy(this.models.setViewModels, this)();
				},
				/** 
				 * (re)-set the view models 
				 */
				setViewModels: function () {
					this.models._mErrors = [];
					var oView = this.getView();
					// CreditCard
					oView.setModel(new JSONModel({ // All from Article
						ArticlesId: "", // needed on saving credit card info 
						Creditcardauthorisationmerchan: "",
						Creditcardexpirymerchant: "",
						Creditcardnumbermerchant: "",
						Creditcardtypemerchant: ""
					}), "CreditCard");
					// BookingsView
					var oBookingViewModel = new JSONModel({
						header: {
							BookingsId: "", // Bookings.BookingsId	
							Bookingdestination: "", // Bookings.Bookingdestination
							ApplicationsId: "", // Bookings.ApplicationsId
							Bookingreference: "", // Bookings.Bookingreference
							BookingCreationdate: "", // Bookings.BookingCreationdate
							Blockremark: "",
							Blocked: ""
						},
						Account: "", // Article.Account
						Source: "", // Booking.ApplicationsId
						// All counters are set in models.setIconTabFilterCount method
						// Counts the total of type articles
						RailCount: "",
						AirCount: "",
						HotelCount: "",
						CarCount: "",
						MiscCount: "",
						// All counters are set in models.setIconTabFilterCount method
						// Counts the total error of type articles
						RailErrorCount: "",
						AirErrorCount: "",
						HotelErrorCount: "",
						CarErrorCount: "",
						MiscErrorCount: "",
						// Colors are set in models.setIconTabFilterAttributesByCounters
						RailIconColor: "Default", // Negative, Positive or Default
						AirIconColor: "Default",
						HotelIconColor: "Default",
						CarIconColor: "Default",
						MiscIconColor: "Default",
						CreditCardIconColor: "Default",
						CreditCardMapping: [],
						CreditCardErrorFields: {
							Creditcardauthorisationmerchan: false,
							Creditcardexpirymerchant: false,
							Creditcardnumbermerchant: false,
							Creditcardtypemerchant: false
						},
						showSaveButtonsCreditCard: false,
						showSaveButtonsBooking: false,
						currentOpenTab: $.proxy(this.iconTabBar.getOpenTab, this)(),
						CITcreationButtonEnabled: false,
						blockButtonEnabled: true,
						unBlockButtonEnabled: true,
						showBlockButton: true,
						showUnBlockButton: true,
						blockActionTxt: "Block",
						InvoiceCount: 0,
						showBlockedMessage: false
					});
					oView.setModel(oBookingViewModel, "BookingView");
					// Booking model
					oView.setModel(new JSONModel({}), "Booking");
					// Booking errors
					oView.setModel(new JSONModel({
						Bookingdestination: false
					}), "BookingErrors");
					// Articles
					oView.setModel(new JSONModel({}), "Articles");
					// set Invoice Count
					$.proxy(this.invoice.onTableUpdateFinished, this)(function (e) {
						oBookingViewModel.setProperty("/InvoiceCount", e.getParameter("total"));
					});
				},
				/**
				 * sets the IconTabFilter Counters and Color
				 * @param {string} sType=Rail|Air|Hotel|Car|Misc
				 * @param {number} iItemCount						- items count
				 * @param {number} iErrorCount						- error count
				 */
				setIconTabFilterAttributesByCounters: function (sType, iItemCount, iErrorCount, iWarningCount) {
					var oBookingViewModel = this.getView().getModel("BookingView"),
						mData = oBookingViewModel.getProperty("/");
					// Icon Count
					if (sType + "Count" in mData) {
						oBookingViewModel.setProperty("/" + sType + "Count", (iItemCount ? iItemCount : ""));
					}
					// Icon Error Count
					if (sType + "ErrorCount" in mData) {
						var iErrorWarningCount = iErrorCount + iWarningCount;
						oBookingViewModel.setProperty("/" + sType + "ErrorCount", (iErrorWarningCount ? iErrorWarningCount : ""));
					}
					// Color: if the items count is 0 the color needs to be set to Neutral
					// if the error count > 0 set the color to Negative
					if (sType + "IconColor" in mData) {
						if (iItemCount === 0) {
							oBookingViewModel.setProperty("/" + sType + "IconColor", "Neutral");
						} else if (iErrorCount > 0) {
							oBookingViewModel.setProperty("/" + sType + "IconColor", "Negative");
						} else if (iWarningCount > 0) {
							oBookingViewModel.setProperty("/" + sType + "IconColor", "Critical");
						}
					}
				},

				/**
				 * reload all data
				 */
				reload: function () {
					$.proxy(this.models.loadByBookingId, this)(this._bookingId);
				},

				/**
				 * Load the data for the needed view models
				 * @param {string} bookingId - The bookingId
				 */
				loadByBookingId: function (bookingId) {
					// do nothing when booking already is loaded
					/*if (this._bookingId == bookingId) {
						console.log("allready loaded");
						return;
					}*/
					// temp save the booking id
					this._bookingId = bookingId;
					var that = this;
					// allow navigation (for all)
					$.proxy(that._allowRouterNavigation, that)();
					// clear all current view data
					$.proxy(this.models.setViewModels, this)();
					// show Page loading indicator
					$.proxy(this._showPageBusyIndicator, this)(true);
					// Deferred objects (results are processed below ajax calls)
					var oDefArticles = $.Deferred(),
						oDefBooking = $.Deferred(),
						oDefErrors = $.Deferred(),
						oView = this.getView();
					oDefArticles.promise();
					oDefBooking.promise();
					oDefErrors.promise();
					// Fetch Booking data from service
					BCDGateway.read(
						"/bookingSet('" + bookingId + "')", {
							success: function (mData) {
								oDefBooking.resolve(mData);
							},
							error: function (e) {
								oDefBooking.resolve(null);
								that._showErrorByOdataResponse(e);
							}
						}
					);
					// Fetch Articles data from service
					BCDGateway.read(
						"/bookingSet('" + bookingId + "')/articlesSet", {
							// filters: [ // filter by BookingsId
							// 	new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId)
							// ],
							success: function (mData) {
								var mProcessedData = mData;
								if ("results" in mProcessedData) {
									mProcessedData = mProcessedData.results;
								}
								oDefArticles.resolve(mProcessedData);
							},
							error: function () {
								oDefArticles.resolve(null);
								that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);
					// Fetch All Field Errors from service
					BCDGateway.readFieldErrors({
						bookingId: bookingId, // filter on bookingId
						success: function (mData, mOrdered) {
							oDefErrors.resolve(mData);
						},
						error: function () {
							// dont throw an error for errorSet
							oDefErrors.resolve(null);
						}
					});
					// When all data has loaded
					$.when(oDefBooking, oDefArticles, oDefErrors).done(function (mBooking, mArticles, mErrors) {
						// remove page loader
						that._showPageBusyIndicator(false);
						// set Booking Data
						$.proxy(that.models.processBookingData, that)(mBooking, mErrors);
						// set Articles data
						$.proxy(that.models.processArticlesData, that)(mArticles, mBooking, mErrors);
						// errors
						$.proxy(that.models.processErrorData, that)(mErrors, mBooking);
						// apply InvoicesTable filter
						oView.byId("InvoicesTable").getBinding("items").filter(
							[new sap.ui.model.Filter("BookingsId", "EQ", bookingId)]
						);
					});
				},
				/**
				 * Fills the model data of the following models:
				 * - Articles (adds an extra column ErrorCount)
				 * - BookingsView
				 * - CreditCard
				 * @param {map} mArticles 	- Article data fetched from oData service,
				 * @param {map}	mBooking	- Booking data fetched from oData service
				 * @param {map}	mErrors		- Booking data fetched from oData service
				 */
				processArticlesData: function (mArticles, mBooking, mErrors) {
					if (!mArticles || _.size(mArticles) === 0) {
						return;
					} // no data to display
					var oView = this.getView(),
						oArticlesModel = oView.getModel("Articles"),
						oBookingViewModel = oView.getModel("BookingView"),
						oCreditCardModel = oView.getModel("CreditCard"),
						mArticleForPageHeader = null,
						mArticleForCreditCard = null,
						bHasArticleWithBillbackFlagSet = false,
						that = this;

					var oMapping = new MappingModel(mBooking.ApplicationsId),
						oDeffered = $.Deferred();
					oMapping.loadMappingForEntity(
						"articles", {
							filters: [
								new sap.ui.model.Filter("FieldnameBs", sap.ui.model.FilterOperator.EQ, "TRANSACTIONTYPE")
							],
							success: function (mMapping) {
								oDeffered.resolve(mMapping);
							},
							error: function () {
								oDeffered.resolve({});
							}
						}
					);

					$.when(oDeffered).then(function (mMapping) {

						var fnGetTransactionTypeFromMapping = function (mArt) {

							for (var i in mMapping) {
								if (mMapping[i].ArticleCategory === mArt.ArticleCategory && mMapping[i].ValueBs === mArt.Transactiontype && mMapping[i].FieldnameBs ===
									"TRANSACTIONTYPE") {
									return (mMapping[i].ValueBcd) ? mMapping[i].ValueBcd : mMapping[i].ValueBs;
								}
							}
							return mArt.Transactiontype;
						};

						// Loop the articles and:
						// - add the ErrorCount
						// - Filter the articles so we can create BookingsView and Credit card model data
						// check if there is a artile which has the billbag flag set > ifso ... you are not allowed to create a CIT
						for (var i in mArticles) {
							if (mArticles.hasOwnProperty(i) === false) {
								continue;
							}
							mArticles[i].TransactiontypeTranslated = fnGetTransactionTypeFromMapping(mArticles[i]);
							// RowHightlite: set to warning if the Article is not tickted or the billback is not released
							mArticles[i].rowHighlightStatus = (mArticles[i].Ticketreference === "" || mArticles[i].BillbackNotReleased === "X") ?
								"Warning" : "Information";
							if (mArticles[i].NoBilling) {
								mArticles[i].rowHighlightStatus = "Disabled";
							}
							// article page header
							if (!mArticleForPageHeader) {
								mArticleForPageHeader = mArticles[i];
							}
							// we use this to check if the cit creation button can be enabled
							if (mArticles[i].BillbackNotReleased) {
								bHasArticleWithBillbackFlagSet = true;
							}
							// // set Passenger name
							// // grab the passengername from the first article
							// // if there different passengernames .. cast the passengername with a *
							// if ("Passengername" in mArticles[i]) {
							// 	var sPassengerName		= mArticles[i].Passengername,
							// 		sPNameInViewModel	= oBookingViewModel.getProperty("/header/PassengerName");
							// 	if (sPNameInViewModel === "") {
							// 		oBookingViewModel.setProperty("/header/PassengerName", sPassengerName);
							// 	} else if (sPNameInViewModel !== sPassengerName && sPNameInViewModel.indexOf("*") === -1) { // only add an * if it is not allready in it
							// 		oBookingViewModel.setProperty("/header/PassengerName", sPNameInViewModel+"*");
							// 	}
							// }
							// search for the first usable creditcard info
							// use the first one which holds an credit card no
							if (mArticles[i].Creditcardnumber !== "") {
								mArticleForCreditCard = mArticles[i];
							}
							// Add ErrorCount to mArticles
							// note : since the credit card fields are displayed in a seperate tab in this view
							// credit card errors should be handled seperately
							//var aCreditCardKeys		= _.keys(oCreditCardModel.getProperty("/"));
							//	aCreditCardFields	= aCreditCardKeys.map(function(s) { return s.toUpperCase(); }); // for comparisation we change all keys to UpperCase
							mArticles[i].ErrorCount = 0;
							if (mErrors && _.size(mErrors)) {
								var iArticleErrorCount = 0,
									iCreditCardErrorCount = 0,
									mErrorFieldsUsed = {};
								//	aErrorFieldsUsedInCount	= [];	// array needed to check if the ErrorField allready has been added to the count
								for (var iCnt in mErrors) {
									if (["05", "06", "07"].indexOf(mErrors[iCnt].ErrorCode) !== -1) {
										mErrors[iCnt].Tabname = "ERROR_" + mErrors[iCnt].ErrorCode;
									}
									// check if the ErrorField has allready been counted
									// for example : a ErrorField could be flagged multiple times (error code 01 and 08)

									if (mErrors[iCnt].ArticlesId === mArticles[i].ArticlesId && (mErrors[iCnt].ErrorField || ["05", "06", "07"].indexOf(mErrors[
											iCnt].ErrorCode) !== -1)) {
										if (!(mErrors[iCnt].Tabname in mErrorFieldsUsed)) {
											mErrorFieldsUsed[mErrors[iCnt].Tabname] = (mErrors[iCnt].Tabname === "ZHY_SEGMENTS") ? {} : [];
										}
										if (mErrors[iCnt].Tabname === "ZHY_SEGMENTS") {
											if (!(mErrors[iCnt].SegmentId in mErrorFieldsUsed[mErrors[iCnt].Tabname])) {
												mErrorFieldsUsed[mErrors[iCnt].Tabname][mErrors[iCnt].SegmentId] = [];
											}
											if (mErrorFieldsUsed[mErrors[iCnt].Tabname][mErrors[iCnt].SegmentId].indexOf(mErrors[iCnt].ErrorField) === -1) {
												mErrorFieldsUsed[mErrors[iCnt].Tabname][mErrors[iCnt].SegmentId].push(mErrors[iCnt].ErrorField);
											} else {
												continue;
											}
										} else {
											if (mErrorFieldsUsed[mErrors[iCnt].Tabname].indexOf(mErrors[iCnt].ErrorField) === -1) {
												mErrorFieldsUsed[mErrors[iCnt].Tabname].push(mErrors[iCnt].ErrorField);
											} else {
												continue;
											}
										}

										//aErrorFieldsUsedInCount.push(mErrors[iCnt].ErrorField);
										iArticleErrorCount++;
									}
									// Credit card errors only needed to be displayed in the CreditCard tab
									// so filter out the credit card fields which are displayed in the booking view
									// if (mErrors[iCnt].ArticlesId === mArticles[i].ArticlesId) { 
									// var iCreditCardFieldIndex = aCreditCardFields.indexOf(mErrors[iCnt].ErrorField.toUpperCase()); // Change to uppercase for comparisation 
									// if (iCreditCardFieldIndex !== -1) { 
									// 	// possible credit card error
									// 	if (mArticleForCreditCard && "ArticlesId" in mArticleForCreditCard && mArticleForCreditCard.ArticlesId === mErrors[iCnt].ArticlesId) {
									// 		iCreditCardErrorCount++;
									// 		oBookingViewModel.setProperty("/CreditCardErrorFields/"+aCreditCardKeys[iCreditCardFieldIndex], true);
									// 	}
									// } else { 
									// normal article error
									// iArticleErrorCount++; 
									//}
									// }
								}

								// add the error count to the article data
								mArticles[i].ErrorCount = iArticleErrorCount;
								if (mArticles[i].NoBilling) {
									mArticles[i].rowHighlightStatus = "Disabled";
								} else if (iArticleErrorCount) { // On error always set error
									mArticles[i].rowHighlightStatus = "Error";
								} else if (mArticles[i].rowHighlightStatus === "Information") {
									// If the article contains an error with code 08
									if (_.findWhere(mErrors, {
											ErrorCode: "08",
											ArticlesId: mArticles[i].ArticlesId
										})) {
										mArticles[i].rowHighlightStatus = "Warning";
									}
								}
								// credit card
								if (iCreditCardErrorCount) {
									oBookingViewModel.setProperty("/CreditCardIconColor", "Negative");
									oBookingViewModel.setProperty("/showSaveButtonsCreditCard", true);
								}
							}
						}
						// Set the page header data from the article
						if (mArticleForPageHeader) {
							if ("Account" in mArticleForPageHeader) {
								oBookingViewModel.setProperty("/Account", mArticleForPageHeader.Account);
							}
						}
						// Set the CreditCard model data
						// note: only copy the necessary fields to the CreditCard model
						if (mArticleForCreditCard) {
							var aCCFields = _.keys(oCreditCardModel.getProperty("/"));
							for (var sField in mArticleForCreditCard) {
								if (aCCFields.indexOf(sField) !== -1) {
									oCreditCardModel.setProperty("/" + sField, mArticleForCreditCard[sField]);
								}
							}
							// get the mapping for the credit card type dropdownselect
							if ("ApplicationsId" in mBooking && "ArticleCategory" in mArticleForCreditCard) {
								var oCcMapping = new MappingModel(mBooking.ApplicationsId, mArticleForCreditCard.ArticleCategory);
								oCcMapping.loadMappingForEntity(
									"articles", {
										filters: [
											new sap.ui.model.Filter("FieldnameBs", sap.ui.model.FilterOperator.EQ, "CREDITCARDTYPEMERCHANT")
										],
										success: function (mCcMapping) {
											oBookingViewModel.setProperty("/CreditCardMapping", mCcMapping);
										}
									}
								);
							}
						}

						// set Articles model data
						oArticlesModel.setData(mArticles);
						// Only enable the CIT creationButton if the all articles are billbacked
						//oBookingViewModel.setProperty("/CITcreationButtonEnabled", ! bHasArticleWithBillbackFlagSet);
						// on 09-08 wim said that the button should always be enabled
						oBookingViewModel.setProperty("/CITcreationButtonEnabled", true);
						// re-apply filter on all tables
						$.proxy(that.tableFilters.reset, that)();
					});
					// Open the first tab which contains article data
					var aTab = ["Air", "Car", "Hotel", "Rail", "Misc"];
					tabloop: for (var iTabOrder in aTab) {
						if (mArticles.length === 0) {
							break;
						}
						for (var i in mArticles) {
							if (mArticles[i].ArticleCategory === aTab[iTabOrder]) {
								$.proxy(this.iconTabBar.openTab, this)(aTab[iTabOrder]);
								break tabloop;
							}
						}
					}
				},
				/**
				 * Process booking data:
				 * - Fills the header model
				 * @param {map} mBooking - Booking data fetched from oData service
				 */
				processBookingData: function (mBooking) {
					if (!mBooking || _.size(mBooking) === 0) {
						return;
					} // no data to display
					var oView = this.getView(),
						oBooking = oView.getModel("Booking"),
						oBookingView = this.getView().getModel("BookingView"),
						aHeaderBooking = ["BookingsId", "Bookingdestination", "ApplicationsId", "Bookingreference", "BookingCreationdate", "Blockremark",
							"Blocked"
						],
						that = this;
					// set booking model data
					oBooking.setProperty("/", mBooking);
					oBooking.attachPropertyChange(function () {
						if (oView.getModel("Booking").getProperty("/Blocked") !== 'X') {
							$.proxy(that._preventRouterNavigation, that)(I18n.getText("Booking.Title"));
						}
					});

					//Set Buttons Based on Booking Block Status	
					if (mBooking.Blocked !== "X") {
						oBookingView.setProperty("/showBlockButton", true);
						oBookingView.setProperty("/showUnBlockButton", false);
						oBookingView.setProperty("/showBlockedMessage", false);
						oBookingView.setProperty("/blockActionTxt", "Block");
					}
					if (mBooking.Blocked === "X") {
						oBookingView.setProperty("/showBlockButton", false);
						oBookingView.setProperty("/showUnBlockButton", true);
						oBookingView.setProperty("/showBlockedMessage", true);
						oBookingView.setProperty("/blockActionTxt", "UnBlock");
					}

					// read from booking data and set BookingView model
					for (var i in aHeaderBooking) {
						if (aHeaderBooking.hasOwnProperty(i) === false) {
							continue;
						}
						var s = aHeaderBooking[i];
						if (s in mBooking) {
							oBookingView.setProperty("/header/" + s, mBooking[s]);
						}
					}
				},
				/**
				 * Pocess Error data:
				 * -
				 * @param {map} mErrors 	- Error data fetched from oData service
				 * @param {map} mBooking - Booking data fetched from oData service
				 */
				processErrorData: function (mErrors, mBooking) {
					this.models._mErrors = mErrors;
					var oView = this.getView(),
						oBookingView = oView.getModel("BookingView"),
						oBookingErrorsModel = this.getView().getModel("BookingErrors");
					// fill the booking errors model
					for (var sField in mBooking) {
						if (mBooking.hasOwnProperty(sField) === false) {
							continue;
						}
						// find where toUpperCase the error DB table only holds uppercase fieldnames
						var bHasError = (_.findWhere(mErrors || {}, {
							ErrorField: sField.toUpperCase(),
							Tabname: "ZHY_BOOKINGS"
						})) ? true : false;
						oBookingErrorsModel.setProperty("/" + sField, bHasError);
						// Error found
						if (bHasError && !User.canOnlyRead()) {
							oBookingView.setProperty("/showSaveButtonsBooking", true);
						}
					}
				}
			},

			/**
			 * Resets the filters of all Article tables 
			 * @namespace com.bcdtravel.pnr.controller.Booking.tableFilters
			 */
			tableFilters: /** @lends com.bcdtravel.pnr.controller.Booking.tableFilters.prototype */ {
				/**
				 * Default filter data
				 * note: the order is imporant! If all errors are set.. the first tab which contains an error will be opened
				 */
				defaultFilters: {
					// Note: the reset function is also using this keys
					// so make sure for every key there is in the view a table
					// example : key Rail ... in the view a talbe with id RailTable has to be present
					Air: [
						["ArticleCategory", "EQ", "AIR"] // Field, Operator, Value
					],
					Car: [
						["ArticleCategory", "EQ", "CAR"] // Field, Operator, Value
					],
					Hotel: [
						["ArticleCategory", "EQ", "HOTEL"] // Field, Operator, Value
					],
					Rail: [
						["ArticleCategory", "EQ", "RAIL"] // Field, Operator, Value
					],
					Misc: [
						["ArticleCategory", "EQ", "MISC"] // Field, Operator, Value
					]
				},
				init: function () {
					// nothing
				},
				/**
				 * Get the table filter in usable sapui5 filters
				 * @return {array} - Filters
				 */
				getTableUI5Filters: function () {
					// convert the tableFilters.defaultFilter to usable sapui5 filters
					var mNewFilters = {};
					for (var sType in this.tableFilters.defaultFilters) {
						if (this.tableFilters.defaultFilters.hasOwnProperty(sType) === false) {
							continue;
						}
						var aType = this.tableFilters.defaultFilters[sType];
						mNewFilters[sType] = [];
						for (var iFilter in aType) {
							if (aType.hasOwnProperty(iFilter) === false) {
								continue;
							}
							var aFilter = aType[iFilter];
							mNewFilters[sType].push(new sap.ui.model.Filter(
								aFilter[0], // Field
								aFilter[1], // Operator
								aFilter[2] // Value
							));
						}
					}
					return mNewFilters;
				},
				/**
				 * Re-set the table articles filters
				 */
				reset: function () {
					var oView = this.getView(),
						aFilters = $.proxy(this.tableFilters.getTableUI5Filters, this)(),
						sFirstTabWithError;
					// apply filter to all table items (AirTable, RailTable, HotelTable, CarTable, MiscTable)
					for (var sType in aFilters) {
						if (aFilters.hasOwnProperty(sType) === false) {
							continue;
						}
						var oTable = oView.byId(sType + "Table");
						// skip if table is undefined or if the table has no items
						if (!oTable || !oTable.getBinding("items")) {
							continue;
						}
						// apply filter
						oTable.getBinding("items").filter(
							aFilters[sType],
							sap.ui.model.FilterType.Application
						);
						// IconTabFilter count
						var aItems = oTable.getItems(),
							iErrorCount = 0,
							iWarningCount = 0;
						// count errors of current tab
						for (var i in aItems) {
							if (aItems.hasOwnProperty(i) === false) {
								continue;
							}
							var oCntx = aItems[i].getBindingContext("Articles"),
								m = oCntx.getModel().getProperty(oCntx.getPath());
							if ("ErrorCount" in m) {
								iErrorCount += m.ErrorCount;
							}
							if ("rowHighlightStatus" in m && m.rowHighlightStatus === "Warning") {
								iWarningCount++;
							}
						}
						if ((iErrorCount || iWarningCount) && !sFirstTabWithError) {
							sFirstTabWithError = sType;
						}
						// change tabbar filter header attributes
						$.proxy(this.models.setIconTabFilterAttributesByCounters, this)(
							sType,
							aItems.length, // Item count
							iErrorCount, // error count
							iWarningCount
						);
					}
					// Open the first tab which has an warning or error
					if (sFirstTabWithError) {
						$.proxy(this.iconTabBar.openTab, this)(sFirstTabWithError);
					}
				}
			},

			/**
			 * Event handler when the New Article button is pressed
			 *
			 * Navigates to the NewArticle Page
			 */
			onNewArticle: function () {
				$.proxy(this._navTo, this)(
					"NewArticle", {
						bookingId: this._bookingId
					}
				);
			},

			/**
			 * @namespace com.bcdtravel.pnr.controller.Booking.valueHelp
			 */
			valueHelp: /** @lends com.bcdtravel.pnr.controller.Booking.valueHelp.prototype */ {
				/**
				 * Value Help for Bookingdestination 
				 * opens the cities value help dialog
				 * @param {object} e - event data
				 */
				onOpenBookingdestination: function (e) {
					ValueHelp.open("Airports", {
						source: e.getSource()
					});
				}
			}
		});
		return oBookingController;
	},
	/* bExport= */
	true);