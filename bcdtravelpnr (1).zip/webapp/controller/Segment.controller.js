/* global _ */
/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"com/bcdtravel/pnr/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/I18n",
	"com/bcdtravel/pnr/model/DisplaySettings",
	"com/bcdtravel/pnr/model/Article",
	"com/bcdtravel/pnr/model/Segment",
	"com/bcdtravel/pnr/model/Mapping",
	"com/bcdtravel/pnr/model/Mandatory",
	"com/bcdtravel/pnr/model/User",
	"com/bcdtravel/pnr/controller/ValueHelp",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, BCDGateway, I18n, DisplaySettings, ArticleModel, SegmentModel, MappingModel, MandatoryModel, User,
	ValueHelp, MessageBox) {
	"use strict";

	/**
	 * Controller for the Segment View
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.controller.Segment
	 * @extends 	com.bcdtravel.pnr.controller.BaseController
	 * 
	 * @constructor
	 * @public
	 */
	var oSegmentController = BaseController.extend("com.bcdtravel.pnr.controller.Segment", /** @lends com.bcdtravel.pnr.controller.Segment.prototype */ {

		// all ids are set in onRouteMatched method
		_bookingId: null,
		_articleId: null,
		_segmentId: null,

		/**
		 * Method called on view initialization
		 */
		onInit: function () {
			// init models
			$.proxy(this.models.init, this)();
			// attach route matched
			//this._getRouter().getTarget("Segment").attachDisplay($.proxy(this.onRouteMatched, this));
			this._getRouter().attachRouteMatched(this.onRouteMatched, this);
			// H0029 - Segment Date Field Validation setting min date for fields added by Naresh Ponnada on 05/05/2020
			var oYear = new Date().getFullYear() - 2;
			this.getView().byId("SegmentdeparturedateId").setMinDate(new Date(oYear, 0, 1));
			this.getView().byId("segmentarrivaldateID").setMinDate(new Date(oYear, 0, 1));
		},

		/**
		 * Enables all fields to be editable
		 */
		onForceEditMode: function () {
			// double check if the user is allowed
			if (!User.canForceEditMode) {
				return false;
			}
			var oSegmentView = this.getView().getModel("SegmentView");
			oSegmentView.setProperty("/forceEditMode", true);
			oSegmentView.setProperty("/showSaveCancelButtons", true);
		},

		/**
		 * Method is called when the Segment view is requested
		 * This method:
		 * - sets the _bookingId, _articleId and _segmentId
		 * - calls the method wich will start firing oData requests
		 * @param	{sap.m.router.event} e - RouteMatched event data
		 */
		onRouteMatched: function (e) {
			var sRouteName = e.getParameter("name"),
				mData = e.getParameter("arguments");
			// check for valid route
			if (mData.TabnameBs === "NewSegment") {
				sRouteName = "NewSegment";
			}

			if (["Segment", "NewSegment"].indexOf(sRouteName) === -1) {
				return;
			}
			// check bookingsId and articleId and set them
			if (!("bookingId" in mData) || !("articleId" in mData)) {
				return;
			}
			this._bookingId = mData.bookingId;
			this._articleId = mData.articleId;
			// Existing Segment
			if (sRouteName === "Segment" && "segmentId" in mData) {
				this._segmentId = mData.segmentId;
				// load article data
				$.proxy(this.models.loadByBookingIdAndArticleIdAndSegmentId, this)(mData.bookingId, mData.articleId, mData.segmentId);
			} else if (sRouteName === "NewSegment") {
				// open newarticle dialog
				$.proxy(this.models.loadByBookingIdAndArticleIdAndSegmentId, this)(
					this._bookingId,
					this._articleId,
					0
				);
			}
		},

		/**
		 * Show a loading indicator over the entire Page
		 * @param {boolean} [b=false] - if true the loading indicator is showed
		 */
		_showPageBusyIndicator: function (b) {
			this.getView().byId("SegmentsPage").setBusy(b);
		},

		/**
		 * Event listener for when the SegmentArrival has changed
		 * @param {object} e - Button change event
		 */
		onChangeSegmentarrival: function (e) {
			this.onChangeCheckError(e);
			$.proxy(this.models.descriptions.generateSegmentarrival, this)();
		},
		/**
		 * Event listener for when the SegmentDeparture has changed
		 * @param {object} e - Button change event
		 */
		onChangeSegmentdeparture: function (e) {
			this.onChangeCheckError(e);
			$.proxy(this.models.descriptions.generateSegmentdeparture, this)();
		},
		/**
		 * Event listener for when the SegmentProvider has changed
		 * @param {object} e - Button change event
		 */
		onChangeSegmentprovider: function (e) {
			this.onChangeCheckError(e);
			$.proxy(this.models.descriptions.generateSegmentprovider, this)();
		},

		/**
		 * Event handler when the button is pressed to nav to Booking
		 * Navigates to the Booking view
		 */
		onNavToBooking: function () {
			this._navTo(
				"Booking", {
					bookingId: this._bookingId
				}
			);
		},

		/**
		 * Event handler when the back button is pressed
		 * Navigates to the Article view
		 */
		onNavToArticle: function () {
			this._navTo(
				"Article", {
					bookingId: this._bookingId,
					articleId: this._articleId
				}
			);
		},

		/**
		 * This event is called when a Segment value changes (by user : sap.m.Select sap.m.DatePicker sap.m.Input)
		 * If it has an error in the errorSet, the value state is changed to None to indicate that the error will be resolved on save 
		 * @param {object} e - Butten event object
		 * trello H0029 - Segment Date Field Validation from Line No173 to 183 makeing date validation by Naresh Ponnada on 05/05/2020
		 */
		onChangeCheckError: function (e) {
			var oSrc = e.getSource(),
				sPath = oSrc.getBindingPath("value"),
				oErrors = this.getView().getModel("SegmentErrors"),
				sVal;
			var sid = oSrc.getId();
			switch (oSrc.getMetadata().getName()) {
			case "sap.m.Input":
				break;
			case "sap.m.DatePicker":
				// Added by Naresh - 07.05.2020 and Label comparsion for Hotel and Car Booking displaysection added on 28/05/2020 
				if (sid === "application-Bookings-display-component---Segment--SegmentdeparturedateId") {
					this.oDepartureHotelLabel = oSrc.getParent().getParent().getTitle();
				} else {
					this.oArriaclHotelLabel = oSrc.getParent().getParent().getTitle();
				}
				if (oSrc._sUsedDisplayPattern === "dd.MM.yyyy") {
					sVal = oSrc.getValue().split(".")[2];
				} else {
					sVal = oSrc.getValue();
				}
				var oDate = new Date();
				var mindateyear = oDate.getFullYear() - 2;
				var sNewValyear = new Date(sVal).getFullYear();
				if (sNewValyear < mindateyear) {
					oSrc.setValueState("Error");
					oSrc.setValueStateText("Please enter Valid Year");
				} else {
					oSrc.setValueState("None");
					oSrc.setValueStateText("");
				}
				break;
			case "sap.m.TimePicker":
				sVal = oSrc.getValue();
				break;
			case "sap.m.Select":
				sVal = oSrc.getSelectedKey();
				sPath = oSrc.getBindingPath("selectedKey");
				// sap ui5 version < 1.50 has an error where the valueStateText doesnt hide when the valuestate is set to None
				// https://github.com/SAP/openui5/commit/703e4938a97d6d7974581dcb733454ab069f5ac4 fixes the problem
				oSrc.closeValueStateMessage();
				break;
			}
			// only change the value state if there was an error indication from the backend
			// (it could be a new article)
			if (oErrors.getProperty(sPath)) {
				oSrc.setValueState(((sVal) ? "None" : "Error"));
			}
		},

		/**
		 * Method called when the save button is clicked
		 * Calls the method which will save the segment data
		 */
		onSaveSegmentData: function () {
			// allow routing
			this._allowRouterNavigation(I18n.getText("Segment.SegmentData"));
			// Show Page loader
			var that = this,
				oSegmentModel = this.getView().getModel("Segment"),
				sSaveType = (oSegmentModel.isNew()) ? "Create" : "Update",
				oView = this.getView(),
				oDefMandatory = $.Deferred();
			if (oSegmentModel.isNew()) {
				var oMandatoryModel = this.getView().getModel("MandatoryFields");
				oMandatoryModel.checkObjectFields(
					oSegmentModel.getProperty("/"), {
						success: function () {
							oDefMandatory.resolve();
						},
						error: function (aErrors) {
							if (aErrors.length) {
								for (var i in aErrors) {
									if (aErrors.hasOwnProperty(i) === false) {
										continue;
									}
									oView.getModel("SegmentErrors").setProperty("/" + aErrors[i], true);
								}
								that._showError(I18n.getText("MandatoryFieldError"));
							}
							oDefMandatory.reject();
						}
					}
				);
			} else {
				oDefMandatory.resolve();
			}
			/*    Segmentdeparturedate and Arrival Date validation check add by Naresh Ponnada on 05/18/2020
                In this method we are going to check the Date Validation with minmal year id the flags are ture then it will exit form the method */
			this._DateValidationMessage(oSegmentModel);
			if (this.osflag) {
				var osMsg = "";
				if (this.oDepYearFlag) {
					if (this.oDepartureHotelLabel === "Arrival") {
						osMsg = I18n.getText("Segment.MSG.ArrivalDate");
					} else if (this.oDepartureHotelLabel === "Departure") {
						osMsg = I18n.getText("Segment.MSG.DepartureDate");
					} else if (this.oDepartureHotelLabel === "Pick-up") {
						osMsg = I18n.getText("Segment.MSG.pickupDate");
					}
				}
				if (this.oArrivalYearFlag) {
					if (this.oArriaclHotelLabel === "Departure") {
						osMsg = I18n.getText("Segment.MSG.DepartureDate");
					} else if (this.oArriaclHotelLabel === "Arrival") {
						osMsg = I18n.getText("Segment.MSG.ArrivalDate");
					} else if (this.oArriaclHotelLabel === "Drop-off") {
						osMsg = I18n.getText("Segment.MSG.DropoffDate");
					}
				}
				if (this.oDepYearFlag && this.oArrivalYearFlag) {
					if (this.oArriaclHotelLabel === "Drop-off" && this.oDepartureHotelLabel === "Pick-up") {
						osMsg = I18n.getText("Segment.MSG.pickupdropoffDate");
					} else {
						osMsg = I18n.getText("Segment.MSG.DeparArrivalDate");
					}
				}
				MessageBox.warning(osMsg);
				return;
			}
			// no errors ? proceed
			oDefMandatory.done(function () {
				that._showPageBusyIndicator(true);
				oSegmentModel.saveData({
					success: function (m) {
						// hide loader 
						that._showPageBusyIndicator(false);
						if (sSaveType === "Create" && typeof m === "object" && "SegmentId" in m) {
							that._segmentId = m.SegmentId;
						}

						if (sSaveType === "Update") {
							// show success message
							that._showMessage(I18n.getText("SavedSuccefully"));
						}
						// reload view models
						$.proxy(that.models.reload, that)();
					},
					error: function (e) {
						// hide loader 
						that._showPageBusyIndicator(false);
						// show error
						that._showErrorByOdataResponse(e);
					}
				});
			});
		},
		/**
		 * Method called inside the save Button Action for segment update and create
		 * Calls the method which resets the date validation flags with respective dates
		 * changes add by Naresh Ponnada on 05/18/2020
		 */
		_DateValidationMessage: function (oSegmentModel) {
			this.oDepYearFlag = false;
			this.oArrivalYearFlag = false;
			var oSegDepDate = oSegmentModel.getProperty("/Segmentdeparturedate"),
				oSegDepYear, oSegArrLYear,
				oSegArrialDate = oSegmentModel.getProperty("/Segmentarrivaldate");
			var oMinmYear = new Date().getFullYear() - 2;
			if (oSegDepDate) {
				oSegDepYear = oSegDepDate.getFullYear();
				if (oSegDepYear < oMinmYear) {
					this.oDepYearFlag = true;
				} else {
					this.oDepYearFlag = false;
				}
			}
			if (oSegArrialDate) {
				oSegArrLYear = oSegArrialDate.getFullYear();
				if (oSegArrLYear < oMinmYear) {
					this.oArrivalYearFlag = true;
				} else {
					this.oArrivalYearFlag = false;
				}
			}
			if (this.oDepYearFlag || this.oArrivalYearFlag) {
				this.osflag = true;
			} else {
				this.osflag = false;
			}
		},
		/**
		 * Method called when the cancel button is clicked
		 * Calls the method which resets and reloads all view data
		 */
		onCancel: function () {
			this._allowRouterNavigation(I18n.getText("Segment.SegmentData"));
			$.proxy(this.models.reload, this)();
		},

		/**
		 * @namespace com.bcdtravel.pnr.controller.Segment.models
		 */
		models: /** @lends com.bcdtravel.pnr.controller.Segment.models.prototype */ {
			/**
			 * Model initializer
			 */
			init: function () {
				$.proxy(this.models.setViewModels, this)();
			},
			/** 
			 * (re)-set the view models 
			 */
			setViewModels: function () {
				var oView = this.getView();
				// SegmentView
				oView.setModel(new JSONModel({
					ArticleCategory: "",
					show: {
						//Departureterminal: true .. etc // dynamically created in this.models.processSegmentData
					},
					showSaveCancelButtons: false,
					showUnticketedMessage: false,
					isNewSegment: false,
					SegmentdepartureDescription: "",
					SegmentarrivalDescription: "",
					SegmentproviderDescription: "",
					// Issue 0016: If the ArticleCategory is Hotel or Car the labels differentiate.
					// these labels are changed in the .models.processArticleData method
					ArrivalDepartureLabels: {
						departure: I18n.getText("Segment.formcontainer.Departure"),
						segmentdeparturedate: I18n.getText("segment.Segmentdeparturedate"),
						segmentdeparture: I18n.getText("segment.Segmentdeparture"),
						segmentdeparturetime: I18n.getText("segment.Segmentdeparturetime"),
						arrival: I18n.getText("Segment.formcontainer.Arrival"),
						segmentarrivaldate: I18n.getText("segment.Segmentarrivaldate"),
						segmentarrival: I18n.getText("segment.Segmentarrival"),
						segmentarrivaltime: I18n.getText("segment.Segmentarrivaltime")
					},
					forceEditMode: false,
					// Issue 0017: SegmentNumberOfDays should be Number of nights if the article category is Hotel
					SegmentnumberofdaysLabel: I18n.getText("segment.Segmentnumberofdays")
				}), "SegmentView");
				// errors 
				// example below the Segmentbaggageallowance has an error
				// dynamically created in this.models.processErrorData
				oView.setModel(new JSONModel({
					/*
						Segmentbaggageallowance : true
					*/
				}), "SegmentErrors");
				oView.setModel(new JSONModel({}), "Booking");
				oView.setModel(new JSONModel({}), "Article");
				oView.setModel(new JSONModel({}), "Segment");
				oView.setModel(new JSONModel({}), "Mapping");
				oView.setModel(new JSONModel({}), "MandatoryFields");
			},
			/**
			 * reload all data
			 */
			reload: function () {
				$.proxy(this.models.loadByBookingIdAndArticleIdAndSegmentId, this)(this._bookingId, this._articleId, this._segmentId);
			},
			/**
			 * Executes all oData read request
			 * @param {string}	bookingId - The Booking Id
			 * @param {string}	articleId - The Article Id
			 * @param {string}	segmentId - The Segment Id
			 */
			loadByBookingIdAndArticleIdAndSegmentId: function (bookingId, articleId, segmentId) {
				// Fetch articledata
				var that = this,
					oView = this.getView();
				// allow navigation (for all)
				$.proxy(that._allowRouterNavigation, that)();
				// Show Page loader
				$.proxy(this._showPageBusyIndicator, this)(true);
				// clear all current view data
				$.proxy(this.models.setViewModels, this)();
				var oArticlesDeferred = $.Deferred(),
					oBookingDeffered = $.Deferred(),
					oSegmentsDeferred = $.Deferred(),
					oErrorDeferred = $.Deferred();
				// Promise so that the deferred cannot be changed
				oArticlesDeferred.promise();
				oBookingDeffered.promise();
				oSegmentsDeferred.promise();
				oErrorDeferred.promise();
				// Load booking
				// Fetch Booking data from service
				BCDGateway.read(
					"/bookingSet('" + bookingId + "')", {
						success: function (mData) {
							oBookingDeffered.resolve(mData);
						},
						error: function () {
							oBookingDeffered.resolve({});
							that._showError(I18n.getText("oDataLoadError"));
						}
					}
				);
				// load Segments
				var oSegment = new SegmentModel(
					bookingId,
					articleId,
					segmentId, {
						success: function (mData) {
							if (oSegment.isNew()) {
								// set the articleId and Bookings Id
								oSegment.setProperty("/ArticlesId", parseInt(that._articleId, 10));
								oSegment.setProperty("/BookingsId", that._bookingId);
								oView.getModel("SegmentView").setProperty("/isNewSegment", true);
							}
							oSegmentsDeferred.resolve(mData);
							// prevent routing
							oSegment.attachPropertyChange(function () {
								if (oView.getModel("Booking").getProperty("/Blocked") !== 'X') {
									$.proxy(that._preventRouterNavigation, that)(I18n.getText("Segment.SegmentData"));
								}
							});
						},
						error: function () {
							oSegmentsDeferred.resolve({});
							that._showError(I18n.getText("oDataLoadError"));
						}
					}
				);
				this.getView().setModel(oSegment, "Segment");
				// load article
				var oArticle = new ArticleModel(
					bookingId,
					articleId, {
						success: function (mData) {
							if (oSegment.isNew()) {
								oSegment.setProperty("/ArticleType", mData.ArticleType);
							}
							oArticlesDeferred.resolve(mData);
						},
						error: function () {
							oArticlesDeferred.resolve(null);
							that._showError(I18n.getText("oDataLoadError"));
						}
					}
				);
				// overwrite the article model
				this.getView().setModel(oArticle, "Article");
				// Read field errors Errors from service
				BCDGateway.readFieldErrors({
					bookingId: bookingId, // filter on bookingId
					articleId: articleId, // filter on articleId
					segmentId: segmentId, // filter on segmentId
					entity: "segment",
					success: function (mData) {
						oErrorDeferred.resolve(mData);
					},
					error: function () {
						// dont throw an error for errorSet
						oErrorDeferred.resolve({});
					}
				});
				// data has loaded
				$.when(oBookingDeffered, oSegmentsDeferred, oArticlesDeferred, oErrorDeferred).done(function (mBooking, mSegment, mArticle,
					mErrors) {
					// initialize &nd overwrite mapping model
					var sApplicationsId = mBooking.ApplicationsId || "",
						sArticleCategory = mArticle.ArticleCategory || "",
						oMapping = new MappingModel(sApplicationsId, sArticleCategory);
					oView.setModel(oMapping, "Mapping");
					// Hide Page loader
					$.proxy(that._showPageBusyIndicator, that)(false);
					// direct bind the booking data
					that.getView().getModel("Booking").setData(mBooking);
					// improtant : first process article data
					$.proxy(that.models.processArticleData, that)(mArticle, mBooking);
					// then proces segment data
					$.proxy(that.models.processSegmentData, that)(mSegment, mArticle);
					// last process error data
					$.proxy(that.models.processErrorData, that)(mErrors, mSegment, mArticle);
					// load mandatory model (if not > the displaysettings will not work)
					oView.setModel(
						new MandatoryModel("segment", oSegment.getProperty("/ArticleType")),
						"MandatoryFields"
					);
				});
			},

			/**
			 * Input description formatters
			 * @namespace com.bcdtravel.pnr.controller.Segment.models.descriptions
			 */
			descriptions: /** @lends com.bcdtravel.pnr.controller.Segment.models.descriptions */ {
				/**
				 * Triggers a read request to the correct set (based on the sType)
				 *
				 * In the callback its sets the correct value help descriptions
				 * @private
				 * @param {string} sType=Segmentprovider|Segmentarrival|Segmentdeparture
				 */
				_load: function (sType) {
					var oView = this.getView(),
						oSegmentViewModel = oView.getModel("SegmentView"),
						mSegmentData = oView.getModel("Segment").getProperty("/"),
						sFilterVal = mSegmentData[sType],
						sCategory = oView.getModel("Article").getProperty("/ArticleCategory");
					if (!sFilterVal) {
						return;
					}
					var sSet, sFilterColumn, sValueColumn;
					if (sType === "Segmentprovider") {
						// No need to show a provider description if the category is Rail
						if (sCategory.toUpperCase() === "RAIL") {
							return;
						}
						//
						sSet = "AirlinesSet";
						sFilterColumn = "Iatacode";
						sValueColumn = "Airlinename";
					} else if (["Segmentarrival", "Segmentdeparture"].indexOf(sType) !== -1) {
						if (sCategory.toUpperCase() === "RAIL") {
							sSet = "RailstationsSet";
							sFilterColumn = "Stationcrscode";
							sValueColumn = "Stationname";
						} else {
							sSet = "AirportsSet";
							sFilterColumn = "Airportcode";
							sValueColumn = "Airportname";
						}
					} else {
						return;
					}
					BCDGateway.read(
						"/" + sSet, {
							filters: [
								new sap.ui.model.Filter(sFilterColumn, "EQ", sFilterVal)
							],
							success: function (m) {
								var sResult = "";
								if ("results" in m && _.size(m.results)) {
									for (var i in m.results) {
										if (m.results.hasOwnProperty(i) === false) {
											continue;
										}
										sResult = m.results[i][sValueColumn];
										break;
									}
								}
								oSegmentViewModel.setProperty("/" + sType + "Description", sResult);
							}
						}
					);
				},
				/**
				 * Loads and sets the Segmentarrival value help description
				 */
				generateSegmentarrival: function () {
					$.proxy(this.models.descriptions._load, this)("Segmentarrival");
				},
				/**
				 * Loads and sets the Segmentdeparture value help description
				 */
				generateSegmentdeparture: function () {
					$.proxy(this.models.descriptions._load, this)("Segmentdeparture");
				},
				/**
				 * Loads and sets the Segmentprovider value help description
				 */
				generateSegmentprovider: function () {
					$.proxy(this.models.descriptions._load, this)("Segmentprovider");
				},
				/**
				 * re-generate all descriptions
				 */
				reset: function () { // reset is called in processArticleData method
					$.proxy(this.models.descriptions.generateSegmentarrival, this)();
					$.proxy(this.models.descriptions.generateSegmentdeparture, this)();
					$.proxy(this.models.descriptions.generateSegmentprovider, this)();
				}
			},
			/**
			 * Process article data:
			 * - sets the Article model data
			 * - sets the SegmentView model ArticleCategory
			 * @param {object} mArticle	 -	ArticleSet oData data
			 */
			processArticleData: function (mArticle) {
				if (_.size(mArticle) === 0) {
					return;
				}
				var oView = this.getView(),
					oArticleModel = oView.getModel("Article"),
					oSegmentViewModel = oView.getModel("SegmentView");
				// set article model data
				//oArticleModel.setData(mArticle);
				// Check if article is unticketed (IMPORANT: you can only check this AFTER Article data has set)
				var bTicketed = oArticleModel.isTicketed();
				oSegmentViewModel.setProperty("/showUnticketedMessage", (!bTicketed ? true : false));
				// set segmetnview model article title
				if ("ArticleCategory" in mArticle) {
					// get the article type and make it uppercase so we can use it in this method
					var sArticleCategory = mArticle.ArticleCategory.toUpperCase();
					// bind the Article category and convert first char to uppercase and the rest lowercase
					oSegmentViewModel.setProperty(
						"/ArticleCategory",
						((sArticleCategory.length) ? sArticleCategory.charAt(0) + sArticleCategory.slice(1).toLowerCase() : ""),
						mArticle.ArticleCategory
					);
					// Issue 0016: If the ArticleCategory is Hotel or Car the labels differentiate.
					// For Hotel Arrival and Departure are switched
					// For Car Departure = Pick-up and Arrival = Drop-off
					if (["HOTEL", "CAR"].indexOf(sArticleCategory) !== -1) {
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/departure", I18n.getText("Segment." + sArticleCategory + ".Departure"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentdeparturedate", I18n.getText("Segment." + sArticleCategory +
							".DepartureDate"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentdeparture", I18n.getText("Segment." + sArticleCategory +
							".Departure"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentdeparturetime", I18n.getText("Segment." + sArticleCategory +
							".DepartureTime"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/arrival", I18n.getText("Segment." + sArticleCategory + ".Arrival"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentarrivaldate", I18n.getText("Segment." + sArticleCategory +
							".ArrivalDate"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentarrival", I18n.getText("Segment." + sArticleCategory + ".Arrival"));
						oSegmentViewModel.setProperty("/ArrivalDepartureLabels/segmentarrivaltime", I18n.getText("Segment." + sArticleCategory +
							".ArrivalTime"));
					}
					// Issue 0017: If ArticleCategory is Hotel Segmentnumberofdays should be Number of Nights
					if (sArticleCategory === "HOTEL") {
						oSegmentViewModel.setProperty("/SegmentnumberofdaysLabel", I18n.getText("Segment." + sArticleCategory + ".Segmentnumberofdays"));

					}
				}
			},
			/**
			 * Process error data and fill the SegmentErrors model
			 * This method:
			 * - sets the SegmentErrors model data (used to see which field triggered the error)
			 * In case an error is found:
			 * - If an field is hidden by the DisplaySettings it will be set to visible.
			 * - the SegmentView>/showSaveCancelButtons will be set to true			  * 
			 * @param {object} mErrors		- errorSet oData data
			 * @param {object} mSegment	- segmentSet oData data (needed to for field comparisation)
			 */
			processErrorData: function (mErrors, mSegment, mArticle) {
				var oView = this.getView(),
					oSegmentErrorsModel = oView.getModel("SegmentErrors"),
					oSegmentViewModel = oView.getModel("SegmentView"),
					oSegmentModel = oView.getModel("Segment"),
					oArticleModel = oView.getModel("Article");

				// No errors is article NoBilling
				if (mArticle.NoBilling === "X") {
					for (var sFieldname in mSegment) {
						oSegmentErrorsModel.setProperty("/" + sFieldname, false);
					}
					return;
				}

				//if (_.size(mErrors) === 0) { return; } DO NOT RETURN IF EMPTY!

				// Disable edit modus if the article is unticketed
				var bTicketed = oArticleModel.isTicketed();
				for (var sField in mSegment) {
					if (mSegment.hasOwnProperty(sField) === false) {
						continue;
					}
					// find where toUpperCase the error DB table only holds uppercase fieldnames
					var bHasError = (_.findWhere(mErrors, {
						ErrorField: sField.toUpperCase()
					})) ? true : false;
					oSegmentErrorsModel.setProperty("/" + sField, bHasError);
					// Error found
					if (bHasError) {
						// if the field is hidden by the DisplaySettings set it to visible
						oSegmentViewModel.setProperty("/show/" + sField, true);
						// only show save buttons if article is ticketed
						if (bTicketed) {
							oSegmentViewModel.setProperty("/showSaveCancelButtons", true);
						}
						// If booking blocked, save button needs to be disabled			  	
						if (this.getView().getModel("Booking").getProperty("/").Blocked) {
							oSegmentViewModel.setProperty("/showSaveCancelButtons", false);
						}
					}
				}
				// show save buttons if new segment
				if (oSegmentModel.isNew()) {
					oSegmentViewModel.setProperty("/showSaveCancelButtons", true);
				}

				// If booking blocked, save button needs to be disabled			  	
				if (this.getView().getModel("Booking").getProperty("/").Blocked) {
					oSegmentViewModel.setProperty("/showSaveCancelButtons", false);
				}
			},
			/**
			 * Process segment data
			 * Note.. article data has to be processed first! (we need the ArticleCategory)
			 * This method:
			 * - creates the field visibility settings SegmentView>/show/<FIELDNAME>
			 * @param {object} mSegment		segmentSet oData data
			 */
			processSegmentData: function (mSegment, mArticle) {
				if (_.size(mSegment) === 0) {
					return;
				}
				var oView = this.getView(),
					oSegmentViewModel = oView.getModel("SegmentView"),
					oSegmentModel = oView.getModel("Segment"),
					sArticleCategory = oSegmentViewModel.getProperty("/ArticleCategory"),
					oMappingModel = oView.getModel("Mapping");
				// Load the article mapping
				// in the view the Mapping model will be updated wit articles mapping and all sap.m.Select items will be created
				var oMappingParams = {
					always: function () { // done callback (both success or error)
						// 30-10-17 the mapSet did not contain data and as an result all dropdowns didn't show any items.
						// to correct that... I manually check all properties which need mapping and if there is no mapping present,
						// I get the value from the article data and create a map for it
						var mMapping = oMappingModel.getProperty("/");
						if (!("segment" in mMapping)) {
							oMappingModel.setProperty("/segment", {});
						}
						// All properties which are bound to a sap.m.select and need a mapping	
						var aAllSelectBoxes = ["Segmentprovider", "Segmentclass"];
						for (var i in aAllSelectBoxes) {
							if (aAllSelectBoxes.hasOwnProperty(i) === false) {
								continue;
							}
							var sProperty = aAllSelectBoxes[i],
								sPropertyUpperCase = sProperty.toUpperCase();
							// check if selectbox item is not allready in mapping and that the article has data for the current property
							if (!(sPropertyUpperCase in mMapping.segment) && (sProperty in mSegment && mSegment[sProperty] !== "")) {
								oMappingModel.setProperty(
									"/segment/" + sPropertyUpperCase, [{
										ValueBs: mSegment[sProperty],
										ValueBcd: mSegment[sProperty]
									}]
								);
							}
							// the mapping for the selectbox has items, but the article data value is not in the mapping
							// so we add it manually so it still can be selected
							if (
								sPropertyUpperCase in mMapping.segment && (sProperty in mSegment && mSegment[sProperty] !== "") && !_.findWhere(mMapping.segment[
									sPropertyUpperCase], {
									ValueBs: mSegment[sProperty]
								})
							) {
								var a = oMappingModel.getProperty("/segment/" + sPropertyUpperCase);
								a.push({
									ValueBs: mSegment[sProperty],
									ValueBcd: ""
								});
								oMappingModel.setProperty("/articles/" + sPropertyUpperCase, a);
							}
						}
						// refresh models to re-init the expression binding
						oSegmentModel.refresh(true);
						oMappingModel.refresh(true);
					}
				};
				// add the article account id so that the mapping table will be extended with the GCN mapping
				if (mArticle.Account) {
					oMappingParams.account = mArticle.Account;
				}
				oMappingModel.loadMappingForEntity(
					"segment", // Entity
					oMappingParams
				);
				// set segment data
				// oSegmentModel.setData(mSegment);
				// dynmamicly create the dislplay model
				// according to displaysettins models SegmentData table
				oSegmentViewModel.setProperty(
					"/show",
					DisplaySettings.getVisibleObjectByTypeAndCategory("SegmentData", sArticleCategory)
				);
				// load and show input descriptions
				$.proxy(this.models.descriptions.reset, this)();
			}
		},

		/**
		 * Valuehelp methods (value help dialog openers)
		 * @namespace com.bcdtravel.pnr.controller.Segment.valueHelp
		 */
		valueHelp: /** @lends com.bcdtravel.pnr.controller.Segment.valueHelp.prototype */ {
			/**
			 * Open the ValueHelp for Airlines
			 * @param {sap.ui.base.Event} e -
			 */
			onOpenAirlines: function (e) {
				ValueHelp.open("Airlines", {
					source: e.getSource()
				});
			},
			/**
			 * Open the ValueHelp for Airports
			 * @param {sap.ui.base.Event} e -
			 */
			onOpenAirports: function (e) {
				ValueHelp.open("Airports", {
					source: e.getSource()
				});
			},
			/**
			 * Open the ValueHelp for Railstations
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onOpenRailstations: function (e) {
				ValueHelp.open("Railstations", {
					source: e.getSource(),
					modelData: {
						Supplier: this.getView().getModel("Article").getProperty("/Supplier")
					}
				});
			},
			/**
			 * Open the ValueHelp for Mainarrival or Maindeparture
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onOpenAirportsOrRail: function (e) {
				var sCategory = this.getView().getModel("Article").getProperty("/ArticleCategory");
				if (sCategory.toUpperCase() === "RAIL") {
					$.proxy(this.valueHelp.onOpenRailstations, this)(e);
					return;
				}
				$.proxy(this.valueHelp.onOpenAirports, this)(e);
			}
		}
	});
	return oSegmentController;
}, /* bExport= */ true);