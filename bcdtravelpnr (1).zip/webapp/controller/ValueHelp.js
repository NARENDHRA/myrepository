/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/I18n",
	"../utils/FragmentDialog"
], function (BCDGateway, I18n, FragmentDialog) {
	"use strict";

	/**
	 * Private object 
	 * @type object
	 */
	var _private = {
		// Fragment type
		type: "",
		Dialog: null,
		filter: {
			init: function () {
				_private.filter._currentFilter = {};
			},
			_currentFilter: {},
			/**
			 * Build the filter dynamically and aply it to the ValueHelpAirportsTable
			 */
			executeFilter: function () {
				var aFilter = [];
				for (var sFilter in _private.filter._currentFilter) {
					if (_private.filter._currentFilter.hasOwnProperty(sFilter) === false) {
						continue;
					}
					var sFilterVal = _private.filter._currentFilter[sFilter];
					if (!sFilterVal) {
						continue;
					}
					// if (sFilter === "BcdpropertyCode" && _private.type === "Hotels") { 
					// 	aFilter = []; 
					// 	aFilter.push(new sap.ui.model.Filter(
					// 		sFilter,
					// 		"EQ",
					// 		sFilterVal
					// 	));
					// 	break;
					// }
					aFilter.push(new sap.ui.model.Filter(
						sFilter,
						(["issuedate" ,"Countrycode", "Country2charcode", "Countrycode2char", "Land1", "Supplier", "Bukrs", "ApplicationsId", "Billbackindicator"].indexOf(
							sFilter) !== -1) ? "EQ" : "Contains",
						sFilterVal
					));
					// console.log(
					// 	sFilter,
					// 	(["Countrycode", "Country2charcode", "Countrycode2char", "Supplier"].indexOf(sFilter) !== -1) ? "EQ" : "Contains",
					// 	sFilterVal
					// );
				}
				// dont apply an empty filter on hotels since there are more than 250.000 k hotels in the db..
				// no filter will start a file download of 150mb... x_X
				if (_private.type === "Hotels" && aFilter.length === 0) {
					return;
				}
				// apply filter to the table
				_private.Dialog.byId("ValueHelpTable").getBinding("items").filter(((aFilter.length) ? aFilter : null), sap.ui.model.FilterType.Application);
			},
			/**
			 * Set a specific filter
			 * @param {string} sFilterVal		- Value to filter
			 * @param {string} sFilterColumn	- Field to filter
			 */
			set: function (sFilterVal, sFilterColumn) {
				// clear from filter if not set
				if (!sFilterVal && sFilterColumn in _private.filter._currentFilter) {
					delete _private.filter._currentFilter[sFilterColumn];
				}
				if (sFilterVal) {
					_private.filter._currentFilter[sFilterColumn] = sFilterVal;
				}
				// apply filter
				_private.filter.executeFilter();
			}
		}
	};

	/**
	 * Controller for all ValueHelp dialogs
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.controller.ValueHelp
	 * 
	 * @constructor
	 * @public
	 */
	var oValueHelp = /** @lends com.bcdtravel.pnr.controller.ValueHelp.prototype */ {
		/**
		 * Opens the ValueHelp Dialog
		 * @param {object} sValueHelpFor=Airlines|Airports|Hotels|Railstations|Cities|Suppliers 	-	What ValueHelp
		 * @param {object}		mParameters  					- Parameters
		 * @param {sap.m.Input} mParameters.source				- Input Source object 
		 * @param {function}	[mParameters.onValueSelect]		- callback function when the value is selected
		 * @param {map}			[modelData]						- Dialog View data
		 *	mParamerters.source		object	input source 
		 *  mParmeters.onValueSelect	method	callback functoin when a value is selectd .. first param will have the method
		 * @returns {sap.m.Dialog} -
		 */
		open: function (sValueHelpFor, mParameters) {
			mParameters = (typeof mParameters === "object") ? mParameters : {};
			mParameters.source = ("source" in mParameters && mParameters.source) ? mParameters.source : false;
			mParameters.onValueSelect = ("onValueSelect" in mParameters && typeof mParameters.onValueSelect === "function") ? mParameters.onValueSelect :
				function () {};

			var mDialog = ("modelData" in mParameters && typeof mParameters.modelData === "object") ? mParameters.modelData : {};
			mDialog.inputSource = mParameters.source;
			mDialog.onValueSelect = mParameters.onValueSelect;

			if (["Airlines", "Airports", "Hotels", "Railstations", "Cities", "Suppliers", "Accountinfo"].indexOf(sValueHelpFor) === -1) {
				jQuery.sap.log("Wrong valuehelp type " + sValueHelpFor);
				return;
			}
			_private.type = sValueHelpFor;
			var strFragment = "com.bcdtravel.pnr.view.valueHelp." + sValueHelpFor;

			// init filter (clears any filter)
			_private.filter.init();
			// create dialog
			_private.Dialog = sap.ui.xmlfragment(strFragment, strFragment, this);
			// set Dialog models
			var oDialogModel = new sap.ui.model.json.JSONModel(mDialog);
			_private.Dialog.setModel(oDialogModel, "Dialog");
			// add i18n
			_private.Dialog.setModel(I18n, "i18n");
			// add gateway model
			_private.Dialog.setModel(BCDGateway, "BCDGateway");
			// add dependancy (so that all models can be used)
			//this.getView().addDependent(oDialog);
			// destory dialog after close
			_private.Dialog.attachEvent("afterClose", function () {
				_private.Dialog.destroy();
				_private.Dialog = null;
			});
			// object selector
			_private.Dialog.byId = function (sId) {
				return sap.ui.getCore().byId(sap.ui.core.Fragment.createId(strFragment, sId));
			};
			// return the dialog data (Dialog Model data)
			_private.Dialog.getDialogData = function () {
				return _private.Dialog.getModel("Dialog").getProperty("/");
			};
			// add compact class
			// if (!!this.getView().$().closest(".sapUiSizeCompact").length) {
			// 	oDialog.addStyleClass("sapUiSizeCompact");
			// }
			// open the dialog
			_private.Dialog.open();

			// Railstations default supplier filer 
			if (sValueHelpFor === "Railstations" && "Supplier" in mDialog && mDialog.Supplier !== "") {
				$.proxy(this.Railstations.setSupplier, this)(mDialog.Supplier);
				oDialogModel.setProperty("/hideSupplierFilter", true);
			}
			// Suppliers default Bukrs filer 
			if (sValueHelpFor === "Suppliers" && "Bukrs" in mDialog && mDialog.Bukrs !== "") {
				$.proxy(this.Suppliers.setBukrs, this)(mDialog.Bukrs);
				oDialogModel.setProperty("/hideBukrsFilter", true);
			}
			// Suppliers Billbackindicator
			if (sValueHelpFor === "Suppliers" && "Billbackindicator" in mDialog) {
				$.proxy(this.Suppliers.setBillbackindicator, this)(mDialog.Billbackindicator);
			}
			// Hotels needs the applicationsID
			if (sValueHelpFor === "Hotels" && "ApplicationsId" in mDialog && mDialog.ApplicationsId !== "") {
				// add to filter
				_private.filter._currentFilter.ApplicationsId = mDialog.ApplicationsId;
			}
			// AccountInfo needs the IssueDate
			if (sValueHelpFor === "Accountinfo" && "IssueDate" in mDialog && mDialog.IssueDate !== "") {
				$.proxy(this.Accountinfo.setIssueDate, this)(mDialog.IssueDate);
				// $.proxy(_private.filter.set, this)(e.getParameter("value"), "issuedate");				
			}
			// return
			return _private.Dialog;
		},

		/**
		 * Event for Accountinfo.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Accountinfo
		 */
		Accountinfo: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Accountinfo.prototype */ {
			_gcnCheckDialog: null,
			gcnCheckDialog: function (mData, mParams) {
				mData.gcnNumberToCheck = "";
				mData.GCNshowBtnPassed = false;
				mData.GCNshowBtnReselect = true;
				_private.Dialog.setVisible(false);
				if (mData.gcnNumber === "") {
					mParams.success();
				} else {
					oValueHelp.Accountinfo._gcnCheckDialog = FragmentDialog.open("com.bcdtravel.pnr.view.valueHelp.AccountinfoGCNCheck", {
						i18nModel: I18n,
						dialogData: mData,
						controller: {
							onCheckGCN: function (e) {
								var oSrc = e.getSource(),
									sValue = e.getSource().getValue(),
									oDialogModel = oValueHelp.Accountinfo._gcnCheckDialog.getModel("Dialog");
								if (sValue === mData.gcnNumber) {
									oSrc.setValueState("Success");
									oDialogModel.setProperty("/GCNshowBtnPassed", true);
									oDialogModel.setProperty("/GCNshowBtnReselect", false);
								} else {
									oDialogModel.setProperty("/GCNshowBtnPassed", false);
									oDialogModel.setProperty("/GCNshowBtnReselect", true);
									oSrc.setValueState("Warning");
								}
							},
							onSelect: function () {
								oValueHelp.Accountinfo._gcnCheckDialog.close();
								mParams.success();
							},
							onClose: function () {
								oValueHelp.Accountinfo._gcnCheckDialog.close();
								_private.Dialog.setVisible(true);
							}
						}
					});
				}
			},

			onSelect: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				oValueHelp.Accountinfo.gcnCheckDialog(m, {
					success: function () {
						_private.Dialog.setVisible(true);
						_private.Dialog.close();
						if (oInputSource) {
							oInputSource.setValue(m.accountid);
							oInputSource.setDescription(m.businesspartner);
						}
						onSelect(m);
					},
					error: function () {
						_private.Dialog.setVisible(true);
						console.log("ERROR");
					}
				});
			},
			onFilterAccount: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "accountid");
			},
			onFilterBusinessPartnerId: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "businesspartnerid");
			},
			onFilterBusinessPartner: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "businesspartner");
			},
			/**
			 * Filter on Bukrs
			 * @param {string} sBukrs - Bukrs (Company Code)
			 */
			setIssueDate: function (sIssueDate) {
				// $.proxy(_private.filter.set, this)(sIssueDate, "issuedate");
				 $.proxy(_private.filter.set, this)(sIssueDate.toISOString().slice(0,10).replace(/-/g, ""), "issuedate");
			}
		},

		/**
		 * Events for Airlines.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Airlines
		 */
		Airlines: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Airlines.prototype */ {
			/**
			 * Event handler if the Airlinename filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeAirlinename: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Airlinename");
			},
			/**
			 * Event handler if the IATACode filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeIATACode: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Iatacode");
			},
			/**
			 * Event handler if the Country filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCountry: function (e) {
				$.proxy(_private.filter.set, this)(e.getSource().getSelectedKey(), "Country2charcode");
			},
			/**
			 * Event handler if a Airline is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectAirline: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				if (oInputSource) {
					oInputSource.setValue(m.Iatacode);
					oInputSource.setDescription(m.Airlinename);
				}
				onSelect(m);
				_private.Dialog.close();
			}
		},

		/**
		 * Events for Airports.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Airports
		 */
		Airports: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Airports.prototype */ {
			/**
			 * Exec filter on Airportcode
			 * @param {string} sAirportcode - Airport IATA code
			 */
			setAirportcode: function (sAirportcode) {
				// clear from filter if not set
				if (!sAirportcode && "Airportcode" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Airportcode;
				}
				if (sAirportcode) {
					_private.filter._currentFilter.Airportcode = sAirportcode;
				}
				// apply filter
				_private.filter.executeFilter();
			},
			/**
			 * Exec filter on Airportname
			 * @param {string} sAirportname - Airport name
			 */
			setAirportname: function (sAirportname) {
				// clear from filter if not set
				if (!sAirportname && "Airportname" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Airportname;
				}
				if (sAirportname) {
					_private.filter._currentFilter.Airportname = sAirportname;
				}
				// apply filter
				_private.filter.executeFilter();
			},
			/**
			 * Exec filter on City
			 * @param {string} sCity - City
			 */
			setCity: function (sCity) {
				// clear from filter if not set
				if (!sCity && "Airportcity" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Airportcity;
				}
				if (sCity) {
					// add to filter
					_private.filter._currentFilter.Airportcity = sCity;
				}
				// apply filter
				_private.filter.executeFilter();
			},
			/**
			 * Exec filter on countrycode
			 * @param {string} sCountryCode	 - 2 char country code
			 */
			setCountrycode: function (sCountryCode) {
				// clear from filter if not set
				if (!sCountryCode && "Countrycode" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Countrycode;
				}
				// clear city filter if a city has changed
				if (sCountryCode) {
					// add to filter
					_private.filter._currentFilter.Countrycode = sCountryCode;
					// reset the city filter
					delete _private.filter._currentFilter.Airportcity;
				}
				// apply filter
				_private.filter.executeFilter();
				// filter the city dropdown
				var oCityComboBox = _private.Dialog.byId("ValueHelpCityComboBox");
				oCityComboBox.setBusyIndicatorDelay(0);
				oCityComboBox.setEnabled((sCountryCode) ? true : false);
				if (sCountryCode) {
					oCityComboBox.getBinding("items").attachEventOnce("dataRequested", function () {
						oCityComboBox.setBusy(true);
					});
					oCityComboBox.getBinding("items").attachEventOnce("dataReceived", function () {
						oCityComboBox.setBusy(false);
					});
					oCityComboBox.getBinding("items").filter(((sCountryCode) ? [new sap.ui.model.Filter("Countrycode", "EQ", sCountryCode)] : null),
						sap.ui.model.FilterType.Application);
				} else if ("Airportcity" in _private.filter._currentFilter) {
					oCityComboBox.setSelectedKey("");
					delete _private.filter._currentFilter.Airportcity;
				}
			},
			/**
			 * Event handler if the Airportname filter changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeAirportname: function (e) {
				this.Airports.setAirportname(e.getParameter("value"));
			},
			/**
			 * Event handler if the Airportcode filter changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeAirportcode: function (e) {
				this.Airports.setAirportcode(e.getParameter("value"));
			},
			/**
			 * Event handler if the Airportname filter changes
			 *
			 * Countries are only filtered equal so we need the selected key to create the filter
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCountry: function (e) {
				this.Airports.setCountrycode(e.getSource().getSelectedKey());
			},
			/**
			 * Event handler if the City filter changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCity: function (e) {
				this.Airports.setCity(e.getParameter("value"));
			},
			/**
			 * Event handler if a Airport is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectAirport: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				if (oInputSource) {
					oInputSource.setValue(m.Airportcode);
					oInputSource.setDescription(m.Airportname);
					oInputSource.fireChange();
				}
				onSelect(m);
				_private.Dialog.close();
			}
		},

		/**
		 * Events for Airports.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Cities
		 */
		Cities: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Cities.prototype */ {
			/**
			 * Event handler if the City filter changes
			 * @param {sap.ui.base.Event} e -
			 */
			onFilterCity: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "City");
			},
			/**
			 * Event handler if the Country filter changes
			 * @param {sap.ui.base.Event} e -
			 */
			onFilterCountry: function (e) {
				$.proxy(_private.filter.set, this)(e.getSource().getSelectedKey(), "Countrycode");
			},
			/**
			 * Event handler a City is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectCity: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				if (oInputSource) {
					oInputSource.setValue(m.City);
				}
				onSelect(m);
				_private.Dialog.close();
			}
		},

		/**
		 * Events for Hotels.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Hotels
		 */
		Hotels: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Hotels.prototype */ {

			/**
			 * Filter results on city
			 * @param {string} sCity - City
			 */
			setCity: function (sCity) {
				// clear from filter if not set
				if (!sCity && "City" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.City;
				}
				if (sCity) {
					// add to filter
					_private.filter._currentFilter.City = sCity;
				}
				// apply filter
				_private.filter.executeFilter();
			},
			/**
			 * filter on countrycode
			 * @param {string} sCountryCode  -	2 char country code
			 */
			setCountrycode: function (sCountryCode) {
				// clear from filter if not set
				if (!sCountryCode && "Countrycode2char" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Countrycode2char;
				}
				// clear city filter if a city has changed
				if (sCountryCode) {
					// add to filter
					_private.filter._currentFilter.Countrycode2char = sCountryCode;
					// reset the city filter
					delete _private.filter._currentFilter.City;
				}
				// apply filter
				_private.filter.executeFilter();
				// filter the city dropdown
				var oCityComboBox = _private.Dialog.byId("ValueHelpCityComboBox");
				oCityComboBox.setBusyIndicatorDelay(0);
				oCityComboBox.setEnabled((sCountryCode) ? true : false);
				if (sCountryCode) {
					oCityComboBox.getBinding("items").attachEventOnce("dataRequested", function () {
						oCityComboBox.setBusy(true);
					});
					oCityComboBox.getBinding("items").attachEventOnce("dataReceived", function () {
						oCityComboBox.setBusy(false);
					});
					oCityComboBox.getBinding("items").filter(((sCountryCode) ? [new sap.ui.model.Filter("Countrycode", "EQ", sCountryCode)] : null),
						sap.ui.model.FilterType.Application);
				} else if ("City" in _private.filter._currentFilter) {
					oCityComboBox.setSelectedKey("");
					delete _private.filter._currentFilter.City;
				}
			},
			/**
			 * Countries are only filtered by equal so we need the selected key to create the filter
			 * Event handler if a Country has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCountry: function (e) {
				this.Hotels.setCountrycode(e.getSource().getSelectedKey());
			},
			/**
			 * Event handler if the city filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCity: function (e) {
				this.Hotels.setCity(e.getParameter("value"));
			},
			/**
			 * Event handler if the postalcode filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangePostalCode: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Postalcode");
			},
			/**
			 * Event handler if the PorpertyName filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangePropertyName: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Actualpropertyname");
			},
			/**
			 * Event handler if the MasterChaincode filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeMasterChainCode: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Masterchaincode");
			},
			/**
			 * Event handler if the BCD Property Id filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeBCDPropertyCode: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "BcdpropertyCode");
			},
			/**
			 * Event handler a hotel is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectHotel: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					//	= mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				onSelect(m);
				_private.Dialog.close();
			}
		},

		/**
		 * Events for Railstaitions
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Railstations
		 */
		Railstations: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Railstations.prototype */ {
			/**
			 * Event handler if the country filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCountry: function (e) {
				$.proxy(_private.filter.set, this)(e.getSource().getSelectedKey(), "Land1");
			},
			/**
			 * Event handler if the Name filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeName: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Stationname");
			},
			/**
			 * Event handler if the CRS Code filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCRSCode: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Stationcrscode");
			},
			/**
			 * Event handler if the Supplier filter has changed
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeSupplier: function (e) {
				$.proxy(this.Railstations.setSupplier, this)(e.getParameter("value"));
			},
			/**
			 * Exec the Supplier fileter
			 * @param {string} sSupplier - Supplier
			 */
			setSupplier: function (sSupplier) {
				$.proxy(_private.filter.set, this)(sSupplier, "Supplier");
			},
			/**
			 * Event handler if a Railstation is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectStation: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				if (oInputSource) {
					oInputSource.setValue(m.Stationcrscode);
					oInputSource.setDescription(m.Stationname);
					oInputSource.fireChange();
				}
				onSelect(m);
				_private.Dialog.close();
			}
		},

		/**
		 * Events for Suppliers.fragment.xml
		 * @namespace com.bcdtravel.pnr.controller.ValueHelp.Suppliers
		 */
		Suppliers: /** @lends com.bcdtravel.pnr.controller.ValueHelp.Suppliers.prototype */ {
			/**
			 * Filter on city
			 * @param {string} sCity - City
			 */
			setCity: function (sCity) {
				// clear from filter if not set
				if (!sCity && "Ort01" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Ort01;
				}
				if (sCity) {
					// add to filter
					_private.filter._currentFilter.Ort01 = sCity;
				}
				// apply filter
				_private.filter.executeFilter();
			},
			/**
			 * Filter on countrycode
			 * @param {string} sCountryCode - 2 char country code
			 */
			setCountrycode: function (sCountryCode) {
				// clear from filter if not set
				if (!sCountryCode && "Land1" in _private.filter._currentFilter) {
					delete _private.filter._currentFilter.Land1;
				}
				// clear city filter if a city has changed
				if (sCountryCode) {
					// add to filter
					_private.filter._currentFilter.Land1 = sCountryCode;
					// reset the city filter
					delete _private.filter._currentFilter.City;
				}
				// apply filter
				_private.filter.executeFilter();
				// filter the city dropdown
				var oCityComboBox = _private.Dialog.byId("ValueHelpCityComboBox");
				oCityComboBox.setBusyIndicatorDelay(0);
				oCityComboBox.setEnabled((sCountryCode) ? true : false);
				if (sCountryCode) {
					oCityComboBox.getBinding("items").attachEventOnce("dataRequested", function () {
						oCityComboBox.setBusy(true);
					});
					oCityComboBox.getBinding("items").attachEventOnce("dataReceived", function () {
						oCityComboBox.setBusy(false);
					});
					oCityComboBox.getBinding("items").filter(((sCountryCode) ? [new sap.ui.model.Filter("Countrycode", "EQ", sCountryCode)] : null),
						sap.ui.model.FilterType.Application);
				} else if ("City" in _private.filter._currentFilter) {
					oCityComboBox.setSelectedKey("");
					delete _private.filter._currentFilter.City;
				}
			},
			/**
			 * Filter on Bukrs
			 * @param {string} sBukrs - Bukrs (Company Code)
			 */
			setBukrs: function (sBukrs) {
				$.proxy(_private.filter.set, this)(sBukrs, "Bukrs");
			},
			/**
			 * Filter on Billbackindicator
			 * @param {string} sBillbackindicator -  Billbackindicator
			 */
			setBillbackindicator: function (sBillbackindicator) {
				$.proxy(_private.filter.set, this)(sBillbackindicator, "Billbackindicator");
			},
			/**
			 * Event Handler if the input filter country changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCountry: function (e) {
				this.Suppliers.setCountrycode(e.getSource().getSelectedKey());
			},
			/**
			 * Event Handler if the input filter city changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeCity: function (e) {
				this.Suppliers.setCity(e.getParameter("value"));
			},
			/**
			 * Event Handler if the input filter country changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeBukrs: function (e) {
				$.proxy(this.Suppliers.setBukrs, this)(e.getParameter("value"), "Bukrs");
			},
			/**
			 * Event Handler if the input filter Name1 changes
			 * @param {sap.ui.base.Event} e -
			 */
			onChangeName1: function (e) {
				$.proxy(_private.filter.set, this)(e.getParameter("value"), "Name1");
			},
			/**
			 * Event Handler a supplier is selected
			 * @param {sap.ui.base.Event} e -
			 */
			onSelectSupplier: function (e) {
				var oItem = e.getParameter("listItem"),
					oCntx = oItem.getBindingContext("BCDGateway"),
					m = oCntx.getModel().getProperty(oCntx.getPath()),
					mDialog = _private.Dialog.getModel("Dialog"),
					oInputSource = mDialog.getProperty("/inputSource"),
					onSelect = mDialog.getProperty("/onValueSelect");
				if (oInputSource) {
					oInputSource.setValue(m.Supplier);
					oInputSource.setDescription(m.Name1);
				}
				onSelect(m);
				_private.Dialog.close();
			}
		},

		//  Oude manier gebruikt de RailsSet (ZHY_MA_RAILSTATIONS) :: laat er in misschien veranderd dit nog 
		//	Railstations: {
		// 	setCity: function(sCity) {
		// 		// clear from filter if not set
		// 		if (! sCity && "City" in _private.filter._currentFilter) {
		// 			delete _private.filter._currentFilter.City;
		// 		}
		// 		if (sCity) {
		// 			// add to filter
		// 			_private.filter._currentFilter.City = sCity;
		// 		}
		// 		// apply filter
		// 		_private.filter.executeFilter();
		// 	},
		// 	/**
		// 	 * filter on countrycode
		// 	 * @param string sCountryCode	2 char country code
		// 	 */
		// 	setCountrycode: function(sCountryCode) {
		// 		// clear from filter if not set
		// 		if (! sCountryCode && "Countrycode2char" in _private.filter._currentFilter) {
		// 			delete _private.filter._currentFilter.Countrycode2char;
		// 		}
		// 		// clear city filter if a city has changed
		// 		if (sCountryCode) {
		// 			// add to filter
		// 			_private.filter._currentFilter.Countrycode2char = sCountryCode;
		// 			// reset the city filter
		// 			delete _private.filter._currentFilter.City;
		// 		}
		// 		// apply filter
		// 		_private.filter.executeFilter();
		// 		// filter the city dropdown
		// 		var oCityComboBox = _private.Dialog.byId("ValueHelpCityComboBox");
		// 		oCityComboBox.setBusyIndicatorDelay(0);
		// 		oCityComboBox.setEnabled((sCountryCode) ? true : false);
		// 		if (sCountryCode) {
		// 			oCityComboBox.getBinding("items").attachEventOnce("dataRequested", function() {
		// 				oCityComboBox.setBusy(true);
		// 			});
		// 			oCityComboBox.getBinding("items").attachEventOnce("dataReceived", function() {
		// 				oCityComboBox.setBusy(false);
		// 			});
		// 			oCityComboBox.getBinding("items").filter(((sCountryCode) ? [new sap.ui.model.Filter("Countrycode2char", "EQ", sCountryCode)] : null), sap.ui.model.FilterType.Application);
		// 		} else	if ("City" in _private.filter._currentFilter) {
		// 			oCityComboBox.setSelectedKey("");
		// 			delete _private.filter._currentFilter.City;
		// 		}
		// 	},
		// 	onSelectStation: function(e) {
		// 		var oItem			= e.getParameter("listItem"),
		// 			oCntx			= oItem.getBindingContext("BCDGateway"),
		// 			m				= oCntx.getModel().getProperty(oCntx.getPath()),
		// 			mDialog			= _private.Dialog.getModel("Dialog"),
		// 			oInputSource	= mDialog.getProperty("/inputSource"),
		// 			onSelect		= mDialog.getProperty("/onValueSelect");
		// 		if (oInputSource) {
		// 			oInputSource.setValue(m.Railstationname);
		// 			oInputSource.setDescription("");
		// 			oInputSource.fireChange();
		// 		}
		// 		onSelect(m);
		// 		_private.Dialog.close();
		// 	},
		// 	/**
		// 	 * Countries are only filtered by equal so we need the selected key to create the filter
		// 	 */
		// 	onChangeCountry: function(e) {
		// 		this.Railstations.setCountrycode(e.getSource().getSelectedKey());
		// 	},
		// 	onChangeCity: function(e) {
		// 		this.Railstations.setCity(e.getParameter("value"));
		// 	}
		// 	//onChangeName
		// 	//onChangeStationId
		// },

		/**
		 * Close the dialog
		 */
		onClose: function () {
			_private.Dialog.close();
		}
	};
	return oValueHelp;
});