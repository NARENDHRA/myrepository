/* eslint sap-no-element-creation:0 */
/* global _ */
/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
		"com/bcdtravel/pnr/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"com/bcdtravel/pnr/model/BCDGateway",
		"com/bcdtravel/pnr/model/User",
		"com/bcdtravel/pnr/model/I18n",
		"com/bcdtravel/pnr/model/DisplaySettings",
		"com/bcdtravel/pnr/model/Mapping",
		"com/bcdtravel/pnr/model/Article",
		"com/bcdtravel/pnr/model/Mandatory",
		"com/bcdtravel/pnr/controller/ValueHelp",
		"./ArticleCopy",
		"sap/m/MessageBox",
		"./Invoice"
	], function (BaseController, JSONModel, BCDGateway, User, I18n, DisplaySettings, MappingModel, ArticleModel, MandatoryModel, ValueHelp,
		ArticleCopy, MessageBox, Invoice) {
		"use strict";

		/**
		 * Controller for the Article View
		 * 
		 * @class 		
		 * @alias 		com.bcdtravel.pnr.controller.Article
		 * @extends 	com.bcdtravel.pnr.controller.BaseController
		 * @requires 	underscore.js
		 * 
		 * @constructor
		 * @public
		 */
		var oArticleController = BaseController.extend("com.bcdtravel.pnr.controller.Article", /** @lends com.bcdtravel.pnr.controller.Article.prototype */ {

			/* privates */
			// ids are set in onRouteMatched method
			_bookingId: null,
			_articleId: null,

			/**
			 * Show a loading indicator over the entire Page
			 * @param {boolean} [b=false] - if true the loading indicator is showed
			 */
			_showPageBusyIndicator: function (b) {
				this.getView().byId("ArticlePage").setBusy(b);
			},

			/**
			 * Helper method for onSaveReferences and onSaveSupplements
			 * Batch saves the References or Supplements data
			 * @param {string} sReferencesOrSupplements=References|Supplements	- Model Name
			 * @param {object} [mParams]							- Parameters
			 * @param {fnSuccessErrorCallback} [mParams.success]	- success callback
			 * @param {fnSuccessErrorCallback} [mParams.error]		- error callback
			 */
			_excuteBatch: function (sReferencesOrSupplements, mParams) {
				var mData = this.getView().getModel(sReferencesOrSupplements).getProperty("/"),
					that = this,
					url = "";
				if (_.size(mData) === 0) {
					return;
				}
				// show page loader
				this._showPageBusyIndicator(true);
				// temp change odata service to batch processing
				BCDGateway.setUseBatch(true);
				// set group id
				BCDGateway.setDeferredGroups([sReferencesOrSupplements]);
				for (var i in mData) {
					if (sReferencesOrSupplements === "References") {
						url = "/referenceSet(BookingsId='" + mData[i].BookingsId + "',ArticlesId=" + mData[i].ArticlesId + ",ReferencesId='" + mData[i].ReferencesId +
							"')";
					} else if (sReferencesOrSupplements === "Supplements") {
						url = "/supplementSet(BookingsId='" + mData[i].BookingsId + "',ArticlesId=" + mData[i].ArticlesId + ",TaxessupplementId=" + mData[
							i].TaxessupplementId + ")";
					}
					BCDGateway.update(
						url,
						mData[i], {
							groupId: sReferencesOrSupplements
						}
					);
				}
				BCDGateway.submitChanges({
					groupId: sReferencesOrSupplements,
					success: function () {
						that._showPageBusyIndicator(false);
						BCDGateway.setUseBatch(false);
						// reload data
						// for supplements only reload the supplements else its possible that the releasebillback fields got reset
						if (sReferencesOrSupplements === "Supplements") {
							$.proxy(that.models.reloadSupplements, that)();
						} else {
							$.proxy(that.models.reload, that)();
						}
						if ("success" in mParams && typeof mParams.success === "function") {
							mParams.success.apply(that, arguments);
						}
					},
					error: function () {
						that._showPageBusyIndicator(false);
						BCDGateway.setUseBatch(false);
						if ("error" in mParams && typeof mParams.error === "function") {
							mParams.error.apply(that, arguments);
						}
					}
				});
			},

			_formcontainers: function () {
				/*
				var aFormContainers = this.getView().byId("ArticleForm").getFormContainers();
				$.each(aFormContainers, function(index, oFormContainer) {
					var aFormElements = oFormContainer.getFormElements();
					//console.log(oFormContainer.getId());
					//console.log("length", aFormElements.length);
					if (aFormElements.length === 0) { return; };
					var bVisible = false;
					for (var i in aFormElements) { 
						//console.log(aFormElements[i].getId(), aFormElements[i].getVisible());
						if (aFormElements[i].getVisible()) {
							bVisible = true;
						}	
					}
					oFormContainer.setVisible(bVisible);
					//console.log("visible " + bVisible);
				});
				*/
			},

			/* Controller Event callbacks */

			/**
			 * Called when the Article View is Initiazed
			 */
			onInit: function () {
				// init models
				$.proxy(this.models.init, this)();
				// init icontabbar
				$.proxy(this.iconTabBar.init, this)();
				// attach route matched
				//this._getRouter().getTarget("Article").attachDisplay($.proxy(this.onRouteMatched, this));
				this._getRouter().attachRouteMatched(this.onRouteMatched, this);
			},

			onAfterRendering: function () {
				// 0333 - Fiori Product Remarks | max length 50 per line
				var iMaxLength = 50;
				$("body").on("input focus keydown keyup", "#" + this.getView().byId("ArticleProductremarks").getId() + " textarea", function () {
					//Split with \n carriage return
					var aLines = $(this).val().split("\n"),
						aNewLines = [];
					for (var i = 0; i < aLines.length; i++) {
						while (aLines[i]) {
							if (aLines[i].length < iMaxLength) {
								aNewLines.push(aLines[i]);
								break;
							} else {
								aNewLines.push(aLines[i].substr(0, iMaxLength));
								aLines[i] = aLines[i].substr(iMaxLength);
							}
						}
					}
					$(this).val(aNewLines.join("\n"));
				});
			},

			/**
			 * Calback method, called when the article page route is called
			 * @param {object} e - Routematched event
			 */
			onRouteMatched: function (e) {
				// Add by naresh Ponnnada to displya notes in artical section
				var oNotesListId = this.getView().byId("ListNotesIdPNR");
				var oIfareModel = new sap.ui.model.json.JSONModel();
				var oIFareRechargeModel = new sap.ui.model.json.JSONModel();
				var RemarkModel = new sap.ui.model.json.JSONModel();
				var oRmarkcode2Model = new sap.ui.model.json.JSONModel();
				var oRmarkcode3Model = new sap.ui.model.json.JSONModel();
				var sRouteName = e.getParameter("name"),
					mData = e.getParameter("arguments");
				this.oArticelCategory = mData.ArticleCategory;
				this.oApplicationId = mData.ApplicationId;
				// check for valid route
				if (["Article", "NewArticle"].indexOf(sRouteName) === -1) {
					return;
				}
				// check bookingsId
				if (!("bookingId" in mData)) {
					return;
				}
				// set the new booking and articleID
				this._bookingId = mData.bookingId;
				// Existing Article
				if (sRouteName === "Article" && "articleId" in mData) {
					//Add by Naresh Ponnada for IfarePcc control change form input to Selct(H0048 - IFARE Dropdown).
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("ApplicationsId", sap.ui.model.FilterOperator.EQ, mData.ApplicationId));

					aFilters.push(new sap.ui.model.Filter("TabnameBs", sap.ui.model.FilterOperator.EQ, "ZHY_ARTICLES"));

					aFilters.push(new sap.ui.model.Filter("ArticleCategory", sap.ui.model.FilterOperator.EQ, mData.ArticleCategory));
					// // aFilters.push(new sap.ui.model.Filter("FieldnameBs", sap.ui.model.FilterOperator.EQ, "IFAREPCC"));
					var that = this;
					BCDGateway.read("/mapSet", {
						filters: aFilters,
						success: function (odata) {
							var oIfarePCCArry = [];
							var oIfareRechareAccountArray = [];
							var RemarkArray = [];
							var Remarkcode2 = [];
							var Remarkcode3 = [];
							for (var i = 0; i < odata.results.length; i++) {
								if (odata.results[i].FieldnameBs === "IFARERECHARGEACCOUNT") {
									delete(odata.results[i].__metadata);
									oIfareRechareAccountArray.push(odata.results[i]);
								} else if (odata.results[i].FieldnameBs === "IFAREPCC") {
									delete(odata.results[i].__metadata);
									oIfarePCCArry.push(odata.results[i]);
								} else if (odata.results[i].FieldnameBs === "REMARKCODE1") {
									delete(odata.results[i].__metadata);
									RemarkArray.push(odata.results[i]);
								} else if (odata.results[i].FieldnameBs === "REMARKCODE2") {
									delete(odata.results[i].__metadata);
									Remarkcode2.push(odata.results[i]);
								} else if (odata.results[i].FieldnameBs === "REMARKCODE3") {
									delete(odata.results[i].__metadata);
									Remarkcode3.push(odata.results[i]);
								}
							}
							if (oIfarePCCArry.length > 0) {
								oIfareModel.setData(oIfarePCCArry);
							}
							if (oIfareRechareAccountArray.length > 0) {
								oIFareRechargeModel.setData(oIfareRechareAccountArray);
							}
							if (RemarkArray.length > 0) {
								RemarkModel.setData(RemarkArray);
							}
							if (Remarkcode2.length > 0) {
								oRmarkcode2Model.setData(RemarkArray);
							}
							if (Remarkcode3.length > 0) {
								oRmarkcode3Model.setData(RemarkArray);
							}
							that.getView().setModel(RemarkModel, "RemarkModel");
							that.getView().setModel(oRmarkcode2Model, "Rmarkcode2Model");
							that.getView().setModel(oRmarkcode3Model, "Rmarkcode3Model");
							that.getView().setModel(oIfareModel, "oIfareModels");
							that.getView().setModel(oIFareRechargeModel, "oIFareRCGAccountModel");
						},
						error: function (error) {}
					});
					// SOC : TO bind the notes for notes section 
					var spath = "BCDGateway>/NotesSet";
					var aFilter = [];
					this.oarticalIDt = mData.articleId;
					var oREID = this._bookingId + "_" + this.oarticalIDt;
					aFilter.push(new sap.ui.model.Filter("Reqid", sap.ui.model.FilterOperator.EQ, oREID));
					aFilter.push(new sap.ui.model.Filter("Appid", sap.ui.model.FilterOperator.EQ, "ZHY_APP_PNR"));
					oNotesListId.bindItems({
						path: spath,
						filters: aFilter,
						template: new sap.m.FeedListItem({
							senderActive: false,
							sender: "{BCDGateway>Username}",
							timestamp: {
								parts: [{
									path: "BCDGateway>Crdate"
								}, {
									path: "BCDGateway>Crtime"
								}],
								formatter: function (date, time) {
									var times = new Date(time.ms);
									var C = times.getUTCHours() + ":" + String(times.getUTCMinutes()).padStart(2, "0");
									var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
										style: "medium",
										UTC: true
									});
									var dateStr = dateFormat.format(date).split(",")[0];
									var fine = dateStr + " " + C + " " + "CET";
									return fine;
								}
							},
							text: "{BCDGateway>Znotes}",
							info: "{BCDGateway>Userrole}"
						})
					});
					// EOC:  Binidng for notes list in notes section 
					// open the first tab only if the bookingId or articleId has changed
					if (this._bookingsId !== null && this._articleId !== null && (this._bookingId !== mData.bookingId || this._articleId !== mData.articleId)) {
						$.proxy(this.iconTabBar.openFirstTab, this)();
					}
					this._articleId = mData.articleId;
					// load article data
					$.proxy(this.models.loadByBookingIdAndArticleId, this)(mData.bookingId, mData.articleId);
				} else if (sRouteName === "NewArticle") {
					// open first tab
					$.proxy(this.iconTabBar.openFirstTab, this)();
					// open newarticle dialog
					$.proxy(this.newArticleDialog.open, this)();
				}
			},
			// Add by Naresh Ponnada for to save the Notes 
			onPostNotes: function (evt) {
				var oListPNRNotesId = this.getView().byId("ListNotesIdPNR");
				var oUserNotes = evt.getParameter("value").trim();
				var objParm = {
					"Appid": "ZHY_APP_PNR",
					"Reqid": this._bookingId + "_" + this.oarticalIDt,
					"Znotes": oUserNotes
				};
				BCDGateway.create("/NotesSet", objParm, {
					success: function (data) {
						sap.m.MessageToast.show("Successfully uploaded the Notes");
						oListPNRNotesId.getModel("BCDGateway").refresh();
					},
					error: function (error) {
						sap.m.MessageToast.show("Error While Post the Notes");
					}
				});
			},
			onUpdateCommestLists: function (evt) {
				var tot = evt.getParameter("total");
				var s = "Notes" + "(" + tot + ")";
				evt.getSource().getParent().setText(s);
			},
			//Add by Naresh Ponnada for change event for ifarepcc:(H0048 - IFARE Dropdown).
			onChangeRemarkcode1: function (evt) {
				var ostate = evt.getSource().getValueState();
				var oselKey = evt.getParameter("selectedItem").getProperty("key");
				if (ostate === "Error") {
					evt.getSource().setValueState("None");
				}
			},
			onChangeIfarepcc: function (evt) {
				var ostate = evt.getSource().getValueState();
				var oselKey = evt.getParameter("selectedItem").getProperty("key");
				var isVisBtn = evt.getSource().getParent().getAggregation("fields")[1].getVisible();
				if (oselKey) {
					if (!isVisBtn) {
						evt.getSource().getParent().getAggregation("fields")[1].setVisible(true);
					}
				} else {
					evt.getSource().getParent().getAggregation("fields")[1].setVisible(false);
				}
				if (ostate === "Error") {
					evt.getSource().setValueState("None");
				}
			},

			/* User interaction events */

			/**
			 * Method called when the cancel button is clicked
			 * Calls the method which resets and reloads all view data
			 */
			onCancel: function () {
				// allow the router to navigate
				this._allowRouterNavigation();
				if (this.getView().getModel("Article").isNew() && $.proxy(this.iconTabBar.getOpenTab, this)() === "ArticleData") {
					this.onNavToBooking();
				} else {
					$.proxy(this.models.reload, this)();
				}
			},

			/**
			 * If the ArticleType = VISA and the Ticketreference has the word "Consular" in it
			 * You are not allowed to change the value to Domestic
			 */
			onChangeDomintindicator: function (e) {
				var oArticleModel = this.getView().getModel("Article"),
					mArticle = oArticleModel.getProperty("/");
				if (mArticle.ArticleType === "VISA" && mArticle.Ticketreference.indexOf("Consular") !== -1 && e.getParameter("selectedItem") && e.getParameter(
						"selectedItem").getKey() === "Domestic") {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						I18n.getText("Article.Warning.ConsularDomint"), {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					// reset
					oArticleModel.setProperty("/Domintindicator", "");
					return;
				}
				this.onChangeCheckError(e);
			},

			/**
			 * Event listener for when the Maindeparture has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onPressDecrementConjunction: function (evt) {
				var oInt = this.getView().byId("stepInput");
				var oVal1 = oInt.getValue();
				oVal1--;
				oInt.setValue(oVal1);
				if (oVal1 >= 0) {
					oInt.setValue(oVal1);
				} else if (oVal1 < 0) {
					var nx = 0;
					oInt.setValue(nx);
				}
			},
			onPressDecrementNumberofpeople: function (evt) {
				var oInt = this.getView().byId("ArticleNumberofpeople");
				var oVal1 = oInt.getValue();
				oVal1--;
				oInt.setValue(oVal1);
				if (oVal1 >= 0) {
					oInt.setValue(oVal1);
				} else if (oVal1 < 0) {
					var nx = 0;
					oInt.setValue(nx);
				}
			},
			onPressAddConjunction: function (evt) {
				var oInt = this.getView().byId("stepInput");
				var oVal = oInt.getValue();
				oVal++;
				oInt.setValue(oVal);
			},
			onPressAddNumberofpeople: function (evt) {
				var oInt = this.getView().byId("ArticleNumberofpeople");
				var oVal = oInt.getValue();
				oVal++;
				oInt.setValue(oVal);
			},
			onChangeConjunction: function (e) {
				// sapui5.version < 1.50 has an error where the value not automatically is set if there is a change event bound to the object
				var sVal = e.getSource().getValue();
				this.getView().getModel("Article").setProperty("/Conjunction", sVal);
				this.onChangeCheckError(e);
			},
			/**
			 * This event is called when a Article value changes (by user : sap.m.Select sap.m.DatePicker sap.m.Input)
			 * If it has an error in the errorSet, the value state is changed to None to indicate that the error will be resolved on save 
			 * @param {sap.ui.base.Event} e - onchanged event 
			 */
			onChangeCheckError: function (e) {
				var oSrc = e.getSource(),
					sPath = oSrc.getBindingPath("value"),
					oArticleErrors = this.getView().getModel("ArticleErrors"),
					sVal;
				switch (oSrc.getMetadata().getName()) {
				case "sap.m.Input":
				case "sap.m.DatePicker":
					sVal = oSrc.getValue();
					break;
				case "sap.m.Select":
					sVal = oSrc.getSelectedKey();
					sPath = oSrc.getBindingPath("selectedKey");
					// sap ui5 version < 1.50 has an error where the valueStateText doesnt hide when the valuestate is set to None
					// https://github.com/SAP/openui5/commit/703e4938a97d6d7974581dcb733454ab069f5ac4 fixes the problem
					oSrc.closeValueStateMessage();
					break;
				}
				// only change the value state if there was an error indication from the backend
				// (it could be a new article)
				if (oArticleErrors.getProperty(sPath)) {
					oSrc.setValueState(((sVal) ? "None" : "Error"));
					// If a user solved an error, the valueStateText messags was still popping, though the valueState was set to None.
					// The fix below will work in all current and future versions
					// Note: The gateway is using ui5 version 1.44.1 and as of version 1.48.3 this was fixed by SAP (see release notes "valueStateText to be hidden when valueState is None")
					// only do this on live change
					if (e.getId() === "liveChange") {
						var tmp = document.createElement("input");
						document.body.appendChild(tmp);
						tmp.focus();
						document.body.removeChild(tmp);
						// set back the focus to the input field
						oSrc.focus();
					}
				}
			},

			/**
			 * Event listener for when the Mainarrival has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeMainarrival: function (e) {
				this.onChangeCheckError(e);
				$.proxy(this.models.descriptions.generateMainarrival, this)();
			},
			/**
			 * Event listener for when the Maindeparture has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeMaindeparture: function (e) {
				this.onChangeCheckError(e);
				$.proxy(this.models.descriptions.generateMaindeparture, this)();
			},
			/**
			 * Event listener for when the Maindeparture has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeNumberofpeople: function (e) {
				// sapui5.version < 1.50 has an error where the value not automatically is set if there is a change event bound to the object
				var sVal = e.getSource().getValue();
				this.getView().getModel("Article").setProperty("/Numberofpeople", sVal);
				this.onChangeCheckError(e);
			},
			/**
			 * Event listener for when the Supplier has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeSupplier: function (e) {
				$.proxy(this.billback.onChange.Supplier, this)(e);
				$.proxy(this.models.descriptions.generateSupplier, this)();
			},
			/**
			 * Event listener for when the Ticketedairline has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeTicketedairline: function (e) {
				this.onChangeCheckError(e);
				$.proxy(this.models.descriptions.generateTicketedairline, this)();
			},
			/**
			 * Event listener for when the ExchangeTicketedairline has changed
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onChangeExchangeTicketedairline: function (e) {
				this.onChangeCheckError(e);
				$.proxy(this.models.descriptions.generateExchangeticketedairline, this)();
			},

			/**
			 * Checkboxes can only have value true or false,
			 * thereofre manually set all checkboxes to "X" when the checkbox is selected
			 * @namespace com.bcdtravel.pnr.controller.Article.onCheckBoxSelect
			 */
			onCheckBoxSelect: /** @lends com.bcdtravel.pnr.controller.Article.onCheckBoxSelect.prototype */ {
				/**
				 * @param {sap.ui.base.Event} e	- onchanged event
				 * @param {string} sField		- Article property name
				 */
				_updateModel: function (e, sField) {
					var sOdataValue = (e.getParameter("selected")) ? "X" : "";
					this.getView().getModel("Article").setProperty("/" + sField, sOdataValue);
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Domintindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Domintindicator");
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Billbackindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Billbackindicator");
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Emtypeindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Emtypeindicator");
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Exchangeindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Exchangeindicator");
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Foreigntariffindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Foreigntariffindicator");
				},
				/**
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				Obfeeindicator: function (e) {
					$.proxy(this.onCheckBoxSelect._updateModel, this)(e, "Obfeeindicator");
				}
			},

			/**
			 * Enables all fields to be editable
			 */
			onForceEditMode: function () {
				// double check if the user is allowed
				if ((!User.canForceEditMode) && (!this.getView().getModel("Booking").getProperty("/").Blocked)) {
					return false;
				}
				var oArticleModel = this.getView().getModel("ArticleView");
				oArticleModel.setProperty("/forceEditMode", true);
				oArticleModel.setProperty("/showSaveCancelButtons/References", true);
				oArticleModel.setProperty("/showSaveCancelButtons/Supplements", true);
				oArticleModel.setProperty("/showSaveCancelButtons/ArticleData", true);
			},

			/**
			 * Event handler when the back button is pressed
			 *
			 * Navigates to the booking view
			 */
			onNavToBooking: function () {
				this._navTo(
					"Booking", {
						bookingId: this._bookingId
					}
				);
			},

			/**
			 * Event handler for add new segment button
			 *
			 * Events to the new Segment page
			 */
			onNewSegment: function () {
				$.proxy(this._navTo, this)(
					"NewSegment", {
						bookingId: this._bookingId,
						articleId: this._articleId,
						TabnameBs: "NewSegment"
					}
				);
			},

			/**
			 * Method called when the save Article button is clicked
			 * - Calling the method which will save the article data
			 */
			onSaveArticleData: function () {
				var oView = this.getView(),
					oArticleViewModel = oView.getModel("ArticleView"),
					oArticleModel = oView.getModel("Article"),
					sSaveType = (oArticleModel.isNew()) ? "Create" : "Update",
					that = this;
				// allow the router to navigate
				$.proxy(that._allowRouterNavigation, that)(I18n.getText("Article.ArticleData"));
				// CHECK mandatory fields if it is a new article
				var oDefMandatory = $.Deferred();
				if (oArticleModel.isNew() && oArticleModel.getProperty("/NoBilling") !== "X") {
					var oMandatoryModel = oView.getModel("MandatoryFields");
					oMandatoryModel.checkObjectFields(
						oArticleModel.getProperty("/"), {
							success: function () {
								oDefMandatory.resolve();
							},
							error: function (aErrors) {
								if (aErrors.length) {
									for (var i in aErrors) {
										oView.getModel("ArticleErrors").setProperty("/" + aErrors[i], true);
									}
									that._showError(I18n.getText("MandatoryFieldError"));
								}
								oDefMandatory.reject();
							}
						}
					);
				} else {
					oDefMandatory.resolve();
				}

				// no errors ? proceed
				oDefMandatory.done(function () {
					// show loader
					that._showPageBusyIndicator(true);
					// execute save
					oArticleModel.saveData({
						success: function (m) {
							// hide loader 
							that._showPageBusyIndicator(false);
							// After creation re-set the articleId 
							// Before create the article id = 0. 
							// Afther the creation the view articleId needs to be resetted
							if (sSaveType === "Create" && typeof m === "object" && "ArticlesId" in m) {
								that._articleId = m.ArticlesId;
							}
							// success message on update
							if (sSaveType === "Update") {
								// show success message
								that._showMessage(I18n.getText("SavedSuccefully"));
							}
							// reload view models
							$.proxy(that.models.reload, that)(function () {
								if (sSaveType === "Create") { // success message on create
									var sMessage = (oArticleViewModel.getProperty("/hasError")) ? I18n.getText("SavedSuccefullyWithErrors") : I18n.getText(
										"SavedSuccefully");
									that._showMessage(sMessage);
								} else if (!oArticleViewModel.getProperty("/hasError")) {
									// if the article is saved and there are no errors, navigate back to the booking
									that.onNavToBooking();
								}
							});
						},
						error: function (e) {
							// hide loader 
							that._showPageBusyIndicator(false);
							// show error
							that._showErrorByOdataResponse(e);
						}
					});
				});
			},

			/**
			 * Method called when the save References button is clicked
			 * Calls the method which will save the segment data
			 */
			onSaveReferences: function () {
				var that = this;
				// allow Navigation
				this._allowRouterNavigation(I18n.getText("Article.References"));
				// Safe references
				this._excuteBatch(
					"References", {
						error: function (e) {
							that._showErrorByOdataResponse(e);
						}
					}
				);
			},

			/**
			 * Method called when the save Supplements button is clicked
			 * Calls the method which will save the segment data
			 */
			onSaveSupplements: function () {
				var that = this;
				// allow Navigation
				this._allowRouterNavigation(I18n.getText("Article.Supplements"));
				// Safe Supplements
				this._excuteBatch(
					"Supplements", {
						error: function (e) {
							that._showErrorByOdataResponse(e);
						}
					}
				);
			},

			/**
			 * Event handler when the segment is clicked, navigates to the Segment page
			 * @param {sap.ui.base.Event} e - onchanged event
			 */
			onSelectSegment: function (e) {
				var oCntx = e.getSource().getBindingContext("Segments"),
					m = oCntx.getModel().getProperty(oCntx.getPath());
				this._navTo(
					"Segment", {
						bookingId: this._bookingId,
						articleId: this._articleId,
						segmentId: m.SegmentId,
						ApplicationId: this.oApplicationId,
						ArticleCategory: this.oArticelCategory
					}
				);
			},

			/* all other */

			account: {
				_dialog: null,
				/**
				 * Load the accountinfo from the backed and opens a dialog which will display the account info
				 */
				onShowInfo: function (evt) {
					var oTitle, oAccount,
						oArticleModel = this.getView().getModel("Article"),
						oAction = evt.getSource().getAggregation("customData")[0].getValue();
					if (oAction === "Ifarepcc") {
						oTitle = "Ifare Recharge Account Info";
						oAccount = evt.getSource().getParent().getAggregation("fields")[0].getSelectedKey();
					} else {
						oTitle = I18n.getText("Account Info");
						oAccount = oArticleModel.getProperty("/Account");
					}
					var oDialog = this._openDialogByFragment(
							"com.bcdtravel.pnr.view.article.ShowAccountInfo", // fragment
							{ // Dialog Model data
								Title: oTitle,
								AccountInfo: {}
							}
						),
						that = this;
					oDialog.setBusy(true);
					this.account._dialog = oDialog;
					var dIssueDate,
						sCurrentYear = new Date().getFullYear().toString(),
						sCurrentMonth = (new Date().getMonth() + 1).toString(),
						sCurrentDay = (new Date().getDate()).toString();
					if (sCurrentMonth < 10) {
						sCurrentMonth = "0" + sCurrentMonth;
					}
					if (sCurrentDay < 10) {
						sCurrentDay = "0" + sCurrentDay;
					}
					dIssueDate = oArticleModel.getProperty("/IssueDate");
					if (dIssueDate !== "") {
						var sIssueYear = dIssueDate.getFullYear().toString(),
							sIssueMonth = (dIssueDate.getMonth() + 1).toString(),
							sIssueDay = dIssueDate.getDate().toString();
						if (sIssueMonth < 10) {
							sIssueMonth = "0" + sIssueMonth;
						}
						if (sIssueDay < 10) {
							sIssueDay = "0" + sIssueDay;
						}
						var sIssueDate = sIssueYear + sIssueMonth + sIssueDay;
					} else {
						sIssueDate = sCurrentYear + sCurrentMonth + sCurrentDay;
					}
					BCDGateway.callFunction(
						"/showAccount", {
							urlParameters: {
								accountNumber: oAccount,
								issueDate: sIssueDate
									//issueDate: sCurrentYear + sCurrentMonth + sCurrentDay
							},
							method: "GET",
							success: function (m) {
								oDialog.getModel("Dialog").setProperty("/AccountInfo", m);
								oDialog.setBusy(false);
							},
							error: function (e) {
								oDialog.close();
								$.proxy(that._showErrorByOdataResponse, that)(e);
							}
						}
					);
				},
				onClose: function () {
					this.account._dialog.close();
				}
			},

			/**
			 * Methods needed for the Billback
			 * @namespace com.bcdtravel.pnr.controller.Article.billback
			 */
			billback: /** @lends com.bcdtravel.pnr.controller.Article.billback.prototype */ {
				/**
				 * On Change handlers for billback necessary fields
				 * @namespace com.bcdtravel.pnr.controller.Article.billback.onChange
				 */
				onChange: /** @lends com.bcdtravel.pnr.controller.Article.billback.onChange.prototype */ {
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					Quantityofproduct: function (e) {
						this.getView().getModel("Article").setProperty("/Quantityofproduct", e.getSource().getValue());
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// recalc Totalamount
						$.proxy(this.billback.recalcTotalAmount, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					Baseamount: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// recalc Totalamount
						$.proxy(this.billback.recalcTotalAmount, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					Totalamount: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					DpDocid: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					Supplier: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					DtelGefInvnr: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					BillBackReleaseAmount: function (e) {
						// the paper invoice .. field is used to check for release billback
						// frist call the method which removes the error valuestate if a value is set
						$.proxy(this.onChangeCheckError, this)(e);
						// in case of a liveChange set the Article Farepaidamount
						// else it will be empty in the enableReleaseButtonWhenAllowed method
						if ("newValue" in e.getParameters()) {
							this.getView().getModel("Article").setProperty("/Farepaidamount", e.getParameter("newValue"));
						}
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					},
					/**
					 * @instance
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					Salespriceamount: function (e) {
						// frist call the method which removes the error valuestate if a value is set
						//$.proxy(this.onChangeCheckError, this)(e);
						// in case of a liveChange set the Salespriceamount
						// else it will be empty in the enableReleaseButtonWhenAllowed method
						if ("newValue" in e.getParameters()) {
							this.getView().getModel("Article").setProperty("/Salespriceamount", e.getParameter("newValue"));
						}
						$.proxy(this.billback.calcMarkup, this)();
						// check if button can be enabeld
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					}
				},
				/**
				 * Recalculate the ArticleView.BillbackMarkup
				 * (Salespriceamount - Totalamount)
				 */
				calcMarkup: function () {
					var oView = this.getView(),
						oArticleView = oView.getModel("ArticleView"),
						oArticle = oView.getModel("Article"),
						mArticle = oArticle.getProperty("/"),
						nMarkup = this._calculateCurrency(mArticle.Salespriceamount, "-", mArticle.Totalamount);
					oArticleView.setProperty("/ClientmarkupValueState", (nMarkup < "0,00") ? "Error" : "None");
					//oArticleView.setProperty("/BillbackMarkup", nMarkup);
					oArticle.setProperty("/Clientmarkup", nMarkup);
				},

				/**
				 * Recalculates the Article.Totalamount
				 * (TotalAmount = ((Quantity * numberofdays) * BaseAmount) + Supplements)
				 */
				recalcTotalAmount: function () {
					var oView = this.getView(),
						oArticle = oView.getModel("Article"),
						nQuantity = oArticle.getProperty("/Quantityofproduct"),
						nBaseAmount = oArticle.getProperty("/Baseamount"),
						nTotal = this._calculateCurrency(nQuantity, "*", nBaseAmount),
						nSegmentNrOfDays = oView.getModel("ArticleView").getProperty("/SegmentNumberOfDays");
					if (["Hotel", "Car"].indexOf(oArticle.getProperty("/ArticleCategory")) !== -1 && nSegmentNrOfDays) {
						nTotal = this._calculateCurrency(nSegmentNrOfDays, "*", nTotal);
					}
					nTotal = this._calculateCurrency(nTotal, "+", this.getView().getModel("ArticleView").getProperty("/SupplementsTotal"));

					oArticle.setProperty("/Totalamount", nTotal);
					// calcMarkup
					$.proxy(this.billback.calcMarkup, this)();
					// check if button can be enabeld
					$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
				},

				/**
				 * Enable the release button if all checks are done
				 * The user is allowed to realease the billback only when:
				 *	- article.BillbackNotReleased === "X" (else the button is hidden)
				 *	- article.Farepaidamount === article.Totalamount
				 *	- The article.DpDocid, article..DtelGefInvnr and article.Supplier are set
				 *	- The article.Salespriceamount >= article.Totalamount
				 */
				enableReleaseButtonWhenAllowed: function () {
					var oView = this.getView(),
						oArticleView = oView.getModel("ArticleView"),
						mArticleView = oArticleView.getProperty("/"),
						mArticle = oView.getModel("Article").getProperty("/"),
						// currency values should be treated as integers (multiplied with 100) before processing.
						//nTotal			= this._calculateCurrency(mArticle.Totalamount, "+", mArticleView.SupplementsTotal);
						nTotal = mArticle.Totalamount;
					// by default disable the button
					oArticleView.setProperty("/billbackButtonEnabled", false);
					// Already Released?
					if (mArticle.BillbackNotReleased !== "X") {
						return;
					}
					// Check if the BillBackReleaseAmount is the same as the sum of totalamount and supplements
					if (this._compareCurrency(mArticle.Farepaidamount, '=', nTotal) === false) {
						if (mArticle.Farepaidamount && User.canProcessBillBack()) { // do not show warning if empty
							oArticleView.setProperty("/BillBackReleaseAmountValueState", "Warning");
							$.proxy(this._showMessage, this)(I18n.getText("Article.BillbackErrorInvoiceAmount"));
						}
						return;
					} else if (User.canProcessBillBack()) {
						oArticleView.setProperty("/BillBackReleaseAmountValueState", "Success");
					}
					// DpDocid and DtelGefInvnr and Supplier cannot be empty
					if (mArticle.DpDocid === "" || mArticle.DtelGefInvnr === "" || mArticle.Supplier === "") {
						return;
					}
					// if the sales price is lower than the total, no billback allowed
					if (this._compareCurrency(mArticle.Salespriceamount, "<", nTotal)) {
						// show error
						oView.getModel("ArticleErrors").setProperty("/Salespriceamount", true);
						// $.proxy(this._showError, this)(I18n.getText("Article.BillbackErrorSales"));
						return;
					} else {
						oView.getModel("ArticleErrors").setProperty("/Salespriceamount", false);
					}
					// enable button
					oArticleView.setProperty("/billbackButtonEnabled", true);
					// show released message
					$.proxy(this._showMessage, this)(I18n.getText("Article.BillbackButtonReleased"));
				}
			},

			copy: {
				openScenarioSelectDialog: function () {
					ArticleCopy.openScenarioSelectDialog(this.getView().getModel("Article").getProperty("/"));
				}
			},

			/**
			 * Methods needed to copy an Article
			 * @namespace com.bcdtravel.pnr.controller.Article.copy
			 */
			copy2: /** @lends com.bcdtravel.pnr.controller.Article.copy.prototype */ {
				_dialog: null,
				/**
				 * Opens a confirmation Dialog
				 */
				onStart: function () {
					this.copy._dialog = this._openDialogByFragment("com.bcdtravel.pnr.view.article.CopyArticleWarningDialog", {
						selected: "",
						options: [{
							value: "ChangeBilLBackToReferal",
							text: "Change the BillbackIndicator to Referal"
						}, {
							value: "ChangeBillBackIndicatorToReferal",
							text: "Change the Referal to Billback"
						}, {
							value: "ChangeAccountAndUATP",
							text: "Change Account and UATP"
						}, {
							value: "ChangeUATP",
							text: "Change UATP"
						}, {
							value: "ChangeAccount",
							text: "Change Account"
						}, {
							value: "RefundArticle",
							text: "Refund Article"
						}, {
							value: "RefundAIRREF",
							text: "Refund AIRREF"
						}, {
							value: "MissingIURforPassenger",
							text: "Missing IUR for passenger"
						}, {
							value: "InvoiceADM",
							text: "Invoice ADM"
						}, {
							value: "RefundACM",
							text: "Refund ACM"
						}, {
							value: "CorrectionInvoiceRefund",
							text: "Correction Invoice / Refund"
						}]
					});
				},
				/**
				 * Execute the actual copy 
				 */
				onPerform: function () {
					this.copy._dialog.close();
				},
				/**
				 * Closes the copy dialog 
				 */
				onClose: function () {
					this.copy._dialog.close();
				}
			},

			/**
			 * Credit card
			 * @namespace com.bcdtravel.pnr.controller.Article.creditcard
			 */
			creditcard: /** @lends com.bcdtravel.pnr.controller.Article.creditcard.prototype  */ {

				onCheckExpiryDate: function (e) {
					var sVal = e.getSource().getValue().toString();
					var sError = "";
					if (sVal.length !== 0 && sVal.length !== 4) {
						sError = "Incorrect format (MMYY)";
					}
					var sMonth = sVal.substr(0, 2),
						sYear = sVal.substr(2, 2),
						sCurrentYear = new Date().getFullYear().toString().substr(2, 2),
						sCurrentMonth = (new Date().getMonth() + 1).toString();
					if (sCurrentMonth < 10) {
						sCurrentMonth = "0" + sCurrentMonth;
					}
					if (!sError && ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"].indexOf(sMonth) === -1) {
						sError = "Invalid Month";
					}
					// if (!sError && sCurrentYear > sYear) {
					// 	sError = "Invalid Year or Card expired";
					// }
					// if (!sError && sCurrentYear === sYear && sMonth < sCurrentMonth) {
					// 	sError = "Card expired";
					// }
					this.getView().getModel("ArticleView").setProperty("/CreditcardexpiryText", sError);
					this.getView().getModel("ArticleErrors").setProperty("/Creditcardexpiry", (sError) ? true : false);
				},

				_dialog: null,
				/**
				 * Load the credit card info from the backed and opens a dialog which will display the credit card no
				 * @param {string} sType=CREDITCARDNUMBER||CREDITCARDNUMBERMERCHANT	- Credit Card No
				 */
				_loadAndShow: function (sType) {
					var sArticleModelField = (sType === "CREDITCARDNUMBER") ? "Creditcardnumber" : "Creditcardnumbermerchant",
						oDialog = this._openDialogByFragment(
							"com.bcdtravel.pnr.view.article.ShowCreditCard", // fragment
							{ // Dialog Model data
								CreditcardNo: "",
								Title: I18n.getText("article." + sArticleModelField)
							}
						),
						oArticleModel = this.getView().getModel("Article"),
						that = this;
					oDialog.setBusy(true);
					this.creditcard._dialog = oDialog;
					BCDGateway.callFunction(
						"/showCC", {
							urlParameters: {
								BookingsId: this._bookingId,
								ArticlesId: this._articleId,
								Type: oArticleModel.getProperty("/ArticleType"),
								Fieldname: sType,
								CCNum: oArticleModel.getProperty("/" + sArticleModelField)
							},
							method: "GET",
							success: function (m) {
								oDialog.getModel("Dialog").setProperty("/CreditcardNo", m.CCardstring);
								oDialog.setBusy(false);
							},
							error: function (e) {
								oDialog.close();
								$.proxy(that._showErrorByOdataResponse, that)(e);
							}
						}
					);
				},
				/**
				 * Event handler when the dialogs close button is pressed
				 * 
				 * Closes the dialog
				 */
				onClose: function () {
					this.creditcard._dialog.close();
				},
				/**
				 * Event handler when the show creditcard no button is pressed
				 * 
				 * opens the dialog which loads the credit card no from the gateway service
				 */
				onShowCreditcardnumber: function () {
					$.proxy(this.creditcard._loadAndShow, this)("CREDITCARDNUMBER");
				},
				/**
				 * Event handler when the show creditcard no merchant button is pressed
				 * 
				 * opens the dialog which loads the credit card no from the gateway service
				 */
				onShowCreditcardnumbermerchant: function () {
					$.proxy(this.creditcard._loadAndShow, this)("CREDITCARDNUMBERMERCHANT");

				}
			},

			/**
			 * Article view formatter methods
			 * @namespace com.bcdtravel.pnr.controller.Article.format
			 */
			format: /** @lends com.bcdtravel.pnr.controller.Article.format.prototype */ {
				/**
				 * Format the Tax & Supplements label
				 * @param {string} sTaxsupplementtypes	- Tax & Supplements Type
				 * @returns {string} Formatted supplements label
				 */
				SupplementsLabel: function (sTaxsupplementtypes) {
					var oMapping = this.getView().getModel("Mapping");
					if ("getSupplementLabelByType" in oMapping) {
						return oMapping.getSupplementLabelByType(sTaxsupplementtypes);
					}
					return sTaxsupplementtypes;
				}
			},

			/**
			 * Methods for the icontabbar
			 * @namespace com.bcdtravel.pnr.controller.Article.iconTabBar
			 */
			iconTabBar: /** @lends com.bcdtravel.pnr.controller.Article.iconTabBar.prototype */ {
				/**
				 * Initialize the iconTabBar (on Page load)
				 */
				init: function () {
					$.proxy(this.iconTabBar.openFirstTab, this)();
				},

				/**
				 * Get the current open tab key
				 * @returns {string} - the selected key
				 */
				getOpenTab: function () {
					return this.getView().byId("ArticleIconTabBar").getSelectedKey();
				},

				/**
				 * Open the first tab (used in onRouteMatched method)
				 */
				openFirstTab: function () {
					$.proxy(this.iconTabBar.open, this)("ArticleData");
				},

				/**
				 * Open the tab of the key passed 
				 * @param {string} sKey - Key of the tab to open
				 */
				open: function (sKey) {
					this.getView().byId("ArticleIconTabBar").setSelectedKey(sKey);
					$.proxy(this.iconTabBar.tabChanged, this)(sKey);
				},

				/**
				 * Open the Supplements tab
				 * this method is used in the billback area (extra button to navigate to supplements)
				 */
				openSupplements: function () {
					$.proxy(this.iconTabBar.open, this)("Supplements");
				},

				/**
				 * Callback method for onSelect & openFirstTab 
				 * @param {string} sKey - open tab key
				 */
				tabChanged: function (sKey) {
					this.getView().getModel("ArticleView").setProperty("/currentOpenTab", sKey);
					if (sKey === "ArticleData") {
						$.proxy(this.billback.enableReleaseButtonWhenAllowed, this)();
					}
				},

				/**
				 * this event is triggered when the open iconTab changes
				 * @param {sap.ui.base.Event} e	IconTabBar select event data
				 */
				onSelect: function (e) {
					var sOpen = e.getParameter("selectedKey");
					$.proxy(this.iconTabBar.tabChanged, this)(sOpen);
				}
			},

			/** INVOICES **/
			invoice: Invoice,

			/**
			 * Note: All methods should be proxied like $.proxy(this.models.methodName, this)();
			 * @namespace com.bcdtravel.pnr.controller.Article.models
			 */
			models: /** @lends com.bcdtravel.pnr.controller.Article.models.prototype */ {

				/**
				 * Model initializer only called on view load once
				 * @private
				 */
				init: function () {
					$.proxy(this.models.setViewModels, this)();
				},
				/** 
				 * (re)-set the view models 
				 */
				setViewModels: function () {
					var oView = this.getView();
					// 14-12 wim would like to be able to edit the account for test purposes force the account field to be editable
					var forceAccount = (this._getURLParameter("forceAccount")) ? true : false,
						bIsTesting = User.isTester();
					// ArticleView
					var ArticleViewModel = new JSONModel({
						ArticleCategory: "", // used in Page title
						header: {
							ArticleTitle: "",
							ArticleIcon: "home-share",
							// dynamic fields are updated in this.models.processArticleData method
							dynamicFields: {
								Account: {
									visible: false,
									value: ""
								}
							}
						},
						show: { // articleData fields
							//OrderedBy... etc // dynamically created in this.models.processArticleData
						},
						OkIconColor: "Default", // Negative, Positive or Default
						ReferencesIconColor: "Default", // Negative, Positive or Default
						SegmentsIconColor: "Default",
						SupplementsIconColor: "Default",
						SupplementsErrorCount: "",
						SupplementsTotal: 0,
						ReferencesErrorCount: "",
						SegmentsErrorCount: "",
						ArticleErrorCount: "",
						SegmentsNavContainerHeight: "250px", // min height > height is caclulated in this.models.processSegmentsData
						showSaveCancelButtons: {
							ArticleData: (forceAccount || bIsTesting) ? true : false,
							References: false,
							Supplements: false
						}, // show or hide footer save cancel buttons
						currentOpenTab: $.proxy(this.iconTabBar.getOpenTab, this)(),
						showUnticketedMessage: false,
						show08ErrorWarning: false,
						show11ErrorWarning: false,
						enableCopyArticleButton: true,
						hasError: false, // set in processArticleData .. used in saveArticleData callback method and the refresh button
						isNewArticle: false,
						isTesting: bIsTesting, // if the users is a tester.. enable all fields
						billbackButtonEnabled: false,
						BillBackReleaseAmountValueState: "None",
						BillbackMarkup: "", // = SalesAmount - totalAmount
						MaindepartureDescription: "",
						MainarrivalDescription: "",
						SupplierDescription: "",
						TicketedairlineDescription: "",
						ExchangeticketedairlineDescription: "",
						forceAccount: forceAccount, // enable account field to be edited (easter egg if url param forceAccount is set)
						forceEditMode: false, // enables all fields to be editable
						userAllowedToCreateSupplement: false,
						// Issue 0016: If the ArticleCategory is Hotel or Car the labels differentiate.
						// these labels are changed in the .models.processArticleData method
						ArrivalDepartureLabels: {
							departuredate: I18n.getText("segment.Segmentdeparturedate"),
							departure: I18n.getText("segment.Segmentdeparture"),
							arrivaldate: I18n.getText("segment.Segmentarrivaldate"),
							arrival: I18n.getText("segment.Segmentarrival")
						},
						currencyDescription: "",
						SegmentNumberOfDays: 0,
						InvoiceCount: 0,
						ClientmarkupValueState: "None",
						CreditcardexpiryText: ""

					});
					oView.setModel(ArticleViewModel, "ArticleView");
					// Article in loadByBookingIdAndArticleId overwritten bij com.bcdtravel.model.Article model
					oView.setModel(new JSONModel({}), "Article");
					// Booking
					oView.setModel(new JSONModel({}), "Booking");
					// Segments
					oView.setModel(new JSONModel({}), "Segments");
					// References
					oView.setModel(new JSONModel({}), "References");
					// Supplements
					oView.setModel(new JSONModel({}), "Supplements");
					// Mapping
					oView.setModel(new JSONModel({}), "Mapping");
					// Mandatory
					oView.setModel(new JSONModel({}), "MandatoryFields");
					// Article errors 
					// example below the Passengername has an error
					// dynamically created in this.models.processErrorData
					var oArticleErrors = new JSONModel();
					oView.setModel(oArticleErrors, "ArticleErrors");
					// On 31-10 the odata server was missing the "IssueDate" field,
					// Before: the ArticleErrors model properties was created dymically by looking at the 
					// oData article properties. but because the IssueDate was missing in the oData service, the ArticleErrors model IssueDate property never was created.
					// As a result in the view.xml the IssueDate field became editable. (default sapui5)
					// So now I make sure all neccesary properties are in the article errors.. we first set the properties by getting the necessary properties from the DisplaySettings
					var mArticleFields = DisplaySettings.getFieldsArrayFor("ArticleData");
					for (var i in mArticleFields) {
						oArticleErrors.setProperty("/" + mArticleFields[i], false);
					}
					// set Invoice Count
					$.proxy(this.invoice.onTableUpdateFinished, this)(function (e) {
						ArticleViewModel.setProperty("/InvoiceCount", e.getParameter("total"));
					});
				},

				/**
				 *  Every time the currency has changed the currencydescription needs to change too
				 */
				resetCurrencyDescription: function () {
					var oView = this.getView(),
						mArticle = oView.getModel("Article").getProperty("/"),
						oArticleViewModel = this.getView().getModel("ArticleView"),
						sDescription = mArticle.Currency;
					if (mArticle.ArticleCategory === "Hotel") {
						sDescription += " " + I18n.getText("Article.FareMarking.HOTEL");
					} else if (mArticle.ArticleCategory === "Car") {
						sDescription += " " + I18n.getText("Article.FareMarking.CAR");
					}
					oArticleViewModel.setProperty("/currencyDescription", sDescription);
				},

				/**
				 * reload all data
				 * @param {fnSuccessErrorCallback} fnAfterReload	- called when the reload is done
				 */
				reload: function (fnAfterReload) {
					$.proxy(this.models.loadByBookingIdAndArticleId, this)(
						this._bookingId,
						this._articleId, {
							done: fnAfterReload
						}
					);
				},

				/**
				 * reload the supplement data
				 */
				reloadSupplements: function () {
					// Fetch supplements
					var that = this;
					BCDGateway.read(
						"/supplementSet", {
							filters: [ // filter by BookingsId and Articles Id
								new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, this._bookingId),
								new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, this._articleId)
							],
							success: function (mData) {
								// mData has multiple results 
								if ("results" in mData) {
									mData = mData.results;
								}
								$.proxy(that.models.processSupplementsData, that)(mData, that.getView().getModel("Article").getProperty("/"));
							}
						}
					);
				},

				/**
				 * Load all necessary data from oData service
				 * @param {string} bookingId									- Bookings Id
				 * @param {string} articleId									- Article Id
				 * @param {object} [mParams]									- additional params
				 * @param {fnSuccessErrorCallback} [mParams.done]				- executed if all odata serivces are loaded and data is processed
				 * @param {fnSuccessErrorCallback} [mParams.afterArticleCreate] - executed if the article is created
				 */
				loadByBookingIdAndArticleId: function (bookingId, articleId, mParams) {
					mParams = (typeof mParams === "object") ? mParams : {};
					mParams.done = ("done" in mParams && typeof mParams.done === "function") ? mParams.done : function () {};
					mParams.afterArticleCreate = ("afterArticleCreate" in mParams && typeof mParams.afterArticleCreate === "function") ? mParams.afterArticleCreate :
						function () {};
					// Fetch articledata
					var that = this,
						oView = this.getView();
					// allow navigation (for all)
					$.proxy(that._allowRouterNavigation, that)();
					// clear all current view data
					$.proxy(this.models.setViewModels, this)();
					// Show Page loader
					$.proxy(this._showPageBusyIndicator, this)(true);
					// Deferred objects (results are processed below ajax calls)
					// We need multiple ajax requests to collect te data (didnt used expand to collect all data at once since the data load could be to big at once)
					// I use defferred objects so we can execute some stuff after all requests have been loaded
					var oArticlesDeferred = $.Deferred(),
						oBookingDeffered = $.Deferred(),
						oSegmentsDeferred = $.Deferred(),
						oReferencesDeferred = $.Deferred(),
						oErrorDeferred = $.Deferred(),
						oSupplementsDeferred = $.Deferred();
					// Promise so that the deferred cannot be changed
					oArticlesDeferred.promise();
					oBookingDeffered.promise();
					oSegmentsDeferred.promise();
					oReferencesDeferred.promise();
					oErrorDeferred.promise();
					oSupplementsDeferred.promise();
					// Load the Articles
					// The view Article model using com.bcdtravel.pnr.model.Article in which we added extra helper methods
					var oArticle = new ArticleModel(
						bookingId,
						articleId, {
							success: function () {
								// re-set the article model 
								oView.setModel(oArticle, "Article");
								// call the afterArticleCreate callback (important > call before deferred )
								mParams.afterArticleCreate(oArticle);
								oArticlesDeferred.resolve(oArticle.getProperty("/"));
								// enables all fields if user is tester of article is new
								if (oArticle.isNew()) {
									oView.getModel("ArticleView").setProperty("/isNewArticle", true);
								}
								// prevent routing
								oArticle.attachPropertyChange(function () {
									if (oView.getModel("Booking").getProperty("/Blocked") !== 'X') {
										$.proxy(that._preventRouterNavigation, that)(I18n.getText("Article.ArticleData"));
									}
								});
							},
							error: function () {
								oArticlesDeferred.resolve(null);
								that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);
					// Fetch Booking data from service
					BCDGateway.read(
						"/bookingSet('" + bookingId + "')", {
							success: function (mData) {
								oBookingDeffered.resolve(mData);
							},
							error: function () {
								oBookingDeffered.resolve({});
								that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);
					// load Segments
					BCDGateway.read(
						"/segmentSet", {
							filters: [ // filter by ArticlesId
								new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId),
								new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, articleId)
							],
							success: function (mData) {
								// mData has multiple results 
								if ("results" in mData) {
									mData = mData.results;
								}
								oSegmentsDeferred.resolve(mData);
							},
							error: function () {
								oSegmentsDeferred.resolve({});
								// temp turned off for demo
								//that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);
					// load References
					BCDGateway.read(
						"/referenceSet", {
							urlParameters: {
								"$expand": "Options"
							},
							filters: [ // filter by BookingsId and Articles Id
								new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId),
								new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, articleId)
							],
							success: function (mData) {
								// mData has multiple results 
								if ("results" in mData) {
									mData = mData.results;
								}
								oReferencesDeferred.resolve(mData);
							},
							error: function () {
								oReferencesDeferred.resolve({});
								// temp turn the error of (for the demo)
								//that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);
					// Read field errors Errors from service
					BCDGateway.readFieldErrors({
						bookingId: bookingId, // filter on bookingId
						articleId: articleId, // filter on articleId
						success: function (mData, mDataOrderedOnTables) {
							oErrorDeferred.resolve(mDataOrderedOnTables);
						},
						error: function () {
							// dont throw an error for errorSet
							oErrorDeferred.resolve({});
						}
					});
					// Fetch supplements
					BCDGateway.read(
						"/supplementSet", {
							filters: [ // filter by BookingsId and Articles Id
								new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId),
								new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, articleId)
							],
							success: function (mData) {
								// mData has multiple results 
								if ("results" in mData) {
									mData = mData.results;
								}
								oSupplementsDeferred.resolve(mData);
							},
							error: function () {
								oSupplementsDeferred.resolve({});
								// temp turned off for demo
								//that._showError(I18n.getText("oDataLoadError"));
							}
						}
					);

					// When all data has loaded call processors
					$.when(
						oArticlesDeferred,
						oBookingDeffered,
						oSegmentsDeferred,
						oReferencesDeferred,
						oErrorDeferred,
						oSupplementsDeferred
					).done(function (
						mArticles,
						mBooking,
						mSegments,
						mReferences,
						mSortedErrors,
						mSupplements
					) {
						// remove loading indicator
						$.proxy(that._showPageBusyIndicator, that)(false);
						// bind booking and references to view
						oView.getModel("Booking").setData(mBooking);
						// initialize &nd overwrite mapping model
						var sApplicationsId = mBooking.ApplicationsId || "",
							sArticleCategory = mArticles.ArticleCategory || "";
						oView.setModel(new MappingModel(sApplicationsId, sArticleCategory), "Mapping");
						// process article data
						var mArticleErrors = (mSortedErrors && "articles" in mSortedErrors) ? mSortedErrors.articles : {};
						$.proxy(that.models.processArticleData, that)(mArticles, mArticleErrors);
						// process segment data
						$.proxy(that.models.processSegmentsData, that)(mSegments, ("segments" in mSortedErrors ? mSortedErrors.segments : {}),
							mArticles);
						// process error data (important.. after processArticleData)
						$.proxy(that.models.processErrorData, that)(mSortedErrors, mArticles);
						// process references data
						$.proxy(that.models.processReferencesData, that)(mReferences, mSortedErrors, mArticles);
						// process supplements data
						$.proxy(that.models.processSupplementsData, that)(mSupplements, mArticles);
						//  load mandatory model (if not > the displaysettings will not work)
						oView.setModel(
							new MandatoryModel("articles", oArticle.getProperty("/ArticleType")),
							"MandatoryFields"
						);
						// done callback
						mParams.done();
						// formcontainer visibility
						$.proxy(that._formcontainers, that)();
						// apply InvoicesTable filter
						oView.byId("InvoicesTable").getBinding("items").filter(
							[
								new sap.ui.model.Filter("BookingsId", "EQ", bookingId),
								new sap.ui.model.Filter("ArticlesID", "EQ", articleId)
							]
						);
					});
				},

				/**
				 * Input description formatters
				 * @namespace com.bcdtravel.pnr.controller.Article.models.descriptions
				 */
				descriptions: /** @lends  com.bcdtravel.pnr.controller.Article.models.descriptions.prototype */ {
					/**
					 * Triggers a read request to the correct set (based on the sType)
					 *
					 * In the callback its sets the correct value help descriptions
					 * @private
					 * @param {string} sType=Ticketedairline|Exchangeticketedairline|Maindeparture|Mainarrival|Supplier
					 */
					_load: function (sType) {
						var oView = this.getView(),
							oArticleViewModel = oView.getModel("ArticleView"),
							mArticleData = oView.getModel("Article").getProperty("/"),
							sFilterVal = mArticleData[sType],
							aFilter = [],
							sSet,
							sValueColumn;
						// clear current value
						oArticleViewModel.setProperty("/" + sType + "Description", "");
						if (!sFilterVal) {
							return;
						}
						if (["Ticketedairline", "Exchangeticketedairline"].indexOf(sType) !== -1) {
							aFilter = [new sap.ui.model.Filter("Iatacode", "EQ", sFilterVal)];
							sSet = "AirlinesSet";
							sValueColumn = "Airlinename";
						} else if (["Maindeparture", "Mainarrival"].indexOf(sType) !== -1) {

							if (mArticleData.ArticleCategory.toUpperCase() === "RAIL") {
								aFilter = [
									new sap.ui.model.Filter("Stationcrscode", "EQ", sFilterVal),
									new sap.ui.model.Filter("Supplier", "EQ", mArticleData.Supplier)
								];
								sSet = "RailstationsSet";
								sValueColumn = "Stationname";
							} else {
								aFilter = [new sap.ui.model.Filter("Airportcode", "EQ", sFilterVal)];
								sSet = "AirportsSet";
								sValueColumn = "Airportname";
							}
						} else if (sType === "Supplier" && mArticleData.Bukrs) {
							aFilter = [
								new sap.ui.model.Filter("Supplier", "EQ", sFilterVal),
								new sap.ui.model.Filter("Bukrs", "EQ", mArticleData.Bukrs)
							];
							sSet = "SuppliersSet";
							sValueColumn = "Name1";
						} else {
							return;
						}
						BCDGateway.read(
							"/" + sSet, {
								filters: aFilter,
								success: function (m) {
									var sResult = "";
									if ("results" in m && _.size(m.results)) {
										for (var i in m.results) {
											sResult = m.results[i][sValueColumn];
											break;
										}
									}
									oArticleViewModel.setProperty("/" + sType + "Description", sResult);
								}
							}
						);
					},
					/**
					 * Loads and sets the Mainarrival value help description
					 */
					generateMainarrival: function () {
						$.proxy(this.models.descriptions._load, this)("Mainarrival");
					},
					/**
					 * Loads and sets the Maindeparture value help description
					 */
					generateMaindeparture: function () {
						$.proxy(this.models.descriptions._load, this)("Maindeparture");
					},
					/**
					 * Loads and sets the Ticketedairline value help description
					 */
					generateTicketedairline: function () {
						$.proxy(this.models.descriptions._load, this)("Ticketedairline");
					},
					/**
					 * Loads and sets the Exchangeticketedairline value help description
					 */
					generateExchangeticketedairline: function () {
						$.proxy(this.models.descriptions._load, this)("Exchangeticketedairline");
					},
					/**
					 * Loads and sets the Supplier value help description
					 */
					generateSupplier: function () {
						$.proxy(this.models.descriptions._load, this)("Supplier");
					},
					/**
					 * Clear out all value help descriptions 
					 */
					reset: function () { // reset is called in processArticleData method
						var sCategory = this.getView().getModel("Article").getProperty("/ArticleCategory");
						//	if (sCategory.toUpperCase() !== "RAIL") {
						$.proxy(this.models.descriptions.generateMainarrival, this)();
						$.proxy(this.models.descriptions.generateMaindeparture, this)();
						//}
						$.proxy(this.models.descriptions.generateTicketedairline, this)();
						$.proxy(this.models.descriptions.generateExchangeticketedairline, this)();
						$.proxy(this.models.descriptions.generateSupplier, this)();
					}
				},

				// loadMandSetByArticleType: function(sArticleType) {
				// 	if (! sArticleType) { return; }
				// 	// Load mandatory fields only on creating a new article!
				// 	// todo if time: omzetten naar eigen model zodat we dit niet op elke plek moeten doen
				// 	if (this.articleId === null) { return; }
				// 	var oView = this.getView();
				// 	BCDGateway.read(
				// 		"/mandSet",
				// 		{
				// 			filters: [
				// 				new sap.ui.model.Filter("ArticleType", "EQ", sArticleType),
				// 				new sap.ui.model.Filter("Tabname", "EQ", "ZHY_ARTICLES")
				// 			],
				// 			success: function(m) {
				// 				var mMandatory = {};
				// 				if (typeof m === "object" && "results" in m && _.size(m.results) > 0) { 
				// 					for (var i in m.results) {
				// 						// the data from the backend are all uppercase
				// 						// remove the _ by a "" .. makes it easier to use and check in the view
				// 						var sFieldname = m.results[i].Fieldname.toUpperCase().replace("_", "");
				// 						mMandatory[sFieldname] = true;
				// 					}
				// 				}
				// 				/**
				// 				 *  NOTE : 
				// 				 *  a article created by FIORI should always be ticketed!!
				// 				 *  so to make sure this is happening make the TICKETREFERENCE mandatory
				// 				 **/
				// 				 mMandatory["TICKETREFERENCE"] = true;
				// 				// set the model
				// 				oView.setModel(new JSONModel(mMandatory), "MandatoryFields");
				// 			}
				// 		}
				// 	);
				// 	//this.articlesId === 0 >>>> ALTIJD ticketed ref
				// },

				/**
				 * Processes Article Data:
				 * - Loads the mappings
				 * - In the view a message will be shown if the article is unticketed
				 * - Changes the Icontab bar colors (red in case of an error) and icon counters
				 * - Shows and hides the field by checking the Article Type (check models/DisplaySettings)
				 * - Triggers the method which will calculate the BillbackMarkup if the Billback is not released
				 * - Enables the create supplement button if the user is allowed to 
				 * @param {object} mData			- Article Data collected from the gateway
				 * @param {object} mArticleErrors	- Article error data
				 */
				processArticleData: function (mData, mArticleErrors) {
					if (_.size(mData) === 0) {
						return;
					}
					// VisibleField = which field shoud be visible and used for Page Header bindings
					// if the Field is not in the ArticleCatery object (for exmple if Account is missing in Rail.. the Account is not visible on a RAIL page)
					/// NOTE : visible fields are not used because "Booking Store Fields V7.5" all articles have the same headers
					/// leave it in, maybe we need it later
					var mHeaderSettings = {
						RAIL: {
							ArticleIcon: "bcd/rail", // use this icon
							ArticleTitle: "ArticleType", // use this field in the articles data
							// in the ArticleView/header/dynamicFiedls: all keys in this object will be set to visible
							visibleFields: { // key = view binding reference		value  = used field from articles Data
								Account: "Account" // for example: the Key Account corresponds to ArticleView/header/dynamicFiedls/Account and the value "Account" correpsonds to the articleset /Account value
							}
						},
						AIR: {
							ArticleIcon: "bcd/airplane",
							ArticleTitle: "ArticleType",
							visibleFields: {}
						},
						HOTEL: {
							ArticleIcon: "bcd/hotel",
							ArticleTitle: "Hotelname",
							visibleFields: {}
						},
						CAR: {
							ArticleIcon: "bcd/car",
							ArticleTitle: "ArticleType",
							visibleFields: {}
						},
						MISC: {
							ArticleIcon: "travel-itinerary",
							ArticleTitle: "ArticleType",
							visibleFields: {}
						}
					};

					var oView = this.getView(),
						oArticleViewModel = oView.getModel("ArticleView"),
						oArticleModel = oView.getModel("Article"),
						oMappingModel = oView.getModel("Mapping"),
						oVismodel = new sap.ui.model.json.JSONModel({
							"Secondreffare": false
						}),
						iArticleErrors = 0;
					oView.setModel(oVismodel, "oVismodelAtricaltype");
					// count only unique article errors
					// sometimes a field has multiple entries due to the different ErrorCodes
					if (_.size(mArticleErrors)) {
						var aCounted = [];
						for (var i in mArticleErrors) {
							var sCurrField = mArticleErrors[i].ErrorField;
							if (aCounted.indexOf(sCurrField) === -1) {
								aCounted.push(sCurrField);
								iArticleErrors++;
							}
						}
					}
					oArticleViewModel.setProperty("/ArticleErrorCount", (iArticleErrors ? iArticleErrors : ""));

					// Load the article mapping
					// in the view the Mapping model will be updated wit articles mapping and all sap.m.Select items will be created
					var oMappingParams = {
						always: function () { // done callback (both success or error)
							// 30-10-17 the mapSet did not contain data and as an result all dropdowns didn't show any items.
							// to correct that... I manually check all properties which need mapping and if there is no mapping present,
							// I get the value from the article data and create a map for it
							var mMapping = oMappingModel.getProperty("/");
							if (!("articles" in mMapping)) {
								oMappingModel.setProperty("/articles", {});
							}
							// All properties which are bound to a sap.m.select and need a mapping	
							var aAllSelectBoxes = [
								"Billbackindicator",
								"Mainbookingclass",
								"Bookingmethods",
								"Bookingcode",
								"Gdsbooking",
								"Ticketingcode",
								"Tickettypes",
								"Creditcardtype",
								"Creditcardtypemerchant",
								"Formofpayment",
								"Domintindicator",
								"Transactiontype",
								"Ratetypes",
								"Reasoncodes",
								"Reasonforissuancecodes",
								"Emdtypeindicator",
								"Foreigntariffindicator",
								"Carhotelroomtype"
							];
							var bSizeLimitSet = false;
							for (var i in aAllSelectBoxes) {
								if (aAllSelectBoxes.hasOwnProperty(i) === false) {
									continue;
								}
								var sProperty = aAllSelectBoxes[i],
									sPropertyUpperCase = sProperty.toUpperCase();
								// In case the mapping for the selectbox is empty, and the article has data for the current selectbox
								// manually create a mapping so that the article data will be present in the selectbox
								if (!(sPropertyUpperCase in mMapping.articles) && (sProperty in mData && mData[sProperty] !== "")) {
									oMappingModel.setProperty(
										"/articles/" + sPropertyUpperCase, [{
											ValueBs: mData[sProperty],
											ValueBcd: ""
										}]
									);
								}
								// the mapping for the selectbox has items, but the article data value is not in the mapping
								// so we  add it manually so it still can be selected !!!! 	
								if (
									sPropertyUpperCase in mMapping.articles && (sProperty in mData && mData[sProperty] !== "") && !_.findWhere(mMapping.articles[
										sPropertyUpperCase], {
										ValueBs: mData[sProperty]
									})
									//&& ! _.findWhere(mArticleErrors, { ErrorField : sPropertyUpperCase })
								) {
									var a = oMappingModel.getProperty("/articles/" + sPropertyUpperCase);
									a.push({
										ValueBs: mData[sProperty],
										ValueBcd: ""
									});
									oMappingModel.setProperty("/articles/" + sPropertyUpperCase, a);
								}
								// sometimes there are more than 100 items in the mapping therefore we need to set the sizelimit to a higher level
								if (_.size(mMapping.articles[sPropertyUpperCase]) > 100 && bSizeLimitSet === false) {
									oMappingModel.setSizeLimit("9999999");
									bSizeLimitSet = true;
								}
							}
							// refresh models to re-init the expression binding
							oArticleModel.refresh(true);
							oMappingModel.refresh(true);
						}
					};
					// add the article account id so that the mapping table will be extended with the GCN mapping
					if (mData.Account) {
						oMappingParams.account = mData.Account;
					}
					oMappingModel.loadMappingForEntity(
						"articles", // Entity
						oMappingParams
					);
					// Check if article is unticketed (IMPORANT: you can only check this AFTER Article data has set)
					oArticleViewModel.setProperty("/showUnticketedMessage", ((!oArticleModel.isTicketed() && !oArticleModel.isNew()) ? true : false));
					// create the viewbindings according the ArticleCategory
					if ("ArticleCategory" in mData) {
						if (mData.ArticleCategory === "Air") {
							oView.getModel("oVismodelAtricaltype").setProperty("/Secondreffare", true);
						}
						// get the article type and make it uppercase so we can use it in this method
						var sArticleCategory = mData.ArticleCategory.toUpperCase();
						// bind the Article category and convert first char to uppercase and the rest lowercase
						oArticleViewModel.setProperty(
							"/ArticleCategory",
							((sArticleCategory.length) ? sArticleCategory.charAt(0) + sArticleCategory.slice(1).toLowerCase() : ""),
							mData.ArticleCategory
						);
						// set the Data visibility settings
						// according to displaysettins models SegmentData table
						oArticleViewModel.setProperty(
							"/show",
							DisplaySettings.getVisibleObjectByTypeAndCategory("ArticleData", sArticleCategory)
						);
						// Apply header visibility settings
						if (sArticleCategory in mHeaderSettings) {
							var mCurrSetting = mHeaderSettings[sArticleCategory];
							// bind the ArticleTitle if the field is available in the data
							if (mCurrSetting.ArticleTitle in mData) {
								oArticleViewModel.setProperty(
									"/header/ArticleTitle",
									mData[mCurrSetting.ArticleTitle]
								);
							}
							// set icon
							oArticleViewModel.setProperty(
								"/header/ArticleIcon",
								mCurrSetting.ArticleIcon
							);
							// loop through the dynamic header fields (set in ArticleView model) to set the visibility and collect the correct value from the article data
							/**
										 * Booking Store Field List v7.5 Article headers have all the same fields
										 * so we can temp disable this (leave it maybe we need this later)
						
										var mViewFields = oArticleViewModel.getProperty("/header/dynamicFields");
										for (var sViewBinding in mViewFields) {
											if (! ("visibleFields" in mCurrSetting && sViewBinding in mCurrSetting.visibleFields)) { continue; } // skip to next one
											var sArticleField = mCurrSetting.visibleFields[sViewBinding];
											if (! (sArticleField in mData)) { continue; } // skip to next one
											oArticleViewModel.setProperty(
												"/header/dynamicFields/"+sArticleField+"/",
												{
													visible	: true,
													value	: mData[sArticleField]
												}
											);
										}
										*/
						}
						// Issue 0016: If the ArticleCategory is Hotel or Car the labels differentiate.
						// For Hotel Arrival and Departure are switched
						// For Car Departure = Pick-up and Arrival is Drop-off
						if (["HOTEL", "CAR"].indexOf(sArticleCategory) !== -1) {
							oArticleViewModel.setProperty("/ArrivalDepartureLabels/departure", I18n.getText("Segment." + sArticleCategory + ".Departure"));
							oArticleViewModel.setProperty("/ArrivalDepartureLabels/departuredate", I18n.getText("Segment." + sArticleCategory +
								".DepartureDate"));
							oArticleViewModel.setProperty("/ArrivalDepartureLabels/arrival", I18n.getText("Segment." + sArticleCategory + ".Arrival"));
							oArticleViewModel.setProperty("/ArrivalDepartureLabels/arrivaldate", I18n.getText("Segment." + sArticleCategory + ".ArrivalDate"));
						}
					}

					// calc BillbackMarkup if BillbackNotReleased
					if (mData.BillbackNotReleased === "X" && mData.Salespriceamount) {
						$.proxy(this.billback.calcMarkup, this)();
					}

					// enable create supplement button if the user is allowed to 
					oArticleViewModel.setProperty(
						"/userAllowedToCreateSupplement",
						User.canCreateSupplementOfArticle(mData)
					);

					// load and show input descriptions for mainarrival and maindeparture on load
					$.proxy(this.models.descriptions.reset, this)();
					// reset the currency descriptions
					$.proxy(this.models.resetCurrencyDescription, this)();
				},

				/**
				 * Processes the error Data:
				 * this method:
				 * - changes the icon colors to red (negative) if the tab has an error
				 * - fills the ArticleErrors model so we know which article fields needs to be editable (has an error)
				 * @param {object} mSortedErrors  - Error data collected from the gateway
				 * @param {object} mArticle - Article data collected from the gateway
				 */
				processErrorData: function (mSortedErrors, mArticle) {
					var oView = this.getView(),
						oArticleModel = oView.getModel("Article"),
						oArticleViewModel = oView.getModel("ArticleView"),
						oArticleErrorsModel = oView.getModel("ArticleErrors");

					// Check if the icon colors needs to be changed (for errors)
					if ("segments" in mSortedErrors && _.keys(mSortedErrors.segments).length > 0) {
						oArticleViewModel.setProperty("/SegmentsIconColor", "Negative");
					}

					// DO NOT SHOW ERRORS IF ARTICLE IS NOBILLING
					if (mArticle.NoBilling === "X") {
						for (var sFieldname in mArticle) {
							oArticleErrorsModel.setProperty("/" + sFieldname, false);
						}
						return;
					}

					if ("articles" in mSortedErrors && _.keys(mSortedErrors.articles).length > 0) {
						oArticleViewModel.setProperty("/OkIconColor", "Negative");
					}
					if ("references" in mSortedErrors && _.keys(mSortedErrors.references).length > 0) {
						oArticleViewModel.setProperty("/ReferencesIconColor", "Negative");
					}
					if ("supplements" in mSortedErrors && _.keys(mSortedErrors.supplements).length > 0) {
						oArticleViewModel.setProperty("/SupplementsIconColor", "Negative");
					}
					// If the article contains an error with code 08
					if ("other" in mSortedErrors && _.keys(mSortedErrors.other).length > 0 && _.findWhere(mSortedErrors.other, {
							ErrorCode: "08"
						})) {
						oArticleViewModel.setProperty("/show08ErrorWarning", true);
					}
					// Focus on the first error field;
					var sFocusOn = "";
					// Disable edit modus if the article is unticketed
					var bTicketed = oArticleModel.isTicketed();
					// fill the article errors model
					for (var sField in mArticle) {
						// find where toUpperCase the error DB table only holds uppercase fieldnames
						var bHasError = (_.findWhere(mSortedErrors.articles || {}, {
							ErrorField: sField.toUpperCase()
						})) ? true : false;
						oArticleErrorsModel.setProperty("/" + sField, bHasError);
						// Error found (erros only vissible if no billing flag is not set)
						if (bHasError && mArticle.NoBilling === "") {
							oArticleViewModel.setProperty("/hasError", true);
							// if the field is hidden by the DisplaySettings set it to visible
							oArticleViewModel.setProperty("/show/" + sField, true);
							// FarepaidAmount field is used for billback calculations so it uses the BillBackReleaseAmountValueState
							if (sField === "Farepaidamount" && User.canProcessBillBack()) { //
								oArticleViewModel.setProperty("/BillBackReleaseAmountValueState", "Error");
							}
							// only show save buttons if article is ticketed
							if (bTicketed === "X" && !User.canOnlyRead()) {
								oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", true);
							}

							// If booking blocked, save button needs to be disabled			  	
							if (this.getView().getModel("Booking").getProperty("/").Blocked) {
								oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", false);
							}

							// set focus on first field
							if (!sFocusOn) {
								sFocusOn = sField;
							}
						}
					}
					// Issue 0204 If Article type is empty, create an error code and it should not be editable in fiori
					if (_.findWhere(mSortedErrors.articles || {}, {
							ErrorCode: "11"
						})) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", false);
						oArticleViewModel.setProperty("/show11ErrorWarning", true);
					}
					// issue 0050 For VISA lowest fare should not be shown
					if (mArticle.ArticleCategory === "Misc" && mArticle.ArticleType === "VISA") {
						oArticleViewModel.setProperty("/show/Lowestofferedfare", false);
					}
					// show save buttons if it is a new article or if the billback is not released (else we cannot save the quantity of product and baseamount )
					if ((oArticleModel.isNew() || mArticle.BillbackNotReleased === "X") && !User.canOnlyRead()) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", true);
					}
					// Go-Live 0112: The user can change the billback indicator, so the save button needs to be enabled			  	
					if (User.canProcessBillBack() && mArticle.Citid === "" && !User.canOnlyRead() &&
						!_.findWhere(mSortedErrors.articles || {}, {
							ErrorCode: "11"
						})) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", true);
					}

					// if Article is NO Billing.. hide the save cancel buttons
					if (mArticle.NoBilling) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", false);
					}

					if (!mArticle.ManualFee) {
						oArticleViewModel.setProperty("/show/Transactionfee", false);
					}

					// If booking blocked, save button needs to be disabled			  	
					if (this.getView().getModel("Booking").getProperty("/").Blocked) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/ArticleData", false);
					}

					// (${User>/canProcessBillBack} &amp;&amp; ${Article>/Citid} === '')
					// set the focus on the first input field with has an error
					var oFocusInput = this.getView().byId("Article" + sFocusOn);
					if (sFocusOn && oFocusInput) { // delayed call is executed after all rendering is done.
						jQuery.sap.delayedCall(0, this, function () {
							oFocusInput.focus();
						});
					}
				},

				/**
				 * Process Segments Data:
				 * - Set counters for the segment icontab icon
				 * - Count segment errors and adds them to the segment
				 * @param {object} mSegments 		- Segment Data collected from the gateway
				 * @param {object} mSegmentErrors 	- Segment Errors collected from the gateway
				 */
				processSegmentsData: function (mSegments, mSegmentErrors, mArticle) {
					var iSegments = _.size(mSegments),
						oView = this.getView(),
						oArticleViewModel = oView.getModel("ArticleView");
					// segment navcontainer to default page
					//$.proxy(this.segments.resetNavContainer, this)();
					// set icontabfilter color to neutral if 0 segments
					if (iSegments === 0) {
						oArticleViewModel.setProperty("/SegmentsIconColor", "Neutral");
						return; // stop here
					}
					var iErrorCount = 0;
					// add ErrorCount to segments
					for (var i in mSegments) {
						mSegments[i].ErrorCount = 0;
						if (_.size(mSegmentErrors)) {
							var aErrorFieldsUsedInCount = []; // array needed to check if the ErrorField allready has been added to the count
							for (var iE in mSegmentErrors) {
								// check if the ErrorField has allready been counted
								// for example : a ErrorField could be flagged multiple times (error code 01 and 08)
								if (mSegmentErrors[iE].SegmentId === mSegments[i].SegmentId && aErrorFieldsUsedInCount.indexOf(mSegmentErrors[iE].ErrorField) ===
									-1) {
									aErrorFieldsUsedInCount.push(mSegmentErrors[iE].ErrorField);
									mSegments[i].ErrorCount++;
									iErrorCount++;
								}
							}
						}
						mSegments[i].rowHighlightStatus = (mSegments[i].ErrorCount > 0) ? "Error" : "Information";
					}
					// set Segment model data
					oView.getModel("Segments").setData(mSegments);
					// set segments count
					oArticleViewModel.setProperty("/SegmentsErrorCount", (iErrorCount ? iErrorCount : ""));
					// 

					if (["HOTEL", "CAR"].indexOf[mArticle.ArticleCategory] !== -1) {
						var iNumberOfDays = 0;
						for (var iS in mSegments) {
							iNumberOfDays += parseInt(mSegments[i].Segmentnumberofdays);
						}
						oView.getModel("ArticleView").setProperty("/SegmentNumberOfDays", iNumberOfDays);
					}
				},

				/**
				 * Process References Data:
				 * - Changes the iconcolor for the references tab if there's an error
				 * - Determines which input type should be used per reference type (lookup table, patter, or input)
				 * @param {object} mReferences 		- Reference data collected from the gateway
				 * @param {object} mSortedErrors 	- Error data collected from the gateway
				 */
				processReferencesData: function (mReferences, mSortedErrors, mArticle) {
					var iReferences = _.size(mReferences),
						oView = this.getView(),
						oArticleViewModel = oView.getModel("ArticleView"),
						that = this;
					// segment navcontainer to default page
					//$.proxy(this.segments.resetNavContainer, this)();
					// set icontabfilter color to neutral if 0 segments
					if (iReferences === 0) {
						oArticleViewModel.setProperty("/ReferencesIconColor", "Neutral");
						return; // stop here
					}
					oArticleViewModel.setProperty("/showSaveCancelButtons/References", (mArticle.NoBilling === "" && User.getProperty(
						"/canCreate/articles") && !User.canOnlyRead()));

					var aErrors = [];
					if ("references" in mSortedErrors && _.keys(mSortedErrors.references).length > 0) {
						oArticleViewModel.setProperty("/ReferencesIconColor", "Negative");
						for (var iR in mSortedErrors.references) {
							aErrors.push(mSortedErrors.references[iR].ReferencesId);
						}
					}

					if (aErrors.length && !User.canOnlyRead()) { // error in refernces so true
						oArticleViewModel.setProperty("/showSaveCancelButtons/References", true);
					}

					// If booking blocked, save button needs to be disabled			  	
					if (this.getView().getModel("Booking").getProperty("/").Blocked) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/References", false);
					}

					for (var i in mReferences) {
						// Make sure the Options are in and is an error
						if ("Options" in mReferences[i] && "results" in mReferences[i].Options) {
							mReferences[i].Options = mReferences[i].Options.results;
						} else {
							mReferences[i].Options = [];
						}
						// the PatternMinLength and PatternMaxLength needs reformatting
						// the odata value are starting with a 0 
						mReferences[i].PatternMinLength = (mReferences[i].PatternMinLength) ? parseInt(mReferences[i].PatternMinLength, 10) : 0;
						mReferences[i].PatternMaxLength = (mReferences[i].PatternMaxLength) ? parseInt(mReferences[i].PatternMaxLength, 10) : 0;
						// If the reference type is a lookup
						// make sure that the reference value is available in the options list
						// else it will never be visible selected in the app
						if (mReferences[i].ReferencetypesId === "L") {
							if (mReferences[i].Value && mReferences[i].Options.length) {
								var bValueInOptions = false;
								for (var iO in mReferences[i].Options) {
									if (mReferences[i].Options[iO].Value == mReferences[i].Value) { // important use == instead of ===
										bValueInOptions = true;
										break;
									}
								}
								if (!bValueInOptions) {
									mReferences[i].Options.push({
										Description: "",
										Value: mReferences[i].Value
									});
								}
							}
						} else if (mReferences[i].ReferencetypesId === "P" && mReferences[i].PatternType === "04") {
							// the pattern mask is saved in the FixedValue and an l is an c in fiori
							if (mReferences[i].PatternMask === "") {
								mReferences[i].PatternMask = mReferences[i].FixedValue.replace(/l/g, "c").replace(/L/g, "C");
							}
							if (mReferences[i].PatternMask !== "") {
								mReferences[i].Placeholder = mReferences[i].PatternMask.replace(/c/g, "a").replace(/C/g, "A").replace(/n/gi, "0");
							}
						}
						// error states
						mReferences[i].valueState = {
							Text: "",
							State: (aErrors.indexOf(mReferences[i].ReferencesId) !== -1) ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None
						};
					}
					// bind model to view
					var oReferences = oView.getModel("References");
					oReferences.setData(mReferences);
					// prevent navTo
					oReferences.attachPropertyChange(function () {
						$.proxy(that._preventRouterNavigation, that)(I18n.getText("Article.References"));
					});
					// set references count
					var iErrorCount = aErrors.length;
					oArticleViewModel.setProperty("/ReferencesErrorCount", (iErrorCount ? iErrorCount : ""));
					// sorting
					$.proxy(this.references.execSorting, this)();
				},

				/**
				 * Process Supplements Data:
				 * - Enables the Save Supplements button if allowed
				 * - Load the mapping for the supplements tab
				 * - Sets the supplements counter
				 * @param {object} mSupplements - Supplement data
				 * @param {object} mArticle 	- Article data
				 */
				processSupplementsData: function (mSupplements, mArticle) {
					var iSupplements = _.size(mSupplements),
						oView = this.getView(),
						oArticleViewModel = oView.getModel("ArticleView"),
						that = this;
					// set icontabfilter color to neutral if 0 segments
					if (iSupplements === 0) {
						oArticleViewModel.setProperty("/SupplementsIconColor", "Neutral");
					}
					//
					oArticleViewModel.setProperty("/showSaveCancelButtons/Supplements",
						(iSupplements > 0 && mArticle.BillbackNotReleased === "X" &&
							mArticle.NoBilling === "" && !User.canOnlyRead()));

					// If booking blocked, save button needs to be disabled			  	
					if (this.getView().getModel("Booking").getProperty("/").Blocked) {
						oArticleViewModel.setProperty("/showSaveCancelButtons/Supplements", false);
					}

					// Issue 0076 Amount fields in BS to much zero's
					// In the backend decimal values are stored with 7 zeroes..
					// We dont want to show those zeroes in fiori therefore I do a rtrim removing all zeroes from the right
					if (_.size(mSupplements)) {
						var mEntityProperties = BCDGateway.getMetaDataEntityProperties("supplement");
						for (var sProperty in mEntityProperties) {
							if ("type" in mEntityProperties[sProperty] && mEntityProperties[sProperty].type === "Edm.Decimal") {
								for (var iS in mSupplements) {
									if (!(sProperty in mSupplements[iS])) {
										continue;
									}
									mSupplements[iS][sProperty] = mSupplements[iS][sProperty].toString().replace(new RegExp("[0]*$"), "");
									if (mSupplements[iS][sProperty] === "0.") {
										mSupplements[iS][sProperty] = mSupplements[iS][sProperty] + "00";
									}
								}
							}
						}
					}
					// preload Mapping data (field translations are done in formatter so we need it before we set the data)
					var oMappingModel = oView.getModel("Mapping");
					oMappingModel.loadMappingForEntity(
						"supplement", // Entity
						{
							always: function () { // done callback (both success or error)
								// Bind the model data, now the view will trigger the .format.SupplementsLabel per field
								var oSupplements = oView.getModel("Supplements");
								oSupplements.setData(mSupplements);
								// prevent navTo
								oSupplements.attachPropertyChange(function () {
									$.proxy(that._preventRouterNavigation, that)(I18n.getText("Article.Supplements"));
								});
								// calc total
								$.proxy(that.models.calculateSupplementsTotal, that)();
							},
							success: function (aData) {
									if (!aData || aData.length === 0) {
										return;
									}

									// Bind the model data, now the view will trigger the .format.SupplementsLabel per field
									var oSupplements = oView.getModel("Supplements");
									oSupplements.setData(mSupplements);

									// Issue 0217 In case of Billback, Only new tax & suppl with ApplicationId "DEFAULT" can be created
									var sApplicationsId = (mArticle.BillbackNotReleased !== "X" && mArticle.Billbackindicator === 'B') ? "DEFAULT" : false;

									// then filter make sure only defautl supplement types are set

									var aNewTaxSupplementTypes = [];
									for (var i in aData) {
										if (aData[i].FieldnameBs === "TAXSUPPLEMENTTYPES" && (!sApplicationsId || (sApplicationsId && aData[i].ApplicationsId ===
												sApplicationsId))) {
											aNewTaxSupplementTypes.push(aData[i]);
										}
									}
									oMappingModel.setProperty("/supplement/TAXSUPPLEMENTTYPES", aNewTaxSupplementTypes);
								}
								//,entityData: mSupplements //  entity data (for filtering)
						}
					);

					// set segments count
					oArticleViewModel.setProperty("/SupplementsCount", iSupplements);
				},

				/**
				 * Calculates the supplements total
				 */
				calculateSupplementsTotal: function () {
					var iTotal = 0,
						oView = this.getView(),
						mSupplements = oView.getModel("Supplements").getProperty("/");
					if (mSupplements.length) {
						for (var i in mSupplements) {
							if (iTotal === 0) {
								iTotal = mSupplements[i].Amount;
							} else {
								iTotal = this._calculateCurrency(iTotal, "+", mSupplements[i].Amount);
							}
							//iTotal += mSupplements[i].Amount;                  
						}
					}
					oView.getModel("ArticleView").setProperty("/SupplementsTotal", iTotal);
					// recalc billback Totalamount
					$.proxy(this.billback.recalcTotalAmount, this)();
				}
			},

			/**
			 * Dialog for creating a new article
			 * @namespace com.bcdtravel.pnr.controller.Article.newArticleDialog
			 */
			newArticleDialog: /** @lends com.bcdtravel.pnr.controller.Article.newArticleDialog.prototype */ {
				_dialog: null,
				_cacheArticleTypeMapping: [],
				_cacheAccounts: [],
				/**
				 * Opens the newArticleDialog in which the Article Type should be selected
				 *
				 * If an Article Type is selected the Article.Category and Type are pre-set
				 */
				open: function () {
					// reset view models to clear any error highlighting
					$.proxy(this.models.setViewModels, this)();
					var that = this;
					// open dialog
					this.newArticleDialog._dialog = this._openDialogByFragment(
						"com.bcdtravel.pnr.view.article.NewArticleDialog", // fragment
						{ // Dialog Model data
							ArticleTypes: this.newArticleDialog._cacheArticleTypeMapping,
							ArticleType: "",
							Account: "",
							Accounts: this.newArticleDialog._cacheAccounts
						}
					);
					if (this.newArticleDialog._cacheAccounts.length === 0) {
						BCDGateway.read(
							"/AccountsSet", {
								success: function (mData) {
									if ("results" in mData) {
										that.newArticleDialog._cacheAccounts = mData.results;
										that.newArticleDialog._dialog.getModel("Dialog").setProperty("/Accounts", mData.results);
									}
								}
							});
					}
					// load mapping if it's not already cached
					if (this.newArticleDialog._cacheArticleTypeMapping.length === 0) {
						var oMapping = new MappingModel("FIORI");
						oMapping.loadMappingForEntity(
							"articles", {
								filters: [
									new sap.ui.model.Filter("FieldnameBs", sap.ui.model.FilterOperator.EQ, "ARTICLE_TYPE")
								],
								success: function (mMapping) {
									if (_.size(mMapping) === 0) {
										// show an error if there are no article types are available and nav back
										that.newArticleDialog._dialog.close();
										that._showError(I18n.getText("Article.AddNewDialog.ErrorNoArticleTypes"));
										$.proxy(that.onNavToBooking, that)();
										return;
									}
									that.newArticleDialog._cacheArticleTypeMapping = mMapping;
									that.newArticleDialog._dialog.getModel("Dialog").setProperty("/ArticleTypes", mMapping);
								},
								error: function (e) {
									that.newArticleDialog._dialog.close();
									that._showErrorByOdataResponse(e);
									$.proxy(that.onNavToBooking, that)();
								}
							}
						);
					}
				},
				/**
				 * Create the article
				 * Method is executed when the user presses ok
				 * The new article is being created
				 */
				onOk: function () {
					var mDialog = this.newArticleDialog._dialog.getModel("Dialog").getProperty("/"),
						mSelectedType = null;
					for (var i in mDialog.ArticleTypes) {
						if (mDialog.ArticleTypes[i].ValueBs === mDialog.ArticleType) {
							mSelectedType = mDialog.ArticleTypes[i];
							break;
						}
					}
					if (!mSelectedType) {
						return;
					}
					var that = this;
					// close dialog
					this.newArticleDialog._dialog.close();
					// load model data
					$.proxy(this.models.loadByBookingIdAndArticleId, this)(
						this._bookingId,
						0, // 0 is for new articles
						{
							afterArticleCreate: function (oArticleModel) {
								// set the articlecategory and BookingsId and articletype after creation
								oArticleModel.setProperty("/ArticleCategory", mSelectedType.ArticleCategory);
								oArticleModel.setProperty("/BookingsId", that._bookingId);
								oArticleModel.setProperty("/ArticleType", mSelectedType.ValueBs);
								oArticleModel.setProperty("/Account", mDialog.Account);
							}
						}
					);
				},
				/**
				 * Suggests the user accounts
				 * @param {sap.ui.base.Event} oEvent - onSuggest event
				 */
				handleSuggest: function (oEvent) {
					var sTerm = oEvent.getParameter("suggestValue");
					var aFilters = [];
					if (sTerm) {
						aFilters.push(new sap.ui.model.Filter("accountid", sap.ui.model.FilterOperator.StartsWith, sTerm));
					}
					oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
				},
				/**
				 * Event handler when a ArticleType is selected
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onSelectArticleType: function (e) {
					var oItem = e.getParameter("listItem"),
						oCntx = oItem.getBindingContext("Dialog"),
						mSelected = oCntx.getModel().getProperty(oCntx.getPath()),
						that = this;
					// close dialog
					this.newArticleDialog._dialog.close();
					// load model data
					$.proxy(this.models.loadByBookingIdAndArticleId, this)(
						this._bookingId,
						0, // 0 is for new articles
						{
							afterArticleCreate: function (oArticleModel) {
								// set the articlecategory and BookingsId and articletype after creation
								oArticleModel.setProperty("/ArticleCategory", mSelected.ArticleCategory);
								oArticleModel.setProperty("/BookingsId", that._bookingId);
								oArticleModel.setProperty("/ArticleType", mSelected.ValueBs);
							}
						}
					);
				},
				/**
				 * Set the dialog account to the account that is choosen in the valuehelp popup
				 */
				onChangeAccount: function (e) {
					this.newArticleDialog._dialog.getModel("Dialog").setProperty("/Account", e.getSource().getValue());
				},
				/**
				 * Close the Dialog
				 */
				onClose: function () {
					this.newArticleDialog._dialog.close();
				},
				/**
				 * Opens the account valueHelp
				 * @param {sap.ui.base.Event} e - valueHelp event 
				 */
				onOpenAccountinfo: function (e) {
					var that = this;
					ValueHelp.open("Accountinfo", {
						source: e.getSource(),
						onValueSelect: function (m) {
							that.newArticleDialog._dialog.getModel("Dialog").setProperty("/Account", m.accountid);
						}
					});
				}
			},

			/**
			 * Methods needed for noBilling
			 */
			noBilling: {
				/**
				 * Removes the Nobilling flag on an article
				 */
				onRemoveFlag: function () {
					this.getView().getModel("Article").setProperty("/NoBilling", "");
					$.proxy(this.onSaveArticleData, this)();
				},
				/**
				 * Sets the NoBilling flag to the article
				 */
				onAddFlagAndSave: function () {
					this.getView().getModel("Article").setProperty("/NoBilling", "X");
					$.proxy(this.onSaveArticleData, this)();
				}
			},

			/**
			 * Methods needed in the references tab
			 * @namespace com.bcdtravel.pnr.controller.Article.references
			 */
			references: /** @lends om.bcdtravel.pnr.controller.Article.references.prototype */ {
				/**
				 * The references are sorted by the reference ID
				 * The referenceIds need a custom comparisation method because "REF10" will be sorted on string in stead of nr
				 */
				execSorting: function () {
					// Custom sorter for references
					var oSorter = new sap.ui.model.Sorter("ReferencesId", null);
					oSorter.fnCompare = function (a, b) {
						var iA = parseInt(a.replace("REF", ""), 10),
							iB = parseInt(b.replace("REF", ""), 10);
						if (iA < iB) return -1;
						if (iA === iB) return 0;
						if (iA > iB) return 1;
					};
					var oList = this.getView().byId("ReferenceTable"),
						oBinding = oList.getBinding("items");
					oBinding.sort([oSorter]);
				},

				// currently only for pattern types
				placeholderFormatter: function (iReferencesId) {
					var m = _.findWhere(
						this.getView().getModel("References").getProperty("/"), {
							ReferencesId: iReferencesId
						}
					);
					if (!m || m.ReferencetypesId !== "P" || ["01", "02", "03", "05"].indexOf(m.PatternType) === -1) {
						return;
					}
					var sReturn = "";
					switch (m.PatternType) {
					case "01": // Alfa only
						sReturn = "Enter a Alfa Only value";
						break;
					case "02": // Alfanumeric
						sReturn = "Enter a Alfa/Numeric value";
						break;
					case "03": // Any character
						sReturn = "Enter a value";
						break;
					case "05": // Numeric only
						sReturn = "Enter a Number";
						break;
					}
					if (m.PatternPrefix) {
						sReturn += (sReturn) ? " prefixed by \"" + m.PatternPrefix + "\"" : m.PatternPrefix;
					}
					if (sReturn) {
						sReturn += ".";
					}
					// min max string
					var iMin = parseInt(m.PatternMinLength, 10),
						iMax = parseInt(m.PatternMaxLength, 10),
						sMinMax = "";
					if (iMin) {
						sMinMax = "min " + iMin + ((!iMax) ? " characters" : "");
					}
					if (iMax) {
						sMinMax += ((iMin) ? ", " : "") + "max " + iMax + " characters";
					}
					if (sMinMax) {
						sReturn += (sReturn) ? " (" + sMinMax + ")" : sMinMax;
					}
					return sReturn;
				},

				/**
				 * Event handler if a reference input has changed with type pattern
				 *
				 * The pattern will be validated, if an error is found, the input field wil be highlighted
				 */
				validatePattern: function (e) {
					var oInput = e.getSource(),
						oCntx = oInput.getBindingContext("References"),
						oModel = oCntx.getModel(),
						sPath = oCntx.getPath(),
						m = oModel.getProperty(sPath),
						sError = false;
					// add prefix if not present
					if (m.PatternPrefix && m.Value) {
						if (m.Value.indexOf(m.PatternPrefix) !== 0) {
							m.Value = m.PatternPrefix + m.Value;
							oModel.setProperty(sPath, m);
						}
					}
					// Min and max length
					m.PatternMinLength = (m.PatternMinLength === "") ? 0 : m.PatternMinLength;
					m.PatternMaxLength = (m.PatternMaxLength === "") ? 0 : m.PatternMaxLength;
					if (m.PatternMinLength && m.Value && m.Value.toString().length < m.PatternMinLength) {
						sError = I18n.getText("Article.References.validateError.MinChars", m.PatternMinLength);
						if (m.PatternMaxLength > 0 && m.PatternMinLength === m.PatternMaxLength) {
							sError = I18n.getText("Article.References.validateError.ExactChars", m.PatternMinLength);
						} else if (m.PatternMaxLength > 0) {
							sError = I18n.getText("Article.References.validateError.MinMaxChars", m.PatternMinLength, m.PatternMaxLength + 1);
						}
					} else if (m.PatternMaxLength && m.Value && m.Value.toString().length > m.PatternMaxLength) {
						sError = I18n.getText("Article.References.validateError.MaxChars", m.PatternMaxLength);
					}
					// Alfanumeric check
					if (m.PatternType === "02") {
						var re = /[^a-z\d\- ]/gi;
						var isValid = !(re.test(m.Value));
						if (!isValid) {
							sError = I18n.getText("Article.References.validateError.AlfaNumeric");
						}
					} else if (m.PatternType === "01") { // alfa only remove any numeric value or non a-z character and allow spaces and -
						m.Value = m.Value.toString().replace(/[^a-z\- ]/gi, '');
					} else if (m.PatternType === "05") { // alfa only remove any numeric value or non a-z character and allow spaces and -
						m.Value = m.Value.toString().replace(/[^0-9\- ]/gi, '');
					}
					oCntx.getModel().setProperty(oCntx.getPath() + "/valueState", {
						Text: sError,
						State: (sError) ? "Error" : "None"
					});
				},
				/**
				 * This event is called when a Article value changes (by user : sap.m.Select sap.m.DatePicker sap.m.Input)
				 * If it has an error in the errorSet, the value state is changed to None to indicate that the error will be resolved on save 
				 */
				onChangeCheckError: function (e) {
					var oSrc = e.getSource(),
						sVal = (oSrc.getMetadata().getName() === "sap.m.Select") ? oSrc.getSelectedKey() : oSrc.getValue();
					if (sVal) {
						oSrc.setValueState("None");
						oSrc.closeValueStateMessage();
					}
				},
				/**
				 * Event handler if the validation had an error
				 * @param {sap.ui.base.Event} oEvent - onchanged event
				 */
				onValidateError: function (oEvent) {
					oEvent.getParameter("element").setValueState(sap.ui.core.ValueState.Error);
				},
				/**
				 * Event handler if a validation was successfull\
				 * @param {sap.ui.base.Event} oEvent - onchanged event
				 */
				onValidateSuccess: function (oEvent) {
					oEvent.getParameter("element").setValueState(sap.ui.core.ValueState.None);
				}
			},

			onApproveTransactionFee: function () {
				var oArticleModel = this.getView().getModel("Article"),
					fnBusyIndicator = $.proxy(this._showPageBusyIndicator, this),
					that = this;
				// show Busy indicator
				fnBusyIndicator(true);
				// release billback
				oArticleModel.approveTransactionFee({
					success: function () {
						// hide busyindicator
						fnBusyIndicator(false);
						// reload all data and show success message
						that.models.reload();
					},
					error: function (e) {
						// hide busyindicator
						fnBusyIndicator(false);
						// show error
						that._showErrorByOdataResponse(e);
					}
				});
			},

			/**
			 * Methods to release a billback
			 * @namespace com.bcdtravel.pnr.controller.Article.releaseBillbackDialog
			 */
			releaseBillbackDialog: /** @lends com.bcdtravel.pnr.controller.Article.releaseBillbackDialog.prototype */ {
				_dialog: null,
				/**
				 * Open the Dialog
				 */
				open: function () {
					this.releaseBillbackDialog._dialog = this._openDialogByFragment(
						"com.bcdtravel.pnr.view.article.ReleasebillbackDialog"
					);
				},
				/**
				 * Event handler if the Approve button is pressed
				 *
				 * The billback will be released, and on success an successmessage is shown
				 */
				onApprove: function () {
					var oArticleModel = this.getView().getModel("Article"),
						fnBusyIndicator = $.proxy(this._showPageBusyIndicator, this),
						that = this;
					//close dialog
					this.releaseBillbackDialog._dialog.close();
					// show Busy indicator
					fnBusyIndicator(true);
					// release billback
					oArticleModel.releaseBillback({
						success: function () {
							// hide busyindicator
							fnBusyIndicator(true);
							// reload all data and show success message
							$.proxy(that.models.reload, that)(function () {
								that._showMessage(I18n.getText("Article.ReleaseBillbackDialog.Success"));
							});
						},
						error: function (e) {
							// hide busyindicator
							fnBusyIndicator(false);
							// show error
							that._showErrorByOdataResponse(e);
						}
					});
				},
				/**
				 * Close the dialog
				 */
				onClose: function () {
					this.releaseBillbackDialog._dialog.close();
				}
			},

			/**
			 * Methods needed in the supplements tab
			 * @namespace com.bcdtravel.pnr.controller.Article.supplements
			 */
			supplements: /** @lends * @namespace com.bcdtravel.pnr.controller.Article.supplements.prototype */ {
				/**
				 * Add new supplement dialog
				 * @namespace com.bcdtravel.pnr.controller.Article.supplements.addNewDialog
				 */
				addNewDialog: /** @lends com.bcdtravel.pnr.controller.Article.supplements.addNewDialog.prototype */ {
					_dialog: null,
					/**
					 * Open the Dialog
					 */
					open: function () {
						var oView = this.getView(),
							sCurrency = oView.getModel("Article").getProperty("/Currency"),
							mMapping = oView.getModel("Mapping").getProperty("/"),
							mSupplementTypes = [];
						if ("supplement" in mMapping && "TAXSUPPLEMENTTYPES" in mMapping.supplement) {
							for (var i in mMapping.supplement.TAXSUPPLEMENTTYPES) {
								var mCurrent = mMapping.supplement.TAXSUPPLEMENTTYPES[i];
								if (!("ValueBs" in mCurrent) || !("ValueBcd" in mCurrent)) {
									continue;
								}
								mSupplementTypes.push({
									type: mCurrent.ValueBs,
									typeMapped: mCurrent.ValueBcd || mCurrent.ValueBs
								});
							}
						}
						// open dialog
						this.supplements.addNewDialog._dialog = this._openDialogByFragment(
							"com.bcdtravel.pnr.view.article.NewSupplementDialog", // fragment
							{ // Dialog Model data
								SupplementTypes: mSupplementTypes,
								SupplementType: "",
								SupplementAmount: "",
								Currency: sCurrency
							}
						);
					},
					/**
					 * Event handler if the Amount has changed
					 * @param {sap.ui.base.Event} e - onchanged event
					 */
					onChangeAmount: function (e) {
						//	this.supplements.addNewDialog._dialog.getModel("Dialog").setProperty("/SupplementAmount", e.getParameters().value);
					},
					/**
					 * Event handler if the Add new button is pressed
					 * 
					 * This will create a new supplement, on success its reloads the data
					 */
					onAddNew: function () {
						var oDialog = this.supplements.addNewDialog._dialog,
							mDialog = oDialog.getModel("Dialog").getProperty("/"),
							that = this;
						oDialog.setBusy(true);
						BCDGateway.create(
							"/supplementSet", {
								BookingsId: this._bookingId,
								ArticlesId: parseInt(this._articleId, 10),
								Amount: mDialog.SupplementAmount,
								Taxsupplementtypes: mDialog.SupplementType,
								Taxsupplementidcurrency: mDialog.Currency
							}, {
								success: function (m) {
									oDialog.close();
									// reset all data but keep all changes set in the articles tab
									//	var oArticleModel	= that.getView().getModel("Article"),
									//		mArticleData	= $.extend(true, {}, oArticleModel.getProperty("/"));
									//	console.log("orig", mArticleData);

									//	$.proxy(that.models.reload, that)(function() {
									//		var mReloadedArticleData = $.extend(true, {}, oArticleModel.getProperty("/"));
									//		console.log(mReloadedArticleData);
									//oArticleModel.setProperty("/", mArticleData);
									$.proxy(that.models.reloadSupplements, that)();
									that._showMessage(I18n.getText("SavedSuccefully"));
									//	});
								},
								error: function (e) {
									oDialog.close();
									$.proxy(that._showErrorByOdataResponse(e), that);
								}
							}
						);
					},
					/**
					 * Closes the dialog
					 */
					onClose: function () {
						this.supplements.addNewDialog._dialog.close();
					}
				}
			},

			/**
			 * Valuehelp methods (value help dialog openers)
			 * @namespace com.bcdtravel.pnr.controller.Article.valueHelp
			 */
			valueHelp: /** @lends com.bcdtravel.pnr.controller.Article.valueHelp.prototype */ {
				/**
				 * Open the ValueHelp for Accounts
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenAccountinfo: function (e) {
					var that = this,
						mArticle = this.getView().getModel("Article").getProperty("/");
					ValueHelp.open("Accountinfo", {
						source: e.getSource(),
						modelData: {
							IssueDate: mArticle.IssueDate
						}
					});
				},
				/**
				 * Open the ValueHelp for Airlines
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenAirlines: function (e) {
					ValueHelp.open("Airlines", {
						source: e.getSource()
					});
				},
				/**
				 * Open the ValueHelp for Airports
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenAirports: function (e) {
					ValueHelp.open("Airports", {
						source: e.getSource()
					});
				},
				/**
				 * Open the ValueHelp for Suppliers
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenSupplier: function (e) {
					var that = this,
						mArticle = this.getView().getModel("Article").getProperty("/");
					ValueHelp.open("Suppliers", {
						source: e.getSource(),
						modelData: {
							Bukrs: mArticle.Bukrs,
							Billbackindicator: mArticle.Billbackindicator
						},
						onValueSelect: function () {
							$.proxy(that.billback.enableReleaseButtonWhenAllowed, that)();
						}
					});
				},
				/**
				 * Open the ValueHelp for Railstations
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenRailstations: function (e) {
					ValueHelp.open("Railstations", {
						source: e.getSource(),
						modelData: {
							Supplier: this.getView().getModel("Article").getProperty("/Supplier")
						}
					});
				},
				/**
				 * Open the ValueHelp for Hotels
				 */
				onOpenHotels: function () {
					var that = this;
					ValueHelp.open("Hotels", {
						onValueSelect: function (m) {
							var oArticle = that.getView().getModel("Article");
							oArticle.setProperty("/Hotelchaincode", m.Masterchaincode);
							oArticle.setProperty("/Hotelname", m.Actualpropertyname);
							oArticle.setProperty("/Hotelpropertycode", m.BcdpropertyCode);
						},
						modelData: {
							ApplicationsId: this.getView().getModel("Booking").getProperty("/ApplicationsId")
						}
					});
				},
				/**
				 * Open the ValueHelp for Mainarrival or Maindeparture
				 * @param {sap.ui.base.Event} e - onchanged event
				 */
				onOpenArrivalDeparture: function (e) {
					var sCategory = this.getView().getModel("Article").getProperty("/ArticleCategory");
					if (sCategory.toUpperCase() === "RAIL") {
						$.proxy(this.valueHelp.onOpenRailstations, this)(e);
						return;
					}
					$.proxy(this.valueHelp.onOpenAirports, this)(e);
				}
			}

		});
		return oArticleController;

	},
	/* bExport= */
	true);

/* JSDOC Type Definitions */

/**
 * A callback function which is called when the data has been retrieved.
 * @callBack fnSuccessErrorCallback
 * @param {object} The data of the retrieved data
 * @param {object} Further information about the response of the request.
 */