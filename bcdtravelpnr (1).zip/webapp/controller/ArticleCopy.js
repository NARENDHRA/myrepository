/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
/* global _ */
sap.ui.define([
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/I18n",
	"../utils/FragmentDialog",
	"../model/CopyArticleScenarios",
	"./ValueHelp",
	"../utils/Utilities",
	"../model/Article"
], function (BCDGateway, I18n, FragmentDialog, CopyArticleScenarios, ValueHelp, Utilities, ArticleModel) {

	var _private = {
		parseParams: function (mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.done = ("done" in mParams && typeof mParams.done === "function") ? mParams.done : function () {};
			return mParams;
		},
		// handle the return message from the CopyHeaderSet
		showDoneMessage: function (sType, sMessage) {
			jQuery.sap.require("sap.m.MessageBox");
			if (!sMessage && ["", "S"].indexOf(sType) !== -1) {
				sMessage = I18n.getText("Article.copy.SuccessMessage");
			}
			if (sType === "E") {
				sap.m.MessageBox.error(sMessage);
			} else {
				sap.m.MessageBox.success(sMessage);
			}
		}
	};

	/**
	 * Scenario select dialog
	 */
	var oScenarioSelect = {
		_Dialog: null,
		_DoneCallback: null,
		_MappingModel: null,
		/**
		 * mParameters.done // done callback
		 * mParameters.mappingModel
		 */
		openDialog: function (mArticle, mParameters) {
			var mParams = _private.parseParams(mParameters);
			oScenarioSelect._DoneCallback = mParams.done;
			oScenarioSelect._MappingModel = mParams.mappingModel || null;
			oScenarioSelect._Dialog = FragmentDialog.open(
				"com.bcdtravel.pnr.view.article.copy.SelectScenario", {
					i18n: I18n,
					dialogData: {
						busy: true,
						scenarios: [],
						showSelectbox: true,
						showWarning: false,
						scenario: 0,
						article: mArticle
					},
					controller: oScenarioSelect
				}
			);
			var oDialogModel = oScenarioSelect._Dialog.getModel("Dialog");
			CopyArticleScenarios.getScenariosToSelect({
				article: mArticle,
				success: function (mScenarios) {
					oDialogModel.setProperty("/busy", false);
					oDialogModel.setProperty("/scenarios", mScenarios);
					var b = (!mScenarios || Object.keys(mScenarios).length === 0) ? false : true;
					oDialogModel.setProperty("/showSelectbox", b);
					oDialogModel.setProperty("/showWarning", !b);
				},
				error: function (oError) {
					//oScenarioSelect._DoneCallback();
					oScenarioSelect._Dialog.close();
					Utilities._showErrorByOdataResponse(oError);
				}
			});
		},
		onSelect: function () {
			var mDialog = oScenarioSelect._Dialog.getModel("Dialog").getProperty("/");
			CopyArticleScenarios.getScenario(
				mDialog.scenario, {
					success: function (mScenarios) {
						oScenarioSelect._Dialog.close();
						var bInputNeededFromUser = false,
							aScenariosArticleLines = []; // holds all scenarios that are not Original scenarios (O1 O2 etc) 
						// check if there is any user input needed before the copy can be done
						for (var i in mScenarios) {
							// Do not create new article lines for O (Original) lines
							if (mScenarios[i].action.indexOf("O") === 0) {
								continue;
							}
							aScenariosArticleLines.push(mScenarios[i]);
							if (mScenarios[i].field_value_inp_type === 'S') {
								bInputNeededFromUser = true;
							}
						}
						if (!bInputNeededFromUser) {
							// no user input needed, start the copy process
							oCopyProcess.start( // eslint-disable-line
								mDialog.scenario,
								mDialog.article,
								aScenariosArticleLines, {}, // userinput
								{
									done: oScenarioSelect._DoneCallback
								}
							);
						} else {
							// User input needed: Open the user input dialog
							oUserInput.openDialog( // eslint-disable-line
								mDialog.scenario,
								mDialog.article,
								aScenariosArticleLines, {
									done: oScenarioSelect._DoneCallback,
									mappingModel: oScenarioSelect._MappingModel
								}
							);
						}
					},
					error: function (oError) {
						oScenarioSelect._DoneCallback();
						oScenarioSelect._Dialog.close();
						Utilities._showErrorByOdataResponse(oError);
					}
				}
			);
		}
	};

	/**
	 * User input dialog
	 */
	var oUserInput = {
		_Dialog: null,
		_DoneCallback: null,
		openDialog: function (sScenario, mArticle, aScenarios, mParameters) {
			var mParams = _private.parseParams(mParameters),
				mUserInput = {},
				sScenarioTitle = "";
			oUserInput._DoneCallback = mParams.done;

			// prepare the fields which require user input
			for (var i in aScenarios) {
				if (sScenarioTitle === "") {
					sScenarioTitle = (aScenarios[i].scenario === sScenario) ? aScenarios[i].scenario + " " + aScenarios[i].description : "";
				}
				if (aScenarios[i].field_value_inp_type === "S") {
					if (!(aScenarios[i].step_no in mUserInput)) {
						mUserInput[aScenarios[i].step_no] = {
							step: aScenarios[i].step_no,
							fields: {}
						};
					}
					var sOdataFieldname = BCDGateway.translateFieldSapToOdata("articles", aScenarios[i].fieldname_bs),
						oMandatoryfield = aScenarios[i].Mand_Field; // Added by Naresh Ponnada for mandatory check 
					if (oMandatoryfield === "X") {
						oMandatoryfield = true;
					} else {
						oMandatoryfield = "";
					}
					var mField = {
						value: aScenarios[i].field_value,
						key: sOdataFieldname,
						label: I18n.getText("article." + sOdataFieldname),
						type: "default", // default (input) .. can be changed by the mapping
						fieldname_bs: aScenarios[i].fieldname_bs, // needed for the mapping
						selectoptions: [], // in case of an select this holds the select options
						valueHelp: null,
						inputDescription: "",
						required: oMandatoryfield
					};

					/**
					 * Value Help input fields
					 */
					switch (sOdataFieldname) {
					case "Account":
						mField.valueHelp = function (e) {
							ValueHelp.open("Accountinfo", {
								source: e.getSource()
							});
						};
						break;

					case "Mainarrival":
					case "Maindeparture":
						mField.valueHelp = function (e) {
							if (mArticle.ArticleCategory.toUpperCase() === "RAIL") {
								ValueHelp.open("Railstations", {
									source: e.getSource(),
									modelData: {
										Supplier: mArticle.Supplier
									}
								});
								return;
							}
							ValueHelp.open("Airports", {
								source: e.getSource()
							});
						};
						break;

					case "Supplier":
						mField.valueHelp = function (e) {
							ValueHelp.open("Suppliers", {
								source: e.getSource(),
								modelData: {
									Bukrs: mArticle.Bukrs,
									Billbackindicator: mArticle.Billbackindicator
								}
							});
						};
						break;

					case "Ticketedairline":
					case "Exchangeticketedairline":
						mField.valueHelp = function (e) {
							ValueHelp.open("Airlines", {
								source: e.getSource()
							});
						};
						break;
					}

					// value help set : then the field is an input field
					if (mField.valueHelp) {
						mField.field = "input";
					}

					/**
					 * Currency fields
					 */
					if (ArticleModel.isCurrencyField(sOdataFieldname)) {
						mField.type = "currency";
						mField.inputDescription = mArticle.Currency;
					}

					/**
					 * Step input fields
					 */
					if (["Conjunction", "Numberofpeople", "Quantityofproduct"].indexOf(sOdataFieldname) !== -1) {
						mField.type = "stepinput";
					}

					/** 
					 * Percentage
					 */
					if (["Commissionpercentage"].indexOf(sOdataFieldname) !== -1) {
						mField.type = "percentage";
						mField.inputDescription = "%";
					}

					/**
					 * Email
					 */
					if (sOdataFieldname === "Einvoiceemailaddress") {
						mField.field = "email";
					}

					/**
					 * Exchangeindicator
					 */
					if (sOdataFieldname === "Exchangeindicator") {
						mField.type = "checkbox";
					}

					/**
					 * Datepicker
					 */
					// if (sOdataFieldname === "IssueDate") {
					// 	mField.field = "date";
					// }

					/**
					 * Memo
					 */
					if (sOdataFieldname === "Note") {
						mField.type = "note";
						mField.required = true;
					}

					//Add field contents for Update Article scenarios
					if (sOdataFieldname in mArticle && aScenarios[i].action === "UA") {
						mField.value = mArticle[sOdataFieldname];
					}

					// add input 					
					mUserInput[aScenarios[i].step_no].fields[sOdataFieldname] = mField;
				}
			}
			oUserInput._Dialog = FragmentDialog.open(
				"com.bcdtravel.pnr.view.article.copy.UserInput", {
					i18n: I18n,
					dialogData: {
						busy: true,
						Title: sScenarioTitle,
						scenarios: aScenarios,
						userInput: mUserInput,
						showWarning: false,
						scenario: sScenario,
						article: mArticle,
						mapping: {}
					},
					controller: oUserInput
				}
			);
			// By loading the mapset we check if the input field should be a selectbox
			if ("mappingModel" in mParams && mParams.mappingModel !== null && Object.keys(mUserInput).length > 0) {
				mParams.mappingModel.loadMappingForEntity(
					"articles", {
						always: function (aMapping) {
							var oDialogModel = oUserInput._Dialog.getModel("Dialog");
							oDialogModel.setProperty("/busy", false);
							if (!(aMapping && aMapping.length)) {
								return;
							}

							for (var iStepNo in mUserInput) {
								for (var sField in mUserInput[iStepNo].fields) {
									var aSelectOptionsFromMapping = [];
									// if we already set the type to something different than an input field
									// do not change it to a select
									if (mUserInput[iStepNo].fields[sField].type !== "default") {
										continue;
									}
									for (var iM in aMapping) {
										if (mUserInput[iStepNo].fields[sField].fieldname_bs === aMapping[iM].FieldnameBs) {
											aSelectOptionsFromMapping.push({
												ValueBs: aMapping[iM].ValueBs,
												ValueBcd: aMapping[iM].ValueBcd
											});
										}
									}
									if (aSelectOptionsFromMapping.length > 0) {
										mUserInput[iStepNo].fields[sField].selectoptions = aSelectOptionsFromMapping;
										mUserInput[iStepNo].fields[sField].type = "select";
									}
								}
							}
							oDialogModel.setProperty("/userInput", mUserInput);
						}
					}
				);
			} else {
				oUserInput._Dialog.getModel("Dialog").setProperty("/busy", false);
			}

			//new MappingModel(sApplicationsId, mArticle.ArticleCategory), "Mapping"
		},
		onValueHelp: function (e) {
			var oState = e.getSource().getValueState();
			var oCtx = e.getSource().getBindingContext("Dialog"),
				m = oCtx.getModel().getProperty(oCtx.getPath());
			if (typeof m.valueHelp === "function") {
				m.valueHelp(e);
			}
			if (oState === "Error") {
				e.getSource().setValueState("None");
			}
		},
		onChkSelect: function (e) {
			var oCtx = e.getSource().getBindingContext("Dialog"),
				m = oCtx.getModel().getProperty(oCtx.getPath());
			m.value = e.getParameter("selected") ? "X" : "";
		},
		// Chengae event for valuestate for all fileds : added by Naresh Ponnada.
		onChangetextArea: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onChangeCombox: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onChangeCurrencyType: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onChangeInputValuedddd: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onchangePercentageType: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onChangeper: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onChangeStepInput: function (evt) {
			var src = evt.getSource();
			var oVal = evt.getSource().getValue();
			if (oVal) {
				src.setValueState("None");
			}
		},
		onStartCopy: function () {
			var oSaveArtieclflg = true;
			var mDialog = oUserInput._Dialog.getModel("Dialog").getProperty("/"),
				mUserInput = {};
			// Add by Naresh Ponnada for Mandatory check for copy and update case
			var oItems = oUserInput._Dialog.getContent()[0].getItems()[0].getItems()[0].getItems();
			for (var i = 0; i < oItems.length; i++) {
				var ofiledItems = oItems[i].getAggregation("content");
				for (var f = 0; f < ofiledItems.length; f++) {
					var oVisble = ofiledItems[f].getVisible();
					if (oVisble) {
						if (ofiledItems[f].getId().search("select") === -1) {
							if (ofiledItems[f]._sPickerType === "Dropdown") {
								var oRequired = ofiledItems[f].getRequired();
								if (oRequired) {
									var oValue = ofiledItems[f].getValue();
									if (!oValue) {
										ofiledItems[f].setValueState("Error");
										oSaveArtieclflg = false;
									}
								}
							} else {
								if (ofiledItems[f].getId().search("box") !== 2) {
									var oRequired1 = ofiledItems[f].getRequired();
									if (oRequired1) {
										var oValue1 = ofiledItems[f].getValue();
										if (!oValue1) {
											ofiledItems[f].setValueState("Error");
											oSaveArtieclflg = false;
										}
									}
								}

							}
						}
					}
				}
			}
			if (!oSaveArtieclflg) {
				return;
			}
			// rewrite te userinput to 
			// [step][fieldname] = value
			for (var i in mDialog.userInput) {
				mUserInput[mDialog.userInput[i].step] = {};
				for (var iP in mDialog.userInput[i].fields) {
					mUserInput[mDialog.userInput[i].step][mDialog.userInput[i].fields[iP].key] = mDialog.userInput[i].fields[iP].value;
				}
			}
			// loading indicator
			oUserInput._Dialog.setBusy(true);
			// Start copy process
			oCopyProcess.start( // eslint-disable-line
				mDialog.scenario,
				mDialog.article,
				mDialog.scenarios,
				mUserInput, {
					done: function (m) {
						oUserInput._Dialog.close();

						oUserInput._DoneCallback(m);
					}
				}
			);
		}
	};

	/**
	 * start and save the copy
	 */
	var oCopyProcess = {
		start: function (sScenario, mArticle, aScenarios, mUserInput, mParameters) {
			var mParams = _private.parseParams(mParameters),
				mCopyHeader = {
					bookings_id: mArticle.BookingsId,
					articles_id: mArticle.ArticlesId,
					article_type: mArticle.ArticleType,
					copy_scenario: sScenario,
					articlesSet: []
				},
				mNewArticleLines = {};
			//var aNewArticlesaAllreadyAdded = [];
			// create the article lines that are used to perform the copy
			// For every new article > Transactiontype will be set to the scenario.transactiontype
			for (var i in aScenarios) {
				var mCurr = aScenarios[i];
				if (!(mCurr.step_no in mNewArticleLines)) {
					mNewArticleLines[mCurr.step_no] = _.clone($.extend(true, mArticle, {})); // underscore.js _.clone creates shallow-copied clone of the provided plain object. , the reference will be lost
					mNewArticleLines[mCurr.step_no].Transactiontype = mCurr.transactiontype;
				}
				// check if the odata field is in the articlesSet
				var sOdataFieldname = BCDGateway.translateFieldSapToOdata("articles", mCurr.fieldname_bs);
				if (!(sOdataFieldname in mNewArticleLines[mCurr.step_no])) {
					if (window.console) { // this console is needed to find out if something is wrong! .. in IE console.log doesnt exist.. 
						console.log("ArticleCopy.js: \"" + sOdataFieldname + "\" not a valid oData article fieldname"); // eslint-disable-line
					}
					continue;
				}
				if (mCurr.field_value_inp_type === "F") {
					mNewArticleLines[mCurr.step_no][sOdataFieldname] = mCurr.field_value;
				} else if ( // add fixed values
					mCurr.field_value_inp_type === "S" && mCurr.step_no in mUserInput && sOdataFieldname in mUserInput[mCurr.step_no]) { // add user input values
					mNewArticleLines[mCurr.step_no][sOdataFieldname] = mUserInput[mCurr.step_no][sOdataFieldname];
				}
			}
			// add the new article lines to the Copy header
			mCopyHeader.articlesSet = _.values(mNewArticleLines);

			// save data
			BCDGateway.create(
				"/CopyHeaderSet",
				mCopyHeader, {
					success: function (m) {
						if (typeof m === "object" && "returnMessage" in m && "returnType" in m) {
							_private.showDoneMessage(m.returnType, m.returnMessage);
						}
						mParams.done(m);
					},
					error: function (oError) {
						Utilities._showErrorByOdataResponse(oError);
					}
				}
			);
		}
	};

	return {
		/**
		 * @param mArticle = the original Article line
		 */
		openScenarioSelectDialog: function (mArticle, mParameters) {
			oScenarioSelect.openDialog(mArticle, mParameters);
		}
	};

});