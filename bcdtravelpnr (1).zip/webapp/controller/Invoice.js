/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/I18n",
	"../utils/FragmentDialog",
	"com/bcdtravel/pnr/model/Mapping"
], function(BCDGateway, I18n, FragmentDialog, Mapping) {
	
	// Invoice methods are being used in the booking and article controller 
	
	return {
		// make sure to call this method with a proxy (so that this points to the view controller)
		onTableUpdateFinished: function(fnCallback) {
			if (typeof fnCallback === "function") {
				this.getView().byId("InvoicesTable").attachUpdateFinished(fnCallback);
			}
		},
		onDownload: function(e) {
			var oCtx		= e.getSource().getBindingContext("BCDGateway"),
				mInvoice	= oCtx.getModel().getProperty(oCtx.getPath()),
				sUrl		= BCDGateway.getServiceUrl() + "/invoiceSet('" + mInvoice.InvoiceNr + "')/$value";
			window.open(sUrl, "_blank");
		},
		onEmail: function(e) {
			var oCtx		= e.getSource().getBindingContext("BCDGateway"),
				mInvoice	= oCtx.getModel().getProperty(oCtx.getPath()),
				that		= this,
				oDialog 	=  FragmentDialog.open(
					"com.bcdtravel.pnr.view.booking.EmailInvoice",
					{
						i18n		: I18n,
						dialogData	: {
							emailTo				: "",
							sendButtonEnabled	: false,
							subject				: "",
							text				: "",
							bookingId			: mInvoice.BookingsId,
							reasoncodes			: [],
							Reasoncode			: ""
						},
						controller	: {
							onEmailChange: function(eChange) {
								var sEmail = eChange.getParameter("value");
								oDialog.getModel("Dialog").setProperty("/sendButtonEnabled", (sEmail.length ? true : false));
							},
							onSendEmail: function() {
								try {
									oDialog.byId("email").getBinding("value").getType().validateValue(oDialog.getDialogData("/emailTo"));
								} catch (oException) {
									return;
								}
								oDialog.setBusy(true);
								BCDGateway.callFunction(
						          "/sendInvoices",
						          {
						            urlParameters: {
						              emailAddress	: oDialog.getDialogData("/emailTo"),
						              InvoiceNr		: mInvoice.InvoiceNr,
						              subject		: oDialog.getDialogData("/subject"),
						              text			: oDialog.getDialogData("/text"),
						              BookingsId	: oDialog.getDialogData("/bookingId"),
						              reasonCode	: oDialog.getDialogData("/Reasoncode"),
						              orderedBy		: ""
						            },
						            method  : "GET",
						            success : function(m) {
						            	if ("results" in m && m.results.length && "message" in m.results[0] && m.results[0].message) {
						            		$.proxy(that._showError, that)(m.results[0].message); 
						            	} else {
						            		$.proxy(that._showMessage, that)(I18n.getText("Booking.InvoiceEmailSendSuccess", oDialog.getDialogData("/emailTo")));
						            	}
						            	oDialog.close();
						            },
						            error   : function(oError) {
						            	oDialog.close();
						            	$.proxy(that._showErrorByOdataResponse, that)(oError);
						            }
						          }
						        );
							}
						}
					}
				);
				var oMapping = new Mapping(this.getView().getModel("Booking").getProperty("/ApplicationsId"), "Misc");
				oMapping.loadMappingForEntity(
					"articles",  // Entity
					{
						filters: [
							new sap.ui.model.Filter("FieldnameBs", "EQ", "REASONCODES"),
						],
						success: function(m) {
							var mNew = [];
							for (var i in m) {
								if (m[i].ValueBcd) {
									mNew.push(m[i]);
								}
							}
							oDialog.getModel("Dialog").setProperty("/reasoncodes", mNew);
						}
					}
				);
				
				// register email input so that it checks the email type for errors
				sap.ui.getCore().getMessageManager().registerObject(oDialog.byId("email"), true);
		},
		formatInvoiceDate: function(sDate) {
			if (sDate && sDate.length === 8) {
				var oDate = new Date(sDate.substring(0,4) + "-" + sDate.substring(4,6) + "-" + sDate.substring(6,8));
				return oDate.toLocaleDateString();
			}
			return sDate;
		},
		formatTooltip: function(sDefault, sAvailableStatus) {
			var sTooltip = "";
			switch(sAvailableStatus) {
				case "S":
					sTooltip = sDefault;
					break;
				case "E":
					sTooltip = I18n.getText("Booking.InvoiceError");
					break;
				default:
					sTooltip = I18n.getText("Booking.InvoiceNotArchived"); 
					break;
			}
			return sTooltip;
		},
		stripLeadingZeroes: function(sIvoiceNr) {
			var iParsed =  parseInt(sIvoiceNr, 10);
			return isNaN(iParsed) ? sIvoiceNr : iParsed;
		}
	};
});