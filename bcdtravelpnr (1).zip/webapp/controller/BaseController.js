/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"com/bcdtravel/pnr/model/I18n"
], function (Controller, History, I18n) {
	"use strict";

	/**
	 * Controller for the Booking View
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.controller.BaseController
	 * @extends 	sap.ui.core.mvc.Controller
	 * 
	 * @constructor
	 * @public
	 */
	var oBaseController = Controller.extend("com.bcdtravel.pnr.controller.BaseController", /** @lends com.bcdtravel.pnr.controller.BaseController.prototype */ {
		/**
		 * Get the registered router
		 * @param 	{string} [sName]	- Name of the router
		 * @returns {sap.ui.core.routing.Router}
		 */
		_getRouter: function (sName) {
			return this.getOwnerComponent().getRouter(sName);
		},
		/**
		 * Prevent the router navTo method by prompting the user with a dialog
		 * @param {string} sBy - What causes the navTo to be cancelled
		 */
		_preventRouterNavigation: function (sBy) {
			if (this._getRouter()._preventNavBy === null) {
				this._getRouter()._preventNavBy = {};
			}
			this._getRouter()._preventNavBy[sBy] = sBy;
		},
		/**
		 * Allow the router navTo method
		 * @param {string}[sBy] - if ommitted all navTo's will be allowed
		 */
		_allowRouterNavigation: function (sBy) {
			if (sBy && this._getRouter()._preventNavBy !== null) {
				delete this._getRouter()._preventNavBy[sBy];
				if (Object.keys(this._getRouter()._preventNavBy).length === 0) {
					this._getRouter()._preventNavBy = null;
				}
			} else {
				this._getRouter()._preventNavBy = null;
			}
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		*/

		/**
		 * Get a url parameter
		 * @param	{string}		name	- Parameter name you want to have
		 * @param	{string}		[url]	- URL
		 * @returns {(string|null)}
		 */
		_getURLParameter: function (name, url) {
			var sName = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
			var regexS = "[\\?&]" + sName + "=([^&#]*)";
			var regex = new RegExp(regexS);
			var results = regex.exec((url) ? url : location.href);
			return results === null ? null : results[1];
		},

		/**
		 * Event handler for navigation
		 * @param {string} to						- Name of the route
		 * @param {string} [mParameters]			- Parameters of the route
		 * @param {string} [bReplaceHash=false]		- If set to true, the hash is replaced, and there will be no entry in the browser history, if set to false, the hash is set and the entry is stored in the browser history.
		 **/
		_navTo: function (to, mParameters, bReplaceHash) {
			var oRouter = this._getRouter();
			if (oRouter.getRoute(to)) {
				oRouter.navTo(to, mParameters, bReplaceHash);
			} else {
				jQuery.sap.log.error("No route for " + to);
			}
		},

		/**
		 * Event handler  for navigating back.
		 * It checks if there is a history entry. If yes, history.go(-1) will happen.
		 * If not, it will replace the current entry of the browser history with the master route.
		 */
		_onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				// Otherwise we go backwards with a forward history
				var bReplace = true;
				this.getRouter().navTo("master", {}, bReplace);
			}
		},

		/**
		 * Open a Error message box
		 * @param {string}	sMessage - the message that should be showed in the message box
		 */
		_showError: function (sMessage) {
			jQuery.sap.require("sap.m.MessageBox");
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.error(
				sMessage, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		/**
		 * Open a MessageToast with a default duration of 5 seconds
		 * @param {string}	sMessage			- the message that should be showed
		 * @param {number}	[iDuration=5000]	- Visibility duration time 
		 */
		_showMessage: function (sMessage, iDuration) {
			sap.m.MessageToast.show(sMessage, {
				duration: iDuration || 5000,
				width: "20em"
			});
		},
		/**
		 * Show an error dialog with default text + any response text from the gateway error
		 * @param {object} e - the error response from the service
		 */
		_showErrorByOdataResponse: function (e) {
			if (typeof e === "undefined") {
				return;
			}
			jQuery.sap.log.debug(e);
			var mOdataError = null,
				strMessage = I18n.getText("oDataLoadError");
			// Errors  from ECC systems
			if (typeof e === "object" && "responseText" in e) {
				try {
					var mResponseText = JSON.parse(e.responseText);
					if ("error" in mResponseText) {
						mResponseText = mResponseText.error;
					}
					if ("message" in mResponseText) {
						mOdataError = mResponseText;
					}
				} catch (eCatch) {
					if (e.responseText.length) {
						mOdataError = {
							message: {
								value: e.responseText
							}
						};
					}
				}
			}
			// Errors of other SAP-systems & default oData errors
			if (typeof e === "object" && mOdataError === null && "message" in e) {
				if (typeof e.message === "string") {
					mOdataError = {
						message: {
							value: e.message
						}
					};
				} else {
					mOdataError = e;
				}
			}
			// string only
			if (mOdataError === null && typeof e === "string" && e.length) {
				mOdataError = {
					message: {
						value: e
					}
				};
			}
			// odata message
			if (mOdataError !== null && "message" in mOdataError && typeof mOdataError.message === "object" && "value" in mOdataError.message) {
				strMessage = I18n.getText("oDataLoadError") + "\r\n \r\n\ Server Message: \r\n" + mOdataError.message.value;
			} else if (mOdataError !== null && "message" in mOdataError && typeof mOdataError.message === "string") {
				strMessage = I18n.getText("oDataLoadError") + "\r\n \r\n\ Server Message: \r\n" + mOdataError.message;
			}
			this._showError(strMessage);
		},

		/**
		 * jQuery DOM selector
		 * @param	{string} strId - Element id
		 * @returns	{object} jQuery object
		 */
		_$byId: function (strId) {
			return jQuery.sap.byId(this.getView().byId(strId).getId());
		},
		/**
		 * Attach aj jQuery event handler function for one or more events to the selected elements.
		 * @param		{string} strEvent								- jQuery Event: One or more space-separated event types and optional namespaces, such as "click" or "keydown.myPlugin".
		 * @param		{string} strId									- View local ID of the element
		 * @param		{(string|fnOnIdHandler)} [strSelectorOrHandler]	- Sub-element dom selector to filter the descendants of the selected elements that trigger the event. If the selector is null or omitted, the event is always triggered when it reaches the selected element
		 * @param		{fnOnIdHandler}			 [fn]					- A function to execute when the event is triggered. The value false is also allowed as a shorthand for a function that simply does return false.
		 * @example
		 * this._$onId("keyup", "Password1", " input", function(e) { console.log("pressed key", e.which); });
		 */
		/**
		 * A function to execute when the event is triggered. The value false is also allowed as a shorthand for a function that simply does return false.
		 * @callBack fnOnIdHandler
		 * @param {object} eventObject
		 * @param {*} Anything extraParameter
		 */
		_$onId: function (strEvent, strId, strSelectorOrHandler, Fn) {
			/*
				Example: this._$onId("keyup", "Password1", " input", function(e) {};
				evaluates to: $("body").on("keyup", #viewiID--Password1 input", function(e){});
			*/
			var Id = "#" + this.getView().byId(strId).getId(),
				fnOn = strSelectorOrHandler;
			if (typeof strSelectorOrHandler !== "function" || typeof strSelectorOrHandler === "string") {
				fnOn = Fn;
				Id += strSelectorOrHandler;
			}
			$(document).on(strEvent, Id, fnOn);
		},

		/**
		 * Open a Dialog from a fragment
		 * @param {string} strFragment	- fragment location (namespace.view.fragmentname)
		 * @param {object} mModel		- Model bound to the Dialog view as "Dialog"
		 * @returns {sap.m.Dialog}		- dialog object with 2 extra properties byId and getDialogData
		 */
		_openDialogByFragment: function (strFragment, mModel) {
			var oDialog = sap.ui.xmlfragment(strFragment, strFragment, this);
			if (!mModel)
				mModel = {};
			// set sizelimit to higher nr: in case of a selectbox now all items are shown
			var oModel = new sap.ui.model.json.JSONModel(mModel);
			oModel.setSizeLimit("9999999");
			oDialog.setModel(oModel, 'Dialog');
			//oDialog.setModel(I18n, "i18n");	
			// add dependancy (so that all models can be used)
			this.getView().addDependent(oDialog);
			// destory dialog after close
			oDialog.attachEvent('afterClose', function () {
				oDialog.destroy();
				oDialog = null;
			});
			// object selector
			// @param {string} sId - View local Id
			oDialog.byId = function (sId) {
				return sap.ui.getCore().byId(sap.ui.core.Fragment.createId(strFragment, sId));
			};
			// return the dialog data (Dialog Model data)
			oDialog.getDialogData = function () {
				return oDialog.getModel("Dialog").getProperty("/");
			};
			// add compact class
			if (this.getView().$().closest(".sapUiSizeCompact").length > 0) {
				oDialog.addStyleClass("sapUiSizeCompact");
			}
			// open the dialog
			oDialog.open();
			// return
			return oDialog;
		},

		/**
		 * Calculate currency
		 * @param {number}	a 						- first floating number
		 * @param {string}	operator				- Math Operator: "+", "-", "/" or "*"
		 * @param {number}  b						- second floating number
		 * @returns {number}						- calculated currency
		 */
		_calculateCurrency: function (a, operator, b) {
			/*
				In JS Currency values should be treated as integers (multiplied with 100) before processing.
				{@link https://docs.oracle.com/cd/E19957-01/806-3568/ncg_goldberg.html}
				{@link https://stackoverflow.com/questions/1458633/how-to-deal-with-floating-point-number-precision-in-javascript}
				(a * cf) * (a * cf) / (cf * cf)
			 */

			var cf = 10, // Correction Factor
				currency;
			a = a * cf;
			b = b * cf;

			if (["-", "+"].indexOf(operator) !== -1) {
				a = a * cf;
				b = b * cf;
			}

			switch (operator) {
			case "*":
				currency = a * b;
				break;
			case "/":
				currency = a / b;
				break;
			case "-":
				currency = a - b;
				break;
			case "+":
				currency = a + b;
				break;
			}
			currency = currency / (cf * cf);
			return currency.toFixed(2);
		},

		/**
		 * @typedef operator
		 * @enum
		 * @value {YouTubeType}
		 * @value {VimeoType}
		 */

		/**
		 * Compare currency
		 * @param {number} 		a			- First floating number
		 * @param {string} 		operator	- Comparisation Operator: "<", ">", "<=", ">=", "=", "==" or "==="
		 * @param {number} 		b			- Second floating number
		 * @returns {boolean}
		 */
		_compareCurrency: function (a, operator, b) {
			if (["<", ">", "<=", ">=", "=", "==", "==="].indexOf(operator) !== -1) {
				a = a * 100;
				b = b * 100;
				var bool = false;
				switch (operator) {
				case ">":
					bool = a > b;
					break;
				case "<":
					bool = a < b;
					break;
				case "<=":
					bool = a <= b;
					break;
				case ">=":
					bool = a >= b;
					break;
				case "=":
				case "==":
				case "===":
					bool = a === b;
					break;
				}
				return bool;
			}
		}
	});
	return oBaseController;
});