/**
 * Custom BCD Icons
 * you can use them this way:
 * sap-icon://bcd/airplane
 */
sap.ui.define([
	"sap/ui/core/IconPool"	
], function(IconPool) {
	"use strict";
	
	var mIcons = {
		airplane   :  "\e900",
		persons    : "\e901",
		tickets    : "\e902",
		conference : "\e903",
		creditcard : "\e904",
		hotel      : "\e905",
		map        : "\e906",
		message    : "\e907",
		trip       : "\e908",
		previous   : "\e909",
		price      : "\e90a",
		rail       : "\e90b",
		car        : "\e90c",
		settings   : "\e90d",
		support    : "\e90e",
		check      : "\e90f",
		search     : "\e910"
	};
	
	var csspath = jQuery.sap.getModulePath("com/bcdtravel/pnr/","/iconfont/style.css");
	jQuery.sap.includeStyleSheet(csspath);

	return {
	
		registerIcons: function() {
			for (var sIcon in mIcons) {
				IconPool.addIcon(sIcon, "bcd", "icomoon", mIcons[sIcon]);
			}
		}

	};
});