sap.ui.define([
	"sap/ui/core/util/MockServer"
], function(MockServer) {
	"use strict";
	return {
		/**
		 * Initializes the mock server.
		 * You can configure the delay with the URL parameter "serverDelay".
		 * The local mock data in this folder is returned instead of the real data for testing.
		 * @public
		 */
		init: function() {
			// create
			var oMockServer = new MockServer({
				rootUri: "/sap/opu/odata/sap/ZLSZ_SRV/"
			});
			
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: 1000 // 1 sec
			});
			
			// simulate against the metadata and mock data
			oMockServer.simulate("../localService/metadata.xml", {
				sMockdataBaseUrl: "../localService/mockdata",
				bGenerateMissingMockData: true
			});
			
			var aMyRequests = [
				{
                    method: "PUT",
                    path: new RegExp("(.*)"), 
                    response: function(oXhr, sUrlParams) {
                    	console.log("Incoming request PUT");
                        oXhr.respondJSON(200, {}, JSON.stringify({
                            d : { success: true }
                        }));
                    }
                },
                {
                    method: "MERGE", // batch?
                    path: new RegExp("(.*)"), 
                    response: function(oXhr, sUrlParams) {
                        console.log("Incoming request for MERGE");
                        console.log(oXhr);
                    	oXhr.respondJSON(
                    		204, 
                    		{
		                      "Content-Type": "application/json;charset=utf-8",
		                      "DataServiceVersion": "1.0"
	                		}, 
	                		JSON.stringify({
                            	d : {}
                        	})
                        );
                    }
                },
                {
                    method: "POST",
                    path: new RegExp("(.*)"), 
                    response: function(oXhr, sUrlParams) {
                        console.log("Incoming request for POSt");
                        console.log(oXhr);
                        oXhr.respondJSON(200, {}, JSON.stringify({
                             d : { success: true }
                        }));
                    }
                },
                {
                    method: "GET",
                    path: new RegExp("showCC?(.*)"), 
                    response: function(oXhr, sUrlParams) {
                        console.log("Incoming request for ShowCC");
                        oXhr.respondJSON(200, {}, JSON.stringify({
                            d: {
                                CCardstring: "Test123"
                            }
                        }));
                    }
                },
                {
                    method: "GET",
                    path: new RegExp("createCIT?(.*)"), 
                    response: function(oXhr, sUrlParams) {
                        console.log("Incoming request for createCIT");
                        oXhr.respondJSON(200, {}, JSON.stringify({
                            d: {
                                CCardstring: "Test123"
                            }
                        }));
                    }
                }
                
			];
			
			 oMockServer.setRequests(oMockServer.getRequests().concat(aMyRequests));
			
			// oMockServer.attachAfter("GET", function() {
			// 	console.log(arguments); 
			// });
			
			// start
			oMockServer.start();
			jQuery.sap.log.info("Running the app with mock data");
		}
	};
});