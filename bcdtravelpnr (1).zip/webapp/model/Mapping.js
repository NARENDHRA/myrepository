/* global _ */
sap.ui.define([ 
	"com/bcdtravel/pnr/model/BCDGateway",
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/I18n"
], function(BCDGateway, JSONModel, I18n) {
	"use strict";
	
	var _private = {
		/**
		 * Helper method to make sure the mandatory mParams for every deffered methods are present
		 * always will be added to the success and error callbacks so we dont need to apply it manually
		 * @param {object} [mParameters]							- Parameters
		 * @param {fnSuccessErrorCallback} [mParameters.success]	- success callback
		 * @param {fnSuccessErrorCallback} [mParameters.error]		- error callback
		 * @param {fnSuccessErrorCallback} [mParameters.always]		- always callback
		 * @returns {object} - parsed mParameters
		 */
		parseParams: function(mParameters) {
			var mParams 	= (typeof mParameters === "object") ? mParameters : {},
				fnSuccess	= ("success" in mParams && typeof mParams.success === "function") ? mParams.success : function() {},
				fnError		= ("error" in mParams && typeof mParams.error === "function") ? mParams.error : function() {},
				fnAlways	= ("always" in mParams && typeof mParams.always === "function") ? mParams.always : function(){};
			mParams.success = function() {
				fnSuccess.apply(this, arguments);
				fnAlways.apply(this, arguments);
			};
			mParams.error = function() {
				fnError.apply(this, arguments);
				fnAlways.apply(this, arguments);
			};
			return mParams;
		}
	};
	
	
	return JSONModel.extend("com.bcdtravel.pnr.model.Mapping", {
		/**
		 * application id  (mandatory)
		 * used to create the read filter
		 */
		 _ApplicationsId : "",  
		 /**
		  * Article Category (not mandatory)
		  * used to create the read filter
		  * 
		  */
		  _ArticleCategory : "",
		/**
		 * Construct the Mapping model
		 * @param {string} sApplicationId		- The ApplicationsId is used to create the read filter (mandatory)
		 * @param {string} sArticleCategory 	- The ArticleCategory is used to create the read filter, if not applied, the ArticleCategory will not be filtered in the read
		 */
		constructor: function(sApplicationId, sArticleCategory) {
			// set application id
			this._ApplicationsId	= sApplicationId;
			// (on 30-10-17: ) It is unsure if the sArticleCategory grabbed from the ArticleSet 
			// has the same case-settings as the one needed in the mapSet,
			// therefore compare the sArticleCategory against the aCategories
			// and correct the articleCategory to the correct case-setting (ucFirst)
			var aCategories 			= ["Air", "Rail", "Hotel", "Car", "Misc"], // in the mapset categories are all UcFirst
				sCorrectArticleCategory	= sArticleCategory;
			if (sArticleCategory) {
				for (var iC in aCategories) {
					if (aCategories[iC].toLowerCase() === sArticleCategory.toLowerCase()) {
						sCorrectArticleCategory = aCategories[iC]; 
						break;
					}
				}
			}
			// set the article category
			// 
			this._ArticleCategory	= sCorrectArticleCategory;
			// call parent && do not pass any argument
			JSONModel.apply(this); // do not pass arguments
		},
		
		/**
		 * Translate the supplement label 
		 * @param {string} sType - Untranslated SupplementType
		 * @returns {string} - Translated Type
		 */
		getSupplementLabelByType: function(sType) {
			var a		= this.getFieldNameBsArray("supplement", "TAXSUPPLEMENTTYPES");
			if (a.length) {
				for (var i in a) {
					if ("ValueBs" in a[i] && a[i].ValueBs === sType) {
						return a[i].ValueBcd || sType;
					}
				}
			}
			return sType;
		},
		
		/**
		 * Get booking store array
		 * @param {string} sEntity			- Entity name
		 * @param {string} sFieldNameBsI 	- BookingStore column name	
		 * @returns {object} -
		 */
		getFieldNameBsArray: function(sEntity, sFieldNameBsI) {
			var sFieldNameBs = sFieldNameBsI.toUpperCase();
			var aReturn = [],
				mData	= this.getProperty("/");
			if (sEntity in mData && sFieldNameBs in mData[sEntity] && mData[sEntity][sFieldNameBs].length > 0) {
				aReturn = mData[sEntity][sFieldNameBs];
			}
			return aReturn;
		},
		
		/*
			{
				"entityName" : {
					"FIELDNAMEBS" : [ // IN UPPERCASE!
						0: { ValueBs: "", ValueBcd: "" },
						...
					]
				},
				..
			}
		*/
		/**
		 * @param {string}	sFor										- Entityname
		 * @param {object}	[mParameters]								- parameters
		 * @param {fnSuccessErrorCallback}	[mParameters.success]		- success callback
		 * @param {fnSuccessErrorCallback}	[mParameters.error]			- error callback
		 * @param {fnSuccessErrorCallback}	[mParameters.always]		- always callback
		 * @param {object}					[mParameters.entityData]	- object with entitydata for filtering purposes
		 * @param {map}						[mParameters.filters]		- array of AND filters that need to be added... NOTE ApplicationsId, ArticleCategory, TabnameBs allready filtered
		 */
		loadMappingForEntity : function (sFor, mParameters) {
			var mParams = _private.parseParams(mParameters),
				mTables = {
					supplement: {
						Tabname					: "ZHY_TAX_SUPPL",
						FieldnameBsIdentifier	: "Taxsupplementtypes" // identifier wich key of the mParams.entityData[0] holds the FieldnameBs
					},
					articles: {
						Tabname : "ZHY_ARTICLES"
					},
					segment: {
						Tabname : "ZHY_SEGMENTS"
					}
				},
				that	= this;
			if (! (sFor in mTables)) { 
				mParams.error();
				return;
			}
			//FieldnameBs
			var aFiltersAnd = [ 
					new sap.ui.model.Filter("ApplicationsId", sap.ui.model.FilterOperator.EQ, this._ApplicationsId),
					new sap.ui.model.Filter("TabnameBs", sap.ui.model.FilterOperator.EQ, mTables[sFor].Tabname)
				],
				aFiltersOr	= [], // Filter on FieldnameBs 
				aFilter		= [];
			if (this._ArticleCategory) { // only add article category if set in constructor (to determine the fiori create article we need to leave this out)
				aFiltersAnd.push(new sap.ui.model.Filter("ArticleCategory", sap.ui.model.FilterOperator.EQ, this._ArticleCategory));
			}
			// add account no so we extend the bcd mapping with gcn mapping
			if ("account" in mParams) {
				aFiltersAnd.push(new sap.ui.model.Filter("ValueBs", sap.ui.model.FilterOperator.EQ, mParams.account));
			}
			// add if any filter is applied to mparams
			if ("filters" in mParams) {
				for (var iF in mParams.filters) {
					if (mParams.filters.hasOwnProperty(iF)) {
						aFiltersAnd.push(mParams.filters[iF]);
					}
				}
			}
			// create Or filter
			if ("entityData" in mParams && _.size(mParams.entityData)) {
				for (var i in mParams.entityData) {
					if (mParams.entityData.hasOwnProperty(i) === false) { continue; }
					var sFieldnameBsIdentifier = mTables[sFor].FieldnameBsIdentifier;
					if (! (sFieldnameBsIdentifier in mParams.entityData[i])) { continue; }
					aFiltersOr.push(
						new sap.ui.model.Filter("FieldnameBs", sap.ui.model.FilterOperator.EQ, mParams.entityData[i][sFieldnameBsIdentifier])
					);
				}
			}
			// create final filter
			if (aFiltersOr.length) {
				aFilter = [
					new sap.ui.model.Filter(aFiltersAnd),
					new sap.ui.model.Filter(aFiltersOr, false)
				];
			} else {
				aFilter = aFiltersAnd;
			}
			//	aFilter = aFiltersAnd;
			//console.log("TODO : CHECK BETER FILTER");
		//	BCDGateway.setSizeLimit(999999);
			BCDGateway.read(
				"/mapSet",
				{
					filters: aFilter,
					success	: function(mData) {
						// mData has multiple results 
						if ("results" in mData) { mData = mData.results; }
						var mCurrentData = that.getProperty("/");
						if (! (sFor in mCurrentData)) {
							mCurrentData[sFor] = {};
						}
						for (var iM in mData) {
							if (mData.hasOwnProperty(iM) === false) { continue; }
							// Currently (oktober 2017) the The FieldnameBS comming from the service is in UPPERCASE
							// But we cannot rely on it that that always be the case
							var sFieldNameUPPERCASE = mData[iM].FieldnameBs.toUpperCase(),
								sValueBS			= mData[iM].ValueBs,
								sValueBCD			= mData[iM].ValueBcd;
							// filter out table entry error values
							if (sValueBS === "" && sValueBCD === "") {
								continue;
							}
							// create array if not existing
							if (! (sFieldNameUPPERCASE in mCurrentData[sFor])) {
								mCurrentData[sFor][sFieldNameUPPERCASE] = [];
							}
							// add values
							var oNewEntry = {
								ValueBs			: sValueBS,
								ValueBcd		: sValueBCD,
								ArticleCategory	: mData[iM].ArticleCategory // needed if no ArticleCategory is passed in the constructor
							};
							// Only add value if its not already present
							if (! _.findWhere(mCurrentData[sFor][sFieldNameUPPERCASE], oNewEntry)) {
								mCurrentData[sFor][sFieldNameUPPERCASE].push(oNewEntry);
							}
						}
						that.setProperty("/", mCurrentData);
						// refresh the model binding
						that.refresh(true);
						mParams.success(mData);
					},
					error	: function() {
						jQuery.sap.log.debug("error", arguments);
						mParams.error.apply(this, arguments);
					}
				}
			);
		}
	});
});
/* JSDOC Type Definitions */

/**
 * A callback function which is called when the data has been retrieved.
 * @callBack fnSuccessErrorCallback
 * @param {object} The data of the retrieved data
 * @param {object} Further information about the response of the request.
 */