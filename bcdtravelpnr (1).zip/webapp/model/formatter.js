sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */

		NoteTimestamp: function (date, time, Reqid) {
			var oArticel = "";
			if (Reqid) {
				oArticel = "Article " + Reqid.split("_")[1];
			}
			var times = new Date(time.ms);
			var C = times.getUTCHours() + ":" + String(times.getUTCMinutes()).padStart(2, "0");
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				style: "medium",
				UTC: true
			});
			var dateStr = dateFormat.format(date).split(",")[0];
			var fine = dateStr + " " + C + " " + "CET" + " " + oArticel;
			return fine;
		}

	};

});