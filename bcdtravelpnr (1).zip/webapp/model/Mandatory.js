/* global _ */
sap.ui.define([ 
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/DisplaySettings",
	"sap/ui/model/json/JSONModel"
], function(BCDGateway, DisplaySettings, JSONModel) {
	"use strict";
	
	return JSONModel.extend("com.bcdtravel.pnr.model.Mandatory", {
		/**
		 * @param {string} sEntity		- Entity name
		 * @param {string} sArticleType	- The Article Type
		 */
		constructor: function(sEntity, sArticleType) {
			// call parent && do not pass any argument
			JSONModel.apply(this); // do not pass arguments
			
			// set the sizelimit to a higher value else some ui5 elements wont show all items (f.e. the valuehelp country combobox)
			this.setSizeLimit("9999999");
			
			if (! sArticleType || ["articles", "segment"].indexOf(sEntity) === -1) { return; }
			var oEntities	= {
					articles: "ZHY_ARTICLES",
					segment: "ZHY_SEGMENTS"
				},
				that		= this;
			BCDGateway.read(
				"/mandSet",
				{
					filters: [
						new sap.ui.model.Filter("ArticleType", "EQ", sArticleType),
						new sap.ui.model.Filter("Tabname", "EQ", oEntities[sEntity])
					],
					success: function(m) {
						var mMandatory			= {}, 
							mEntityProperties	= BCDGateway.getMetaDataEntityProperties(sEntity);
						// Create model based on the entity properties (pre-set them to false)
						if (_.size(mEntityProperties)) {
							for (var sField in mEntityProperties) {
								if (mEntityProperties.hasOwnProperty(sField)) {
									mMandatory[sField] = false;
								}
							}
						}
						// only set the mandatory fields to TRUE
						// if the field is also available in the view.xml
						// We use the DisplaySettings to check if the field is in the xml view
						var aDisplaySettings = [];
						if (["articles", "segment"].indexOf(sEntity) !== -1) {
							var sDisplaytype = (sEntity === "articles") ? "ArticleData" : "SegmentData";
							aDisplaySettings =	DisplaySettings.getFieldsArrayFor(sDisplaytype);
						}
						// Set all mandatory fields to true
						if (typeof m === "object" && "results" in m && _.size(m.results) > 0) { 
							for (var i in m.results) {
								if (m.results.hasOwnProperty(i) === false) { continue; }
								var sFieldname = BCDGateway.translateFieldSapToOdata(sEntity, m.results[i].Fieldname);
								if (aDisplaySettings.indexOf(sFieldname) !== -1) {
									mMandatory[sFieldname] = true;
								}
							}
						}
						if (sEntity === "articles") {
							/**
							 *  NOTE : 
							 *  a article created by FIORI should always be ticketed!!
							 *  so to make sure this is happening make the Ticketreference mandatory
							 **/
							mMandatory.Ticketreference = true;
						}
						// set the model
						that.setProperty("/", mMandatory);
					}
				}
			);
		},
		
		/**
		 * Check the fields of an entity object
		 * @param {object}	m										- entity object with fields which need to be checked
		 * @param {object} [mParameters]							- Parameters
		 * @param {fnSuccessErrorCallback} [mParameters.success]	- success callback is executed if all fields are OK
		 * @param {fnSuccessErrorCallback} [mParameters.error]		- error callback is executed if there is are ore more mandatory fields left out
		 * @returns {boolean} - false if there are no missing mandatory fields
		 */
		checkObjectFields: function(m, mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.success = ("success" in mParams && typeof mParams.success === "function" ) ? mParams.success : function() {};
			mParams.error = ("error" in mParams && typeof mParams.error === "function" ) ? mParams.error : function() {};
			// no fields set
			if (typeof m !== "object" || _.size(m) === 0) {
				mParams.error(_.keys(this.getProperty("/")));
				return false;
			}
			// get only mandatory fields TRUE
			var mMandatory 		=  this.getProperty("/"),
				aErrors			= [];
			for (var sField in mMandatory) {
				// only true value
				if (mMandatory[sField]) { 
					// field not present in model or not filled
					if (! (sField in m) || m[sField] === "") {
						aErrors.push(sField);
					}
				}
			}
			if (aErrors.length) {
				mParams.error(aErrors);
				return false;
			} else {
				mParams.success();
				return true;
			}
		}
	});
});
/* JSDOC Type Definitions */

/**
 * A callback function which is called when the data has been retrieved.
 * @callBack fnSuccessErrorCallback
 * @param {object} The data of the retrieved data
 * @param {object} Further information about the response of the request.
 */