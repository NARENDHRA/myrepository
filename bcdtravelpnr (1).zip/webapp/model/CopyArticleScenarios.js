/* global _ */
sap.ui.define([
	"com/bcdtravel/pnr/model/BCDGateway",
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/I18n"
], function (BCDGateway, JSONModel, I18n) {
	"use strict";

	var _private = {
		aScenarioCache: [],
		/**
		 * reads the scsenario from cache
		 * or reloads data
		 */
		getScenarios: function (mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.success = ("success" in mParameters && typeof mParameters.success === "function") ? mParameters.success : function () {};
			mParams.error = ("error" in mParameters && typeof mParameters.error === "function") ? mParameters.error : function () {};
			if (_private.aScenarioCache.length === 0) {
				BCDGateway.read("/CopyArticleScenarios", {
					filters: [ // filter by BookingsId and Articles Id
						new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, mParams.article.BookingsId),
						new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, mParams.article.ArticlesId)
					],
					success: function (m) {
						if (!("results" in m) || m.results.length === 0) {
							mParams.error(I18n.getText("Article.copy.selectScenario.NoScenariosFoundInService"));
							return;
						}
						_private.aScenarioCache = m.results;
						mParams.success(_private.aScenarioCache);
					}
				});
			} else {
				mParams.success(_private.aScenarioCache);
			}
		}
	};

	return {
		/**
		 * Returns the list of scenarios for the dialog select box
		 * note: only scenarios which action start with an O are retured
		 */
		getScenariosToSelect: function (mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};

			mParams.success = ("success" in mParameters && typeof mParameters.success === "function") ? mParameters.success : function () {};
			mParams.error = ("error" in mParameters && typeof mParameters.error === "function") ? mParameters.error : function () {};
			// this method will be triggerd if the scenarios are loaded (from cache of new)
			var fnProcess = function () {
				var mNew = {},
					aAllowedScenarios = []; // holds the scenario ids which are allowed for this article
				for (var i in _private.aScenarioCache) {
					var mCurr = _private.aScenarioCache[i];
					// remap
					mNew[mCurr.scenario] = {
						scenario: mCurr.scenario,
						description: mCurr.description
					};
					// // only scenarios which action starts with an O should be added to the list
					// // if an article is passed in the parameters, check if the scenario is allowed for this article
					// if (
					// 	"article" in mParams && mCurr.action.indexOf("O") === 0 && mParams.article.Transactiontype === mCurr.transactiontype
					// ) {
					// 	// if the fieldname_bs is filled in the scenario: only add the 
					// 	// the scenario if the artile field has the same value
					// 	if (
					// 		(mCurr.tabname_bs === "" || mCurr.fieldname_bs === "") // not set in scenario: always allowed
					// 		|| ( // check the scenario fieldname value against the article
					// 			mCurr.tabname_bs === "ZHY_ARTICLES" && mCurr.field_value === mParams.article[BCDGateway.translateFieldSapToOdata("articles",
					// 				mCurr.fieldname_bs)]
					// 		)
					// 	) {
					aAllowedScenarios.push(mCurr.scenario);
					// 	}
					// }
				}
				mNew = _.filter(mNew, function (m) {
					return aAllowedScenarios.indexOf(m.scenario) !== -1;
				});
				mParams.success(mNew);
			};
			// CHECK cache
			// if (_private.aScenarioCache.length) {
			// 	fnProcess();
			// } else { // reload the scenarios and add the mto the cache
			BCDGateway.read("/CopyArticleScenarios", {
				filters: [ // filter by BookingsId and Articles Id
					new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, mParams.article.BookingsId),
					new sap.ui.model.Filter("ArticlesId", sap.ui.model.FilterOperator.EQ, mParams.article.ArticlesId)
				],
				success: function (m) {
					if (!("results" in m) || m.results.length === 0) {
						mParams.error(I18n.getText("Article.copy.selectScenario.NoScenariosFoundInService"));
						return;
					}
					_private.aScenarioCache = m.results;
					fnProcess();
				}
			});
			//			}
		},

		/** 
		 * return all scenarios lines with @param sScenarioId
		 */
		getScenario: function (sScenarioId, mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.success = ("success" in mParameters && typeof mParameters.success === "function") ? mParameters.success : function () {};
			mParams.error = ("error" in mParameters && typeof mParameters.error === "function") ? mParameters.error : function () {};
			_private.getScenarios({
				success: function (m) {
					var mNew = _.filter(m, function (mCurr) {
						return mCurr.scenario === sScenarioId;
					});
					mParams.success(mNew);
				},
				error: mParams.error
			});
		}
	};

});