/* global _ */
// register the resource of nl/barrydam in here
// tried first to put it in the manifest sap.ui5.resourceRoots but those resources get registered after the Component.js is loaded (and that is where I need it)
jQuery.sap.registerModulePath("nl/barrydam", jQuery.sap.getModulePath("com.bcdtravel.pnr") + "/lib/bd/");
sap.ui.define([
	"nl/barrydam/model/ODataV2Model",
	"sap/ui/model/json/JSONModel"
], function (bdODataV2Model, JSONModel) {
	"use strict";
	/**
	 * OData service model settings
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.model.BCDGateway
	 * @extends 	nl.barrydam.model.ODataV2Model
	 * 
	 * @constructor
	 * @public
	 */
	var oModel = new bdODataV2Model(
		"/sap/opu/odata/sap/ZLSZ_SRV/", {
			json: true,
			defaultBindingWay: "TwoWay",
			useBatch: false
		}
	);
	// set the sizelimit to a higher value else some ui5 elements wont show all items (f.e. the valuehelp country combobox)
	oModel.setSizeLimit("9999999");
	// needed for 
	var _translationFields = {
		articles: {
			"BookingsId": "BOOKINGS_ID",
			"ArticlesId": "ARTICLES_ID",
			"ArticleType": "ARTICLE_TYPE",
			"Twofopindicator": "TWOFOPINDICATOR",
			"Account": "ACCOUNT",
			"ArticleCategory": "ARTICLE_CATEGORY",
			"Agencylicencenumber": "AGENCYLICENCENUMBER",
			"Airlinepnrlocator": "AIRLINEPNRLOCATOR",
			"Baseamount": "BASEAMOUNT",
			"Baseamountlocal": "BASEAMOUNTLOCAL",
			"Billbackindicator": "BILLBACKINDICATOR",
			"BillbackNotReleased": "BILLBACK_NOT_RELEASED",
			"Bookingagentcode": "BOOKINGAGENTCODE",
			"Bookingcode": "BOOKINGCODE",
			"Bookingmethods": "BOOKINGMETHODS",
			"Bookingsourcecreation": "BOOKINGSOURCECREATION",
			"Bookingsourcecreationtime": "BOOKINGSOURCECREATIONTIME",
			"Carhotelroomtype": "CARHOTELROOMTYPE",
			"Commissionpercentage": "COMMISSIONPERCENTAGE",
			"Conjunction": "CONJUNCTION",
			"Creditcardamount": "CREDITCARDAMOUNT",
			"Creditcardauthorisation": "CREDITCARDAUTHORISATION",
			"Creditcardexpiry": "CREDITCARDEXPIRY",
			"Creditcardnumber": "CREDITCARDNUMBER",
			"Creditcardtype": "CREDITCARDTYPE",
			"IssueDate": "ISSUEDATE",
			"Commissionamount": "COMMISSIONAMOUNT",
			"Creditcardauthorisationmerchan": "CREDITCARDAUTHORISATIONMERCHAN",
			"Creditcardexpirymerchant": "CREDITCARDEXPIRYMERCHANT",
			"Creditcardnumbermerchant": "CREDITCARDNUMBERMERCHANT",
			"Creditcardtypemerchant": "CREDITCARDTYPEMERCHANT",
			"Currency": "CURRENCY",
			"Domintindicator": "DOMINTINDICATOR",
			"Einvoiceemailaddress": "EINVOICEEMAILADDRESS",
			"Emdtypeindicator": "EMDTYPEINDICATOR",
			"Exchangeamount": "EXCHANGEAMOUNT",
			"Exchangeindicator": "EXCHANGEINDICATOR",
			"Exchangeticketedairline": "EXCHANGETICKETEDAIRLINE",
			"Exchangeticketreference": "EXCHANGETICKETREFERENCE",
			"Fareconstruction": "FARECONSTRUCTION",
			"Farepaidamount": "FAREPAIDAMOUNT",
			"Foreigntariffindicator": "FOREIGNTARIFFINDICATOR",
			"Formofpayment": "FORMOFPAYMENT",
			"Gdsbooking": "GDSBOOKING",
			"Hotelchaincode": "HOTELCHAINCODE",
			"Hotelname": "HOTELNAME",
			"Hotelpropertycode": "HOTELPROPERTYCODE",
			"Ifaremarkup": "IFAREMARKUP",
			"Ifarepcc": "IFAREPCC",
			"Ifarerechargeaccount": "IFARERECHARGEACCOUNT",
			"Itnumber": "ITNUMBER",
			"Totallocalamount": "TOTALLOCALAMOUNT",
			"Lowestofferedfare": "LOWESTOFFEREDFARE",
			"Mainarrival": "MAINARRIVAL",
			"Mainbookingclass": "MAINBOOKINGCLASS",
			"Maindeparture": "MAINDEPARTURE",
			"Numberofpeople": "NUMBEROFPEOPLE",
			"Obfeeindicator": "OBFEEINDICATOR",
			"Orderedby": "ORDEREDBY",
			"Passengername": "PASSENGERNAME",
			"Passengertype": "PASSENGERTYPE",
			"Productid": "PRODUCTID",
			"Productremarks": "PRODUCTREMARKS",
			"Quantityofproduct": "QUANTITYOFPRODUCT",
			"Ratetypes": "RATETYPES",
			"Reasoncodes": "REASONCODES",
			"Reasonforissuancecodes": "REASONFORISSUANCECODES",
			"Refundauthorization": "REFUNDAUTHORIZATION",
			"Salespriceamount": "SALESPRICEAMOUNT",
			"Standardfare": "STANDARDFARE",
			"Supplier": "SUPPLIER",
			"Supplierfaxnumber": "SUPPLIERFAXNUMBER",
			"Supplierphonenumber": "SUPPLIERPHONENUMBER",
			"Ticketedairline": "TICKETAIRLINE",
			"Ticketingagentcode": "TICKETINGAGENTCODE",
			"Ticketingcode": "TICKETINGCODE",
			"Ticketreference": "TICKETREFERENCE",
			"Tickettypes": "TICKETTYPES",
			"Totalamount": "TOTALAMOUNT",
			"Transactioncontrolnumber": "TRANSACTIONCONTROLNUMBER",
			"Transactiontype": "TRANSACTIONTYPE",
			"Vouchernumber": "VOUCHERNUMBER",
			"CrName": "CR_NAME",
			"CrTime": "CR_TIME",
			"ChName": "CH_NAME",
			"ChTime": "CH_TIME",
			"Reversed": "REVERSED",
			"CitTriggered": "CIT_TRIGGERED",
			"Citid": "CITID",
			"DrivingRecord": "DRIVING_RECORD",
			"ErrorCode": "ERROR_CODE",
			"DtelGefInvnr": "DTELGEFINVNR",
			"DpDocid": "DPDOCID",
			"Note": "NOTE"
		},
		segment: {
			"BookingsId": "BOOKINGSID",
			"ArticlesId": "ARTICLES_ID",
			"ArticleType": "ARTICLE_TYPE",
			"SegmentId": "SEGMENT_ID",
			"Arrivalterminal": "ARRIVALTERMINAL",
			"Codeshareoperator": "CODESHAREOPERATOR",
			"Departureterminal": "DEPARTURETERMINAL",
			"Electronicticketindicator": "ELECTRONICTICKETINDICATOR",
			"Segmentaircrafttypes": "SEGMENTAIRCRAFTTYPES",
			"Segmentarrivaldate": "SEGMENTARRIVALDATE",
			"Segmentarrivaltime": "SEGMENTARRIVALTIME",
			"Segmentarrival": "SEGMENTARRIVAL",
			"Segmentbaggageallowance": "SEGMENTBAGGAGEALLOWANCE",
			"Segmentclass": "SEGMENTCLASS",
			"Segmentcoach": "SEGMENTCOACH",
			"Segmentdeparturedate": "SEGMENTDEPARTUREDATE",
			"Segmentdeparturetime": "SEGMENTDEPARTURETIME",
			"Segmentdeparture": "SEGMENTDEPARTURE",
			"Segmentdurationtime": "SEGMENTDURATIONTIME",
			"Segmentfarebasis": "SEGMENTFAREBASIS",
			"Segmentfarebasisendorsement": "SEGMENTFAREBASISENDORSEMENT",
			"Segmentfarebasisvalidfrom": "SEGMENTFAREBASISVALIDFROM",
			"Segmentfarebasisvalidfromtime": "SEGMENTFAREBASISVALIDFROMTIME",
			"Segmentfarebasisvalidto": "SEGMENTFAREBASISVALIDTO",
			"Segmentfarebasisvalidtotime": "SEGMENTFAREBASISVALIDTOTIME",
			"Segmentflight": "SEGMENTFLIGHT",
			"Segmentflightcouponindicator": "SEGMENTFLIGHTCOUPONINDICATOR",
			"Segmentfrequentflyermiles": "SEGMENTFREQUENTFLYERMILES",
			"Segmentidentifier": "SEGMENTIDENTIFIER",
			"Segmentintdeparturetime": "SEGMENTINTDEPARTURETIME",
			"Segmentintnextdayarrivalind": "SEGMENTINTNEXTDAYARRIVALIND",
			"Segmentmealcode": "SEGMENTMEALCODE",
			"Segmentnauticalmiles": "SEGMENTNAUTICALMILES",
			"Segmentnumberofdays": "SEGMENTNUMBEROFDAYS",
			"Segmentprovider": "SEGMENTPROVIDER",
			"Segmentseatindicator": "SEGMENTSEATINDICATOR",
			"Segmentseatnumber": "SEGMENTSEATNUMBER",
			"Segmentstatuscodes": "SEGMENTSTATUSCODES",
			"Segmentstopcount": "SEGMENTSTOPCOUNT",
			"Segmentstopover": "SEGMENTSTOPOVER",
			"Segmentticketcouponidentifier": "SEGMENTTICKETCOUPONIDENTIFIER",
			"Segmentticketedindicator": "SEGMENTTICKETEDINDICATOR",
			"CrName": "CR_NAME",
			"CrDate": "CR_DATE",
			"CrTime": "CR_TIME",
			"ChName": "CH_NAME",
			"ChDate": "CH_DATE",
			"ChTime": "CH_TIME",
			"Reversed": "REVERSED",
			"CitTriggered": "CIT_TRIGGERED"
		}
	};

	/**
	 *  Create a new entity data method overwrite for ODataV2Model.js
	 *  it adds the ApplicationsId Fiori in case we creata a new booking
	 * @param {string} sEntityName - The Entityname which you want the fields for
	 * @returns {object} -
	 * @instance
	 */
	oModel.getNewEntityData = function (sEntityName) {
		var mNewEntityData = bdODataV2Model.prototype.getNewEntityData.call(this, sEntityName);
		// new booking created from this app have ApplicationsId FIORI
		if (sEntityName === "booking") {
			mNewEntityData.ApplicationsId = "FIORI";
		}
		return mNewEntityData;
	};

	/**
	 * Translates a SAP Techical Field name to the oData set field name 
	 * @param {sEntity} 	sEntity - The Entityname
	 * @param {sField} 		sField	- Field / Column SAP Technical name
	 * @returns {string} -
	 * @instance
	 */
	oModel.translateFieldSapToOdata = function (sEntity, sField) {
		if (sEntity in _translationFields) {
			for (var sOdataField in _translationFields[sEntity]) {
				if (_translationFields[sEntity][sOdataField] === sField) {
					return sOdataField;
				}
			}
		}
		return sField;
	};

	/**
	 * Translates a oData set field name to the SAP Techical Field name 
	 * @param {sEntity} 	sEntity - The Entityname
	 * @param {sField} 		sField	- Field / Column oData name
	 * @returns {string} -
	 */
	oModel.translateFieldOdataToSap = function (sEntity, sField) {
		return (sEntity in _translationFields) ? _translationFields[sEntity] : sField;
	};

	/**
	 * Error types
	 * 01 Mandatory field missing
	 * 02 Billback - Document references missing
	 * 03 Missing master data / mapping data
	 * 04 Booking without article data
	 * 05 No segment data but necessary
	 * 06 Missing reference data
	 * 07 Wrong reference data
	 * 08 Currency cannot be derived form article
	 * 09 Missing Bundle Product Reference data
	 * 10 Amount has wrong number of decimals
	 * 11 Article Type is empty (article is not allowed to change. should be deleted)
	 * 12 Invalid credit card number
	 * 
	 * Fetch all field errors from errorSet with ErrorCode 01 (mandatory field missing)
	 * 
	 * @param {object}					[mParams]			- Parameters
	 * @param {fnSuccessErrorCallback}	[mParams.success]		- success callback
	 * @param {fnSuccessErrorCallback}	[mParams.error]			- error callback
	 * @param {string}					[mParams.bookingId]		- If set, the errors will be filtered on BookingsId
	 * @param {string}					[mParams.articleId]		- If set, the errors will be filtered on ArticleId
	 * @param {string}					[mParams.segmentId]		- If set, the errors will be filtered on SegmentId
	 * @param {string}					[mParams.referenceId]	- If set, the errors will be filtered on ReferenceId
	 * @param {string}					[mParams.entity=bookings|segment|articles|supplements|references] - filter data on entityname
	 * @returns {map} -
	 */
	oModel.readFieldErrors = function (mParams) {
		mParams = (typeof mParams !== "object") ? {} : mParams;
		mParams.success = ("success" in mParams && typeof mParams.success === "function") ? mParams.success : function () {};
		mParams.error = ("error" in mParams && typeof mParams.error === "function") ? mParams.error : function () {};
		var aExcludeErrorCodes = [], //["04", "05", "09"],
			aFilters = [],
			mEntities = {
				bookings: "ZHY_BOOKINGS",
				articles: "ZHY_ARTICLES", // articles
				segment: "ZHY_SEGMENTS", // segments
				references: "ZHY_REFERENCES", // references
				supplements: "ZHY_SUPPLEMENTS" // supplements
			};
		// add booking id to filter if needed
		if ("bookingId" in mParams) {
			aFilters.push(new sap.ui.model.Filter(
				"BookingsId",
				"EQ",
				mParams.bookingId
			));
		}
		// add article id to filter if needed
		if ("articleId" in mParams) {
			aFilters.push(new sap.ui.model.Filter(
				"ArticlesId",
				"EQ",
				mParams.articleId
			));
		}
		if ("segmentId" in mParams) {
			aFilters.push(new sap.ui.model.Filter(
				"SegmentId",
				"EQ",
				mParams.segmentId
			));
		}
		// add reference filter if needed
		if ("referenceId" in mParams) {
			aFilters.push(new sap.ui.model.Filter(
				"ReferencesId",
				"EQ",
				mParams.referenceId
			));
		}
		// add supplement filter if needed
		if ("supplementId" in mParams) {
			aFilters.push(new sap.ui.model.Filter(
				"SupplementId",
				"EQ",
				mParams.supplementId
			));
		}
		// check if tableName is passed in mParams 
		// and create the TableName filter if allowed
		if ("entity" in mParams) {
			if (mParams.entity in mEntities) {
				aFilters.push(
					new sap.ui.model.Filter(
						"Tabname",
						"EQ",
						mEntities[mParams.entity]
					)
				);
				// }
				// var sTableName	= "ZHY_"+mParams.tableName.toUpperCase();
				// if(aPossibleTables.indexOf(sTableName) !== -1) { // add TableName filter
				// 	aFilters.push(
				// 		new sap.ui.model.Filter(
				// 			"Tabname",
				// 			"EQ",
				// 			sTableName
				// 		)
				// 	);
			} else { // return error
				return mParams.error();
			}
		}
		// Fetch Errors from service
		oModel.read(
			"/errorSet", {
				filters: aFilters,
				success: function (mData) {
					if ("results" in mData) {
						mData = mData.results;
					}
					var mDataOrderedOnTableName = {},
						mDataFiltered = [];
					if (typeof mData === "object" && _.size(mData)) {
						mDataOrderedOnTableName.bookings = {};
						mDataOrderedOnTableName.articles = {};
						mDataOrderedOnTableName.segments = {};
						mDataOrderedOnTableName.references = {};
						mDataOrderedOnTableName.supplements = {};
						mDataOrderedOnTableName.other = {};
						for (var i in mData) {
							// exclude
							if (aExcludeErrorCodes.indexOf(mData[i].ErrorCode) !== -1) {
								continue;
							}
							mDataFiltered.push(mData[i]);
							// sort data
							if ("Tabname" in mData[i]) {
								var s = mData[i].Tabname.toLowerCase().replace("zhy_", "");
								if (!(s in mDataOrderedOnTableName)) {
									s = "other";
								}
								mDataOrderedOnTableName[s][i] = mData[i];
								// translate 
								if (mDataOrderedOnTableName[s][i].ErrorField === "DTEL_GEF_INVNR") {
									mDataOrderedOnTableName[s][i].ErrorField = "DTELGEFINVNR";
								}
								if (mDataOrderedOnTableName[s][i].ErrorField === "DP_DOCID") {
									mDataOrderedOnTableName[s][i].ErrorField = "DPDOCID";
								}
							}
						}
					}
					mParams.success(mDataFiltered, mDataOrderedOnTableName);
				},
				error: mParams.error
			}
		);
	};

	return oModel;
});