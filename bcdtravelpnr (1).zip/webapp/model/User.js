sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/BCDGateway"
], function (JSONModel, BCDGateway) {
	"use strict";

	/*
		There are 2 type of users who are going to use this app.
		user type ERRORCORRECTION : 
			- Can only do error corrections (updates) 
			- Can create new supplements if the Article.BillbackNotReleased = "X"
		user type ADMIN : 
			- Can do all what user a can do
			- Can allways create new suplements
			- Is also allowed to create new data for all other entities
		
		So for now: in the app now we only have to check if the user is allowed to create entities since update is allowed for all atm.		
	
		also:
			the user has an property showCC.... if it is X the user is allowed to view the creditcardnumber
	
		The user model is bound to all views
		you can use it on this way
		{User>/canCreate/articles}
	*/

	var _private = { // private object for varialbes
		mPermissions: {}, // set below
		bSettingsLoaded: false, // if the user settings are loaded this will be set to true
		loadEvents: [] // holds any method set in the attachSettingsLoaded method.. and will be executed after load
	};

	/**
	 * Permissions model
	 * key = EntityType names (check odata metadata)
	 * At this moment only the entities which are needed to check inside the app are in this permission model
	 * and only creates need to be checked 
	 */
	_private.mPermissions = {
		//articlesSet
		articles: {
			create: ["ADMIN"], // user which types are allowed to create an article?
			update: "ALL"
		},
		// bookingSet
		booking: {
			create: ["ADMIN"] // user whic types are allowed to create an booking
		},
		segment: {
			create: ["ADMIN"] // user whic types are allowed to create an segment
		},
		supplement: {
			create: ["ADMIN"] // user whic types are allowed to create an supplement
		}
	};

	var User = new JSONModel({ // default settings... overwritten in odata read
		Type: "ADMIN",
		showCC: "X",
		canChangeArticleNoBilling: false, // User is allowed to change the no-billing flag
		canCopyArticle: false, // User is allowed to copy an article 
		canCreateCIT: "X", // User can trigger a CIT
		canProcessBillBack: false, // User is allowed to process the billback
		canForceEditMode: false, // User	can (force) enable article fields so that changes can be made
		canBlockBooking: "X", // User can block a Booking	
		canUnBlockBooking: "X", // User can unblock a Booking
		canSeeAppID: false
	});

	/**
	 * Method is called when the settings are loaded
	 * @param {function} fnCallback	- method which is called if the settings are loaded
	 */
	User.attachSettingsLoaded = function (fnCallback) {
		if (typeof fnCallback !== "function") {
			return;
		}
		if (_private.bSettingsLoaded) {
			fnCallback();
		} else {
			_private.loadEvents.push(fnCallback);
		}
	};
	/**
	 * Method will be fired if the settings are loaded and will execute all events that needs to be executed after the settings are loaded
	 */
	User.fireSettingsLoaded = function () {
		_private.bSettingsLoaded = true;
		if (_private.loadEvents.length) {
			for (var i in _private.loadEvents) {
				if (typeof _private.loadEvents[i] === "function") {
					_private.loadEvents[i]();
				}
			}
		}
	};

	/**
	 * Check if the user has an certain permission
	 * @param  {string}	sEntity		-  Table name
	 * @param  {string}	sCommand=create|read|update|delete - CRUD operartion type
	 * @return {boolean} -
	 */
	User._hasPermission = function (sEntity, sCommand) {
		// table not in permissions
		if (!(sEntity in _private.mPermissions)) {
			return false;
		}
		// action not in persmission table
		if (!(sCommand in _private.mPermissions[sEntity])) {
			return false;
		}
		var mixedPermission = _private.mPermissions[sEntity][sCommand];
		// no one has access
		if (mixedPermission === "NONE") {
			return false;
		}
		// everyone has access
		if (mixedPermission === "ALL") {
			return true;
		}
		// mixedPermission is array > check user types
		var aCheck = (mixedPermission instanceof Array) ? mixedPermission : [mixedPermission];
		return (aCheck.indexOf(this.getProperty("/Type")) !== -1);
	};

	/**
	 * Check if the user can create a certain entity
	 * @param {string}	sEntity - Entity type name (articles, booking, segment, supplement)
	 * @return {boolean} -
	 */
	User.canCreate = function (sEntity) {
		return this._hasPermission(sEntity, "create");
	};

	/**
	 * Check if the user can create a certain entity
	 * @param {string} sEntity - Entity type name (articles, booking, segment, supplement)
	 * @return {boolean} -
	 */
	User.canUpdate = function (sEntity) {
		return this._hasPermission(sEntity, "update");
	};

	/**
	 * Special check to determine of a user is allowed to create an supplement
	 * user type ERRORCORRECTION can only edit this if mArticle.BillbackNotReleased = "X"
	 * user type ADMIN is always allowed to edit
	 * @param {object} mArticle - Article object
	 * @returns {boolean} -
	 */
	User.canCreateSupplementOfArticle = function (mArticle) {
		var sType = this.getProperty("/Type"),
			bAllowed = false;
		switch (sType) {
		case "ADMIN":
			bAllowed = true;
			break;
		case "READONLY":
			break;
		case "ERRORCORRECTION":
			bAllowed = (typeof mArticle === "object" && "BillbackNotReleased" in mArticle && mArticle.BillbackNotReleased === "X") ? true : false;
			break;
		}
		return bAllowed;
	};

	/**
	 * Check if the users is allowed to create a CIT
	 * @returns {boolean} -
	 */
	User.canCreateCIT = function () {
		return this.getProperty("/canCreateCIT");
	};

	/**
	 * Check if the users is allowed to Block a Booking
	 * @returns {boolean} -
	 */
	User.canBlockBooking = function () {
		return this.getProperty("/canBlockBooking");
	};

	// /**
	//  * Check if the user should see Application ID
	//  * @returns {boolean} -
	//  */
	// User.showAppID = function () {
	// 	return this.getProperty("/showAppID");
	// };

	/**
	 * Check if the users is allowed to UnBlock a Booking
	 * @returns {boolean} -
	 */
	User.canUnBlockBooking = function () {
		return this.getProperty("/canUnBlockBooking");
	};

	/**
	 * Check if the user is ReadOnly
	 * * @returns {boolean} -
	 */
	User.canOnlyRead = function () {
		var sType = this.getProperty("/Type"),
			bDisplayOnly = false;
		switch (sType) {
		case "READONLY":
			bDisplayOnly = true;
		}
		return bDisplayOnly;
	};

	/**
	 * Check if the user is allowed to view the creditcard no
	 * @returns {boolean} -
	 */
	User.canSeeCreditCardnumber = function () {
		return this.getProperty("/canSeeCreditCardnumber");
	};

	/**
	 * Check if the user is allowed to change the articlesSet.NoBilling property
	 * @returns {boolean} -
	 */
	User.canChangeArticleNoBilling = function () {
		return this.getProperty("/canChangeArticleNoBilling");
	};

	/**
	 * CHeck if the user is allowed to do a billback process
	 */
	User.canProcessBillBack = function () {
		return this.getProperty("/canProcessBillBack");
	};

	/**
	 * CHeck if the user has the Application ID filter setting enabled
	 */
	User.canSeeAppID = function () {
		return this.getProperty("/canSeeAppID");
	};

	/**
	 * User can (force) enable article fields so that changes can be made
	 */
	User.canForceEditMode = function () {
		return this.getProperty("/canForceEditMode");
	};

	User.canCopyArticle = function () {
		return this.getProperty("/canCopyArticle");
	};

	/**
	 * Check if the user is a tester 
	 * Only allowed on the webide and dev and test systems
	 * @returns {boolean} - sdf
	 */
	User.isTester = function () {
		function getURLParameter(name) {
			var sName = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
			var regexS = "[\\?&]" + sName + "=([^&#]*)";
			var regex = new RegExp(regexS);
			var results = regex.exec(location.href);
			return results === null ? null : results[1];
		}
		var bReturn = false,
			sHostname = window.location.hostname;
		if (["bcddgw110.bcd.scheer", "bcdqgw110.bcd.scheer"].indexOf(sHostname) !== -1 || sHostname.indexOf("webide") === 0) {
			bReturn = (getURLParameter("testing")) ? true : false;
		}
		return bReturn;
	};

	// load user setting
	var fnAfterRead = function () {
		var mData = User.getProperty("/");
		// than add 
		mData.canCreate = {};
		for (var sEntity in _private.mPermissions) {
			if (_private.mPermissions.hasOwnProperty(sEntity)) {
				mData.canCreate[sEntity] = User._hasPermission(sEntity, "create");
			}
		}
		// Copy
		mData.canCopyArticle = ("canCopyArticle" in mData && mData.canCopyArticle === "X") ? true : false;
		// CIT
		mData.canCreateCIT = ("canCreateCIT" in mData && mData.canCreateCIT === "X") ? true : false;
		// Block Booking
		mData.canBlockBooking = ("canBlockBooking" in mData && mData.canBlockBooking === "X") ? true : false;
		// UnBlock Booking
		mData.canUnBlockBooking = ("canUnBlockBooking" in mData && mData.canUnBlockBooking === "X") ? true : false;
		// showCC
		mData.canSeeCreditCardnumber = ("showCC" in mData && mData.showCC === "X") ? true : false;
		// No Billing
		mData.canChangeArticleNoBilling = ("canChangeArticleNoBilling" in mData && mData.canChangeArticleNoBilling === "X") ? true : false;
		// Billback process
		mData.canProcessBillBack = ("canProcessBillBack" in mData && mData.canProcessBillBack === "X") ? true : false;
		// canForceEditMode // TEMP use the nobilling flag auth object 
		mData.canForceEditMode = mData.canChangeArticleNoBilling;
		// Read Only
		mData.canOnlyRead = ("canOnlyRead" in mData && mData.canOnlyRead === "X") ? true : false;
		// ShowAppID
		mData.canSeeAppID = ("canSeeAppID" in mData && mData.canSeeAppID === "X") ? "X" : false;
		// re set the data
		User.setData(mData);
	};

	// Load user settings from service
	BCDGateway.read(
		"/userSettingsSet", {
			success: function (mData) {
				// first set data
				if ("results" in mData && mData.results.length) {
					for (var i in mData.results) {
						if (mData.results.hasOwnProperty(i)) {
							User.setData(mData.results[i]);
						}
						break;
						debugger;
					}
				}
				// call the afterRead method wich will add the canCreate object to the model
				fnAfterRead();
				// fire loaded
				User.fireSettingsLoaded();
			},
			error: function () {
				// after read
				fnAfterRead();
				// fire settings loaded
				User.fireSettingsLoaded();
			}
		}
	);

	return User;
});