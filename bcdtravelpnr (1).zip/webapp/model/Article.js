sap.ui.define([
	"com/bcdtravel/pnr/model/BCDGateway",
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/I18n"
], function (BCDGateway, JSONModel, I18n) {
	"use strict";

	var _private = {
		parseParams: function (mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.success = ("success" in mParams && typeof mParams.success === "function") ? mParams.success : function () {};
			mParams.error = ("error" in mParams && typeof mParams.error === "function") ? mParams.error : function () {};
			return mParams;
		},
		getServiceURl: function (sBookingsId, sArticlesId) {
			if (sBookingsId && sArticlesId) { // all read, update or delete
				return "/articlesSet(BookingsId='" + sBookingsId + "',ArticlesId=" + sArticlesId + ")";
			}
			// create only
			return "/articlesSet";
		}
	};

	var oArticleModel = JSONModel.extend("com.bcdtravel.pnr.model.Article", {
		/**
		 * Construct the Article model
		 * @param {string} sBookingsId 
		 * @param {string} sArticlesId		0 = new article
		 * @param {object} mParams
		 * @param {fnSuccessErrorCallback} [mParams.success]	- success callback
		 * @param {fnSuccessErrorCallback} [mParams.error]		- error callback
		 * @param {object} [mParams.newArticleData]				- in case of an new article, this object will hold the default properties
		 */
		constructor: function (sBookingsId, sArticlesId, mParams) {
			// call parent && do not pass any argument
			JSONModel.apply(this); // do not pass arguments
			// parse params
			mParams = _private.parseParams(mParams);
			var that = this,
				oDeffered = $.Deferred();
			oDeffered.promise(this);
			// new article 
			// create a new article object based on the metadata
			if (sArticlesId === 0) {
				var m = BCDGateway.getNewEntityData("articles");
				// set default data passed in constructor
				if ("newArticleData" in mParams && typeof mParams.newArticleData === "object") {
					m = $.extend(true, m, mParams.newArticleData);
				}
				// set the articles id to 0 to indicate it's a new article (see .isNew() method)
				m.ArticlesId = 0;
				// default values for stepinputs
				m.Quantityofproduct = 1;
				m.Conjunction = 1;
				m.Numberofpeople = 1;
				// default values for currency input fields
				m.Farepaidamount = "0.00";
				m.Lowestofferedfare = "0.00";
				m.Standardfare = "0.00";
				m.Salespriceamount = "0.00";
				m.CopiedFromArticlesId = 0;
				// set the model data
				this.setData(m);
				// exec the callbacks after an short timeout
				// sometimes the article needs to be already constructed in the success callback
				setTimeout(function () {
					mParams.success.apply(this, [m]);
					oDeffered.resolve(m);
				}, 10);
				return;
			}
			// Articles
			BCDGateway.read(
				_private.getServiceURl(sBookingsId, sArticlesId), {
					// filters: [ // filter by BookingsId
					// 	new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId)
					// ],
					success: function (mData) {
						// make sure these fields are set.
						// if not the live sapui5 verion stepinput won;t work
						var aMustBeZero = ["Quantityofproduct", "Conjunction", "Numberofpeople"];
						for (var i in aMustBeZero) {
							var s = aMustBeZero[i];
							if (s in mData && mData[s] === "") {
								mData[s] = 0;
							}
						}
						// Issue 0076 Amount fields in BS to much zero's
						// In the backend decimal values are stored with 7 zeroes..
						// We dont want to show those zeroes in fiori therefore I do a rtrim removing all zeroes from the right
						var mEntityProperties = BCDGateway.getMetaDataEntityProperties("articles");
						for (var sProperty in mEntityProperties) {
							if ("type" in mEntityProperties[sProperty] && mEntityProperties[sProperty].type === "Edm.Decimal" && sProperty in mData &&
								mData[sProperty] !== "") {
								mData[sProperty] = mData[sProperty].toString().replace(new RegExp("[0]*$"), "");
								if (mData[sProperty] === "0.") {
									mData[sProperty] = mData[sProperty] + "00";
								}
							}
						}
						// set data
						that.setData(mData);
						oDeffered.resolve(mData);
						mParams.success.apply(this, arguments);
					},
					error: function () {
						oDeffered.reject();
						mParams.error.apply(this, arguments);
					}
				}
			);
		},
		/**
		 * Helper method to check if the Article is ticketed or not 
		 * @return	<boolean>
		 */
		isTicketed: function () {
			var mData = this.getProperty("/");
			return (mData.Ticketreference !== "") ? "X" : "";
			//return ("Ticketreference" in mData && mData.Ticketreference);
		},

		/**
		 * Check if the article is new or not
		 */
		isNew: function () {
			return (this.getProperty("/ArticlesId") === 0);
		},

		/**
		 * release the billback
		 */
		releaseBillback: function (mParams) {
			// clear out the BillBackNotReleased so that martin knows
			this.setProperty("/BillbackNotReleased", "");
			this.saveData(mParams);
		},

		/**
		 * Approve transaction fee
		 */
		approveTransactionFee: function (mParams) {
			// clear out the BillBackNotReleased so that martin knows
			this.setProperty("/Tafeeapproved", "X");
			this.saveData(mParams);
		},

		/**
		 * Save the article data on the gateway
		 */
		saveData: function (mParams) {
			mParams = _private.parseParams(mParams);
			var mData = this.getProperty("/");
			// Prevent update if the article is not ticketed
			if (!this.isNew() && !this.isTicketed()) {
				// show message and throw error
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(I18n.getText("Article.UnticketedWarning"));
				mParams.error();
				return;
			}
			// // Since this is an JSONModel, additional properties could be added
			// // we need to compare the model data agains the metadata enity properties
			// // remove any property which is not present in the entity properties before sending it back to the odata service
			// // (maybe) todo: contstraints check / field checks
			// var mProperties = BCDGateway.getMetaDataEntityProperties("articles");
			// if (mProperties) {
			// 	var mNewData  = {};
			// 	for (var sProperty in mData) {
			// 		if (sProperty in mProperties) {
			// 			var mMetaData = mProperties[sProperty];
			// 			// make sure a string value is send back as string
			// 			if ("type" in mMetaData) {
			// 				if (mMetaData.type === "Edm.String" && typeof mData[sProperty] !== "string") {
			// 					mData[sProperty] = mData[sProperty].toString();
			// 				}
			// 				// todo else
			// 			}
			// 			mNewData[sProperty] = mData[sProperty];
			// 		}
			// 	}
			// 	mData = mNewData;
			// }
			/**
			 * On updating an article, the ErrorCode should be an whitespace
			 * The update function Martin created in the backend, then knows that all field-checks
			 * needs to be recalculated and the "error" table (errorSet) will be updated.
			 **/
			mData.ErrorCode = " ";
			var that = this;
			// Save data to service
			if (this.isNew()) { // Create New
				BCDGateway.create(
					_private.getServiceURl(),
					mData, {
						success: function (m) {
							// reset the data (this will re-set the newly created ArticlesId)
							that.setData(m);
							mParams.success.apply(that, arguments);
						},
						error: mParams.error
					}
				);
			} else { // update
				BCDGateway.update(
					_private.getServiceURl(mData.BookingsId, mData.ArticlesId),
					mData,
					mParams
				);
			}

		}
	});

	/**
	 * Returns all currency field names
	 * This is needed in the ArticleCopy.js to determine which fields are currency input fields
	 * @return array
	 */
	oArticleModel.getCurrencyFieldsnames = function () {
		return [
			"Clientmarkup",
			"Ifaremarkup",
			"Creditcardamount",
			"Standardfare",
			"Lowestofferedfare",
			"Farepaidamount",
			"Baseamount",
			"Totalamount",
			"Salespriceamount",
			"Clientmarkup",
			"Baseamountlocal",
			"Exchangeamount"
		];
	};

	oArticleModel.isCurrencyField = function (sFieldname) {
		return (oArticleModel.getCurrencyFieldsnames().indexOf(sFieldname) !== -1);
	};

	return oArticleModel;
});

/* JSDOC Type Definitions */

/**
 * A callback function which is called when the data has been retrieved.
 * @callBack fnSuccessErrorCallback
 * @param {object} The data of the retrieved data
 * @param {object} Further information about the response of the request.
 */