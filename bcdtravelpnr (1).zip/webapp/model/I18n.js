sap.ui.define([
	"sap/ui/model/resource/ResourceModel"
], function(ResourceModel) {
	"use strict";
	var _private = {
		I18n:null
	};

	var oExtend = $.extend(true, {}, {
		getText: function(sResourceText) {
			var aArgs = [];
			if (arguments.length > 1) {
				if (arguments.length === 2 && arguments[1] instanceof Array) {
					aArgs = arguments[1];
				}
				for (var i in arguments) {
					if (i == 0) { // IMPORTANT not ===
						continue;
					}
					aArgs.push(arguments[i]);
				}
			}
			return _private.I18n.getResourceBundle().getText(sResourceText, aArgs);
		}
	});

	var I18n = ResourceModel.extend("com.bcdtravel.pnr.i18n.i18n", oExtend);
	_private.I18n = new I18n({
		bundleName: "com.bcdtravel.pnr.i18n.i18n"
	});
	return _private.I18n;
});