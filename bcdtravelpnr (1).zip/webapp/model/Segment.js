sap.ui.define([ 
	"com/bcdtravel/pnr/model/BCDGateway",
	"sap/ui/model/json/JSONModel",
	"com/bcdtravel/pnr/model/I18n"
], function(BCDGateway, JSONModel, I18n) {
	"use strict";
	
	var _private = {
		/**
		 * Helper method to make sure the mandatory mParams for every deffered methods are present
		 * always will be added to the success and error callbacks so we dont need to apply it manually
		 * @param {object} [mParameters]							- Parameters
		 * @param {fnSuccessErrorCallback} [mParameters.success]	- success callback
		 * @param {fnSuccessErrorCallback} [mParameters.error]		- error callback
		 * @param {fnSuccessErrorCallback} [mParameters.always]		- always callback
		 * @returns {object} - parsed mParameters
		 */
		parseParams: function(mParameters) {
			var mParams = (typeof mParameters === "object") ? mParameters : {};
			mParams.success = ("success" in mParams && typeof mParams.success === "function") ? mParams.success : function() {};
			mParams.error	= ("error" in mParams && typeof mParams.error === "function") ? mParams.error : function() {};
			return mParams;
		},
		/**
		 * Generates the correct service url
		 * @param {string} [sBookingsId]	- The Bookings Id
		 * @param {string} [sArticlesId]	- The Article Id
		 * @param {string} [sSegmentId] 	- The Segment Id
		 * @return {string} - Service URL
		 */
		getServiceURl: function(sBookingsId, sArticlesId, sSegmentId) {
			if (sBookingsId && sArticlesId && sSegmentId) { // all read, update or delete
				return "/segmentSet(BookingsId='" + sBookingsId + "',ArticlesId=" + sArticlesId + ",SegmentId=" + sSegmentId + ")";
			}
			// create only
			return "/segmentSet";
		}
	};
	
	
	return JSONModel.extend("com.bcdtravel.pnr.model.Segment", {
		/**
		 * Construct the segments model
		 * @param {string} sBookingsId	- The Bookings Id
		 * @param {string} sArticlesId	- The Article Id
		 * @param {string} sSegmentId	- The Segment Id
		 * @param {object} [mParameters]								- Parameters
		 * @param {fnSuccessErrorCallback}	[mParameters.success]		- Success callback
		 * @param {fnSuccessErrorCallback}	[mParameters.error]			- Error callback
		 * @param {object}					[mParams.newSegmentData]	- In case of an new segment, this object will hold the default properties
		 */
		constructor: function(sBookingsId, sArticlesId, sSegmentId, mParameters) {
			// call parent && do not pass any argument
			JSONModel.apply(this); // do not pass arguments
			// parse params
			var mParams = _private.parseParams(mParameters);
			var	oDeffered	= $.Deferred(),
				that		= this;
			// add deferred to this model
			oDeffered.promise(this);
			// new Segment 
			// create a new Segment object based on the metadata
			if (sSegmentId === 0) {
				var m = BCDGateway.getNewEntityData("segment");
				// set default data passed in constructor
				if ("newSegmentData" in mParams && typeof mParams.newArticleData === "object") {
					m = $.extend(true, m, mParams.newArticleData);
				}
				// set the SegmentId id to 0 to indicate it's a new SegmentId (see .isNew() method)
				m.SegmentId = 0;
				// set the model data
				this.setData(m);
				// exec the callbacks after an short timeout
				// sometimes the SegmentId needs to be already constructed in the success callback
				setTimeout(function() {
					mParams.success.apply(this, [m]);
					oDeffered.resolve(m);
				}, 10);
				return;
			} 
			// Read
			BCDGateway.read(
				_private.getServiceURl(sBookingsId, sArticlesId, sSegmentId),
				{
					// filters: [ // filter by BookingsId
					// 	new sap.ui.model.Filter("BookingsId", sap.ui.model.FilterOperator.EQ, bookingId)
					// ],
					success: function(mData) {
						that.setData(mData);
						oDeffered.resolve(mData);
						mParams.success.apply(this, arguments);
					},
					error: function() {
						oDeffered.reject();
						mParams.error.apply(this, arguments);
					}
				}
			);
		},
		
		/**
		 * Make sure articlesId is an int
		 * TODO: check from metadata
		 */
		/*setProperty: function() {
			if (arguments.length > 1 && arguments[0] === "/ArticlesId") {
				arguments[1] = parseInt(arguments[1], 10);
			}
			//oSegment.setProperty("/ArticlesId", that._articleId);
			this.setProperty.apply(this, arguments);
		},*/
		
		/**
		 * Helper method to check if the Segment is ticketed or not 
		 * @returns	{boolean} -
		 */
		isTicketed: function() {
			var mData = this.getProperty("/");
			/// we need to grab use the article to determine if it is ticketed
			var mArticle = BCDGateway.getProperty("/articlesSet(BookingsId='" + mData.BookingsId + "',ArticlesId=" + mData.ArticlesId + ")");
			if ("Ticketreference" in mArticle) { return (mArticle.Ticketreference) ? true : false; }
			// not possible via article? check segment it self
			return ("Segmentticketedindicator" in mData && mData.Segmentticketedindicator);
		},
		
		/**
		 * Check if the Segment is new or not
		 * @returns {boolean} -
		 */
		isNew	: function() {
			return (this.getProperty("/SegmentId") === 0);
		},
		
		/**
		 * Save the article data on the gateway
		 * @param {object} [mParameters]							- Parameters
		 * @param {fnSuccessErrorCallback} [mParameters.success]	- success callback
		 * @param {fnSuccessErrorCallback} [mParameters.error]		- error callback
		 */
		 saveData: function(mParameters) {
		 	var mParams = _private.parseParams(mParameters),
		 		mData	= this.getProperty("/"),
		 		that	= this;
		 	// Prevent update if the article is not ticketed
		 	if (! this.isNew() && ! this.isTicketed()) {
		 		jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(I18n.getText("Segment.UnticketedWarning"));
				mParams.error();
				return;
			}
			// // Since this is an JSONModel, additional properties could be added
			// // we need to compare the model data agains the metadata enity properties
			// // remove any property which is not present in the entity properties before sending it back to the odata service
			// // (maybe) todo: contstraints check / field checks
			// var mProperties = BCDGateway.getMetaDataEntityProperties("segment");
			// if (mProperties) {
			// 	var mNewData  = {};
			// 	for (var sProperty in mData) {
			// 		if (sProperty in mProperties) {
			// 			mNewData[sProperty] = mData[sProperty];
			// 		}
			// 	}
			// 	mData = mNewData;
			// }
			// Save data to service
			if (this.isNew()) { // Create New
				BCDGateway.create(
					_private.getServiceURl(),
					mData,
					{
						success: function(m) {
							// reset the data (this will re-set the newly created SegmentId)
							that.setData(m);
							mParams.success.apply(that, arguments);
						},
						error: mParams.error
					}
				);
			} else { // update
				BCDGateway.update(
					_private.getServiceURl(mData.BookingsId, mData.ArticlesId, mData.SegmentId),
					mData,
					mParams
				);
			}
		 }
	});
});
/* JSDOC Type Definitions */

/**
 * A callback function which is called when the data has been retrieved.
 * @callBack fnSuccessErrorCallback
 * @param {object} The data of the retrieved data
 * @param {object} Further information about the response of the request.
 */