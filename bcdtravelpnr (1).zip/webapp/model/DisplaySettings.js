/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.model */
sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	var 
		mDisplaySettings	= {
			/* Visibility settings for ArtticleData (formdata) > Article.view.xml articlesSet values*/
			ArticleData : { // note: fields that are categorized in the XLS file are ommited here and in the view
				Account							 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Agencylicencenumber            : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Airlinepnrlocator              : ["AIR", "RAIL"],
				Bookingagentcode				: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Bookingcode						: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Baseamount                     : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Baseamountlocal				   : [], // 28-11 Wim zegt dat ze verborgen moeten worden//["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Billbackindicator              : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Bookingmethods                 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Bookingsourcecreation          : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Carhotelroomtype               : ["HOTEL", "CAR"],
				Clientmarkup				   :  ["AIR", "RAIL"],
				Commissionamount               : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Commissionpercentage           : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Conjunction                    : ["AIR", "RAIL", "CAR", "MISC"],
				Creditcardamount               : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardauthorisation        : ["AIR", "RAIL"],
				Creditcardexpiry               : ["AIR", "RAIL"],
				Creditcardnumber               : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardtype                 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardauthorisationmerchan : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardexpirymerchant       : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardnumbermerchant       : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Creditcardtypemerchant         : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Currency                       : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Domintindicator                : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Einvoiceemailaddress           : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				DpDocid							 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				DtelGefInvnr					 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Emdtypeindicator                : ["AIR", "RAIL"],
				Exchangeamount                 : ["AIR", "RAIL"],
				Exchangeindicator              : ["AIR", "RAIL"],
				Exchangeticketedairline        : ["AIR", "RAIL", "MISC"],
				Exchangeticketreference        : ["AIR", "RAIL", "MISC"],
				Farepaidamount                 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Foreigntariffindicator         : ["AIR", "RAIL"],
				Formofpayment                  : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Gdsbooking                     : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Hotelchaincode                 : ["HOTEL"],
				Hotelname                      : ["HOTEL"],
				Hotelpropertycode              : ["HOTEL"],
				Ifaremarkup                    : ["AIR", "RAIL"],
				Ifarepcc                       : ["AIR", "RAIL"],
				Ifarerechargeaccount             : ["AIR", "RAIL"],
				IssueDate                      : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Itnumber                       : ["AIR", "RAIL"],
				Totallocalamount               : [], // 28-11 Wim zegt dat ze verborgen moeten worden["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Lowestofferedfare              : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Mainarrival                    : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Mainbookingclass               : ["AIR", "RAIL"],
				Maindeparture                  : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Numberofpeople                 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Obfeeindicator                 : ["AIR"],
				Orderedby                      : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Passengername                  : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"], // IMPORTANT ALWAYS VISIBLE
				Passengertype                  : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Productid                      : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Productremarks                 : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Quantityofproduct              : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Ratetypes                      : ["AIR", "RAIL", "HOTEL", "CAR"],
				Reasoncodes                    : ["AIR", "RAIL", "HOTEL", "CAR"],
				Reasonforissuancecodes         : ["AIR", "RAIL"],
				Refundauthorization            : ["AIR", "RAIL", "HOTEL", "CAR"],
				Salespriceamount                : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Standardfare                   : ["AIR", "RAIL", "HOTEL", "CAR"],
				Supplier                       : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Ticketedairline                : ["AIR", "RAIL", "CAR"],
				Ticketingagentcode             : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Ticketingcode                  : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Ticketreference                : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"], // IMPORTANT:: ALWAYS VISIBLE SINCE ON CREATE THIS FIELD IS MANDATORY
				Tickettypes                    : ["AIR", "RAIL"],
				Totalamount                    : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Transactioncontrolnumber       : ["AIR", "RAIL"],
				Transactiontype                : ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Vouchernumber                  : ["HOTEL", "CAR", "MISC"],
				Transactionfee					: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"]
			},
			/* Visibility settings for SegmentData > Segment.view.xml segmentSet values*/
			SegmentData : {
				Departureterminal			: ["AIR"] ,
				Segmentdeparturedate		: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentdeparturetime		: ["AIR", "RAIL"],
				Segmentdeparture			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Arrivalterminal				: ["AIR"],
				Segmentarrivaldate			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentarrival				: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentarrivaltime			: ["AIR", "RAIL"],
				Segmentdurationtime			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Codeshareoperator			: ["AIR"],
				Electronicticketindicator	: ["AIR", "RAIL"],
				Segmentaircrafttypes		: ["AIR", "RAIL"],
				Segmentbaggageallowance		: ["AIR", "RAIL"],
				Segmentclass				: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentcoach				: ["RAIL"],
				Segmentfarebasis			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentfarebasisendorsement	: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentfarebasisvalidfrom	: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentfarebasisvalidto		: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentflight				: ["AIR", "RAIL"],
				Segmentflightcouponindicator : ["AIR"],
				Segmentfrequentflyermiles	: ["AIR"],
				Segmentidentifier			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentintnextdayarrivalind	: ["AIR", "RAIL"],
				Segmentmealcode				: ["AIR", "RAIL"],
				Segmentnauticalmiles		: ["AIR", "RAIL"],
				Segmentnumberofdays			: ["HOTEL", "CAR"],
				Segmentprovider				: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentseatindicator		: ["AIR", "RAIL"],
				Segmentseatnumber			: ["AIR", "RAIL"],
				Segmentstatuscodes			: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentstopcount			: ["AIR", "RAIL"],
				Segmentstopover				: ["AIR", "RAIL"],
				Segmentticketcouponidentifier	: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"],
				Segmentticketedindicator	: ["AIR", "RAIL", "HOTEL", "CAR", "MISC"]
			}
		},
		aAllTypes			= ["AIR", "RAIL", "HOTEL", "CAR", "MISC", "CC"];
	
	/**
	 * Display settings
	 * 
	 * @class 		
	 * @alias 		com.bcdtravel.pnr.model.DisplaySettings
	 * @extends 	sap.ui.model.json.JSONModel
	 * 
	 * @constructor
	 * @public
	 * @classdesc
	 * The Display Settings are used to determine which fields should be visible on the Article- and Segment Views according to the ArticleCategory
	 * @example
	 * // On initializing the DisplaySettings json model is created:
	 * // {
	 * //	Article :{
	 * //		AirlinePNRLocator: {
	 * //			Air: {
	 * //				show: true,
	 * //				hide: false
	 * //			},
	 * //			Car: {
	 * //				show: true,
	 * //				hide: false
	 * //			},
	 * //			... etc
	 * //		},
	 * //		... etc
	 * //	}
	 * //	Segment: {....},
	 * //	... etc
	 * //  }
	 *  
	 * // in The view you can do
	 * <Text visible="{DisplaySettings>/Article/AirlinePNRLocation/Air/show}" text="example"/>
	 * 
	 */
	var	oDisplaySettings	= new JSONModel({});
	
	/**
	 * Check if a enitity column should be visible or hidden
	 * @param {string} sBookingStore=ArticleData|SementData		- Booking Store type
	 * @param {string} sColumn									- Entity column
	 * @param {string} sArticleCategory=AIR|RAIL|HOTEL|CAR|MISC	- Article Category
	 * @returns {boolean} -
	 */
	oDisplaySettings.isVisible = function(sBookingStore, sColumn, sArticleCategory) {
		if (! (sBookingStore in mDisplaySettings) || ! (sColumn in mDisplaySettings[sBookingStore]) ) {
			return false;
		}
		return (mDisplaySettings[sBookingStore][sColumn].indexOf(sArticleCategory.toUpperCase()) !== -1);
	};
	
	/**
	 * Check if a Article Data column should be visible 
	 * @param {string} sColumn									- Article Entity Column name
	 * @param {string} sArticleCategory=AIR|RAIL|HOTEL|CAR|MISC - Article Category
	 * @returns {boolean} -
	 */
	oDisplaySettings.ArticleIsVisible = function(sColumn, sArticleCategory) {
		return oDisplaySettings.isVisible("ArticleData", sColumn, sArticleCategory);	
	};
	
	/**
	 * Get the Visibility settigns model
	 * @param {string} sBookingStore=ArticleData|SementData		- Booking Store type
	 * @return {object} -
	 */
	oDisplaySettings.getVisibilityModelFor = function(sBookingStore) {
		var m = this.getProperty("/"),
			oModel = new JSONModel({});
		if (sBookingStore in m) {
			oModel.setData(m[sBookingStore]);
		}
		return oModel;
	};
	
	/**
	 * returns all keys of the required displaysetting
	 * @param	{string}	sType=ArticeData|SegmentData	- Display setting
	 * @return	{map}	["DepartureTerminal", ""Segmentdeparture", .... etc ] (SegmentData is used in this example)
	 */
	oDisplaySettings.getFieldsArrayFor = function(sType) {
		var a = [];
		if (! (sType in mDisplaySettings)) { return a; }
		// note : do not use Object.keys here ... not supported IE < 9
		for (var sField in mDisplaySettings[sType]) {
			if (mDisplaySettings[sType].hasOwnProperty(sField)) {
				a.push(sField);
			}
		}
		return a;
	};
	
	/**
	 * returns an object with with the visibility settings 
	 * @param	{string} sType=ArticeData|SegmentData		- Display setting key 
	 * @param	{string} sCategory=AIR|RAIL|HOTEL|CAR|MISC	- Article Category
	 * @returns	{object} { DepartureTerminal: true, Segmentdeparture: false, ...etc... }
	 */
	oDisplaySettings.getVisibleObjectByTypeAndCategory = function(sType, sCategory) {
		var aFields = this.getFieldsArrayFor(sType),	
			oReturn	= {};
		if (aFields.length > 0) { 
			for (var i in aFields) {
				if (aFields.hasOwnProperty(i)) {
					oReturn[aFields[i]] = this.isVisible(sType, aFields[i], sCategory);
				}
		 	}
	 	}
	 	return oReturn;
	};
	
	var mModelData = {};
	/*
		Create default data
	  model example for Article AirlinePNRLocator
	  {
		Article :{
			AirlinePNRLocator: {
				Air: {
					show: true,
					hide: false
				},
				Car: {
					show: true,
					hide: false
				},
				... etc
			},
			... etc
		}
		Segment: {....},
		... etc
	  }
	  
	  in ui5 you can do
	  <Text visible="{DisplaySettings>/Article/AirlinePNRLocation/Air/show}" text="example"/>
	 */
	for (var sBookingStore in mDisplaySettings) {
		// check if booking store is in model data
		if (! (sBookingStore in mModelData)) {
			mModelData[sBookingStore] = {};
		}
		for(var sField in mModelData[sBookingStore]) {
			if (mModelData[sBookingStore].hasOwnProperty(sField) === false) { continue; }
			for (var sType in aAllTypes) {
				if (aAllTypes.hasOwnProperty(sType) === false) { continue; }
				var bVisible = oDisplaySettings.isVisible(sBookingStore, sField, sType);
				mModelData[sBookingStore][sField] = {
					show: bVisible,
					hide: (bVisible) ? false : true
				};
			}
		}
	}
	// Set model data
	oDisplaySettings.setData(mModelData);
	// return model
	return oDisplaySettings;
});