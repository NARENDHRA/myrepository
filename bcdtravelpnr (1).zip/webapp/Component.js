sap.ui.define([
	"sap/ui/core/UIComponent",
	"com/bcdtravel/pnr/model/models",
	"com/bcdtravel/pnr/model/BCDGateway",
	"com/bcdtravel/pnr/model/DisplaySettings",
	"sap/ui/Device",
	"com/bcdtravel/pnr/iconfont/CustomIcons",
	"com/bcdtravel/pnr/model/User",
	"com/bcdtravel/pnr/model/I18n"
], function(UIComponent, models, BCDGateway, DisplaySettings, Device, CustomIcons, User, I18n) {
	"use strict";

	return UIComponent.extend("com.bcdtravel.pnr.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			
			
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			// set the odata model
			this.setModel(BCDGateway, "BCDGateway");
			// set the DisplaySettings globally
			this.setModel(DisplaySettings, "DisplaySettings");
			
			// BCD Icons
			CustomIcons.registerIcons();
			
			// var oUserData = new sap.ui.model.json.JSONModel(),
			// 	oUserAttributes = new sap.ui.model.json.JSONModel();
			// oUserData.loadData("/services/userapi/currentUser");
			// oUserData.loadData("/services/userapi/attributes");
			
			// bind the User model to all views so we can use it
			this.setModel(User, "User");
			
			/**
			 * This method adds additionally functionality to the Router
			 * It Overrides the .navTo method, it is now possible to cancel the navTo navigation
			 * and show a dialog that unsaved changed will be lost on navigating.
			 * This can be done by setting the router _preventNavBy 
			 * @see BaseController.js _preventRouterNavigation and _allowRouterNavigation method
			 */
			var createRouterMethods = function(oComponent) {
				var oRouter = oComponent.getRouter();
				// {object|null} - Holds the info which will cause the navgiation prevention
				oRouter._preventNavBy = null;
				// make sure the preventNavBy is resetted if the user hits the browsers backbutton
				oRouter.attachRouteMatched(function() {
					oRouter._preventNavBy = null;
				});
				// overwrite the navt method
				oRouter.navTo = function() {
					var that			= this,
						aNavToArguments = arguments;
					if (oRouter._preventNavBy !== null && Object.keys(oRouter._preventNavBy).length) {
						// create the prevent by string
						var aPreventBy = [],
							sPreventBy = "";
						for (var i in oRouter._preventNavBy) {
							aPreventBy.push(oRouter._preventNavBy[i]);
						}
						if (aPreventBy.length >= 3) {
							sPreventBy = "\"" + aPreventBy.shift() + "\", \"" + aPreventBy.shift() + "\" and ";
						}
						sPreventBy += "\"" + aPreventBy.join("\" " + I18n.getText("UnsavedData.and") + " \"") + "\"";
						// create dialog
						var oDialog = new sap.m.Dialog({
							title	: I18n.getText("UnsavedData.Title"),
							type	: "Message",
							content	: [
								new sap.m.Text({
									text: I18n.getText("UnsavedData.Message", sPreventBy)
								})
							],
							beginButton: new sap.m.Button({
								text		: I18n.getText("UnsavedData.Proceed"),
								press		: function () {
									oRouter._preventNavBy = null;
									sap.m.routing.Router.prototype.navTo.apply(that, aNavToArguments);
									oDialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text		: I18n.getText('Cancel'),
								press		: function () {
									oDialog.close();
								}
							}),
							afterClose: function() {
								oDialog.destroy();
							}
						});
						oDialog.open();
					} else {
						sap.m.routing.Router.prototype.navTo.apply(this, aNavToArguments);
					}
				};
				return oRouter;
			};
			
			var oRouter = createRouterMethods(this);
			/**
			 * Note: the app does not start untill the user settings are loaded!
			 */
			User.attachSettingsLoaded(function() {
				// init the router to create the views based on the url/hash
				oRouter.initialize();
				// dont close any open dialog on page transition (needed for the create article popup to work)
				oRouter.getTargetHandler().setCloseDialogs(false);
			});
		},
		
		/**
		 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} - css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function() {
			if (this._sContentDensityClass === undefined) {
				// check whether FLP has already set the content density class; do nothing in this case
				if ($(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
					this._sContentDensityClass = "";
				} else if (! Device.support.touch) { // apply "compact" mode if touch is not supported
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}
	});
});