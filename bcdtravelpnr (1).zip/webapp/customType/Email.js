sap.ui.define([
    "sap/ui/model/SimpleType",
    "sap/ui/model/ValidateException"
], function (SimpleType, ValidateException) {
    "use strict";

    return SimpleType.extend("customType.Email", {
		formatValue: function(sEmail) {
	        return sEmail;
        },
        parseValue: function(sEmail) {
            return sEmail;
        },
        validateValue: function(sEmail) {
        	var oRegex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
			if (! oRegex.test(sEmail)) {
				throw new ValidateException(sEmail + " is not a valid e-mail address");
			}
        }
    });

});