/** @namespace com */
/** @namespace com.bcdtravel */
/** @namespace com.bcdtravel.pnr */
/** @namespace com.bcdtravel.pnr.controller */
sap.ui.define([
	"com/bcdtravel/pnr/model/I18n"
], function(I18n) {
	"use strict";
	
	var oUtils = {
		/**
		 * Open a Error message box
		 * @param {string}	sMessage - the message that should be showed in the message box
		 */
		_showError: function(sMessage) {
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.error(sMessage);
		},
		
		/**
		 * Show an error dialog with default text + any response text from the gateway error
		 * @param {object} e - the error response from the service
		 */
		_showErrorByOdataResponse: function(e) {
			if (typeof e === "undefined") { return; }
			jQuery.sap.log.debug(e);
			var mOdataError	= null,
				strMessage	= I18n.getText("oDataLoadError");
			// Errors  from ECC systems
			if (typeof e === "object" && "responseText" in e) {
				try {
				   	var mResponseText = JSON.parse(e.responseText);
				   	if ("error" in mResponseText) {
				   		mResponseText = mResponseText.error;
				   	}
				   	if ("message" in mResponseText) {
				   		mOdataError = mResponseText;
				   	}
				} catch (eCatch) {
					if (e.responseText.length) {
						mOdataError = {
							message: { value: e.responseText }
						};
					}
				}
			}
			// Errors of other SAP-systems & default oData errors
			if (typeof e === "object" && mOdataError === null && "message" in e) {
				if (typeof e.message === "string") {
					mOdataError = { message: { value: e.message }};
				} else{
					mOdataError = e;
				}
			}
			// string only
			if (mOdataError === null && typeof e === "string" && e.length) {
				mOdataError = { message: { value: e } };
			}
			// odata message
			if (mOdataError !== null && "message" in mOdataError && typeof mOdataError.message === "object" && "value" in mOdataError.message) {
				strMessage = I18n.getText("oDataLoadError") + "\r\n \r\n\ Server Message: \r\n" + mOdataError.message.value; 
			} else if (mOdataError !== null && "message" in mOdataError && typeof mOdataError.message === "string") {
				strMessage = I18n.getText("oDataLoadError") + "\r\n \r\n\ Server Message: \r\n" + mOdataError.message; 
			}
			oUtils._showError(strMessage);
		}
	};
	
	return oUtils;
});