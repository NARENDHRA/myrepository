jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsmmanagebudget/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsmmanagebudget/test/integration/pages/Worklist",
		"lsmmanagebudget/test/integration/pages/Object",
		"lsmmanagebudget/test/integration/pages/NotFound",
		"lsmmanagebudget/test/integration/pages/Browser",
		"lsmmanagebudget/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmmanagebudget.view."
	});

	sap.ui.require([
		"lsmmanagebudget/test/integration/WorklistJourney",
		"lsmmanagebudget/test/integration/ObjectJourney",
		"lsmmanagebudget/test/integration/NavigationJourney",
		"lsmmanagebudget/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});