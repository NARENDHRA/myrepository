sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		statusColorChange: function(sValue) {
			if (sValue === "01") {
				return "Warning";
			}
			if (sValue === "02") {
				return "Success";
			}
			if (sValue === "03") {
				return "Success";
			}
			if (sValue === "04") {
				return "Warning";
			}
			if (sValue === "05") {
				return "Error";
			}
		},
		SeTStatusIcon: function(isError) {
			if (isError === "S") {
				return "sap-icon://message-success";
			} else if (isError === "E") {
				return "sap-icon://message-error";
			} else if (isError === null || isError === undefined) {
				return "";
			}
		},
		SeTStatusIconColor: function(isError) {
			if (isError === "S") {
				return "Green";
			} else if (isError === "E") {
				return "Red";
			} else if (isError === null || isError === undefined) {
				return "";
			}
		}

	};

});