jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsminvoicenew/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsminvoicenew/test/integration/pages/Worklist",
		"lsminvoicenew/test/integration/pages/Object",
		"lsminvoicenew/test/integration/pages/NotFound",
		"lsminvoicenew/test/integration/pages/Browser",
		"lsminvoicenew/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsminvoicenew.view."
	});

	sap.ui.require([
		"lsminvoicenew/test/integration/WorklistJourney",
		"lsminvoicenew/test/integration/ObjectJourney",
		"lsminvoicenew/test/integration/NavigationJourney",
		"lsminvoicenew/test/integration/NotFoundJourney",
		"lsminvoicenew/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});