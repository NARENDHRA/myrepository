/*global location */
jQuery.sap.require("jszip");
sap.ui.define([
	"lsminvoicenew/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsminvoicenew/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("lsminvoicenew.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {

			// this.getView().setBusy(true);
			this.bServiceFlag = true;
			this.bTimeKeeperServiceFlag = true;
			var JsonModelButton = new JSONModel({
				"Print": false,
				"Accept": false,
				"Approve": false,
				"Reject": false,
				"UploadAttc": false,
				"Save": false,
				"invStatus": true,
				"payStatus": false,

				Paid: 0,
				Processed: 0,
				ApprovedPayment: 0,
				Faild: 0
			}, true);
			this.getView().setModel(JsonModelButton, "JModelButton");

			this._oTableSearchState = [];

			// this.getView().byId("InvSmartTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			this._oTableSearchState = [];

			var oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				"PayDoc": false,
				"InvStatus": true,
				"PayStatus": false,
				"attachUpload": false
			});
			this.setModel(oViewModel, "worklistView");

			this.sideKey = "";

			this._mFilters = {
				"pending": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "01")],
				"inProcess": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "04")],
				"approved": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "02")],
				"rejected": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "03")],
				"holdBudget": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "05")]

			};

		},
		onSelectionItemPress: function(evt) {
			var oViewModel = this.getView().getModel("worklistView");
			var oItem = evt.getParameters("listItem").listItems;
			if (oItem.length > 0) {
				oViewModel.setProperty("/attachUpload", true);
			} else {
				oViewModel.setProperty("/attachUpload", false);
			}
		},
		// Attachments upload.
		onChangeUploadAttch: function(evt) {
			var oTable = this.getView().byId("InvSmartTable");
			var tbl = oTable.getTable();
			var obj = tbl.getSelectedContexts()[0].getObject();
			var invNo = obj.ZzinvoiceNumber;
			var oFile = evt.getParameter("files");
			var sFileName = oFile[0].name;
			var oModel = this.getView().getModel();
			var oToken = oModel.getSecurityToken();
			var oUpload = evt.getSource();
			if (oUpload.getHeaderParameters().length === 0) {
				oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "x-csrf-token",
					value: oToken
				}));
				oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "slug",
					value: invNo + "|" + sFileName
				}));
			}
			oUpload.upload();
			oUpload.clear();
		},
		handleUploadAttach: function(evt) {
			var oTable = this.getView().byId("InvSmartTable");
			var tbl = oTable.getTable();
			var oUpload = evt.getSource();
			var oStatus = evt.getParameter("status");
			if (oStatus === 201) {
				tbl.removeSelections();
				sap.m.MessageBox.show(
					"Successfully Upload Attachment", {
						icon: sap.m.MessageBox.Icon.confirm,
						title: "Success",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {}
					}
				);
				tbl.rebindTable();
				// this.getView().getModel().refresh(true);
			} else {
				sap.m.MessageBox.error("Error while Uploading attachment", {
					title: "Error", // default
					onClose: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
			}
			oUpload.clear();
		},

		// handleDataReceived: function(oEvent) {
		// 	// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV");
		// 	var oModel = this.getOwnerComponent().getModel();

		// 	var oViewModel = this.getModel("JModelButton");

		// 	oModel.read("/InvHeaderSet/$count", {
		// 		success: function(oData) {
		// 			oViewModel.setProperty("/pending", oData);
		// 		},
		// 		filters: this._mFilters.pending
		// 	});

		// 	// read the count for the unitsInStock filter
		// 	oModel.read("/InvHeaderSet/$count", {
		// 		success: function(oData) {
		// 			oViewModel.setProperty("/inProcess", oData);
		// 		},
		// 		filters: this._mFilters.inProcess
		// 	});

		// 	// read the count for the outOfStock filter
		// 	oModel.read("/InvHeaderSet/$count", {
		// 		success: function(oData) {
		// 			oViewModel.setProperty("/approved", oData);
		// 		},
		// 		filters: this._mFilters.approved
		// 	});

		// 	// read the count for the shortage filter
		// 	oModel.read("/InvHeaderSet/$count", {
		// 		success: function(oData) {
		// 			oViewModel.setProperty("/rejected", oData);
		// 		},
		// 		filters: this._mFilters.rejected
		// 	});
		// 	// read the count for the shortage filter
		// 	oModel.read("/InvHeaderSet/$count", {
		// 		success: function(oData) {
		// 			oViewModel.setProperty("/holdBudget", oData);
		// 		},
		// 		filters: this._mFilters.holdBudget
		// 	});

		// },

		getTable: function() {
			var oTable = this.getView().byId("InvSmartTable");
			return oTable.getTable();
		},
		onBeforeRebindTable: function(oEvent) {
			var oViewModel = this.getView().getModel("worklistView");
			var sFBar = this.getView().byId("LSMINVFilterId");
			// added By Naresh for Custom Filter
			var mBindingParams = oEvent.getParameter("bindingParams");
			var sFilters = sFBar.getFilters();
			var oPaystatus = sFBar.getControlByKey("ZzpayStatus");
			var oInvoice = sFBar.getControlByKey("ZzinvStatus");
			var oInvKey = oInvoice.getSelectedKey();
			var oKey = oPaystatus.getSelectedKey();
			if (oKey !== "") {
				sFilters.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, oKey));
				mBindingParams.filters = sFilters;
				oViewModel.setProperty("/PayDoc", true);
				oViewModel.setProperty("/PayStatus", true);
				oViewModel.setProperty("/InvStatus", false);
			} else {
				oViewModel.setProperty("/PayDoc", false);
				oViewModel.setProperty("/PayStatus", false);
				oViewModel.setProperty("/InvStatus", true);
			}
			if (oInvKey === "02") {
				oViewModel.setProperty("/PayDoc", true);
				oViewModel.setProperty("/InvStatus", true);
				oViewModel.setProperty("/PayStatus", false);
			}

		},
		onSelectIconTabBarMyWB: function(oEvent) {
			var sFBar = this.getView().byId("LSMINVFilterId"),
				sFilters = sFBar.getFilters();
			var that = this;
			// var segmbtnKey = oEvent.mParameters.key;
			var segmbtnKey = oEvent.getParameters("item").item.getKey();

			var aFilter = [],
				path = "ZzinvStatus";
			var oTab = this.getTable(),
				cntx = oTab.getBinding("items");
			//SegmentKey = oEvent.getParameters().key;
			//    cntx.aApplicationFilters = null;
			if (sFilters) {
				sFilters.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));
				cntx.filter(sFilters, "Application");
			} else {
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));
				cntx.filter(aFilter, "Application");
			}

		},

		handleDocPress: function(oEvent) {

			var oModel = this.getView().getModel(),
				servUri = oModel.sServiceUrl,
				sObj = oEvent.getSource().getBindingContext().getObject(),
				invoiceNo = sObj.ZzinvoiceNumber;
			var sRead = "/PrintInvoiceCollection(Vbeln='" + invoiceNo + "')" + "/$value";
			var mainUri = servUri + sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");

		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		// Excel Upload function
		handleUploadChange: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._importinvoice(file, action);

			}
		},
		// Text file Upload Invoices
		onChangeTextUpload: function(evt) {
			var oFile = evt.getParameter("files");
			var sFileName = oFile[0].name;
			var oModel = this.getView().getModel();
			var oToken = oModel.getSecurityToken();
			var oUpload = evt.getSource();
			if (oUpload.getHeaderParameters().length === 0) {
				oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "x-csrf-token",
					value: oToken
				}));
				oUpload.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "slug",
					value: sFileName
				}));
			}
			oUpload.upload();
			oUpload.clear();
		},
		onTextUploadComplete: function(evt) {
			var oUpload = evt.getSource();
			var oStatus = evt.getParameter("status");
			if (oStatus === 201) {
				sap.m.MessageBox.show(
					"Successfully Upload Attachment", {
						icon: sap.m.MessageBox.Icon.confirm,
						title: "Success",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {}
					}
				);
			} else {
				sap.m.MessageBox.error("Error while Uploading attachment", {
					title: "Error", // default
					onClose: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
			}
			oUpload.clear();
		},
		// Excel Sheet read function method
		_importinvoice: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}

					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["Message type"] === undefined) {
							sheetData[i]["Message type"] = "";
						}
						if (sheetData[i]["Purchasing Doc"] === undefined) {
							sheetData[i]["Purchasing Doc"] = "";
						}
						if (sheetData[i]["Billing Date"] === undefined) {
							sheetData[i]["Billing Date"] = "";
						}
						if (sheetData[i]["Invoice Number"] === undefined) {
							sheetData[i]["Invoice Number"] = "";
						}
						if (sheetData[i]["Matter"] === undefined) {
							sheetData[i]["Matter"] = "";
						}
						if (sheetData[i]["Amount"] === undefined) {
							sheetData[i]["Amount"] = "";
						}
						if (sheetData[i]["Invoice Description"] === undefined) {
							sheetData[i]["Invoice Description"] = "";
						}
						if (sheetData[i]["Quantity"] === undefined) {
							sheetData[i]["Quantity"] = "";
						}
						if (sheetData[i]["Matter Name"] === undefined) {
							sheetData[i]["Matter Name"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["Client Number"] === undefined) {
							sheetData[i]["Client Number"] = "";
						}
						if (sheetData[i]["Client Name"] === undefined) {
							sheetData[i]["Client Name"] = "";
						}

					}
					that.creatObj(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		creatObj: function(newData, action) {
			var objArray = [],
				oTable = this.getView().byId("InvSmartTable"),
				otbl = oTable.getTable();
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VENDOR_SRV");
			var batchChanges = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var Messagetype = data["Message type"].trim();
				var PurchasingDoc = data["Purchasing Doc"].trim();
				var WorkDate = new Date(data["Work Date"].trim());
				var BillingDate = new Date(data["Billing Date"].trim());
				var InvoiceNumber = data["Invoice Number"].trim();
				var Matter = data["Matter"].trim();
				var Amount = data["Amount"].trim();
				var InvoiceDescription = data["Invoice Description"].trim();
				var Quantity = data["Quantity"].trim();
				var MatterName = data["Matter Name"].trim();
				var Currency = data["Currency"].trim();
				var clientname = data["Client Name"].trim();
				var client = data["Client Number"].trim();
				var oVendor = data["VendorNo"].trim();
				var obj = {
					// "Type": Messagetype,
					"Zzebeln": PurchasingDoc,
					"ZzinvoiceDate": BillingDate,
					"ZzinvoiceNumber": InvoiceNumber,
					"ZzlawFirmMatterId": Matter,
					"ZzinvoiceTotal": Amount,
					"ZzinvoiceDescription": InvoiceDescription,
					"ZzlineItemNumberOfUnits": Quantity,
					"ZzmatterName": MatterName,
					"Zzwaerk": Currency,
					"ZzlawFirmNo": oVendor,
					"Zzclientname": clientname,
					"Zzclient": client,
					"ZzworkDate": WorkDate
				};

				if (Messagetype === "" && PurchasingDoc === "" && BillingDate === "" && InvoiceNumber === "" && Matter === "" && Amount === "" &&
					InvoiceDescription === "" && Quantity === "" && MatterName === "" && Currency === "") {
					continue;
				} else {
					// objArray.push(obj);
					otbl.setBusy(true);
					batchChanges.push(oModel.createBatchOperation("/AddInvoiceSet", "POST", obj));
				}
			}
			oModel.addBatchChangeOperations(batchChanges);
			//submit changes and refresh the table and display message&nbsp;\&nbsp;
			oModel.setUseBatch(true);
			oModel.submitBatch(function(oSuccess) {
				var smg = "Successfully Upload Invoice";
				sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
				oTable.rebindTable();
				otbl.setBusy(false);
			}, function(oError) {
				var sEmsg = "Error While Uploading";
				sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
				otbl.setBusy(false);
			});
		},
		onAfterRendering: function() {

			//	this.getView().byId("InvSmartTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);

		},
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("MatterType", FilterOperator.Contains, sQuery)];
				}
				//this._applySearch(oTableSearchState);
			}

		}

	});
});