sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},
		status: function(val) {
			if (val === "OPEN") {
				return "Success";
			} else if (val === "CLOSE") {
				return "Error";
			}
			return "None";
		},
		convertingToFloat: function(val) {
			return parseFloat(val);
		},
		RatingIndicator: function(val) {
			// debugger;
			// 	if (!val) {
			// 	return "";
			// }
			// return parseFloat(val);
			return parseInt(val, 10);
		},
		stateSwitch: function(val) {
			if (val === "Yes") {
				return true;
			}
			return  false;
		},
		currencyformate: function(val, cl) {

		}
	};

});