/*global location */
sap.ui.define([
	"mymatterlsm/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"mymatterlsm/model/formatter"
], function(BaseController, JSONModel, formatter) {
	"use strict";

	return BaseController.extend("mymatterlsm.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getView().setBusy(true);
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				CreateMatter: true,
				EditMatter: true,
				Save: false,
				Cancle: false,
				MatterDesc: "",
				CmiRec: "",
				editMatter: false,
				Pspid: "",
				MFala: true,
				AttorneyVisbl: true,
				AttorneySelectVisbl: false,
				SuccessCritria: true,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});
			var TabSwitchMod = new JSONModel({
				General: true,
				LegalTeam: false,
				LawSuit: false,
				StoreNo: "",
				CaseType: "",
				MatterType: "",
				PracticeArea: "",
				CaseTypeSec: "",
				Facility: "",
				PrimaryIssues: "",
				State: "",
				SecondaryIssue: "",
				County: "",
				Outcome: ""
			});
			this.setModel(TabSwitchMod, "TabSwitchMod");

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			// F4 help model
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			this.getView().setModel(fo4Model, "fo4Model");
			// model for Legal Team Attrony column
			this.oAttorModel();
			// Empty json model binging for Create function
			this.createObject();

		},

		onAfterRendering: function() {
			if (!this.oModel) {
				this.oModel = this.getView().getModel();
			}
			this.oModel.setDefaultBindingMode("TwoWay");
		},

		oAttorModel: function() {
			var that = this;
			var aAttroneyJson = new sap.ui.model.json.JSONModel();
			var AttorneyModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			AttorneyModel.read("/ZprsShParvwLsmSet", {
				success: function(data, response) {
					aAttroneyJson.setData({
						Modeldata: data.results
					});
					that.getView().setModel(aAttroneyJson, "aAttroneyJson");
				},
				error: function(oError) {}
			});
		},
		createObject: function() {
			this.oeditFragModel = new sap.ui.model.json.JSONModel("./model/editfragData.json");
			this.generalFragModel = new sap.ui.model.json.JSONModel("./model/generalCreate.json");
			this.finalresFragModel = new sap.ui.model.json.JSONModel("./model/finalResCreate.json");
			this.lawSuitFragModel = new sap.ui.model.json.JSONModel("./model/lawSuitCreate.json");
			this.legalTeamFragModel = new sap.ui.model.json.JSONModel("./model/legalTeamCreate.json");
			this.DemandOfferFragModel = new sap.ui.model.json.JSONModel("./model/DemandOfferCreate.json");
			this.AttachfragModel = new sap.ui.model.json.JSONModel("./model/AttachDataCreate.json");
		},
		// onedit matter button press
		onEditMatter: function(evt) {
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			var oSelect = this.getView().byId("legalSelectId");
			var oviewModel = this.getView().getModel("detailView");
			oviewModel.setProperty("/Save", true);
			oviewModel.setProperty("/Cancle", true);
			oviewModel.setProperty("/EditMatter", false);
			oviewModel.setProperty("/CreateMatter", false);
			oviewModel.setProperty("/editMatter", true);
			oviewModel.setProperty("/MFalg", false);
			oviewModel.setProperty("/AttorneySelectVisbl", true);
			oviewModel.setProperty("/AttorneyVisbl", false);
			// var oModelLegal = this.getView().getModel("onlegalModel"),
			// 	objLegal = oModelLegal.oData,
			// 	oresults = objLegal.modelData;
			// 	oSelect.setSelectedKey(oresults.Parvw);

		},
		// on Cancle matter button press
		onCancleEdit: function(evt) {
			var oView = this.getView();
			if (!this.oModel) {
				this.oModel = this.getView().getModel();
			}
			var oviewModel = this.getView().getModel("detailView");
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oviewModel.setProperty("/Save", false);
			oviewModel.setProperty("/Cancle", false);
			oviewModel.setProperty("/EditMatter", true);
			oviewModel.setProperty("/CreateMatter", true);
			oviewModel.setProperty("/editMatter", false);
			var oMianModel = oView.getModel("oMDLocal");
			oviewModel.setProperty("/AttorneySelectVisbl", false);
			oviewModel.setProperty("/AttorneyVisbl", true);
			//Setting Display Data
			this.getView().byId("GeneralID").setModel(this.onTabModel, "onTabModel");
			this.getView().byId("editlegalTeam").setModel(this.onlegalModel, "onlegalModel");
			this.getView().byId("LawSuiteID").setModel(this.onlawModel, "onlawModel");
			this.getView().byId("DOID").setModel(this.onDemandModel, "onDemandModel");
			this.getView().byId("FRID").setModel(this.onFRModel, "onFRModel");
			this.getView().byId("AttachmentID").setModel(this.attchModel, "attchModel");
			this.getView().byId("HeaderID").setModel(this.TabSwitchMod);
			this.getView().byId("HeaderID").setModel(oMianModel, "oMDLocal");
		},

		onCreateMatter: function(evt) {
			var oView = this.getView();
			var oviewModel = this.getView().getModel("detailView");
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oviewModel.setProperty("/Save", true);
			oviewModel.setProperty("/Cancle", true);
			oviewModel.setProperty("/EditMatter", false);
			oviewModel.setProperty("/CreateMatter", false);
			oviewModel.setProperty("/editMatter", true);
			oviewModel.setProperty("/MFalg", true);
			oviewModel.setProperty("/AttorneySelectVisbl", true);
			oviewModel.setProperty("/AttorneyVisbl", false);
			this.setNullData();
			this.editFragBinding();
			this.getView().byId("HeaderID").setModel(this.oeditFragModel, "oMDLocal");

		},
		editFragBinding: function() {

			this.getView().byId("HeaderID").setModel(this.oeditFragModel);
			this.getView().byId("GeneralID").setModel(this.generalFragModel, "onTabModel");
			this.getView().byId("editlegalTeam").setModel(this.legalTeamFragModel, "onlegalModel");
			this.getView().byId("LawSuiteID").setModel(this.lawSuitFragModel, "onlawModel");
			this.getView().byId("DOID").setModel(this.DemandOfferFragModel, "onDemandModel");
			this.getView().byId("FRID").setModel(this.finalresFragModel, "onFRModel");
			this.getView().byId("AttachmentID").setModel(this.AttachfragModel, "attchModel");

		},
		setNullData: function() {
			var oView = this.getView();
			var oviewModel = this.getView().getModel("detailView");
			var oSetModel = this.getView().getModel("TabSwitchMod");
			oviewModel.setProperty("/Status", "");
			oviewModel.setProperty("/StatusDesc", "");
			oSetModel.setProperty("/CaseType", "");
			oSetModel.setProperty("/MatterType", "");
			oSetModel.setProperty("/PracticeArea", "");
			oSetModel.setProperty("/CaseTypeSec", "");
			oSetModel.setProperty("/PrimaryIssues", "");
			oSetModel.setProperty("/State", "");
			oSetModel.setProperty("/Facility", "");
			oSetModel.setProperty("/SecondaryIssue", "");
			oSetModel.setProperty("/County", "");
			oSetModel.setProperty("/Outcome", "");
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");

			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		_onObjectMatched: function(oEvent) {
			// jQuery.sap.delayedCall(100, this, function() {
			// 	this.getView().setBusy(true);
			// });
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.sMatterno = sObjectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("HeaderSet", {
					Pspid: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
			jQuery.sap.delayedCall(100, this, function() {
				this.getView().setBusy(false);
			});
		},
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView"),
				oDataModel = this.getModel();
			var oModel = this.getOwnerComponent().getModel();
			var oMDLocal = new sap.ui.model.json.JSONModel();

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);
			var that = this;
			oModel.read(sObjectPath, {
				success: function(data, response) {
					oMDLocal.setData(data);
					that.getView().setModel(oMDLocal, "oMDLocal");
					if (data.Status === "OPEN") {
						that.getModel("detailView").setProperty("/SuccessCritria", false);
					} else {
						that.getModel("detailView").setProperty("/SuccessCritria", true);
					}
				},
				error: function(oError) {}
			});

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
			this.oTabModel(sObjectPath);
			this.svalue = sObjectPath;
		},
		oTabModel: function(sObjectPath) {
			this.obj = sObjectPath;
			var oModel = this.getOwnerComponent().getModel();
			var onTabModel = new sap.ui.model.json.JSONModel();
			var oPath = this.obj + "/HeaderToGeneralSet";
			var that = this;
			oModel.read(oPath, {
				success: function(data, response) {
					onTabModel.setData(data);
					that.getView().setModel(onTabModel, "onTabModel");
				},
				error: function(oError) {}
			});
			var onlegalModel = new sap.ui.model.json.JSONModel();
			var oPathl = this.obj + "/HeaderToLegalTeamSet";
			// var that = this;
			oModel.read(oPathl, {
				success: function(data, response) {
					onlegalModel.setData({
						modelData: data.results
					});
					that.getView().setModel(onlegalModel, "onlegalModel");
				},
				error: function(oError) {}
			});
			var onlawModel = new sap.ui.model.json.JSONModel();
			var oPathLaw = this.obj + "/HeaderToLawSuitSet";
			// var that = this;
			oModel.read(oPathLaw, {
				success: function(data, response) {
					onlawModel.setData(data);
					that.getView().setModel(onlawModel, "onlawModel");
				},
				error: function(oError) {}
			});

			var onDemandModel = new sap.ui.model.json.JSONModel();
			var oPathDemand = this.obj + "/HeaderToDemandSet";
			oModel.read(oPathDemand, {
				success: function(data, response) {
					onDemandModel.setData(data);
					that.getView().setModel(onDemandModel, "onDemandModel");
				},
				error: function(oError) {}
			});

			var onFRModel = new sap.ui.model.json.JSONModel();
			var oPathFR = this.obj + "/HeaderToFinalResolSet";
			// var that = this;
			oModel.read(oPathFR, {
				success: function(data, response) {
					onFRModel.setData(data);
					that.getView().setModel(onFRModel, "onFRModel");
				},
				error: function(oError) {}
			});
			var accModel = new sap.ui.model.json.JSONModel();
			var oPathAcc = this.obj + "/HeaderToAccrual";
			// var that = this;
			oModel.read(oPathAcc, {
				success: function(data, response) {
					accModel.setData({
						modelData: data
					});
					that.getView().setModel(accModel, "accModel");
				},
				error: function(oError) {}
			});

			var IncModel = new sap.ui.model.json.JSONModel();
			var oPathIn = this.obj + "/HeaderToInvoiceSet";
			// var that = this;
			oModel.read(oPathIn, {
				success: function(data, response) {
					IncModel.setData({
						modelData: data.results
					});
					that.getView().setModel(IncModel, "IncModel");
				},
				error: function(oError) {}
			});

			var oSuccesCAModel = new sap.ui.model.json.JSONModel();
			var sobjPath = "/MatterDetailSet" + "(" + "'" + Number(this.sMatterno) + "'" + ")";
			var oPath = sobjPath + "/DetailToSuccessCriteria";
			oModel.read(oPath, {
				success: function(data, response) {
					oSuccesCAModel.setData(data);
					that.getView().setModel(oSuccesCAModel, "SCAModel");
				},
				error: function(oError) {}
			});
		},
		// F4 help for all input fileds .
		_onSelectSearchHelpSrvF4: function(oEvent) {
			var oFilter, aFilter, oSource, sInputValue, sValueHelpSrv, fo4Model, customFields, that;
			customFields = oEvent.getSource().data();
			sInputValue = oEvent.getSource().getValue();
			sValueHelpSrv = "/sap/opu/odata/sap/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/";
			fo4Model = new sap.ui.model.odata.ODataModel(sValueHelpSrv, {
				json: true,
				loadMetadataAsync: true
			});
			fo4Model.setDefaultBindingMode("TwoWay");
			this._oDialog = sap.ui.xmlfragment("mymatterlsm.fragments.dailogSearch." + customFields.fName, this);
			this.getView().addDependent(this._oDialog);
			this.setModel(fo4Model, "fo4Model");
			// create a filter for the binding
			aFilter = [];
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(customFields.ffName, sap.ui.model.FilterOperator.Contains, sInputValue);
				aFilter.push(oFilter);
				this._oDialog.getBinding("items").filter(aFilter);
			}
			this._oDialog.open(sInputValue);
			that = this;
			oSource = oEvent.getSource();
			this._oDialog.attachConfirm(that, function(evt) {
				var svalue = evt.getParameter("selectedItem");
				oSource.setValue(svalue.getTitle());
				that._oDialog.destroy();
			}, null);
		},
		_handleF4Close: function(evt) {
			var oSelectedItem, oCustomFields;
			oCustomFields = evt.getSource().data();
			oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				sap.ui.getCore().byId(oCustomFields.fName).setValue(oSelectedItem.getTitle());

			}
			this._oDialog.destroy();
		},
		_handleF4Search: function(oEvent) {
			var aFilter, sValue, oCustomFields, oFilter;
			oCustomFields = oEvent.getSource().data();
			aFilter = [];
			sValue = oEvent.getParameter("value");
			if (sValue !== "") {
				oFilter = new sap.ui.model.Filter(oCustomFields.ffName, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			oEvent.getSource().getBinding("items").filter(aFilter);

		},
		// onSave function for both changes and create button
		onSaveMatter: function(evt) {
			var oView = this.getView();
			// var BtnTxt = evt.getSource().getText();
			//var oCmiRec = oView.getBindingContext().getProperty("CmiRec");
			//General Model Data 
			var tbl = oView.byId("editlegalTeam");
			var oMianModel = oView.getModel("oMDLocal");
			this.objHeader = oMianModel.oData;
			var oModelGeneral = oView.getModel("onTabModel");
			this.objGeneral = oModelGeneral.oData;
			delete(this.objGeneral.__metadata);
			// LeaglTeam Model Data
			var oModelLegal = oView.getModel("onlegalModel"),
				objLegal = oModelLegal.oData,
				oresults = objLegal.modelData,
				// lawSuit Model Data
				oModelLawSuit = oView.getModel("onlawModel"),
				objLawsuit = oModelLawSuit.oData;
			delete(objLawsuit.__metadata);
			//Demand Offer Model Data
			var oModelDemand = oView.getModel("onDemandModel"),
				objDemand = oModelDemand.oData;
			delete(objDemand.__metadata);
			//Final Resolution Model Data
			var oModelFinRes = oView.getModel("onFRModel"),
				objFinRes = oModelFinRes.oData;
			delete(objFinRes.__metadata);
			//SuccessCriteria model Data
			var oModelSuccescrt = oView.getModel("SCAModel"),
				objSucessCrt = oModelSuccescrt.oData;
			delete(objSucessCrt.__metadata);
			var oViewModel = this.getView().getModel("detailView"),
				ActionTxt = oViewModel.getProperty("/MFalg");
			var oAction;
			if (ActionTxt) {
				oAction = "create";
			} else {
				oAction = "change";
			}
			if (this.SuccessfulOutcome === "") {
				this.SuccessfulOutcome = "No";
			}
			if (this.BudgetMaintain === "") {
				this.BudgetMaintain = "No";
			}
			if (this.TimelineMet === "") {
				this.TimelineMet = "No";
			}
			if (this.EffectMattStruct === "") {
				this.EffectMattStruct = "No";
			}
			if (this.UseVndrAgain === "") {
				this.UseVndrAgain = "No";
			}
			if (this.VendorService === "") {
				this.VendorService = "";
			}
			if (this.ResourceQuality === "") {
				this.ResourceQuality = "";
			}
			var oSuccessCriteria = {
				Pspid: this.objGeneral.Pspid,
				Overallcomments: objSucessCrt.Overallcomments,
				Resourcecomments: objSucessCrt.Resourcecomments,
				VendorService: this.VendorService,
				ResourceQuality: this.ResourceQuality,
				SuccessfulOutcome: this.SuccessfulOutcome,
				BudgetMaintain: this.BudgetMaintain,
				TimelineMet: this.TimelineMet,
				EffectMattStruct: this.EffectMattStruct,
				UseVndrAgain: this.UseVndrAgain
			};
			var oObjectParm = {
				Action: oAction,
				AdrLine1: this.objHeader.AdrLine1,
				AdrLine2: this.objHeader.AdrLine2,
				AuthorizationAmount: objDemand.AuthorizationAmount,
				CaseType: this.objGeneral.CaseType,
				CaseTypeSec: this.objGeneral.CaseTypeSec,
				City: this.objHeader.City,
				CloseDate: this.objGeneral.CloseDate,
				CmiRec: this.objHeader.CmiRec,
				ConferenceDate: objLawsuit.ConferenceDate,
				County: objLawsuit.County,
				Court: objLawsuit.Court,
				CurrentOffer: objDemand.CurrentOffer,
				DemandAmount: objDemand.DemandAmount,
				DetailToLegalTeamSet: oresults,
				DetailToNarrativesSet: [],
				Facility: objLawsuit.Facility,
				FinResAmt: objFinRes.FinResAmt,
				Iserror: "",
				MatterCuky: this.objGeneral.MatterCuky,
				MatterSubtype: this.objGeneral.MatterSubtype,
				MatterType: this.objGeneral.MatterType,
				MediationDate: objLawsuit.MediationDate,
				Message: "",
				OcFirm: "",
				OpenDate: this.objGeneral.OpenDate,
				Outcome: objFinRes.Outcome,
				OutcomeSub: objFinRes.OutcomeSub,
				Payer: objFinRes.Payer,
				PaymentAmount: objFinRes.PaymentAmount,
				PaymentDate: objFinRes.PaymentDate,
				Post1: this.objHeader.Post1,
				PracticeArea: this.objGeneral.PracticeArea,
				PrimaryIssues: objLawsuit.PrimaryIssues,
				Pspid: this.objGeneral.Pspid,
				Pstlz: this.objHeader.Pstlz,
				// Region: this.objHeader.Region,
				ResolutionDate: objFinRes.ResolutionDate,
				SecondaryIssues: objLawsuit.SecondaryIssues,
				SettlementDate: objLawsuit.SettlementDate,
				State: objLawsuit.State,
				Status: this.objHeader.Status,
				// StatusDesc: this.objHeader.StatusDesc,
				StoreName: this.objHeader.StoreName,
				StoreNo: this.objHeader.StoreNo,
				TrialDate: objLawsuit.TrialDate,
				TotResAmt: objFinRes.TotResAmt,
				DetailToSuccessCriteria: oSuccessCriteria
			};

			var oChangeModel = this.getOwnerComponent().getModel();
			var that = this;
			oChangeModel.create("/MatterDetailSet", oObjectParm, {
				success: function(oData, response) {
					var smg = oData.Message;
					sap.m.MessageToast.show(smg);
					that.onCancleEdit();
				},
				error: function(oData) {
					sap.m.MessageToast.show("error");
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				// oViewModel = this.getModel("detailView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Pspid,
				sObjectName = oObject.Pspid,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		// F4 Help for AttorneyId
		handleValueHelpAttorneyId: function(evt) {
			var aFilter = [],
				tbl, AttorneyIDFragment,
				matterNo = this.sMatterno,
				that = this;
			this.selectedKey = evt.getSource().getParent().getCells()[0].getSelectedItem().getKey();
			//tbl = this.getView().byId("editlegalTeam");
			this.inputAttornyId = evt.getSource();

			var attorneyKey = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, this.selectedKey);
			aFilter.push(attorneyKey);
			var MatterNo = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, matterNo);
			aFilter.push(MatterNo);

			AttorneyIDFragment = "mymatterlsm.fragments.dailogSearch.AttorneyId";
			var attorneyModel = new sap.ui.model.json.JSONModel();
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			fo4Model.read("/PartnerDetailSet", {
				filters: aFilter,
				success: function(oData) {
					attorneyModel.setData(oData);

					that._valueHelpMatterDialog = sap.ui.xmlfragment(AttorneyIDFragment, that);
					that.getView().addDependent(that._valueHelpMatterDialog);

					that._valueHelpMatterDialog.setModel(attorneyModel, "attorneyModel");
					that._valueHelpMatterDialog.open();
				},
				error: function(oError) {}
			});

		},
		handleValueHelpSearchAttorneyId: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleConfirmAttorneyId: function(evt) {
			// var tbl = this.getView().byId("editlegalTeam");
			// var index = parseInt(this.inputAttornyId.getId().split("__input13-application-Test-url-component---object--editlegalTeam-")[1]);
			// this.selectedField = tbl.getItems()[index].getAggregation("cells")[1];

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				//this.selectedField.setValue(oSelectedItem.getTitle());
				this.inputAttornyId.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpMatterDialog._oDialog.destroy();
		},
		onCancelDialogAttorneyId: function() {
			this._valueHelpMatterDialog._oDialog.close();
		},
		//F4 help for Payer
		_onValueHelpRequestPayer: function(evt) {
			var aFilter = [],
				sfragmentName,
				matterNo = this.sMatterno,
				oPayer = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, "PY"),
				MatterNo = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, matterNo);
			sfragmentName = "mymatterlsm.fragments.dailogSearch.Payer";
			aFilter.push(oPayer);
			aFilter.push(MatterNo);
			var oPayerModel = new sap.ui.model.json.JSONModel();
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			var that = this;
			fo4Model.read("/PartnerDetailSet", {
				filters: aFilter,
				success: function(oData) {
					oPayerModel.setData(oData);
					if (!that._valueHelpPayerDialog) {
						that._valueHelpPayerDialog = sap.ui.xmlfragment(sfragmentName, that);
						that.getView().addDependent(that._valueHelpPayerDialog);
					}
					that._valueHelpPayerDialog.setModel(oPayerModel, "oPayerModel");
					that._valueHelpPayerDialog.open();
				},
				error: function(oError) {}
			});

		},
		_handlePayerClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var payerInput = this.getView().byId("PayerId");
				var valuetxt = oSelectedItem.getTitle();
				payerInput.setValue(valuetxt);
			}
			// this._valueHelpPayerDialog.close();
		},

		onAddRowPress: function(oEvent) {
			var oTable = this.getView().byId("editlegalTeam");
			var tableModel = oTable.getModel("onlegalModel");
			var tableModelData = this.getView().byId("editlegalTeam").getModel("onlegalModel").getData().modelData;
			var newRowData = {};
			var emptyArray = [];
			newRowData.ParnrOld = "";
			newRowData.Name1 = "";
			newRowData.Addrln = "";
			newRowData.RATE = "";
			newRowData.HOURS = "";
			newRowData.BILLLIFE2DATE = "";
			if (tableModelData === undefined) {
				emptyArray.push(newRowData);
				tableModelData = emptyArray;

			} else {
				tableModelData.push(newRowData);

			}
			tableModel.setProperty("/modelData", tableModelData);
		},

		handleDelete: function(oEvent) {
			var oTable = oEvent.getSource();
			var oModel = oTable.getModel("onlegalModel");
			var oList = oEvent.getParameters("listItem").listItem;
			var index = oEvent.getParameters("listItem").listItem.getBindingContextPath();

			var oConfirmMsg = "Are you sure you want to delete?";
			sap.m.MessageBox.confirm(oConfirmMsg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirmation",
				onClose: function(oEvent1) {
					if (oEvent1 === "OK") {
						// Condition for existing row or New row.....if it is new row index will be undefine 
						if (index) {
							index = index.charAt(index.lastIndexOf('/') + 1);

							if (index !== -1) {
								var data = oModel.getData().modelData;
								data.splice(index, 1);

								oModel.setData({
									modelData: data
								});

							}
						} else if (index === undefined) {

							oTable.removeItem(oList);
						}
					}
				}
			});

			// after deletion put the focus back to the list
			oList.attachEventOnce("updateFinished", oList.focus, oList);
			// send a delete request to the odata service
			//this.oModel.remove(sPath);
		},

		NavToMYMatters: function(evt) {
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.toExternal({
				target: {
					semanticObject: "ZPRS_LSM_MATTER",
					action: "display"
				}
			});
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList"),
				iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			oLineItemTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for line item table
				oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			});

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onChange: function(oEvent) {
			var oModel = this.getView().getModel("attchModel");
			var oData = oModel.getProperty("/modelData");
			var files = oEvent.getParameter("files")[0];
			var obj = {
				"AttachmentNo": files.lastModified,
				"FileName": files.name,
				"MimeType": files.type,
				"url": "https://",
				"visibleDelete": false
			};
			oData.push(obj);
			oModel.refresh();
		},
		onChangeSwitchstate: function(evt) {
			var idsitch = evt.getParameter("id"),
				oparm = evt.getParameters("state").state;
			if (idsitch === "__switch0" || oparm === "true") {
				this.SuccessfulOutcome = "Yes";
			} else {
				this.SuccessfulOutcome = "";
			}
			if (idsitch === "__switch1" || oparm === "true") {
				this.BudgetMaintain = "Yes";
			} else {
				this.BudgetMaintain = "";
			}
			if (idsitch === "__switch2" || oparm === "true") {
				this.TimelineMet = "Yes";
			} else {
				this.TimelineMet = "";
			}
			if (idsitch === "__switch3" || oparm === "true") {
				this.EffectMattStruct = "Yes";
			} else {
				this.EffectMattStruct = "";
			}
			if (idsitch === "__switch4" || oparm === "true") {
				this.UseVndrAgain = "Yes";
			} else {
				this.UseVndrAgain = "";
			}

		},
		onRatingChange: function(evt) {
			var oId = evt.getParameters().id;
			if (oId === "__indicator0") {
				var oval = evt.getParameters().value;
				this.VendorService = oval.toLocaleString();
			}
			if (oId === "__indicator1") {
				var ResourceQuality1 = evt.getParameters().value;
				this.ResourceQuality = ResourceQuality1.toLocaleString();
			}
		}

	});

});