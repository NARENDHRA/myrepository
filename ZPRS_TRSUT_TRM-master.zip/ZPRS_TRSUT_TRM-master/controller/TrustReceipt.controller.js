sap.ui.define([
	"trustreceiptmul/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustreceiptmul/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/BusyDialog",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/UploadCollectionParameter",
	"sap/m/PDFViewer"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox, BusyDialog, Dialog, Button,
	UploadCollectionParameter, PDFViewer) {
	"use strict";

	return BaseController.extend("trustreceiptmul.controller.TrustReceipt", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                                */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */

		onInit: function() {
			this._formFragments = {};
			//component create
			this.busyDialog = new BusyDialog();
			this.busyDialog.open();
			if (!this.oOutputComp) {
				this.oOutputComp = sap.ui.getCore().createComponent({
					name: "fgt.trustdispdoc.control.comp.outputitems"
				});
			}

			this._showFormFragment("MTrustReceipt");
			var oViewModel;
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				tableBusyDelay: 0,
				ifremitter: true,
				ifcheque: false,
				ReceivedDate: new Date(),
				ClearanceDate: null,
				ClearanceDateVal: null,
				TransactionDate: new Date(),
				trustPayment: [],
				totalAmount: 0,
				currency: "",
				bankAccDesc: "",
				bankAccNum: [],
				bAccNum: "",
				ChequeNumber: "",
				ChequeDate: null,
				BankName: "",
				BankBranchCode: "",
				DrawnBy: "",
				ReceivedFrom: "",
				RemitterNonCli: "",
				RemitterCli: "",
				RemitTextCli: "",
				AddEnable: false,
				RemitterCliEnable: true,
				RemitterNonCliEnable: true,
				documentTitle: ""
			});
			this.setModel(oViewModel, "worklistView");
			this.url = "";
			this.FileUploadSet = [];
			this.createMode();
		},
		hanldeChangeTrustReceiptMatter: function(evt) {
			var source = evt.getSource();
			var oTable = this.getView().byId("trustRecId");
			var value = source.getValue();
			if (source.getProperty("value") !== evt.getParameter("value")) {
				this._handleResetValues();
			}
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");

			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);

			var items = oTable.getItems();
			for (var i = 0; i < items.length; i++) {
				var sMPath = items[i].getBindingContext().sPath;
				var oModel = items[i].getBindingContext().getModel();
				oModel.setProperty(sMPath + "/" + path, value);
			}
		},

		onUpdateOfficeValue: function(evt) {
			var oChangeValues = evt.getParameter("changes");
			var sPath = this.getView().getBindingContext().sPath;
			var oTable = this.getView().byId("trustRecId"),
				aItems = oTable.getItems();

			if (oChangeValues.hasOwnProperty("Office")) {
				this.getView().getBindingContext().getModel().setProperty(sPath + "/Office", oChangeValues.Office);
				if (oChangeValues.Office.length > 0 && aItems.length === 0) {
					this.onAddRowItemMatter();
				}
			}

		},

		_handleResetValues: function() {
			var oViewModel = this.getModel("worklistView");
			var oTable = this.getView().byId("trustRecId");
			var oRType = this.getView().byId("idReceiptType");
			oRType.getAggregation("_content").setSelectedKey();

			oViewModel.setProperty("/ClearanceDate", null);
			//oViewModel.setProperty("/TransactionDate", null);
			//	oViewModel.setProperty("/ReceivedDate", null);
			oViewModel.setProperty("/totalAmount", "");
			oViewModel.setProperty("/currency", "");
			oViewModel.setProperty("/bankAccDesc", "");
			oViewModel.setProperty("/bAccNum", "");
			this.FileUploadSet = [];
			oTable.removeAllItems();
			this._handleResetChequeCashValue();
			this.handleBankDetails();
		},

		createMode: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				that.busyDialog.close();
				var oContextClients = oModel.createEntry("/Headertrusts", {});
				var c = oContextClients.getModel();
				//	c.setProperty(oContextClients.getPath() + "/TransactionDate");
				c.setProperty(oContextClients.getPath() + "/Office", "");
				c.setProperty(oContextClients.getPath() + "/OfficeDesc", "");
				c.setProperty(oContextClients.getPath() + "/AccNum", "");
				c.setProperty(oContextClients.getPath() + "/ReceiptType", "");
				c.setProperty(oContextClients.getPath() + "/Remitter", "");
				c.setProperty(oContextClients.getPath() + "/RemitText", "");
				c.setProperty(oContextClients.getPath() + "/ItemtrustSet", []);
				that.getView().setBindingContext(oContextClients);
			});
		},

		handleDeleteMatter: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem");

			oTable.removeItem(oItmSel);
			var totAmt = this.getView().getModel("worklistView").getProperty("/totalAmount"),
				sAmt = oItmSel.getBindingContext().getObject().Amount;
			this.getView().getModel("worklistView").setProperty("/totalAmount", (totAmt - sAmt));
			//this.getView().getModel("worklistView").setProperty("/totalAmount", (totAmt - sAmt).toFixed(2));

			this.handleBankDetails();
		},

		_createTableItemContext: function() {
			var oModel = this.getOwnerComponent().getModel();
			var viewContext = this.getView().getBindingContext().getObject();
			//"OfficeDesc":viewContext.OfficeDesc,
			var oContext = oModel.createEntry("/Itemtrusts", {
				properties: {
					"Office": viewContext.Office,
					"OfficeDesc": viewContext.OfficeDesc,
					"Matter": "",
					"MatterDesc": "",
					"Amount": "",
					"ReasonForDeposit": "",
					"ClientNum": "",
					"ClientName": ""
				}
			});

			return oContext;
		},
		onAddRowItemMatter: function() {
			var oContext = this._createTableItemContext();
			var oTable = this.getView().byId("trustRecId");
			var items = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						width: "100%",
						value: "{ClientNum}",
						change: this.handleBankDetailsClient.bind(this)
					}),

					new sap.m.Text({
						text: "{ClientName}"
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Matter}",
						width: "auto",
						change: this.handleBankDetails.bind(this)
					}),
					new sap.m.Text({
						text: "{MatterDesc}"
					}),
					new sap.m.Input({
						value: "{Amount}",
						type: "Number",
						textAlign: "Right",
						liveChange: this.handleTotalAmount.bind(this)
					}),
					new sap.ui.comp.smartfield.SmartField({
						rows: 1,
						maxLength: 50,
						width: "100%",
						value: "{ReasonForDeposit}",
						change: this.handleTextArea.bind(this)
					})

				]
			});
			items.setBindingContext(oContext);
			oTable.addItem(items);
		},
		handleBankDetails: function(evt) {
			var oTable = this.getView().byId("trustRecId"),
				aItems = oTable.getItems(),
				oViewModel = this.getModel("worklistView"),
				bDuplicateVal = false;
			this.getView().byId("btnAddRecipt").setEnabled(true);
			if (evt) {
				var oSource = evt.getSource();
				if (oSource.getValue().length > 0) {
					oSource.setValueState("None");
				} else {
					oSource.setValueState("Error");
				}
				if (aItems.length > 1) {
					jQuery.each(aItems, function(i, oItem) {
						if (oItem.getBindingContext().getObject().Matter === evt.getParameter("value")) {
							bDuplicateVal = true;
						}
					});
				}

				if (bDuplicateVal) {
					//oSource.getAggregation("_content").setSelectionItem();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						"The selected Matter already exist in the list", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					var oContext = this._createTableItemContext();
					oSource.getParent().setBindingContext(oContext);
					return;
				}
				var aPath = oSource.getBindingContext().getPath();
				var Model = oSource.getBindingContext().getModel();
				Model.setProperty(aPath + "/Matter", evt.getParameter("value"));
			}

			var aFilters = [];
			var ctx;

			if (aItems.length === 0) {
				oViewModel.setProperty("/bankAccNum", []);
				oViewModel.setProperty("/bAccNum", "");
				oViewModel.setProperty("/currency", "");
				oViewModel.setProperty("/bankAccDesc", "");
				return;
			}
			for (var i = 0; i < aItems.length; i++) {
				if (!ctx) {
					ctx = aItems[i].getBindingContext().getObject().Matter;
				} else {
					ctx += "," + aItems[i].getBindingContext().getObject().Matter;
				}
			}
			if (ctx !== "") {
				var filterByName = new sap.ui.model.Filter("MatterStr", FilterOperator.EQ, ctx),
					sOffice = this.getView().getBindingContext().getProperty("Office"),
					filterOfc = new sap.ui.model.Filter("Office", FilterOperator.EQ, sOffice);

				aFilters.push(filterByName, filterOfc);
			} else {
				var sOffice1 = this.getView().getBindingContext().getProperty("Office"),
					filterOfc1 = new sap.ui.model.Filter("Office", FilterOperator.EQ, sOffice1);
				aFilters.push(filterOfc1);
			}
			var oModel = this.getOwnerComponent().getModel();

			//var BankArr = [];
			this.busyDialog.open();
			oModel.read("/MatterAccNums", {
				filters: aFilters,
				success: function(oData) {
					this.busyDialog.close();
					var aRes = oData.results;
					oViewModel.setProperty("/bankAccNum", oData.results);
					if (aRes.length === 1) {
						oViewModel.setProperty("/currency", oData.results[0].Currency);
						oViewModel.setProperty("/bAccNum", oData.results[0].AccNum);
						oViewModel.setProperty("/bankAccDesc", oData.results[0].HbankDesc);
					} else {
						oViewModel.setProperty("/bAccNum", "");
						oViewModel.setProperty("/currency", "");
						oViewModel.setProperty("/bankAccDesc", "");
					}

				}.bind(this),
				error: function() {
					this.busyDialog.close();
				}
			});
		},

		handleBankDetailsClient: function(evt) {
			var oTable = this.getView().byId("trustRecId"),
				aItems = oTable.getItems(),
				oViewModel = this.getModel("worklistView"),
				bDuplicateVal = false;
			if (evt) {
				var oSource = evt.getSource();
				if (oSource.getValue().length > 0) {
					oSource.setValueState("None");
				} else {
					oSource.setValueState("Error");
				}
				if (aItems.length > 1) {
					jQuery.each(aItems, function(i, oItem) {
						if (oItem.getBindingContext().getObject().ClientNum === evt.getParameter("value")) {
							bDuplicateVal = true;
						}
					});
				}

				if (bDuplicateVal) {
					//oSource.getAggregation("_content").setSelectionItem();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						"The selected Matter already exist in the list", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					var oContext = this._createTableItemContext();
					oSource.getParent().setBindingContext(oContext);
					return;
				}
				var aPath = oSource.getBindingContext().getPath();
				var Model = oSource.getBindingContext().getModel();
				Model.setProperty(aPath + "/ClientNum", evt.getParameter("value"));
				Model.setProperty(aPath + "/Matter", "");
				Model.setProperty(aPath + "/MatterDesc", "");
				this.getView().byId("btnAddRecipt").setEnabled(false);
			}

			var aFilters = [];
			var ctx;

			if (aItems.length === 0) {
				oViewModel.setProperty("/bankAccNum", []);
				oViewModel.setProperty("/bAccNum", "");
				oViewModel.setProperty("/currency", "");
				oViewModel.setProperty("/bankAccDesc", "");
				return;
			}
			/*	for (var i = 0; i < aItems.length; i++) {
					if (!ctx) {
						ctx = aItems[i].getBindingContext().getObject().ClientNum;
					} else {
						ctx += "," + aItems[i].getBindingContext().getObject().ClientNum;
					}
				}
				if (ctx !== "") {
					var filterByName = new sap.ui.model.Filter("MatterStr", FilterOperator.EQ, ctx),
						sOffice = this.getView().getBindingContext().getProperty("Office"),
						filterOfc = new sap.ui.model.Filter("Office", FilterOperator.EQ, sOffice);

					aFilters.push(filterByName, filterOfc);
				} else {*/
			var sOffice1 = this.getView().getBindingContext().getProperty("Office"),
				filterOfc1 = new sap.ui.model.Filter("Office", FilterOperator.EQ, sOffice1);
			aFilters.push(filterOfc1);
			//	}
			var oModel = this.getOwnerComponent().getModel();

			//var BankArr = [];
			this.busyDialog.open();
			oModel.read("/MatterAccNums", {
				filters: aFilters,
				success: function(oData) {
					this.busyDialog.close();
					var aRes = oData.results;
					oViewModel.setProperty("/bankAccNum", oData.results);
					if (aRes.length === 1) {
						oViewModel.setProperty("/currency", oData.results[0].Currency);
						oViewModel.setProperty("/bAccNum", oData.results[0].AccNum);
						oViewModel.setProperty("/bankAccDesc", oData.results[0].HbankDesc);
					} else {
						oViewModel.setProperty("/bAccNum", "");
						oViewModel.setProperty("/currency", "");
						oViewModel.setProperty("/bankAccDesc", "");
					}

				}.bind(this),
				error: function() {
					this.busyDialog.close();
				}
			});
		},
		/*handleTotalAmount: function(evt) {
			var source = evt.getSource(),
				sPath = source.getBindingContext().sPath,
				path = source.getBindingPath("value"),
				value = source.getValue(),
				oTable = this.getView().byId("trustRecId");

			if (source.getValue().length > 0) {
				source.setValueState("None");
				value = value.substring(0, value.length - 1);
				source.setValue(value);
				if (value.startsWith('-')) {
					source.setValue("");
					source.setValueState("Error");
					return;
				}
			} else {
				source.setValueState("Error");
			}
			source.getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			var tot = 0;

			for (var i = 0; i < oTable.getItems().length; i++) {
				var am = oTable.getItems()[i].getBindingContext().getObject().Amount;
				if (!am) {
					am = 0;
				}
				tot = tot + parseFloat(am);
			}
			this.getView().getModel("worklistView").setProperty("/totalAmount", tot.toFixed(2));
		},*/

		handleTotalAmount: function(oEvent) {

			var oSrc = oEvent.getSource(),
				vAmount = oSrc.getValue(),
				sPath = oSrc.getBindingContext().sPath,
				path = oSrc.getBindingPath("value"),
				oTable = this.getView().byId("trustRecId");

			//var validAmount = /^[1-9][0-9]*(\.([0-9]){0,2})?$/;
			var validAmount = /^[1-9][0-9,]*\.?[0-9,]{0,2}$/;
			if (vAmount) {
				if (vAmount.startsWith("-")) {
					oSrc.setValue("");
					oSrc.setValueState("Error");
					return;
				}
				if (vAmount.match(validAmount)) {
					oEvent.getSource().setValueState("None");
				} else {
					//vAmount = findAndReplace(vAmount, ".", "");
					vAmount = vAmount.substring(0, vAmount.length - 1);
					oSrc.setValue(vAmount);
					//oEvent.getSource().setValueState("Error");
				}
			} else {
				oSrc.setValueState("Error");
			}

			oSrc.getBindingContext().getModel().setProperty(sPath + "/" + path, vAmount);
			var tot = 0;

			for (var i = 0; i < oTable.getItems().length; i++) {
				var am = oTable.getItems()[i].getBindingContext().getObject().Amount;
				if (!am) {
					am = 0;
				}
				tot = tot + parseFloat(am);
			}
			this.getView().getModel("worklistView").setProperty("/totalAmount", tot);
			//this.getView().getModel("worklistView").setProperty("/totalAmount", tot.toFixed(2));
		},

		handleTextArea: function(evt) {
			var source = evt.getSource(),
				sPath = source.getBindingContext().sPath,
				path = source.getBindingPath("value"),
				value = source.getValue();

			if (source.getValue().length > 0) {
				source.setValueState("None");
			} else {
				source.setValueState("Error");
			}

			source.getBindingContext().getModel().setProperty(sPath + "/" + path, value);
		},
		onReceiptTypChg: function(evt) {
			var oView = this.getView();

			if (evt) {
				var source = evt.getSource(),
					path = source.getBindingPath("value"),
					value = source.getValue(),
					sPath = this.getView().getBindingContext().sPath;
				source.setValueState("None");
				this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			}
			var ctx = oView.getBindingContext(),
				obj = ctx.getObject(),
				oRecType = obj.ReceiptType;

			this._handleDateValues(oRecType);
			this._handleResetChequeCashValue();
		},

		_handleDateValues: function(sRecType) {
			var oViewModel = this.getView().getModel("worklistView");
			var oReceivedDate = oViewModel.getProperty("/ReceivedDate");
			if (oReceivedDate) {
				var oNewDate = new Date(oReceivedDate);
			}

			function interval5Days() {
				oViewModel.setProperty("/ifremitter", false);
				oViewModel.setProperty("/ifcheque", true);
				if (oReceivedDate) {
					oNewDate.setDate(oReceivedDate.getDate() + 5);
				}
			}

			function interval3Days() {
				oViewModel.setProperty("/ifremitter", false);
				oViewModel.setProperty("/ifcheque", true);
				if (oReceivedDate) {
					oNewDate.setDate(oReceivedDate.getDate() + 3);
				}
			}

			function interval1Day() {
				oViewModel.setProperty("/ifremitter", true);
				oViewModel.setProperty("/ifcheque", false);
				if (oReceivedDate) {
					oNewDate.setDate(oReceivedDate.getDate() + 0);
				}
			}

			var oReceiptType = {
				"1": interval3Days,
				"2": interval1Day,
				"3": interval5Days,
				"4": interval1Day,
				"5": interval1Day,
				"6": interval1Day,
				"7": interval1Day,
				"8": interval3Days
			};
			oReceiptType[sRecType]();
			if (oReceivedDate) {
				oViewModel.setProperty("/ClearanceDateVal", oNewDate);
			}
		},

		_handleResetChequeCashValue: function() {
			var oView = this.getView();
			var aInputs = [
				oView.byId("idChequeNumber"),
				oView.byId("ChequeDate"),
				oView.byId("idBankName"),
				oView.byId("idBankBranchCode"),
				oView.byId("idDrawnBy"),
				oView.byId("idReceivedFrom"),
				oView.byId("idRemitterNonCli")
			];

			this.getView().getModel("worklistView").setProperty("/RemitterCliEnable", true);
			this.getView().getModel("worklistView").setProperty("/RemitterNonCliEnable", true);

			jQuery.each(aInputs, function(i, oInput) {
				oInput.setValue(null);
				oInput.setValueState("None");
			});

			var oRemCli = oView.byId("idRemitterCli"),
				viewModel = this.getModel("worklistView");
			if (viewModel.getProperty("/RemitterCli")) {
				viewModel.setProperty("/RemitterCli", "");
				viewModel.setProperty("/RemitTextCli", "");
				oRemCli.getAggregation("_content").setSelectionItem();
			}
			//var sPath = this.getView().getBindingContext().sPath;
			//this.getView().getBindingContext().getModel().setProperty(sPath + "/Remitter", null);
			oRemCli.setValueState("None");
		},

		onChangeReceivedDate: function(oEvent) {
			var src = oEvent.getSource(),
				oDate = src.getDateValue(),
				sDate = this.formatter.dateFormatter(oDate),
				oViewModel = this.getModel("worklistView");

			if (!oEvent.getParameter("valid")) {
				src.setDateValue();
				this.handleonValueInput(oEvent);
				return;
			}
			this.handleonValueInput(oEvent);
			this.onReceiptTypChg();
			oViewModel.setProperty("/ClearanceMinDate", new Date(sDate));
		},

		_handleValidateDate: function(oEvent) {
			var src = oEvent.getSource();

			if (!oEvent.getParameter("valid")) {
				src.setDateValue();
				this.handleonValueInput(oEvent);
				return;
			}
			this.handleonValueInput(oEvent);

		},

		onChangeRemitter: function(evt) {
			var sVal = evt.getParameter("value");
			var oVModel = this.getView().getModel("worklistView");
			oVModel.setProperty("/RemitTextCli", sVal);
			if (sVal.length > 0) {
				oVModel.setProperty("/RemitterCliEnable", true);
				oVModel.setProperty("/RemitterNonCliEnable", false);
			} else {
				oVModel.setProperty("/RemitterCliEnable", true);
				oVModel.setProperty("/RemitterNonCliEnable", true);
			}

			this.onChangeRemitterNonCli();
		},
		onUpdateRemitterValue: function(evt) {
			var oChangeValues = evt.getParameter("changes");
			var oVModel = this.getView().getModel("worklistView");
			var oTable = this.getView().byId("trustRecId"),
				aItems = oTable.getItems();

			if (oChangeValues.hasOwnProperty("Office")) {
				oVModel.setProperty("/RemitterCli", oChangeValues.Remitter);
				if (oChangeValues.Office.length > 0 && aItems.length === 0) {
					this.onAddRowItemMatter();
				}
			}
		},
		onChangeRemitterNonCli: function(evt) {
			var oVModel = this.getView().getModel("worklistView");
			if (evt) {
				var sVal = evt.getParameter("value");
				if (sVal.length > 0) {
					oVModel.setProperty("/RemitterCliEnable", false);
					oVModel.setProperty("/RemitterNonCliEnable", true);
				} else {
					oVModel.setProperty("/RemitterCliEnable", true);
					oVModel.setProperty("/RemitterNonCliEnable", true);
				}
			}
			var oView = this.getView();
			var aCashInputs = [
				oView.byId("idRemitterCli"),
				oView.byId("idRemitterNonCli")
			];
			jQuery.each(aCashInputs, function(i, oInput) {
				oInput.setValueState("None");
			});
		},
		_createPayload: function() {

			var bVal = this._handleValidation(),
				that = this;
			if (!bVal) {
				return;
			}

			var oViewData = this.getModel("worklistView").getData(),
				oContextData = this.getView().getBindingContext().getObject();

			var oTable = this.getView().byId("trustRecId");
			var aItemtrustSet = [];
			var aItems = oTable.getItems();

			if (aItems.length > 0) {
				aItems.forEach(function(item) {
					aItemtrustSet.push({
						"Matter": item.getBindingContext().getObject().Matter,
						"Amount": item.getBindingContext().getObject().Amount,
						"ReasonForDeposit": item.getBindingContext().getObject().ReasonForDeposit,
						"MatterDesc": item.getBindingContext().getObject().MatterDesc,
						"ClientNum": item.getBindingContext().getObject().ClientNum,
						"ClientName": item.getBindingContext().getObject().ClientName
					});
				});
			}
			/*	var ItemfileSet = [{
					"DocNum": "1234",
					"Office": "CHI1",
					"File": "",
					"Slug": that.url + "." + "pdf"
				}];*/

			var oPayload = {
				"Office": oContextData.Office,
				"OfficeDesc": oContextData.OfficeDesc,
				"ReceiptType": oContextData.ReceiptType,
				"TransDate": this.formatter.formatDate(oViewData.TransactionDate),
				"ReceivedDate": this.formatter.formatDate(oViewData.ReceivedDate),
				"ClearanceDate": this.formatter.formatDate(oViewData.ClearanceDateVal),
				"AccNum": oViewData.bAccNum,
				"Amount": oViewData.totalAmount.toString(),
				"HbankDesc": oViewData.bankAccDesc,
				"Currency": oViewData.currency,
				"Remitter": oViewData.RemitterCli,
				"RemitText": oViewData.RemitTextCli,
				"RemitNonClnt": oViewData.RemitterNonCli,
				"ChqNum": oViewData.ChequeNumber,
				"ChqDate": this.formatter.formatDate(oViewData.ChequeDate),
				"BnkBrnchCode": oViewData.BankBranchCode,
				"BnkName": oViewData.BankName,
				"DrawnBy": oViewData.DrawnBy,
				"RecvdFrom": oViewData.ReceivedFrom,
				"ItemtrustSet": aItemtrustSet,
				"ItemfileSet": that.FileUploadSet
			};
			this.busyDialog.open();
			var oModel = this.getOwnerComponent().getModel();

			oModel.create("/Headertrusts", oPayload, {
				success: function(oData) {
					/*var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.success(
						oData.Return, {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);*/
					this.onMessageSuccessDialog(oData);
					//var oOfc = this.getView().byId("idOffice");
					//oOfc.getAggregation("_content").setSelectionItem();
					var sPath = this.getView().getBindingContext().sPath;
					this.getView().getBindingContext().getModel().setProperty(sPath + "/Office", "");
					this.getView().getBindingContext().getModel().setProperty(sPath + "/OfficeDesc", "");
					this._handleResetValues();
					this.busyDialog.close();
				}.bind(this),
				error: function(oErr) {
					this.busyDialog.close();
					var oResp = JSON.parse(oErr.responseText);
					if (oResp.error.innererror.errordetails.length > 0) {
						this.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
					}
					var resp = oErr.responseText,
						result = resp ? resp : 1;
					if (result !== 1) {
						//var respError = that.converttoJson(result);
						//stop showing standar popup
						this.applyResp(jQuery.parseJSON(result));
					}
				}.bind(this)

			});

		},

		onMessageSuccessDialog: function(oResp) {
			var dialog = new Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: oResp.Return
				}),
				buttons: [new Button({
						text: "Print Receipt",
						press: function() {
							dialog.close();
							this._displayForm("print", oResp);

						}.bind(this)
					}),
					new Button({
						text: "Display Document",
						press: function() {
							dialog.close();
							this._displayForm("display", oResp);
						}.bind(this)
					}),
					new Button({
						text: "OK",
						press: function() {
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		_displayForm: function(sKey, oResp) {
			var oModel = this.getOwnerComponent().getModel(),
				oViewModel = this.getModel("worklistView");

			if (oResp) {
				oViewModel.setProperty("/display", oResp);
			}

			var oContent = oViewModel.getProperty("/display");

			if (sKey === "print") {
				this._pdfViewer = new PDFViewer({
					showDownloadButton: false,
					popupButtons: [new Button({
						text: "Display Document",
						press: function() {
							this._displayForm("display");
						}.bind(this)
					})]
				});
				this.getView().addDependent(this._pdfViewer);
				var oHost = window.location.host,
					http = window.location.protocol,
					sSource = http + "//" + oHost + oModel.sServiceUrl + "/TrustPdfS(Spool='" + oContent.Spoolid + "')/$value";
				this._pdfViewer.setSource(sSource);
				this._pdfViewer.setTitle("Document " + oContent.DocNo);
				this._pdfViewer.open();
			}
			if (sKey === "display") {
				if (this._pdfViewer) {
					if (this._pdfViewer._bIsPopupOpen) {
						this._pdfViewer.getParent().oPopup.close();
					}
				}
				this._showFormFragment("MTrustReceiptDisplay");
				///DocHeaderS(Gjahr='2016',Belnr='1900000000',Bukrs='GB11')
				//invokeDocDisp: function(sFiscalYear,sDocumentNumber,sCompanyCode)
				//oViewModel.setProperty("/documentTitle","Document " + oContent.DocNo);
				this.oOutputComp.invokeDocDisp(oContent.Gjahr, oContent.DocNo, oContent.Bukrs, true);
				this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
			}
		},

		_handleValidation: function() {

			var oView = this.getView();
			var oViewModel = this.getView().getModel("worklistView");
			var aInputs = [
				oView.byId("idOffice"),
				oView.byId("idReceiptType"),
				oView.byId("idReceivedDate"),
				oView.byId("idClearanceDate"),
				oView.byId("TDate"),
				oView.byId("idbankAccNumInput")
			];
			var aChequeBInputs = [
				oView.byId("idChequeNumber"),
				oView.byId("ChequeDate"),
				oView.byId("idBankName"),
				oView.byId("idBankBranchCode"),
				oView.byId("idDrawnBy"),
				oView.byId("idReceivedFrom")
			];

			var aCashInputs = [
				oView.byId("idRemitterCli"),
				oView.byId("idRemitterNonCli")
			];

			var bValidationError = false;

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValue()) {
					oInput.setValueState("None");
					bValidationError = true;
				} else {
					oInput.setValueState("Error");
				}
			});

			//Cheque Validation
			if (oViewModel.getProperty("/ifcheque")) {
				jQuery.each(aChequeBInputs, function(i, oInput) {
					if (oInput.getValue()) {
						oInput.setValueState("None");
						bValidationError = true;
					} else {
						oInput.setValueState("Error");
					}
				});
			} else {
				jQuery.each(aChequeBInputs, function(i, oInput) {
					oInput.setValue(null);
					oInput.setValueState("None");
				});
			}

			//Cash Validation
			if (oViewModel.getProperty("/ifremitter")) {
				jQuery.each(aCashInputs, function(i, oInput) {
					if (oInput.getEnabled()) {
						if (oInput.getValue()) {
							oInput.setValueState("None");
							bValidationError = true;
						} else {
							oInput.setValueState("Error");
						}
					}
				});
			} else {
				jQuery.each(aCashInputs, function(i, oInput) {
					oInput.setValue(null);
					oInput.setValueState("None");
				});
			}

			bValidationError = this.handleTableValidation();

			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			jQuery.each(aChequeBInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			jQuery.each(aCashInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			if (!bValidationError) {
				MessageBox.alert("Please fill all required fields");
			}
			return bValidationError;
		},

		handleTableValidation: function() {
			var oTable = this.getView().byId("trustRecId"),
				aItems = oTable.getItems(),
				bValidationError = false;

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 5) {
						if (oCell.getValue().length > 0) {
							bValidationError = true;
							oCell.setValueState("None");
						} else {
							oCell.setValueState("Error");
						}
					} else if (index === 4) {
						var validAmount = /^[1-9]\d*(\.\d{1,2})?$/,
							sVal = oCell.getValue();
						if (sVal.length > 0 && sVal.match(validAmount)) {
							bValidationError = true;
							oCell.setValueState("None");
						} else {
							oCell.setValueState("Error");
						}
					}
				});
			});

			jQuery.each(aItems, function(i, oItem) {
				var aCells = oItem.getCells();
				jQuery.each(aCells, function(index, oCell) {
					if (index === 4 || index === 5) {
						if (oCell.getValueState() === "Error") {
							bValidationError = false;
						}
					}
				});
			});

			return bValidationError;
		},

		handleonValueInput: function(evt) {
			var oSrc = evt.getSource();

			if (oSrc.getValue().length > 0) {
				oSrc.setValueState("None");
			} else {
				oSrc.setValueState("Error");
			}
		},

		// Bank Account Value help Code
		handleValueHelp: function(oEvent) {
			//	var sInputValue = oEvent.getSource().getValue();

			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"trustreceiptmul.fragments.F4BankAccNumber",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// create a filter for the binding
			/*this._valueHelpDialog.getBinding("items").filter([new Filter(
				"AccNum",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);*/

			// open value help dialog filtered by the input value
			//	this._valueHelpDialog.open(sInputValue);
			this._valueHelpDialog.open();
		},

		_handleValueHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"AccNum",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose: function(oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var oViewModel = this.getView().getModel("worklistView");

			if (aContexts && aContexts.length) {
				var oInput = this.getView().byId(this.inputId),
					sAccNum = aContexts.map(function(oContext) {
						return oContext.getObject().AccNum;
					}).join(", ");
				oInput.setValue(sAccNum);
				oInput.setValueState("None");

				var sCurrency = aContexts.map(function(oContext) {
					return oContext.getObject().Currency;
				}).join(", ");
				oViewModel.setProperty("/currency", sCurrency);

				var sBankDesc = aContexts.map(function(oContext) {
					return oContext.getObject().HbankDesc;
				}).join(", ");
				oViewModel.setProperty("/bankAccDesc", sBankDesc);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		suggestionItemSelected: function(evt) {
			var oViewModel = this.getView().getModel("worklistView");
			var oItem = evt.getParameter("selectedItem"),
				src = evt.getSource(),
				sKey = oItem ? oItem.getKey() : "",
				sCurrency = oItem ? oItem.data("currency") : "",
				sBankDesc = oItem ? oItem.data("bankdesc") : "";

			src.setValue(sKey);
			oViewModel.setProperty("/currency", sCurrency);
			oViewModel.setProperty("/bankAccDesc", sBankDesc);
			src.setValueState("None");
		},

		onChangeAccNumber: function(oEvent) {
			var oSource = oEvent.getSource(),
				sInputValue = oSource.getValue(),
				oViewModel = this.getModel("worklistView"),
				aBankAccNum = oViewModel.getProperty("/bankAccNum");

			function isExist(value) {
				return value.AccNum === sInputValue;
			}

			if (aBankAccNum.length > 0) {
				var aFilterVal = aBankAccNum.filter(isExist);
				if (aFilterVal.length > 0) {
					oViewModel.setProperty("/currency", aFilterVal[0].Currency);
					oViewModel.setProperty("/bankAccDesc", aFilterVal[0].HbankDesc);
					oSource.setValueState("None");
				} else {
					oViewModel.setProperty("/currency", "");
					oViewModel.setProperty("/bankAccDesc", "");
					oSource.setValueState("Error");
				}
			}
		},

		handleOnPrint: function() {
			this._displayForm("print");
		},

		handleOnNewDoc: function() {
			this._showFormFragment("MTrustReceipt");
			this._handleResetValues();
		},

		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "trustreceiptmul.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},

		onPressHandleAttachments: function(oEvent) {
			var oAttachModel = new sap.ui.model.json.JSONModel();
			if (!this._attchParties) {
				this._attchParties = sap.ui.xmlfragment(this.getView().getId(), "trustreceiptmul.fragments.Attachment", this);
				this.getView().addDependent(this._attchParties);
			}

			oAttachModel.setData(this.FileUploadSet);
			this.getView().byId("UploadCollection").setModel(oAttachModel, "oAttachModel");
			//	jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._attchParties);
			this._attchParties.open();

		},
		onPressAttachmentCancel: function(oEvent) {
			var oButtonId = this.getView().byId("btnAttch");
			var oData = this.getView().byId("UploadCollection").getModel("oAttachModel").getData();
			if (oData.length > 0) {
				oButtonId.setType("Emphasized");
			} else {
				oButtonId.setType("Transparent");
			}
			this._attchParties.close();
		},
		onChange: function(oEvent) {
			var that = this,
				viewContext = this.getView().getBindingContext().getObject(),
				oUploadCollection = this.byId("UploadCollection");
			var oModel = this.getView().byId("UploadCollection").getModel("oAttachModel");
			var oData = oUploadCollection.getModel().getData();
			var fileData = new Blob([oEvent.getParameter("files")[0]]);
			var sFileName = oEvent.getParameter("files")[0].name;
			var buf = function getBuffer(resolve) {
				var reader = new FileReader();
				reader.readAsBinaryString(fileData);
				reader.onload = function() {
					var arrayBuffer = reader.result;
					resolve(arrayBuffer);
				};
			};

			var promise = new Promise(buf);
			// Wait for promise to be resolved, or log error.
			promise.then(function(data) {
				// Here you can pass the bytes to another function.
				var bData = btoa(data);
				that.url = bData;
				var obj = {
					"DocNum": "",
					"Office": viewContext.Office,
					"File": bData,
					"Slug": sFileName

				};
				that.FileUploadSet.push(obj);
				oModel.setData(that.FileUploadSet);
				this.getView().byId("UploadCollection").setModel(oModel, "oAttachModel");
				//	that.setJsonData(bData);
				//     sap.m.URLHelper.redirect("http://localhost:8080/sendMail?to=" + sTo + "&sub=" + sSubject + "&body=" + sBody +"&ath="+bData+"&app=true", true);

			}).catch(function(err) {});
		},
		onUploadComplete: function(oEvent) {

			// Sets the text to the label
			//	this.byId("attachmentTitle").setText(this.getAttachmentTitleText());

			// delay the success message for to notice onChange message
			setTimeout(function() {
				//MessageBox.show("UploadComplete event triggered.");
			}, 4000);
		},

		getAttachmentTitleText: function() {
			var aItems = this.byId("UploadCollection").getItems();
			return "Uploaded (" + aItems.length + ")";
		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var oCustomerHeaderSlug = new UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
			//	MessageBox.show("BeforeUploadStarts event triggered.");
		},

		onFileDeleted: function(oEvent) {
			this.deleteItemById(oEvent.getParameter("documentId"));
		},
		deleteItemById: function(sItemToDeleteId) {
			var oData = this.getView().byId("UploadCollection").getModel("oAttachModel").getData();
			var aItems = jQuery.extend(true, {}, oData);
			jQuery.each(aItems, function(index) {
				if (aItems[index] && aItems[index].Slug === sItemToDeleteId) {
					oData.splice(index, 1);
				}
			});
			this.getView().byId("UploadCollection").getModel("oAttachModel").setData(oData);
		},

		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});