sap.ui.define(["sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function() {
	"use strict";

	return {

		SeTStatusIcon: function(isError) {
			if (isError === "S")
				return "sap-icon://message-success";
			else if (isError === "E")
				return "sap-icon://message-error";
			else if (isError === "W")
				return "sap-icon://message-warning";

			else if (isError === "" || isError === null || isError === undefined)
				return "";

		},
		SeTStatusIconColor: function(isError) {

			if (isError === "S")
				return "Green";
			else if (isError === "E")
				return "Red";
			else if (isError === "W")
				return "Orange";
		},
		SeTIconToolTip: function(Message) {

			return Message;
		},
		SeTSubmitStatus: function(Submit) {
			if (Submit === "" || Submit === null) {
				return false;
			}
			return true;
		},
		setNavigation: function(vbln) {
			if (vbln !== "") {
				return sap.m.ListType.Active;
			}
			return sap.m.ListType.Inactive;
		}

	};

});