sap.ui.define([
	"dbcreation/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"dbcreation/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("dbcreation.controller.Worklist", {

		formatter: formatter,

		onInit: function() {
			var oViewModel;
			var oView = this.getView();
			var oTable = oView.byId("table");
			oTable.setVisible(false);
			oView.byId("Dcreate").setEnabled(false);

			var odate = new sap.ui.model.json.JSONModel();
			odate.setData({
				dateValue: new Date()
			});
			this.getView().setModel(odate, "fdate");
			this.byId("Dateto").setDateValue(new Date());

			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				countAll: 0
			});
			this.setModel(oViewModel, "worklistView");
		},
		PNumChange: function() {
			var ptype = this.getView().byId("idpartnerType").getSelectedKey();
			var PlsSelPrtnerTypeMsg = this.getResourceBundle().getText("PlsSelPartnerType");
			var SplChrNtAllwdMsg = this.getResourceBundle().getText("SplCharNtAllowed");
			if (ptype === "" || ptype === null) {
				sap.m.MessageBox.warning(PlsSelPrtnerTypeMsg, {
					title: "Warning",
					onClose: null,
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Center
				});
				// this.getView().byId("idpartnerType").sap.ui.core.ValueStatee("Error");
				this.getView().byId("idbillPartner").setValue(null);
				return;
			} else {

				var oidbillPartner = this.getView().byId("idbillPartner").getValue();

				var regex = /^[A-Za-z0-9]+$/;
				if (!oidbillPartner.match(regex)) {
					this.getView().byId("idbillPartner").setValueState("Error");
					this.getView().byId("idbillPartner").setValueStateText(SplChrNtAllwdMsg);
				} else {
					this.getView().byId("idbillPartner").setValueState("None");
				}

			}

		},
		onselctionchange: function() {
			var PlsSelPartnerNumMsg = this.getResourceBundle().getText("PlsSelPartnerNumMsg");
			var selkey = this.getView().byId("idpartnerType").getSelectedKey();
			if (selkey === "" || selkey === null) {
				this.getView().byId("idbillPartner").setValue(null);
				this.getView().byId("idbillPartner").setDescription(null);
				this.getView().byId("idbillPartner").setValueState("None");
			} else {
				this.getView().byId("idbillPartner").setValueState("Error");
				this.getView().byId("idbillPartner").setValueStateText(PlsSelPartnerNumMsg);
			}
		},
		// F4 Search helps for selection Selection Screens

		// Search Help For Billing Parnter
		handleValueHelpBillpart: function(oEvent) {
			var PlsSelPartnerTypeMsg = this.getResourceBundle().getText("PlsSelPartnerTypeMsg");
			var ptype = this.getView().byId("idpartnerType").getSelectedKey();
			if (ptype === "") {
				sap.m.MessageBox.warning(PlsSelPartnerTypeMsg, {
					title: "Warning",
					onClose: null,
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Center
				});
				return;
			}

			//var sInputValue = oEvent.getSource().getValue();
			var sInputValue = oEvent.getSource().getDescription();
			// create a filter for the binding
			var tk = this.getView().byId("idpartnerType").getSelectedKey();
			var aFilter = [];
			var oFilter;
			oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, tk);
			aFilter.push(oFilter);

			//if (!this._valueHelpDialog) {
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments.billingpartner", this);
			this.getView().addDependent(this._valueHelpDialog);
			//}
			this._valueHelpDialog.getBinding("items").filter(aFilter);
			if (sInputValue !== "") {

				oFilter = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this.getView().byId("idbillPartner").setValueState("None");
						that.byId("idbillPartner").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that.byId("idbillPartner").setDescription(evt.getParameters("selectedItems").selectedItem.getDescription());

						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchpartner: function(evt) {
			var sValue = evt.getParameter("value");
			var tk = this.getView().byId("idpartnerType").getSelectedKey();
			var aFilter = [];
			var oFilter;
			oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, tk);
			aFilter.push(oFilter);
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelppartnerClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var billpartnerInput = this.getView().byId("idbillPartner");
				this.getView().byId("idbillPartner").setValueState("None");
				billpartnerInput.setValue(oSelectedItem.getTitle());
				billpartnerInput.setDescription(oSelectedItem.getDescription());

			}
			// this._valueHelpDialog.destroy();
		},
		_handleValueCancel: function(evt) {
			this._valueHelpDialog.destroy();
		},
		// Search Help For Billing Office
		handleValueHelpBillofc: function(oEvent) {

			var sFieldName1 = "Werks";
			var sFrgmntName = "billingofc";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("idbillingOffice").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchBilling: function(evt) {
			//var sFieldName1 = "Werks";
			var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var BillofcInput = this.getView().byId("idbillingOffice");
				BillofcInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// Search Help For Client
		handleValueHelpClient: function(oEvent) {
			var sFieldName1 = "Kunnr";
			var sFrgmntName = "clientf4";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("clientid").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchclient: function(evt) {
			//	var sFieldName1 = "Kunnr";
			var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelpclientClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var clientInput = this.getView().byId("clientid");
				clientInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},

		//	search Help For Matters
		handleValueHelpMatter: function(oEvent) {
			var sFieldName1 = "Pspid";
			var sFrgmntName = "matters";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("idMatter").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchmatter: function(evt) {
			//	var sFieldName1 = "Kunnr";
			var sFieldName2 = "Post1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelpmatterClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var clientInput = this.getView().byId("idMatter");
				clientInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// search Help For Legal Entity
		handleValueHelpLegalEnt: function(oEvent) {
			var sFieldName1 = "Bukrs";
			var sFrgmntName = "legalentity";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("idlegalentity").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchlegalentity: function(evt) {

			var sFieldName2 = "Butxt";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelplegalentityClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var clientInput = this.getView().byId("idlegalentity");
				clientInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// search Help For Group Bill Id
		handleValueHelpGroupBill: function(oEvent) {
			var sFieldName1 = "Zzgrpbillid";
			var sFrgmntName = "groupbill";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("idgroupbill").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchgroupbill: function(evt) {

			var sFieldName2 = "Post1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelpgroupbillClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var clientInput = this.getView().byId("idgroupbill");
				clientInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// search Help For Billing Name
		handleValueHelpBillingTeam: function(oEvent) {
			var sFieldName1 = "Zzbillteam";
			var sFrgmntName = "billingteam";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("dbcreation.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						that.byId("idBillingTeam").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchbillteam: function(evt) {

			var sFieldName2 = "Zzdesc";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelpbillteamClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var clientInput = this.getView().byId("idBillingTeam");
				clientInput.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		//for selection screen Suggesion
		// onsuggestclient: function() {
		// 	var oclient = this.getView().byId("clientid").getValue();
		// 	//var Clenght = oclient.length;
		// 	var regex = /^[A-Za-z0-9]+$/;
		// 	if (!oclient.match(regex) && oclient !== "") {
		// 		this.getView().byId("clientid").setValueState("Error");
		// 		this.getView().byId("clientid").setValueStateText("Special Characters are not Allowed");
		//         }else
		//         {
		//         	this.getView().byId("clientid").setValueState("None");
		//         }

		// },
		datechange: function() {
			var odatefrm = this.getView().byId("Datefrom").getValue();
			var FrDate = /(19|20)\d\d[- \/.](0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])/;
			if (!odatefrm.match(FrDate)) {
				this.getView().byId("Datefrom").setValueState("Error");
				this.getView().byId("Datefrom").setValueStateText("Please Enter Correct Date Format(yyyy-MM-dd)");
			} else {
				this.getView().byId("Datefrom").setValueState("None");
			}
		},
		datechange1: function() {
			var odateto = this.getView().byId("Dateto").getValue();
			var FrDate = /(19|20)\d\d[- \/.](0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])/;
			if (!odateto.match(FrDate)) {
				this.getView().byId("Dateto").setValueState("Error");
				this.getView().byId("Dateto").setValueStateText("Please Enter Correct Date Format(yyyy-MM-dd)");
			} else {
				this.getView().byId("Dateto").setValueState("None");
			}
		},
		// F4search Helps End
		onClickGo: function() {

			this._oTableSearchState = [];
			var searchbt = this.getView().byId("searchField");
			searchbt.setValue("");
			var aFilter = [];
			var oFilter;
			var WrkDatToNtEmptyMsg = this.getResourceBundle().getText("WrkDatToNtEmptyMsg");
			var WrkDatFromNtEmptyMsg = this.getResourceBundle().getText("WrkDatFromNtEmptyMsg");
			var PlsSelPartnerNumMsg = this.getResourceBundle().getText("PlsSelPartnerNumMsg");
			var WrkDatFromNtGrtThnWrkDatToMsg = this.getResourceBundle().getText("WrkDatFromNtGrtThnWrkDatToMsg");
			var MatterSummaryMsg = this.getResourceBundle().getText("MatterSummaryMsg");
			//creating filter for client 
			var oclient = this.getView().byId("clientid").getValue();
			if (oclient !== "") {
				oFilter = new sap.ui.model.Filter("Client", sap.ui.model.FilterOperator.EQ, oclient);
				aFilter.push(oFilter);
			}
			//creating filter for bilkling office 
			var oBillingoffice = this.getView().byId("idbillingOffice").getValue();
			if (oBillingoffice !== "") {
				oFilter = new sap.ui.model.Filter("BillOffice", sap.ui.model.FilterOperator.EQ, oBillingoffice);
				aFilter.push(oFilter);
			}
			//creating filter for Partner Type
			var opartnerType = this.getView().byId("idpartnerType").getSelectedKey();

			if (opartnerType !== "") {
				oFilter = new sap.ui.model.Filter("MpartnerParvw", sap.ui.model.FilterOperator.EQ, opartnerType);
				aFilter.push(oFilter);
			}
			//creating filter for Billing Partner
			var oBillingpartner = this.getView().byId("idbillPartner").getValue();

			if (oBillingpartner !== "") {
				oFilter = new sap.ui.model.Filter("Mpartner", sap.ui.model.FilterOperator.EQ, oBillingpartner);
				aFilter.push(oFilter);
			}
			//creating filter for Legal Entity
			var oidlegalentityr = this.getView().byId("idlegalentity").getValue();

			if (oidlegalentityr !== "") {
				oFilter = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oidlegalentityr);
				aFilter.push(oFilter);
			}
			//creating filter for Matter
			var oidMatter = this.getView().byId("idMatter").getValue();

			if (oidMatter !== "") {
				oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oidMatter);
				aFilter.push(oFilter);
			}
			//creating filter for Group Bill Id
			var oidgroupbill = this.getView().byId("idgroupbill").getValue();

			if (oidgroupbill !== "") {
				oFilter = new sap.ui.model.Filter("Zzgrpbillid", sap.ui.model.FilterOperator.EQ, oidgroupbill);
				aFilter.push(oFilter);
			}
			//creating filter for Billing Team
			var oidBillingTeam = this.getView().byId("idBillingTeam").getValue();

			if (oidBillingTeam !== "") {
				oFilter = new sap.ui.model.Filter("Zzbillteam", sap.ui.model.FilterOperator.EQ, oidBillingTeam);
				aFilter.push(oFilter);
			}
			//creating filter for From Date
			var odatefrom = this.getView().byId("Datefrom").getValue();
			var odatetimefrom = odatefrom + "T00:00:00";
			if (odatefrom !== "") {
				oFilter = new sap.ui.model.Filter("BudatFrom", sap.ui.model.FilterOperator.EQ, odatetimefrom);
				aFilter.push(oFilter);
			}
			//creating filter for To Date
			var odateto = this.getView().byId("Dateto").getValue();
			var odatetimeto = odateto + "T00:00:00";
			if (odateto !== "") {
				oFilter = new sap.ui.model.Filter("BudatTo", sap.ui.model.FilterOperator.EQ, odatetimeto);
				aFilter.push(oFilter);
			}

			// new modification validating date limit
			var regvalid = true;
			var oTable = this.getView().byId("table");
			var RegExpDate = /(19|20)\d\d[- \/.](0[1-9]|1[012])[-](0[1-9]|[12][0-9]|3[01])/;
			if (odateto === "") {
				this.getView().byId("Dateto").setValueState("Error");
				this.getView().byId("Dateto").setValueStateText(WrkDatToNtEmptyMsg);
				regvalid = false;
			} 
			// else if (!odateto.match(RegExpDate)) {
			// 	this.getView().byId("Dateto").setValueState("Error");
			// 	this.getView().byId("Dateto").setValueStateText("Please Enter Correct Date Format");
			// 	regvalid = false;
			// }
			if (odatefrom === "") {
				this.getView().byId("Datefrom").setValueState("Error");
				this.getView().byId("Datefrom").setValueStateText(WrkDatFromNtEmptyMsg);
				regvalid = false;
			}
			// else if (!odatefrom.match(RegExpDate)) {
			// 	this.getView().byId("Datefrom").setValueState("Error");
			// 	this.getView().byId("Datefrom").setValueStateText("Please Enter Correct Date Format(yyyy-mm-dd)");
			// 	regvalid = false;
			// }
			if (opartnerType !== "" && oBillingpartner === "") {
				this.getView().byId("idbillPartner").setValueState("Error");
				this.getView().byId("idbillPartner").setValueStateText(PlsSelPartnerNumMsg);
				regvalid = false;
			} else {
				this.getView().byId("idbillPartner").setValueState("None");
			}

			if (regvalid !== false) {
				var oWDT = odateto.substring(0, 4);
				var oWDF = odatefrom.substring(0, 4);
				if (oWDF <= oWDT) {
					regvalid = true;
				} else {
					sap.m.MessageBox.error(WrkDatFromNtGrtThnWrkDatToMsg);
					regvalid = false;
				}
			}
			if (regvalid === true) {
				this.getView().byId("Dateto").setValueState("None");
				this.getView().byId("Datefrom").setValueState("None");
				this._filter = aFilter;
				var oView = this.getView();
				var oModel = oView.getModel();
				oView.byId("ssPanel").setExpanded(false);
				var oTable = oView.byId("table");
				var title = oView.byId("title");
				oTable.setVisible(true);
				oTable.setBusy(true);
				var oPath = "/MatterDetailSet";
				var mParameters = {
					filters: aFilter,
					success: function(data) {
						oView.byId("Dcreate").setEnabled(true);
						var aTableData = [];
						for (var k = 0; k < data.results.length; k++) {
							var oRow = {
								Iserror: data.results[k].Iserror,
								Pspid: data.results[k].Pspid,
								Post1: data.results[k].Post1,
								Name1: data.results[k].Name1,
								Zzgrpbillid: data.results[k].Zzgrpbillid,
								BillOfficeName: data.results[k].BillOffice + " " + data.results[k].BillOfficeName,
								BillingPartner: data.results[k].BillingPartner,
								Submit: data.results[k].Submit,
								Vbeln: data.results[k].Vbeln
							};
							aTableData.push(oRow);
						}
						var oModel1 = new sap.ui.model.json.JSONModel();
						oModel1.setData({
							modelData: aTableData
						});
						oTable.setModel(oModel1);
						oTable.bindRows("/modelData");
						var sTitle,
							iTotalItems = data.results.length;
					
						if (iTotalItems) {
							sTitle = MatterSummaryMsg + " (" + iTotalItems + ")";
						} else {
							sTitle = MatterSummaryMsg;
							// sap.m.MessageToast.show("Matter not billable");
						}
						title.setText(sTitle);
						oTable.setBusy(false);
						var oBinding = oTable.getBinding("rows");
						oBinding.attachChange(function() {
							var worklistView = oView.getModel("worklistView");
							var sTitle1 = MatterSummaryMsg + " (" + oBinding.getLength() + ")";
							worklistView.setProperty("/worklistTableTitle", sTitle1);
						}.bind(this));
					},
					error: function(oError) {

						oTable.setBusy(false);
					}
				};

				oModel.read(oPath, mParameters);
			}

		},
		onUpdateFinished: function() {
			var oTable = this.getView().byId("table");
			var sTitle,
				iTotalItems = oTable.getBinding().getLength();
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding().isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);

		},
		onRowSelect: function(e) {
			var oTable = this.getView().byId("table");
			var indices = e.getParameter("rowIndices"),
			rowIndex = e.getParameter("rowIndex"),
			src = e.getSource(),
			rc = e.getParameter("rowContext");
			// var length = indices.length;
			// var count = 0;
			// var itemcount;
			if(rowIndex < 0){
				var selItem = 0;
				for(selItem; selItem < oTable.getBinding().getLength();selItem++) {
					var ctx = oTable.getContextByIndex(selItem);
					var model = ctx.getModel();
					model.setProperty(ctx.getPath() + "/Submit", "");
				}
			}
			
			if(!src.isIndexSelected(rowIndex) && rc){
				rc.getModel().setProperty(rc.getPath() + "/Submit","");
			}
			
			if (indices.length !== 0) {
				this.getView().byId("Dcreate").setEnabled(true);
				this.getView().byId("headercheckbox").setSelected(false);
			}
			var ind = oTable.getSelectedIndices();
			if (ind.length === 0) {
				var idx = ind[0];
				if (oTable.isIndexSelected(idx) === false) {
					this.getView().byId("Dcreate").setEnabled(false);
				}

			}

			// for (var i = 0; i < indices.length; i++) {

			// 	// var context1 = oTable.getContextByIndex(i);

			// 	// var ocheck = e.oSource.getRows()[i].getCells()[7];
			// 	if(indices.length === 1)
			// 	{
			// 	var idx = indices[i];
			// 	if (oTable.isIndexSelected(idx) === false) {
			// 	this.getView().byId("Dcreate").setEnabled(false);
			// 	} }
			// 	// itemcount = count;
			// 	// if (itemcount === length) {
			// 	// 	this.getView().byId("headercheckbox").setEnabled(true);

			// 	// }
			// }
		},

		handleSelect: function(oEvent) {
			var checked = oEvent.getParameter("selected");
			oEvent.getSource().setBusy(true);
			this.setstatusselection(checked);
			oEvent.getSource().setBusy(false);
		},
		setstatusselection: function(checked) {
			var tbl = this.getView().byId("table");
			$.each(tbl.getSelectedIndices(), function(i, selItem) {

				var ctx = tbl.getContextByIndex(selItem);

				var model = ctx.getModel();

				if (checked) {
					model.setProperty(ctx.getPath() + "/Submit", "X");
				} else {
					model.setProperty(ctx.getPath() + "/Submit", "");
				}
			});
		},
		onSubmitSelect: function(oEvent) {
			var src = oEvent.getSource();
			var bc = src.getBindingContext();
			var model = bc.getModel();
			var sValue = oEvent.getParameter('selected') ? "X" : " ";
			model.setProperty(bc.getPath() + "/Submit", sValue);
		},
		onDisplayLog: function(oEvent) {
			var mPlsSelOneMatrMsg = this.getResourceBundle().getText("PlsSelOneMatrMsg");
			var tbl = this.getView().byId("table");
			if (tbl.getSelectedIndices().length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatrMsg, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			var oView = this.getView();
			var oModel = oView.getModel();
			var oPspidArray1 = [];
			var oFilter;
			var aFilter = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var newpspid = context1.getProperty("Pspid");
				oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, newpspid);
				oPspidArray1.push(oFilter);
				// oPspidArray1.push();
				aFilter.push(oFilter);

			});
			if (aFilter.length > 1) {
				aFilter = [new Filter(aFilter, true)];
			}
			var oPath = "/DBCreateLogSet";
			var mParameters = {
				filters: aFilter,
				success: function(oData) {
					$.each(tbl.getSelectedIndices(), function(i, o) {
						var context1 = tbl.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Pspid === oo.Pspid;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = tbl.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							model.setProperty(VbelnPath, a[0].Vbeln);
							model.setProperty(isErrorPath, a[0].Iserror);
							// if (a[0].Vbeln !== "") {
							// 	o.setSelected(false);
							// }

						}
					});
					tbl.setBusy(false);
					oView.byId("Dcreate").setEnabled(false);
				},
				error: function(oError) {
					// sap.m.MessageBox.show("Error");
				}
			};
			oModel.read(oPath, mParameters);
		},
		createDraft: function(oEvent, oModel) {
var mPlsSelOneMatr = this.getResourceBundle().getText("PlsSelOneMatr");
			var tbl = this.getView().byId("table");

			var oComponent = this.getOwnerComponent();
			var oFModel = oComponent.getModel(oModel);
			var odatefrom1 = this.getView().byId("Datefrom").getValue();
			var odatefrom = odatefrom1.replace(/-/g, '');
			var odateto1 = this.getView().byId("Dateto").getValue();
			var odateto = odateto1.replace(/-/g, '');
			var oUrlParams;
			var oRows = tbl.getSelectedIndices();
			if (oRows.length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatr, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;

			}

			var oPspidArray = [];
			var oCheckArray = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				oPspidArray.push(context1.getProperty("Pspid"));
				var ocheck1 = context1.getProperty("Submit");
				oCheckArray.push(ocheck1);
			});
			oUrlParams = {
				budat_from: odatefrom,
				budat_to: odateto,
				PSPID: oPspidArray,
				Submit: oCheckArray
			};

			oFModel.callFunction("/CreateDraft", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(tbl.getSelectedIndices(), function(i, o) {
						var context1 = tbl.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Pspid === oo.Pspid;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = tbl.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							model.setProperty(VbelnPath, a[0].Vbeln);
							model.setProperty(isErrorPath, a[0].Iserror);

						}
					});
					tbl.setBusy(false);
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}

			});

		},

		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			var sQuery = oEvent.getParameter("query");
			var oTableSearchState = [];
			this.aSearchFilter = [];

			if (sQuery && sQuery.length > 0) {
				this.aSearchFilter = [new Filter("Post1", FilterOperator.Contains, sQuery)]; // filter for backend call and it contains pspid1 filter parameter
				var aORFilter = new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Post1", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery)
					],
					false);
				this.aSearchFilter1 = []; // Filter for ui table filteration and it has OR conditions
				this.aSearchFilter1.push(aORFilter);
				if (oTableSearchState.length > 0) {
					oTableSearchState = oTableSearchState.concat(this.aSearchFilter1);
				} else {
					oTableSearchState = this.aSearchFilter1;
				}

				this._applySearch(oTableSearchState);
			}
			if (oEvent.getParameters().clearButtonPressed) {

				this._applySearch(oTableSearchState);
			}

		},
		_applySearch: function(oTableSearchState) {

			var oViewModel = this.getModel("worklistView");
			var tbl = this.getView().byId("table");
			tbl.getBinding("rows").filter(oTableSearchState);
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState && oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}

		},
		onRefresh: function(oEvt) {
			this.getView().byId("headercheckbox").setSelected(false);
			var oTable = this.getView().byId("table");
			// this.setstatusselection(false);
			// this.resetTableSelection();

			this.onClickGo();
			var searchbt = this.getView().byId("searchField");
			searchbt.setValue("");
			oTable.clearSelection();

		},
		resetTableSelection: function() {
			var tbl = this.getView().byId("table");
			var searchbt = this.getView().byId("searchField");
			searchbt.setValue("");
			var indices = tbl.getSelectedIndices();
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var idx = indices[i];
				//	tbl.isIndexSelected(idx);

				var ctx = tbl.getContextByIndex(idx);
				//var ctx = tbl.getBinding("rows");
				var model = ctx.getModel();
				var isErrorPath = ctx.getPath() + "/Iserror";
				var MessagePath = ctx.getPath() + "/Message";
				var VbelnPath = ctx.getPath() + "/Vbeln";
				model.setProperty(MessagePath, "");
				model.setProperty(VbelnPath, "");
				model.setProperty(isErrorPath, "");
				model.setProperty(ctx.getPath() + "/Submit", null);
			});
			tbl.clearSelection();
		},
		BillEditRedirect: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject();
			var billerUrl;
			// var oHref = "#ZPRS_DB_WF05-display&/" + oObj.Vbeln;
			// oEvent.oSource.setHref(oHref);
			billerUrl = "/sap/bc/ui5_ui5/sap/zprs_bedit/index.html#/main/" + oObj.Vbeln;
			sap.m.URLHelper.redirect(billerUrl, true);

		},

		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Pspid")
			});
		},
		onHelpPress: function(evt) {
				sap.m.URLHelper.redirect(
					"/gm/PerformSearch?format=EU_SearchXML.shtml&source=HLP&MH=200&profile=1.11.5520&mode=EU&F6=transaction_code&SO=rel&searchText=VA02&saveData=true&O1=iph&P6=VA02&F6=transaction_code_and_screen_ids",
					true);
			}
			/**
			 * Internal helper method to apply both filter and search state together on the list binding
			 * @param {object} oTableSearchState an array of filters for the search
			 * @private
			 */

	});
});