jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsmreports/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsmreports/test/integration/pages/Worklist",
		"lsmreports/test/integration/pages/Object",
		"lsmreports/test/integration/pages/NotFound",
		"lsmreports/test/integration/pages/Browser",
		"lsmreports/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmreports.view."
	});

	sap.ui.require([
		"lsmreports/test/integration/WorklistJourney",
		"lsmreports/test/integration/ObjectJourney",
		"lsmreports/test/integration/NavigationJourney",
		"lsmreports/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});