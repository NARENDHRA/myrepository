sap.ui.define([
	"cminewrequest/controller/RequestBaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cminewrequest/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"cminewrequest/model/JsonData"
], function(RequestBaseController, JSONModel, History, formatter, Filter, FilterOperator, JsonData) {
	"use strict";
	return RequestBaseController.extend("cminewrequest.controller.LandingPage", {
		// change this function origninal once back services are stablized
		onPressSubmit_continueworking: function(oEvent) {
			this._newRequestPopup.close();
			this.getRouter().navTo("ECNM", {
				Cmino: "1000000053"
			}, true);
		},
		formatter: formatter,
		JsonData: JsonData,
		onInit: function() {
			var oc = this.getOwnerComponent();
			this._createGeneralSettingsModel();
			oc.getRouter().getRoute("LandingPage").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("ConflictSearch").attachPatternMatched(this._onObjectConflictMatched, this);
			oc.getRouter().getRoute("MyInboxNewRequest").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			this.showNewRequestPopup();
		},
		_onObjectConflictMatched: function(oEvent) {
			var cmiNo = oEvent.getParameter("arguments").Cmino,
				searchId = oEvent.getParameter("arguments").Searchid,
				oGeneral = this.getModel("generalSettings");
			oGeneral.setProperty("/oClientObj/Cmino", cmiNo);
			oGeneral.setProperty("/oClientObj/searchId", searchId);
			oGeneral.setProperty("/conflictsVisibility", true);
			this.showNewRequestPopup();
		},
		showNewRequestPopup: function(oEvent) {
			if (!this._newRequestPopup) {
				this._newRequestPopup = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.ClientDetailsPopup", this);
				this.getView().addDependent(this._newRequestPopup);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._newRequestPopup);
			this._newRequestPopup.open();
		},
		// changed event name to _1 for testing with hardcoded cmino
		onPressNewClient: function(oEvent) {
			var oSource = oEvent.getSource(),
				oClientContext,
				oPage = this.getView().byId(oSource.data("masterPage")),
				oGeneral = this.getModel("generalSettings"),
				bNewClient = (oSource.data("source") === "NCNM" ? true : false),
				oDetailPage = this.getView().byId(oSource.data("destination")),
				oClientForm = this.getView().byId("idClientDetails"),
				oClientGroup = this.getView().byId("cminewrequest.clientNameInput_");
			oDetailPage.setTitle(oSource.getTitle());
			oGeneral.setProperty("/bNewClient", bNewClient);
			oGeneral.setProperty("/oClientObj/Cmirequesttype", oSource.data("source"));
			oClientGroup.setEditMode(true);
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				if (!this.cmiHdrs) {
					this.cmiHdrs = this._createContexts("/Cmihdrs", {});
				}
				oClientContext = this._createContexts("/Cmiclients", {
					Cmino: oGeneral.getProperty("/oClientObj/Cmino")
				});
				oClientForm.setBindingContext(oClientContext);
				oPage.to(oDetailPage);
				oGeneral.setProperty("/bClientSubmitButton", true);
			}.bind(this));
		},
		onPressClientFormNavBackButton: function(oEvent) {
			this.getModel("generalSettings").setProperty("/bClientSubmitButton", false);
			this._deleteContexts(this.getBindingContextbyId("idClientDetails"));
			var oPage = this.getView().byId("cminewrequest.masterPage");
			oPage.back();
		},
		onPressSubmitPopup: function(oEvent) {
			var oModel = this.getModel();
			var oClient = this.getBindingContextbyId("idClientDetails").getObject(),
				oGeneral = this.getModel("generalSettings");
			oGeneral.setProperty("/oClientObj/Clientk", oClient.Clientk);
			//	    oGeneral.setProperty("/oClientObj/Cmino", "$000000001");
			var requestType = oGeneral.getProperty("/oClientObj/Cmirequesttype");
			var bNewClient = oGeneral.getProperty("/bNewClient");
			// uncomment clientk for ECNM
			// oModel.createEntry("/Cmihdrs", {
			// 	properties: {
			// 		Cmino: oGeneral.getProperty("/oClientObj/Cmino"),
			// 		Clientk: bNewClient ? "$000000001" : oClient.Clientk,
			// 		Searchid: oGeneral.getProperty("/oClientObj/searchId"),
			// 		Cmirequesttype: requestType
			// 	}
			// });
			this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Cmino", oGeneral.getProperty("/oClientObj/Cmino"));
			this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Clientk", bNewClient ? "$000000001" : oClient.Clientk);
			this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Searchid", oGeneral.getProperty("/oClientObj/searchId"));
			this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Cmirequesttype", requestType);
			// test for lavanya

			oModel.createEntry("/Cmiclientdetails", {
				properties: {
					Cmino: oGeneral.getProperty("/oClientObj/Cmino"),
					Clientk: bNewClient ? "$000000001" : oClient.Clientk,
					Iname1: oClient.Client,
					Iline1: oClient.Addr1,
					Iline2: oClient.Addr2,
					Iline3: oClient.City,
					Iline4: oClient.State,
					Email: oClient.Email
				}
			});
			oModel.createEntry("/Cmimatters", {
				properties: {
					Cmino: bNewClient ? "$000000001" : oClient.Clientk,
					Matter: "$000000001"
				}
			});
			oModel.createEntry("/Cmimatterdetails", {
				properties: {
					Cmino: bNewClient ? "$000000001" : oClient.Clientk,
					Matter: "$000000001"
				}
			});
			// ends test for lavanya

			// comment below code for ECNM
			// delete oClient.Clientk;
			// oModel.createEntry("/Cmiclient", {
			// 	properties: oClient
			// });

			//this._navigateToPage();
			//	oModel.setProperty(this.cmiHdrsCntx.getPath()+"/Cmirequesttype",requestType);
			jQuery.sap.delayedCall(200, this, function() {
				var that = this;
				oModel.submitChanges({
					success: function(res) {
						var cmiNo = res.__batchResponses[0].__changeResponses[0].data.Cmino;
						that._newRequestPopup.close();
						//that._navigateToPage();
						that.getRouter().navTo(requestType, {
							Cmino: cmiNo
						}, true);
					},
					error: function(res) {
						// delete or reset pending changes: discuss with BG

					}
				});
			}.bind(this));
		},
		onPressClientAmendment: function() {
			var Request = "CA";
			var sObject = "ZPRS_CMI_AMENDN",
				action = "display&/" + "AmendmentReq" + "/" + Request;
			this._newRequestPopup.close();
			jQuery.sap.delayedCall(1000, this, function() {
				this.navigatetoCrossApp(sObject, action);
			}.bind(this));
		},
		onPressMatterAmendment: function() {
			var Request = "MA";
			var sObject = "ZPRS_CMI_AMENDN",
				action = "display&/" + "AmendmentReq" + "/" + Request;
			this._newRequestPopup.close();
			jQuery.sap.delayedCall(1000, this, function() {
				this.navigatetoCrossApp(sObject, action);
			}.bind(this));
		},
		navigatetoCrossApp: function(sObject, action) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sObject,
					action: action
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		onCloseDialog: function(oEvent) {
			this._newRequestPopup.close();
			this._deleteContexts(this.getBindingContextbyId("idClientDetails"));
			if (!oEvent.getParameter("origin")) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.backToPreviousApp();
			}
		},
		_navigateToPage: function() {
			var bClient = this.getModel("generalSettings").getProperty("/bNewClient");
			var sView = bClient ? "NCNM" : "ECNM";
			this.getRouter().navTo(sView, true);
		}

	});
});