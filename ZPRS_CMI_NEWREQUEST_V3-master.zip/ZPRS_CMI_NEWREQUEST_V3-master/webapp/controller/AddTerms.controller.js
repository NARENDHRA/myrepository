/* global myFormatter xmlToJSON PDFJS TextLayerBuilder CustomStyle getOutputScale*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"cminewrequest/controller/RequestBaseController",
	"cminewrequest/model/formatter"
], function(Controller, RequestBaseController, formatter) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView;
	return RequestBaseController.extend("cminewrequest.controller.AddTerms", {
		formatter: formatter,
		onInit: function() {
			var oc = this.getOwnerComponent();
			if (!this.getModel("generalSettings")) {
				this._createGeneralSettingsModel();
			}
			oDynamicSideView = this.getView().byId("DynamicSideContent");
			oc.getRouter().getRoute("Terms").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var CmiNo = this.CmiNo = oEvent.getParameter("arguments").Cmino,
				Cmiocgseq = oEvent.getParameter("arguments").Cmiocgseq,
				sEdit = oEvent.getParameter("arguments").editFlag,
				oFullScreen,
				oModel = this.getOwnerComponent().getModel();
		    this.selTermsContent="";
			this.getView().getModel("generalSettings").setProperty("/Edit", sEdit);
			oDynamicSideView.setShowSideContent(true);
			oFullScreen = this.byId("idExitFullScreen");
			oFullScreen.setIcon("sap-icon://full-screen");
			var sObjectPath = oModel.createKey("Cmiocgs", {
				Cmino: CmiNo,
				Cmiocgseq: Cmiocgseq
			});
			this._bindView("/" + sObjectPath);
		},
		onAfterRendering: function() {
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
		},
		handleSideContentPress: function(oEvent) {

			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				var sTermPath = this.getView().getElementBinding().getPath(),
					oFullScreen = this.byId("idExitFullScreen"),
					oSelectedTerm = this.getModel().getProperty(sTermPath);
				if (oDynamicSideView.getShowSideContent()) {
					oFullScreen.setIcon("sap-icon://full-screen");
					this.onAddTermReview(oSelectedTerm.Filecontent, 1.4);
				} else {
					oFullScreen.setIcon("sap-icon://exit-full-screen");
					this.onAddTermReview(oSelectedTerm.Filecontent, 2.2);
				}
			}
		},
		_bindView: function(sObjectPath) {
			var that = this;
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {},
					dataReceived: function(data) {
						//	 var oOcgsData = data.getParameter("data");
						//	 that.onAddTermReview(oOcgsData.Filecontent,1.4);
					}
				}
			});
			var m = this.getView().getModel();
			var oOcgsData = m.getProperty(sObjectPath);
			this.onAddTermReview(oOcgsData.Filecontent, 1.4);
		},
		afterRendering: function(oEvent) {

		},
		onAddTermReview: function(base64, scale) {
			var that = this;
			this.scaleT = scale;
			this.byId("ID_FRAME").setVisible(true);
			var tag = "<div id='pdfContainer' class='pdf-content'></div>";
			this.getView().byId("idFrame").setContent(tag);
			var $pdfContainer = jQuery("#pdfContainer");
			if ($pdfContainer) {
				$pdfContainer.empty();
				$pdfContainer.css("height", "0 px").css("width", "0 px");
			}
			jQuery.sap.delayedCall(1000, this, function() {
				function base64ToUint8Array(base64) {
					var raw = atob(base64); //This is a native function that decodes a base64-encoded string.
					var uint8Array = new Uint8Array(new ArrayBuffer(raw.length));
					for (var i = 0; i < raw.length; i++) {
						uint8Array[i] = raw.charCodeAt(i);
					}
					return uint8Array;
				}

				function renderPage(page) {
					var viewport = page.getViewport(scale);
					var $canvas = jQuery("<canvas></canvas>");
					//Set the canvas height and width to the height and width of the viewport
					var canvas = $canvas.get(0);
					var context = canvas.getContext("2d");

					var devicePixelRatio = window.devicePixelRatio || 1,
						backingStoreRatio = context.webkitBackingStorePixelRatio ||
						context.mozBackingStorePixelRatio ||
						context.msBackingStorePixelRatio ||
						context.oBackingStorePixelRatio ||
						context.backingStorePixelRatio || 1,
						auto,

						ratio = devicePixelRatio / backingStoreRatio;

					canvas.height = viewport.height * ratio;
					canvas.width = viewport.width * ratio;
					if (typeof auto === 'undefined') {
						auto = true;
					}
					var $textLayerDiv = jQuery("<div />")
						.addClass("textLayer")
						.css("height", viewport.height * ratio + "px")
						.css("width", viewport.width * ratio + "px")
						.offset({
							top: "-" + canvas.height,
							left: 0
						});

					//Append the canvas to the pdf container div
					$pdfContainer = jQuery("#pdfContainer");
					var $pdfDiv = jQuery("<div></div>");
					$pdfContainer.append($pdfDiv);
					$pdfDiv.css("height", canvas.height + "px").css("width", canvas.width + "px");
					$pdfDiv.append($canvas);

					//The following few lines of code set up scaling on the context if we are on a HiDPI display
					var outputScale = getOutputScale();
					if (outputScale.scaled) {
						var cssScale = 'scale(' + (1 / outputScale.sx) + ', ' +
							(1 / outputScale.sy) + ')';
						CustomStyle.setProp('transform', canvas, cssScale);
						CustomStyle.setProp('transformOrigin', canvas, '0% 0%');

						if ($textLayerDiv.get(0)) {
							CustomStyle.setProp('transform', $textLayerDiv.get(0), cssScale);
							CustomStyle.setProp('transformOrigin', $textLayerDiv.get(0), '0% 0%');
						}
						var oldWidth = canvas.width;
						var oldHeight = canvas.height;

						canvas.width = oldWidth * ratio;
						canvas.height = oldHeight * ratio;

						canvas.style.width = oldWidth + 'px';
						canvas.style.height = oldHeight + 'px';
						context.scale(ratio, ratio);
					}
					$pdfDiv.append($textLayerDiv);

					page.getTextContent().then(function(textContent) {
						var textLayer = new TextLayerBuilder($textLayerDiv.get(0), 0); //The second zero is an index identifying
						//the page. It is set to page.number - 1.
						textLayer.setTextContent(textContent);
						var renderContext = {
							canvasContext: context,
							viewport: viewport,
							textLayer: textLayer
						};
						page.render(renderContext);
					});
				}

				function renderPdf(pdf) {
					for (var i = 0; i < pdf.numPages; i++) {
						pdf.getPage(i + 1).then(renderPage);
					}
				}
				var pdfData = base64ToUint8Array(base64);

				function loadPdf() {
					PDFJS.disableWorker = true;
					var pdf = PDFJS.getDocument(pdfData);
					pdf.then(renderPdf);
				}
				loadPdf();

				if (!window.x) {
					var x = {};
				}
				x.Selector = {};
				x.Selector.getSelected = function() {
					var t = "";
					if (window.getSelection) {
						t = window.getSelection();
					} else if (document.getSelection) {
						t = document.getSelection();
					} else if (document.selection) {
						t = document.selection.createRange().text;
					}
					return t;
				};
				$(function() {
					$("#pdfContainer").on('selectstart', function() {
						$(window).keydown(function(e) {
							jQuery.sap.delayedCall(2000, this, function() {
								var sel = window.getSelection();
								var textBody = document.createElement("div");
								var container = jQuery("<div />").addClass("textLayers");
								container[0].appendChild(sel.getRangeAt(0).cloneContents());
								var arr = [];
								for (var i = 0; i < container[0].children.length; i++) {
									if (!arr.includes(container[0].children[i].style.top)) {
										arr.push(container[0].children[i].style.top);
									}
								}
								for (var j = 0; j < arr.length; j++) {
									var textV = document.createElement("div");
									textV.style.fontSize = "12px";
									textV.style.paddingLeft = "4px";
									var text = "";
									for (var k = 0; k < container[0].children.length; k++) {
										if (arr[j] == container[0].children[k].style.top) {
											text = text + " " + container[0].children[k].innerText;
										}
									}
									textV.append(text);
									textBody.appendChild(textV);
								}
								var containerHTML = jQuery("<div />");
								textBody.style = "width: 581.4px;";
								containerHTML[0].appendChild(textBody);
								var html = containerHTML[0].innerHTML;
								that.selTermsContent = html;
								if (!container[0].children.length) {
									that.selTermsContent = container[0].innerText;
								}

							}.bind(this));
						});
					});
				});
				$("#pdfContainer")[0].addEventListener("mouseup", function() {
					var sel = window.getSelection();
					var textBody = document.createElement("div");
					var container = jQuery("<div />").addClass("textLayers");
					container[0].appendChild(sel.getRangeAt(0).cloneContents());
					var arr = [];
					for (var i = 0; i < container[0].children.length; i++) {
						if (!arr.includes(container[0].children[i].style.top)) {
							arr.push(container[0].children[i].style.top);
						}
					}
					for (var j = 0; j < arr.length; j++) {
						var textV = document.createElement("div");
						textV.style.fontSize = "12px";
						textV.style.paddingLeft = "4px";
						var text = "";
						for (var k = 0; k < container[0].children.length; k++) {
							if (arr[j] == container[0].children[k].style.top) {
								text = text + " " + container[0].children[k].innerText;
							}
						}
						textV.append(text);
						textBody.appendChild(textV);
					}
					var containerHTML = jQuery("<div />");
					textBody.style = "width: 581.4px;";
					containerHTML[0].appendChild(textBody);
					var html = containerHTML[0].innerHTML;
					that.selTermsContent = html;
					if (!container[0].children.length) {
						that.selTermsContent = container[0].innerText;
					}
				}, false);
			});
		},
		onPressTermsClose:function(){
			window.history.back();
		}
	});

});