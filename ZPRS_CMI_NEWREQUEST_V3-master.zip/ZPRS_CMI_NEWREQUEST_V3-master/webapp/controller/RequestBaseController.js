sap.ui.define([
	"cminewrequest/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"cminewrequest/model/JsonData",
	"cminewrequest/model/formatter",
	"sap/ui/model/Filter"
], function(BaseController, JSONModel, JsonData, formatter, Filter) {
	"use strict";
	return BaseController.extend("cminewrequest.controller.RequestBaseController", {
		JsonData: JsonData,
		formatter: formatter,
		/* Create general Settings Model */
		_createGeneralSettingsModel: function() {
			var oViewData, oViewSettingsModel;
			oViewData = this.JsonData._initialJSON();
			oViewSettingsModel = new sap.ui.model.json.JSONModel(oViewData);
			this.getView().setModel(oViewSettingsModel, "generalSettings");
		},
		beforeCloseAddEditDialog: function(oEvent) {
			var oSource = oEvent.getParameter("origin");
			var oDialog = oEvent.getSource();
			var oContext = oDialog.getBindingContext();
			var sPath = oContext.getPath();
			var sDialogState = oDialog.data("bType");
			var sBtn = oSource ? oSource.data("btnType") : "";
			if (!oSource || sBtn === "CNL") {
				if (sDialogState === "Edit") {
					this.getModel().resetChanges([sPath]);
				} else {
					this._deleteContexts(oContext);
				}
			}
		},
		_resetCheckFields: function(oForm) {
			var i = oForm.getSmartFields(true);
			i.forEach(function(o) {
				o.setSimpleClientError(false);
			});
		},
		/* Begin of Client Contact */
		onpressaddContact: function(oEvent) {
			this._addoreditContact();
		},
		_addoreditContact: function(oContactctx) {
			var oContactContext = oContactctx;
			if (!this._oContact) {
				this._oContact = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.Client.clientContacts.ContactEntryForm", this);
				this.getView().addDependent(this._oContact);
			}
			if (!oContactContext) {
				this._oContact.data("bType", "Create");
				var oClient = this.getBindingContextbyId("idClientDetails");
				oClient = oClient.getObject();
				oContactContext = this._createContexts("/Cmiclntcontacts", {
					Cmino: oClient.Cmino,
					Clientk: oClient.Clientk,
					Client: oClient.Client,
					Partnertype: "CEC"
				});
			} else {
				this._oContact.data("bType", "Edit");
			}
			this._oContact.setBindingContext(oContactContext);
			this._oContact.open();
		},
		onContactEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditContact(oContext);
		},
		handleDeleteContacts: function(sPath) {
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		closeContact: function() {
			this._oContact.close();
		},
		onPressSubmitContact: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.clientContact.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oContact.close();
					//	this.getView().byId("cminewrequest.idClientContact.table_").getBinding("items").refersh(true);
					//	that._deleteContexts(that.getBindingContextbyId("cminewrequest.clientContact.form_"));
				}.bind(this),
				error: function(res) {
					this._oContact.close();

				}.bind(this)
			});
		},
		/*End of Client Contact */

		/*Begin of Known parties */
		onpressaddKnownparty: function(oEvent) {
			this._addoreditKnownparty();
		},
		_addoreditKnownparty: function(oKnownpartyctx) {
			var oKnownpartyContext = oKnownpartyctx;
			if (!this._oKnownparty) {
				this._oKnownparty = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.knownParty.KnownpartyEntryForm", this);
				this.getView().addDependent(this._oKnownparty);
			}
			if (!oKnownpartyContext) {
				this._oKnownparty.data("bType", "Create");
				var oClient = this._getHeaderContextObject("idClientDetails");
				oKnownpartyContext = this._createContexts("/Cmiknownparties", {
					Cmino: oClient.Cmino
				});
			} else {
				this._oKnownparty.data("bType", "Edit");
			}
			this._oKnownparty.setBindingContext(oKnownpartyContext);
			this._oKnownparty.open();
		},
		onKnownpartyEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditKnownparty(oContext);
		},
		onKnownpartyDelete: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		closeKnownparty: function() {
			this._oKnownparty.close();
		},
		onPressSubmitKnownparty: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.knownParty.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oKnownparty.close();
					//	this.getView().byId("cminewrequest.idClientKnownparty.table_").getBinding("items").refersh(true);
					//	that._deleteContexts(that.getBindingContextbyId("cminewrequest.clientKnownparty.form_"));
				}.bind(this),
				error: function(res) {
					this._oKnownparty.close();

				}.bind(this)
			});
		},
		/*End of Known parties */

		/* Begin of Office */
		onpressaddOffice: function() {
			this._addoreditOffice();
		},
		onOfficeEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditOffice(oContext);
		},
		closeOffice: function(oEvent) {
			this._oOffice.close();
		},
		_addoreditOffice: function(oOfficectx) {
			var oOfficeContext = oOfficectx;
			if (!oOfficeContext) {
				this._addNewOffice();
			} else {
				if (!this._oOffice) {
					this._oOffice = sap.ui.xmlfragment(this.getView().getId(),
						"cminewrequest.fragment.matterDetails.workingOffice.WorkingOfficeEntryForm", this);
					this.getView().addDependent(this._oOffice);
				}
				this._oOffice.data("bType", "Edit");
				this._oOffice.setBindingContext(oOfficeContext);
				this._oOffice.open();
			}
		},
		_addNewOffice: function() {
			if (!this._oaddOffice) {
				this._oaddOffice = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.matterDetails.workingOffice.WoOffice", this);
				this.getView().addDependent(this._oaddOffice);
			}
			this._oaddOffice.data("bType", "Create");
			this._oaddOffice.open();
		},
		closeAddOffice: function(oEvent) {
			this._oaddOffice.close();
		},
		beforeCloseAddWOOffice: function() {
			var sTable = this._oaddOffice.data().tableId;
			var oTable = this.getView().byId(sTable);
			oTable._oTable.clearSelection();
			this.byId("smartFilterBar").clear();
			oTable.rebindTable();
		},
		afterOpenCloseAddWOOffice: function() {
			var sTable = this._oaddOffice.data().tableId;
			var oTable = this.getView().byId(sTable);
			oTable._oTable.setMinAutoRowCount(8);
		},
		onPressSubmitOffice: function(evt) {
			var sTable = this._oaddOffice.data().tableId;
			var oTable = this.getView().byId(sTable),
				officeModel = this.getOwnerComponent().getModel(),
				headerData = this._getHeaderContextObject(),
				that = this,
				i18n = this.getResourceBundle();
			this.getTableOfficeSelectedData(officeModel, oTable, headerData);
			this.selectedRowIndices = oTable._oTable.getSelectedIndices();
			if (!this.selectedRowIndices.length) {
				sap.m.MessageBox.error(
					i18n.getText("PleaseSelectRow"), {}
				);
				return;
			}
			officeModel.submitChanges({
				success: function(res) {
					oTable._oTable.clearSelection();
					that._oaddOffice.close();
				},
				error: function(res) {
					sap.m.MessageBox.error(res.message, {});
				}
			});

		},
		getTableOfficeSelectedData: function(officeModel, oTable, headerData) {
			if (oTable) {
				var aIndices = oTable._oTable.getSelectedIndices();
				jQuery.each(aIndices, function(i, index) {
					var oRowData = oTable._oTable.getContextByIndex(index).getObject();
					officeModel.createEntry("/Cmimatteroffices", {
						properties: {
							Matterofficeseq: i.toString(),
							Cmino: headerData.Cmino,
							OfficeCode: oRowData.WERKS,
							OfficeName: oRowData.WERKSNAME,
							CompCode: oRowData.VKORG,
							CompanyName: oRowData.VKORGDESC,
							Country: oRowData.COUNTRY,
							CountryName: oRowData.COUNTRYNAME
						}
					});
				});
			}
		},
		onPressSubmitOffice_bk: function() {
			var oForm = this.getView().byId("cminewrequest.matter.workingOffice.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			var oModel = this.getModel();
			oModel.submitChanges({
				success: function(res) {
					this._oOffice.close();
				}.bind(this),
				error: function(res) {
					this._oOffice.close();

				}.bind(this)
			});
		},
		_MandatoryError: function() {
			var i18n = this.getResourceBundle();
			var message = i18n.getText("VALITATEFORM_TITLE_TXT");
			sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
		},
		onOfficeDelete: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		/* End of Office */

		/* Start of Internal Contacts  */
		onpressaddInternalContact: function() {
			this._addoreditInternalContact();
		},
		onInternalContactEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditInternalContact(oContext);
		},
		_addoreditInternalContact: function(oIntContactx) {
			var oIntContactContext = oIntContactx;
			if (!this._oIntContact) {
				this._oIntContact = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.matterDetails.internalContacts.InternalContactsEntryForm", this);
				this.getView().addDependent(this._oIntContact);
			}
			if (!oIntContactContext) {
				this._oIntContact.data("bType", "Create");
				var oClient = this._getHeaderContextObject("idClientDetails");
				oIntContactContext = this._createContexts("/Cmialtpayers", {
					Cmino: oClient.Cmino,
					Partnertype: "MIC"
				});
			} else {
				this._oIntContact.data("bType", "Edit");
			}
			this._oIntContact.setBindingContext(oIntContactContext);
			this._oIntContact.open();
		},
		closeInternalContact: function() {
			this._oIntContact.close();
		},
		onPressSubmitInternalContact: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.matter.internalContacts.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oIntContact.close();
				}.bind(this),
				error: function(res) {
					this._oIntContact.close();

				}.bind(this)
			});
		},
		handleDeleteInternalContacts: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		/* End of Internal Contacts  */

		/* Start of Matter Partner */
		onpressaddMatterPartner: function() {
			this._addoreditMatterPartner();
		},
		onMatterPartnerEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditMatterPartner(oContext);
		},
		_addoreditMatterPartner: function(oMatterPartnerx) {
			var oMatterPartnerContext = oMatterPartnerx;
			if (!this._oMatterPartner) {
				this._oMatterPartner = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.matterDetails.matterPartners.MatterPartnerEntryForm", this);
				this.getView().addDependent(this._oMatterPartner);
			}
			if (!oMatterPartnerContext) {
				this._oMatterPartner.data("bType", "Create");
				var oClient = this._getHeaderContextObject("idClientDetails");
				oMatterPartnerContext = this._createContexts("/Cmialtpayers", {
					Cmino: oClient.Cmino,
					Partnertype: "MP"
				});
			} else {
				this._oMatterPartner.data("bType", "Edit");
			}
			this._oMatterPartner.setBindingContext(oMatterPartnerContext);
			this._oMatterPartner.open();
		},
		closeMatterPartner: function() {
			this._oMatterPartner.close();
		},
		onPressSubmitMatterPartner: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.matter.matterPartner.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oMatterPartner.close();
				}.bind(this),
				error: function(res) {
					this._oMatterPartner.close();
				}.bind(this)
			});
		},
		handleDeleteMatterPartners: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		/* End of Matter Partner */

		/* Start of Multi Payer */
		onpressaddMultiPayer: function() {
			this._addoreditMultiPayer();
		},
		onMultiPayerEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditMultiPayer(oContext);
		},
		_addoreditMultiPayer: function(oMultiPayerx) {
			var oMultiPayerContext = oMultiPayerx;
			if (!this._oMultiPayer) {
				this._oMultiPayer = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.matterDetails.billingFinance.BillingFinanceEntryForm", this);
				this.getView().addDependent(this._oMultiPayer);
			}
			if (!oMultiPayerContext) {
				this._oMultiPayer.data("bType", "Create");
				var oClient = this._getHeaderContextObject("idClientDetails");
				oMultiPayerContext = this._createContexts("/Cmialtpayers", {
					Cmino: oClient.Cmino,
					Parvw: "PY",
					Parvwdesc: "Payer"
				});
			} else {
				this._oMultiPayer.data("bType", "Edit");
			}
			this._oMultiPayer.setBindingContext(oMultiPayerContext);
			this._oMultiPayer.open();
		},
		closeMultiPayer: function() {
			this._oMultiPayer.close();
		},
		onPressSubmitMultiPayer: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.matter.multiPayer.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oMultiPayer.close();
				}.bind(this),
				error: function(res) {
					this._oMultiPayer.close();
				}.bind(this)
			});
		},
		handleDeleteMultiPayer: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		/* End of Multi Payer */

		/* Start of Client Partner */
		onpressaddClientPartner: function() {
			this._addoreditClientPartner();
		},
		onClientPartnerEdit: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			this._addoreditClientPartner(oContext);
		},
		_addoreditClientPartner: function(oMatterPartnerx) {
			var oClientPartnerContext = oMatterPartnerx;
			if (!this._oClientPartner) {
				this._oClientPartner = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.Client.clientPartners.ClientPartnerEntryForm", this);
				this.getView().addDependent(this._oClientPartner);
			}
			if (!oClientPartnerContext) {
				this._oClientPartner.data("bType", "Create");
				var oClient = this.getBindingContextbyId("idClientDetails");
				oClient = oClient.getObject();
				oClientPartnerContext = this._createContexts("/Cmileadpartners", {
					Cmino: oClient.Cmino,
					Clientk: oClient.Clientk,
					Partnertype: "CIC"
				});
			} else {
				this._oClientPartner.data("bType", "Edit");
			}
			this._oClientPartner.setBindingContext(oClientPartnerContext);
			this._oClientPartner.open();
		},
		closeClientPartner: function() {
			this._oClientPartner.close();
		},
		onPressSubmitClientPartner: function() {
			var oModel = this.getModel();
			var oForm = this.getView().byId("cminewrequest.clientPartner.form_");
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0) {
				this._MandatoryError();
				return;
			}
			oModel.submitChanges({
				success: function(res) {
					this._oClientPartner.close();
				}.bind(this),
				error: function(res) {
					this._oClientPartner.close();
				}.bind(this)
			});
		},
		handleDeleteClientPartners: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},
		/* End of Client Partner */

		/*Start general Info */

		// get header info
		_getHeaderInfo: function() {
			// Method for geting selected clientK and CMI key from innital page
			var gModel = this.getModel("generalSettings");
			return {
				Clientk: gModel.getProperty("/oClientObj/Clientk"),
				Cmino: gModel.getProperty("/oClientObj/Cmino"),
			};
		},
		// create context
		_createContexts: function(sPath, oClientObject) {
			var oModel = this.getModel(),
				oContext = oModel.createEntry(sPath, {
					properties: oClientObject
				});
			return oContext;
		},
		// delete context
		_deleteContexts: function(oContext) {
			this.getModel().deleteCreatedEntry(oContext);
		},
		// get context by control Id
		getBindingContextbyId: function(sId) {
			var oContext = this.getView().byId(sId).getBindingContext();
			return oContext;
		},
		setBindingContextbyId: function(sId, oContext) {
			this.getView().byId(sId).setBindingContext(oContext);
		},
		_getHeaderContextObject: function(sId) {
			var v = this.getView();
			return v.getBindingContext().getObject();
		},
		_getContextObject: function(sId) {
			var bc = this.getBindingContextbyId(sId);
			var path = bc.getPath();
			var m = bc.getModel();
			return m.getProperty(path);
		},
		onPressSave: function() {
			var oModel = this.getModel();
			var oGeneralModel = this.getModel("generalSettings");
			var iStep = oGeneralModel.getProperty("/currentStep");
			var oClient = this._getHeaderContextObject("idClientDetails");
			//update considerations value
			if ((iStep === 4 && oClient.Cmirequesttype === "ECNM") || (iStep === 6 && oClient.Cmirequesttype === "NCNM")) {
				oModel.setProperty("/CmiconsiderationsN('" + oClient.Cmino + "')/Consideration", this.getQuestionData());
			}
			var that = this;
			var i18n = this.getResourceBundle();
			var oCmihdrs = this._getHeaderContextObject("idClientDetails");
			if (!$.isEmptyObject(oModel.getPendingChanges())) {
				oModel.submitChanges({
					success: function(res) {
						var msg = i18n.getText("saveButtonSuccessMessage", [oCmihdrs.Cmino]);
						sap.m.MessageBox.show(msg, {
							icon: "SUCCESS",
							title: "Success",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: function(oAction) {
								if (oAction === "YES") {

								} else {
									that.onCancelSubmit();
								}
							}
						});
					},
					error: function(res) { // delete or reset pending changes: discuss with BG

					}
				});
			} else {
				sap.m.MessageBox.show(i18n.getText("MESSAGE_TXT_NoSaveChanges"), sap.m.MessageBox.Icon.INFORMATION, "Information");
			}
		},
		onPressSubmit: function(oEvent) {
			var sPath = this.getView().getBindingContext().getPath();
			var i18n = this.getResourceBundle();
			var oCmihdrs = this._getHeaderContextObject("idClientDetails");
			var oModel = this.getModel();
			var that = this;
			var wizard = oCmihdrs.Cmirequesttype === "NCNM" ? "ncnmwizard" : "NRWizard";
			var wizardStep = oCmihdrs.Cmirequesttype === "NCNM" ? "cminewrequest.ncnm.clientInformation" :
				"cminewrequest.ecnm.clientInformation";
			var oGeneralModel = this.getModel("generalSettings");
			var iStep = oGeneralModel.getProperty("/currentStep");
			var validContactAllocation = this.handlePrimaryContact();
			if (validContactAllocation.validFlag) {
				return;
			}
			if (!this.checkMandatoryFields()) {
				return;
			}
			if ((iStep === 4 && oCmihdrs.Cmirequesttype === "ECNM") || (iStep === 6 && oCmihdrs.Cmirequesttype === "NCNM")) {
				oModel.setProperty("/CmiconsiderationsN('" + oCmihdrs.Cmino + "')/Consideration", this.getQuestionData());
			}
			this.getModel().setProperty(sPath + "/Action", "SUBM");
			if (!$.isEmptyObject(oModel.getPendingChanges())) {
				oModel.submitChanges({
					success: function(res) {
						var msg = i18n.getText("submitButtonSuccessMessage", [oCmihdrs.Cmino]);
						sap.m.MessageBox.show(msg, {
							icon: "SUCCESS",
							title: "Success",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: function(oAction) {
								if (oAction === "YES") {
									jQuery.sap.delayedCall(600, this, function() {
										var sObjectPath = oModel.createKey("Cmihdrs", {
											Cmino: oCmihdrs.Cmino,
											Matterk: "",
											Clientk: "",
											Cmirequesttype: oCmihdrs.Cmirequesttype
										});
										that._bindView("/" + sObjectPath);
										that.byId(wizard).discardProgress(that.byId(wizardStep));
									});
								} else {
									that.onCancelSubmit();
								}
							}
						});
					},
					error: function(res) { // delete or reset pending changes: discuss with BG

					}
				});
			} else {
				sap.m.MessageBox.show(i18n.getText("MESSAGE_TXT_NoSUBChanges"), sap.m.MessageBox.Icon.INFORMATION, "Information");
			}

		},
		onCancelSubmit: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: "#Shell-home"
				}
			});
		},
		_submitChanges: function(binding) {
			var oModel = this.getModel();
			if (!$.isEmptyObject(oModel.getPendingChanges())) {
				oModel.submitChanges({
					success: function(res) {
						if (binding) {
							oModel.refresh();
						}
					},
					error: function(res) { // delete or reset pending changes: discuss with BG

					}
				});
			}
		},
		// Ocg attachment
		onChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			this.oUploadCollection = oUploadCollection;
			this.initialOcgLoad = false;
			oUploadCollection.setUploadUrl("/sap/opu/odata/SAP/ZPRS_CMI_SRV/Cmiocgs");
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oUploadCollection.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var oCmihdrs = this._getHeaderContextObject("idClientDetails");
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oCmihdrs.Cmino + '|' + oEvent.getParameter("fileName") + '|' + oEvent.getParameter("fileSize")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadComplete: function(oEvent) {
			var s = oEvent.getSource();
			var ib = s.getBinding("items");
			ib.refresh();
		},
		onTypeMissmatch: function(oEvent) {
			var i18n = this.getResourceBundle(),
				msgF = i18n.getText("MESSAGE_TXT_PDFFILE");
			sap.m.MessageBox.show(msgF, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: "Error",
				actions: [sap.m.MessageBox.Action.OK]
			});
		},
		onSelectionChange: function(oEvent) {

		},
		// Begin:Considerations
		getConsiderations: function() {
			// var sPath = jQuery.sap.getModulePath("cminewrequest.model", "/ClientModel.json"),
			var oJModel = new JSONModel();
			this.getView().setModel(oJModel, "viewModel");

			//Check Consideration exists or not
			var oModel = this.getOwnerComponent().getModel();
			var oClient = this._getHeaderContextObject("idClientDetails");
			if (oClient.Cmino) {
				oModel.read("/CmiconsiderationsN('" + oClient.Cmino + "')", {
					success: function(res) {
						if (res) { //if cosiderations exists set
							this.setQuestionData(res.Consideration);
						} else {
							this._loadData();
						}
					}.bind(this),
					error: function(res) { //if consideration doesn't exists read from admin
						this._loadData();
					}.bind(this)
				});
			}
		},

		//read considerations from admin
		_loadData: function() {
			function isJSON(str) {
				try {
					JSON.parse(str);
				} catch (e) {
					return false;
				}
				return true;
			}
			var oJSONModel = this.getModel("viewModel");
			var oDataModel = this.getOwnerComponent().getModel("categories");
			oDataModel.read("/Considerations", {
				success: function(res) {
					var aResults = res.results,
						aResBC = [],
						aResRC = [];
					jQuery.each(aResults, function(i, item) {
						if (isJSON(item.Questionobject)) {
							var obj = JSON.parse(item.Questionobject);
							obj.Uniqueid = item.Uniqueid;
							if (item.Questiontypek === "BC") {
								aResBC.push(obj);
							} else if (item.Questiontypek === "RC") {
								aResRC.push(obj);
							}
						}
					});
					oJSONModel.setProperty("/BusinessQuestions", aResBC);
					oJSONModel.setProperty("/RiskQuestions", aResRC);
					this._createConsiderations(this.getQuestionData());
				}.bind(this)
			});
		},
		_createConsiderations: function(cData) {
			var oModel = this.getModel();
			var oClient = this._getHeaderContextObject("idClientDetails");
			this._createContexts("/CmiconsiderationsN", {
				Cmino: oClient.Cmino,
				Clientk: oClient.Clientk,
				Matterk: oClient.Matterk,
				Consideration: cData
			});
			oModel.submitChanges();
		},

		// Factory function
		createContentFact: function(sId, oContext) {

			//Creating form Content
			var sStyleClass = "sapUiSmallMarginTop sapUiTinyMarginBegin",
				formContent = this._getFormContent(oContext);

			//Creating List Item
			return new sap.m.CustomListItem(sId, {
				content: [
					new sap.m.HBox({
						justifyContent: "SpaceBetween",
						items: [
							new sap.m.Text({
								text: "{viewModel>QuestionText}",
								tooltip: "{viewModel>QuestionText}"

							}).addStyleClass("textBold"),
							new sap.m.Switch({
								state: "{viewModel>state}",
								customTextOn: "Yes",
								enabled: {
									path: 'generalSettings>/Edit',
									formatter: formatter.editRequestScreen
								},
								customTextOff: "No"
									//change: $.proxy(this.onChange, this)
							})
						]
					}),
					new sap.ui.layout.form.SimpleForm({
						editable: true,
						layout: "ResponsiveGridLayout",
						labelSpanXL: 3,
						labelSpanL: 3,
						labelSpanM: 3,
						labelSpanS: 12,
						adjustLabelSpan: false,
						emptySpanXL: 6,
						emptySpanL: 6,
						emptySpanM: 6,
						emptySpanS: 0,
						singleContainerFullSize: true,
						visible: "{viewModel>state}",
						content: formContent
					})
				]
			}).addStyleClass(sStyleClass);
		},
		_getFormContent: function(oContext) {
			var obj = oContext.getObject(),
				subQuestion = oContext.getProperty("subQuestion"),
				sPath = oContext.getPath(),
				formContent = [],
				that = this;
			if (subQuestion.length > 0) {
				jQuery.each(subQuestion, function(i, Quet) {
					formContent.push(new sap.m.Label({
						text: Quet.QuestionText,
						tooltip: Quet.QuestionText
					}));
					var content = that._getControl(Quet, sPath + "/subQuestion/" + i);
					formContent.push(content);
				});
			} else {
				formContent.push(new sap.m.Label({
					text: obj.AnswerText,
					tooltip: obj.AnswerText
				}));
				var content = this._getControl(obj, sPath);
				formContent.push(content);
			}

			return formContent;
		},
		_getControl: function(control, sPath) {
			var oModel = this.getModel("viewModel");
			switch (control.ControlType) {
				case "TextArea":
					return new sap.m.TextArea({
						value: '{viewModel>' + sPath + '/Answer}',
						tooltip: '{viewModel>' + sPath + '/Answer}',
						enabled: {
							path: 'generalSettings>/Edit',
							formatter: formatter.editRequestScreen
						},
						layoutData: new sap.ui.layout.GridData({
							span: "XL6 L6 M6 S12"
						})
					});
				case "Input":
					return new sap.m.Input({
						enabled: {
							path: 'generalSettings>/Edit',
							formatter: formatter.editRequestScreen
						},
						value: '{viewModel>' + sPath + '/Answer}',
						tooltip: '{viewModel>' + sPath + '/Answer}'
					});
				case "SingleSelect":
					var oBindingInfo = {
						path: sPath + "/Values",
						enabled: {
							path: 'generalSettings>/Edit',
							formatter: formatter.editRequestScreen
						},
						template: new sap.ui.core.Item({
							text: "{text}",
							key: "{text}"
						})
					};
					var oSel = new sap.m.Select({
						enabled: {
							path: 'generalSettings>/Edit',
							formatter: formatter.editRequestScreen
						},
						selectedKey: '{viewModel>' + sPath + '/Answer}',
						tooltip: '{viewModel>' + sPath + '/Answer}'
					});
					oSel.setModel(oModel);
					return oSel.bindItems(oBindingInfo);
				case "MultiSelect":
					var oBindingInfoM = {
						path: sPath + "/Values",
						template: new sap.ui.core.Item({
							text: "{text}"
						})
					};
					var oMultiCombo = new sap.m.MultiComboBox({});
					oMultiCombo.setModel(oModel);
					return oMultiCombo.bindItems(oBindingInfoM);
				case "RadioButton":
					var oBindingInfoRadio = {
						path: sPath + "/Values",
						template: new sap.m.RadioButton({
							enabled: {
								path: 'generalSettings>/Edit',
								formatter: formatter.editRequestScreen
							},
							text: "{text}"
						})
					};
					var oRadioButtonGroup = new sap.m.RadioButtonGroup({
						columns: 5
					});
					oRadioButtonGroup.setModel(oModel);
					return oRadioButtonGroup.bindButtons(oBindingInfoRadio);
			}
		},
		setQuestionData: function(encodedURIString) {
			var sModelData = decodeURIComponent(encodedURIString);
			this.getModel("viewModel").setJSON(sModelData);
			//	this.onInitializeBC();
		},
		getQuestionData: function() {
			var sModelData = this.getModel("viewModel").getJSON();
			return encodeURIComponent(sModelData);
		},
		// End:Considerations
		onPressAddTerms: function(oEvent) {
			var s = oEvent.getSource(),
				oClient = this._getHeaderContextObject(),
				oOcg = s.getBindingContext().getObject();
			this.getRouter().navTo("Terms", {
				Cmino: oOcg.Cmino,
				Cmiocgseq: oOcg.Cmiocgseq,
				editFlag: oClient.Edit
			}, false);
		},
		onPressShowCategories: function(oEvent) {
			if (!this.selTermsContent) {
				var i18n = this.getResourceBundle();
				this._errorValidValueField(i18n.getText("VALID_DOCUMENT_TERM"));
				return;
			}
			if (!this._oTermCategories) {
				this._oTermCategories = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.CategoriesList", this);
				this.getView().addDependent(this._oTermCategories);
				var oModel = this.getModel("categories");
				this._oTermCategories.setModel(oModel);
			}
			this._oTermCategories.open();
		},
		onCategoryDialogClose: function() {
			this._oTermCategories.close();
		},
		onPressSubCategorySelection: function(oEvent) {
			var oItem = oEvent.getParameter("listItem"),
				oCategory = this.getModel("categories").getProperty(oItem.getBindingContextPath()),
				sTermPath = this.getView().getElementBinding().getPath(),
				oSelectedTerm = this.getModel().getProperty(sTermPath),
				oTermsContext,
				oModel,
				sCategoryPath;

			var oTerm = this.getListContextData("idListImportedTerms", oCategory);

			if (!$.isEmptyObject(oTerm)) {
				var oTermObj = oTerm.getBindingContext().getObject();
				if (!$.isEmptyObject(oTermObj.Status)) {
					var i18n = this.getResourceBundle();
					this._errorValidValueField(i18n.getText("VALID_TERM_APPEND", [oTermObj.Status]));
					return;
				}
				var a = $.parseHTML(this.selTermsContent)[0];
				var c = oTermObj.Terms;
				var b = $.parseHTML(c)[0];
				var d = $.parseHTML(a.innerHTML);
				oTermsContext = oTerm.getBindingContext();
				oModel = oTermsContext.getModel();
				sCategoryPath = oTermsContext.getPath();
				var brk = document.createElement("br");
				b.appendChild(brk);
				for (var i = 0; i < d.length; i++) {
					b.appendChild(d[i]);
				}
				var containerHTML = jQuery("<div />");
				b.style = "width: 581.4px;";
				containerHTML[0].appendChild(b);
				var html = containerHTML[0].innerHTML;
				oModel.setProperty(sCategoryPath + "/Terms", html);
			} else {
				oTermsContext = this._createContexts("/Cmiocgterms", {});
				oModel = oTermsContext.getModel();
				sCategoryPath = oTermsContext.getPath();
				oModel.setProperty(sCategoryPath + "/Cmino", oSelectedTerm.Cmino);
				oModel.setProperty(sCategoryPath + "/Cmiocgseq", oSelectedTerm.Cmiocgseq);
				oModel.setProperty(sCategoryPath + "/Termhdrk", oCategory.Categoryid);
				oModel.setProperty(sCategoryPath + "/Termhdr", oCategory.CategoryidDesc);
				oModel.setProperty(sCategoryPath + "/Termitemk", oCategory.Subcategoryid);
				oModel.setProperty(sCategoryPath + "/Termitem", oCategory.SubcategoryidDesc);
				oModel.setProperty(sCategoryPath + "/Terms", this.selTermsContent);
			}
			this._submitChanges();
			this.selTermsContent = "";
			this._oTermCategories.close();
		},
		getListContextData: function(sTableId, oCategory) {
			var obj, termObj = {},
				oTable = this.getView().byId(sTableId);
			$.each(oTable.getItems(), function(rindex, row) {
				obj = row.getBindingContext().getObject();
				if (obj.Termhdrk === oCategory.Categoryid && obj.Termitemk === oCategory.Subcategoryid) {
					termObj = row;
				}
			});
			return termObj;
		},
		onPressTermsSave: function() {
			this._submitChanges();
		},
		onDocumentClick: function(e) {
			var k = this.byId("idAttachment").getSelectedKey();
			if (k === "CD" || k === "MD") {
				this.byId("idAttachment").data("Action", k);
				//	this.fileattachmentFilter(this.byId(k).getContent()[0], k);
			}
		},
		fileattachmentFilter: function(oList, cType) {
			var aFilters = [],
				oFinalFilterApply,
				oFilterCommentType = new sap.ui.model.Filter("Doctype", sap.ui.model.FilterOperator.EQ, cType);
			aFilters.push(oFilterCommentType);
			if (this.seqno) {
				aFilters.push(new sap.ui.model.Filter("Kpseq", sap.ui.model.FilterOperator.EQ, this.seqno));
			}
			oFinalFilterApply = new sap.ui.model.Filter(aFilters, true);
			oList.getBinding("items").filter(oFinalFilterApply);
		},
		onPostComments: function(oEvent) {
			var oClient = this._getHeaderContextObject("idClientDetails");
			var sUserComment = oEvent.getParameter("value");
			this._createContexts("/Cmicomments", {
				Cmino: oClient.Cmino,
				CommentType: "CI",
				UserComment: sUserComment
			});
			this._submitChanges();
		},
		handleDeleteComments: function(oEvent) {
			var oContext = oEvent.getParameter("listItem");
			var sPath = oContext.getBindingContextPath();
			var oModel = this.getModel();
			oModel.remove(sPath, {
				success: function(res) {

				},
				error: function(res) {

				}
			});
		},

		onPressKPConflicts: function(oEvent, oView) {
			if (!oView) {
				oView = this.getView();
			}
			var oModel,
				sTableId = oEvent.getSource().data("tableId");
			if (!this._oKPConflictReport) {
				this._oKPConflictReport = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.KPConflicts", this);
				oView.addDependent(this._oKPConflictReport);
			}
			var oTable = this.getView().byId(sTableId);
			oModel = this.getModel();
			this.KPName = oEvent.getSource().getBindingContext().getObject().Name;
			oTable.setModel(oModel);
			oTable._oTable.clearSelection();
			oTable.rebindTable();
			this._oKPConflictReport.open();
		},
		onPressCloseKPConflicts: function() {
			this._oKPConflictReport.close();
		},
		handlebeforeRebindKPConflictTable: function(OEVT) {
			var oModel = this.getView().getModel();
			var oHdr = oModel.getProperty(this.getView().getElementBinding().oElementContext.getPath());
			var oBindingParams = OEVT.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};
			oBindingParams.filters.push(new Filter("Cmino", "EQ", oHdr.Cmino));
			oBindingParams.filters.push(new Filter("Name", "EQ", this.KPName));

		},
		onPressConflictSearch: function(oEvent, oView) {
			if (!oView) {
				oView = this.getView();
			}
			this.sConflict = oEvent.getSource().data("Action");
			var oModel, oTable,
				sTableId = oEvent.getSource().data("tableId");
			if (!this._oConflictReport) {
				this._oConflictReport = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.ViewConflicts", this);
				oView.addDependent(this._oConflictReport);
			}
			oTable = this.getView().byId(sTableId);
			oModel = this.getModel("searchConflicts");

			oModel.metadataLoaded().then(function() {
				this._oConflictReport.setModel(oModel);
				oTable._oTable.clearSelection();
				oTable.rebindTable();
				this._oConflictReport.open();
			}.bind(this));
		},
		onPressCloseConflicts: function() {
			this._oConflictReport.close();
		},
		handlebeforeRebindTable: function(OEVT) {
			var oModel = this.getView().getModel();
			var oHdr = oModel.getProperty(this.getView().getElementBinding().oElementContext.getPath());
			var oBindingParams = OEVT.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};
			oBindingParams.filters.push(new Filter("Searchid", "EQ", oHdr.Searchid));
		},
		/* End of general Info */
		onChangeDocuments: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
			var oModel = this.getView().getModel();
			var oHdr = oModel.getProperty(this.getView().getElementBinding().oElementContext.getPath());
			//key = this.byId("idAttachment").data("Action"),
			var key = oUploadCollection.getParent().mProperties.key ? oUploadCollection.getParent().getProperty("key") : "KP",
				oFile = oEvent.getParameter("files")[0];
			var slug;
			if (key === "KP") {
				slug = oHdr.Cmino + "|" + oHdr.Clientk + "|" + oHdr.Matterk + "|" + oFile.name + "|" + oFile.size +
					"|" + key + "|" + " " + "|" + this.seqno;
			} else {
				slug = oHdr.Cmino + "|" + oHdr.Clientk + "|" + oHdr.Matterk + "|" + oFile.name + "|" + oFile.size +
					"|" + key;
				this.seqno = null;
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: slug
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderSlug);
		},
		handleDeleteDocuments: function(oEvent) {
			var oContext = oEvent.getParameter("item");
			var oCollection = oEvent.getSource();
			var sPath = oContext.getBindingContext().getPath();
			var i18n = this.getResourceBundle(),
				bFlagLength = false,
				that = this;
			if (that.seqno && oCollection.getItems().length === 1) {
				bFlagLength = true;
			}
			this.getModel().remove(sPath, {
				success: function(oData, oResponse) {
					sap.m.MessageToast.show(i18n.getText("MESSAGE_TXT_DELETEDDoc"));
					if (bFlagLength) {
						that.getView().byId("idKnownParty").getBinding("items").refresh();
					}
				},
				error: function(value) {
					var message = JSON.parse(value.response.body).error.message.value;
					sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			});
		},
		onUploadCompleteDocuments: function(oEvent) {
			var s = oEvent.getSource();
			var ib = s.getBinding("items");
			if (this.seqno && s.getItems().length === 0) {
				this.getView().byId("idKnownParty").getBinding("items").refresh();
			}
			ib.refresh();
		},
		onKnownPartyDocuments: function(oEvent, oView) {
			if (!oView) {
				oView = this.getView();
			}
			this.seqno = oEvent.getSource().getBindingContext().getObject().Knownpartyseq;
			if (!this._oKPDocument) {
				this._oKPDocument = sap.ui.xmlfragment(this.getView().getId(), "cminewrequest.fragment.KPDocument", this);
				oView.addDependent(this._oKPDocument);
			}
			var oUpload = this.byId("idAttachment");
			oUpload.data("Action", "KP");
			this.fileattachmentFilter(this._oKPDocument.getContent()[0], "KP");
			this._oKPDocument.open();
		},
		onKPDialogClose: function() {
			this._oKPDocument.close();
		},
		onCreateClientMatter: function() {
			var oBusy = new sap.m.BusyDialog();
			var sPath = this.getView().getBindingContext().getPath();
			var obj = this.getModel().getProperty(sPath);
			var oModel = this.getModel();
			var validContactAllocation = this.handlePrimaryContact();
			if (validContactAllocation.validFlag) {
				return;
			}
			oBusy.open();
			oModel.callFunction(
				"/CreateCmi", {
					method: "GET",
					urlParameters: {
						Cmino: obj.Cmino,
						Clientk: obj.Clientk,
						Requesttype: obj.Cmirequesttype
					},
					success: function(oData) {
						oBusy.close();
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.SUCCESS, "Success");
								}
							}
						}
					},
					error: function(oError) {
						oBusy.close();
					}
				});
		},
		onPressSubmitTerms: function(oEvent) {
			var oModel = this.getModel(),
				oSource = oEvent.getSource(),
				oSModel = oSource.getBindingContext().getModel(),
				sPath = oSource.getBindingContext().getPath(),
				viewPath = this.getView().getElementBinding().getPath(),
				ocgseq = oModel.getProperty(viewPath + "/Cmiocgseq"),
				msg, status, statusk, that = this,
				data = oEvent.getSource().getBindingContext().getObject();
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: data.Termitemk,
						Termhdrk: data.Termhdrk,
						Cmino: data.Cmino,
						Cmiocgsequence: ocgseq
					},
					success: function(oData) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									msg = oData.results[0].Message;
									statusk = msg.split("|")[0];
									status = msg.split("|")[1];
									oSModel.setProperty(sPath + "/Statusk", statusk);
									oSModel.setProperty(sPath + "/Status", status);
									//	that._submitChanges();
									if (msg.indexOf("|") !== -1) {
										sap.m.MessageBox.show(status, sap.m.MessageBox.Icon.INFORMATION, "Information");
									}
								}
							}
						}
					},
					error: function() {}
				});
		},
		addressEdit: function() {
			var iddisplay = this.byId("cminewrequest.client.displayAddress"),
				idEdit = this.byId("cminewrequest.client.editAddress");
			iddisplay.setVisible(false);
			idEdit.setVisible(true);
			var idSmartGroup = this.byId("cminewrequest.client.section_header_Address3");
			idSmartGroup.setEditMode(false);
		},
		/**
		 * Function to display address details
		 */
		addressDisplay: function() {
			var iddisplay = this.byId("cminewrequest.client.displayAddress"),
				idEdit = this.byId("cminewrequest.client.editAddress");
			iddisplay.setVisible(true);
			idEdit.setVisible(false);
			var idSmartGroup = this.byId("cminewrequest.client.section_header_Address3");
			idSmartGroup.setEditMode(true);
		},
		getTableConflictSelectedData: function(oTable) {
			var aResults = [];
			if (oTable) {
				var aIndices = oTable._oTable.getSelectedIndices();
				jQuery.each(aIndices, function(i, index) {
					var obj = oTable._oTable.getContextByIndex(index).getObject();
					if (obj.hasOwnProperty("__metadata")) {
						//		delete obj.Conflictsequenceno;
						delete obj.__metadata;
					}
					aResults.push(obj);
				});
			}
			return aResults;
		},
		onSubmitViewConflicts: function(oEvent) {
			var sTableId = oEvent.getSource().data("tableId");
			var oTable = this.getView().byId(sTableId),
				aResults = this.getTableConflictSelectedData(oTable),
				rFlag = false, // flag for checking submitted records
				conflictModel = this.getOwnerComponent().getModel(),
				headerData = this._getHeaderContextObject(),
				i18n = this.getResourceBundle();
			this.selectedRowIndices = oTable._oTable.getSelectedIndices();
			if (!this.selectedRowIndices.length) {
				sap.m.MessageBox.error(
					i18n.getText("PleaseSelectRowReview"), {}
				);
				return;
			}
			$.each(aResults, function(i, oRowData) {
				if (!oRowData.Wfstatk) {
					rFlag = true;
					oRowData.Cmino = headerData.Cmino;
					conflictModel.createEntry("/Cmigetconflicts", {
						properties: oRowData
					});
				}
			});
			if (!rFlag) {
				oTable._oTable.clearSelection();
				sap.m.MessageBox.information(
					i18n.getText("ConflictAlreadySubmitted"), {}
				);
				return;
			}
			conflictModel.submitChanges({
				success: function(res) {
					oTable._oTable.clearSelection();
					oTable.getModel().refresh(true);
					sap.m.MessageBox.success(i18n.getText("SubmittedForReview"), {});
				},
				error: function(res) {
					sap.m.MessageBox.error(res.message, {});

				}
			});
		},
		onAddressValidate: function(oEvent) {
			var data = {},
				oSource = oEvent.getSource(),
				sBtn = oSource.data("buttonName"),
				sControlId = oSource.data("conId"),
				oModel = this.getModel(),
				bAddress = true,
				that = this,
				msg = "",
				oBusy = new sap.m.BusyDialog();
			data = this.getBindingContextbyId(sControlId).getObject();
			var oForm = this.getView().byId(sControlId);
			this._resetCheckFields(oForm);
			var oErrors = oForm.check();
			if (oErrors.length > 0 && sBtn !== "save") {
				if (sBtn === "submit") {
					this.checkMandatoryFields();
				} else {
					this._MandatoryError();
				}
				return;
			}
			oBusy.open();
			oModel.callFunction(
				"/ValidateAddress", {
					method: "GET",
					urlParameters: {
						Address1: sBtn === "multiPayer" ? "" : data.Addr1,
						Address2: sBtn === "multiPayer" ? "" : (data.Addr2 || ""),
						City: sBtn === "multiPayer" ? data.Altpayercityk : data.City,
						Region: sBtn === "multiPayer" ? data.Altpayerstatek : data.Statek,
						Postalcode: sBtn === "multiPayer" ? data.Altpayerzip : data.Zipcode,
						Country: sBtn === "multiPayer" ? data.Altpayercountryk : data.Countryk,
						Billingoffice: sBtn === "multiPayer" ? "" : data.Bofficek,
						Email: sBtn === "multiPayer" ? "" : data.Email
					},
					success: function(oData, response) {
						oBusy.close();
						if (oData.results) {
							if (oData.results.length) {
								for (var i = 0; i < oData.results.length; i++) {
									if (oData.results[i].Type === "E") {
										msg += oData.results[i].Message + "\n";
										bAddress = false;
									}
								}
								if (!bAddress) {
									sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									that.onErrOfAddessValidate(sBtn);
								}
							}
						}
					},
					error: function(oError) {
						oBusy.close();
						return false;
					}
				});
		},
		onErrOfAddessValidate: function(subType) {
			switch (subType) {
				case "clientSubmit":
					this.onPressSubmitPopup();
					break;
				case "multiPayer":
					this.onPressSubmitMultiPayer();
					break;
				case "save":
					this.onPressSave();
					break;
				case "submit":
					this.onPressSubmit();
					break;
				default:
					break;
			}
		},
		valueListChangedName: function(evt) {
			var data = evt.getSource().getBindingContext().getObject(),
				source = evt.getSource(),
				model = source.getModel(),
				i18n = this.getResourceBundle(),
				message,
				sPath = source.getBindingContext().getPath(),
				sParvw = data.Parvw,
				sAlternatepayer = data.Alternatepayer,
				aFilter = [new Filter("Parvw", sap.ui.model.FilterOperator.EQ, sParvw), new Filter("Alternatepayer", sap.ui.model
					.FilterOperator
					.EQ, sAlternatepayer)],
				filesPath = "/Cmialtpayers",
				oModel = this.getModel();
			if (this.getTotalPerCent(data, "cminewrequest.matter.billindFinance.table_") >= 100 && !(data.Altpayerseq)) {
				model.setProperty(sPath + "/Firstname", "");
				message = i18n.getText("multiMaxAllocationPerc");
				this._errorValidValueField(message);
				return;
			}
			oModel.read(filesPath, {
				filters: aFilter,
				urlParameters: null,
				success: function(oData) {
					if (oData.results) {
						if (oData.results.length) {
							var obj = oData.results[0];
							model.setProperty(sPath + "/Altpayeraddr1", obj.Altpayeraddr1);
							model.setProperty(sPath + "/Altpayeraddr2", obj.Altpayeraddr2);
							model.setProperty(sPath + "/Altpayercityk", obj.Altpayercityk);
							model.setProperty(sPath + "/Altpayerstatek", obj.Altpayerstatek);
							model.setProperty(sPath + "/Altpayercountryk", obj.Altpayercountryk);
							model.setProperty(sPath + "/Altpayerphone", obj.Altpayerphone);
							model.setProperty(sPath + "/Altpayerstate", obj.Altpayerstate);
							model.setProperty(sPath + "/Altpayercountry", obj.Altpayercountry);
							model.setProperty(sPath + "/Altpayerzip", obj.Altpayerzip);
						}
					}
				},
				error: function(err) {
					var errmessage = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.show(errmessage, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
			});
		},
		//Method to check Mandatory fields
		checkMandatoryFields: function() {
			var oClient = this._getHeaderContextObject("idClientDetails"),
				bValidation = true,
				that = this;

			var aFormIDs = [
				"idClientDetails",
				"cminewrequest.matter.matterDetails.general",
				"cminewrequest.matter.Cmimatterdetails",
				"cminewrequest.matter.CmimatterBillingData",
				"cminewrequest.matter.CmimatterOutputData"
			];

			if (oClient.Cmirequesttype === "NCNM") {
				aFormIDs.push("cminewrequest.client.CmiClientGeneralData", "cminewrequest.client.CmiClientAddress");
			}

			var bVal = false;
			this._validationDialog();
			$.each(aFormIDs, function(i, sID) {
				bVal = that._checkMandatoryFieldsSmartForm(sID);
				if (!bVal) {
					bValidation = false;
				}
			});
			if (!bValidation) {
				this._oValidationDialog.open();
				that._oValidationDialog.attachAfterOpen(function() {
					$.each(aFormIDs, function(i, sID) {
						that._setValidationFormVisible(sID);
					});
				});
			}
			return bValidation;
		},

		_validationDialog: function() {
			if (!this._oValidationDialog) {
				this._oValidationDialog = sap.ui.xmlfragment(this.getView().getId(),
					"cminewrequest.fragment.ValidationForm",
					this
				);
				this.getView().addDependent(this._oValidationDialog);
				if (this._getHeaderContextObject("idClientDetails").Cmirequesttype === "ECNM") {
					this.getView().byId("cminewrequest.client.CmiClientGeneralData.valid").setVisible(false);
				}
			}
		},
		onPressOk: function() {
			this._setValueState();
			this._oValidationDialog.close();
		},

		_checkMandatoryFieldsSmartForm: function(formID) {
			var oHeaderForm = this.getView().byId(formID);
			// var	that = this;

			if (oHeaderForm.getMetadata().getName() === "sap.ui.comp.smartform.SmartForm") {
				var aErrorFields = oHeaderForm.check();

				if (aErrorFields.length === 0) {
					return true;
				} else {
					return false;
				}
			} else {
				throw "Validates only for SmartForm";
			}
		},

		_setValidationFormVisible: function(formId) {
			var oValidationForm = this.getView().byId(formId + ".valid"),
				that = this;
			if (!oValidationForm) {
				return;
			}
			if (oValidationForm.check().length > 0) {
				oValidationForm.setVisible(true);
			} else {
				oValidationForm.setVisible(false);
			}
			var aMandatoryFields = JsonData.aMandatoryFields,
				oView = this.getView();
			$.each(aMandatoryFields, function(index, val) {
				var oField = oView.byId(val + ".valid");
				if (oField) {
					oField.setValueState("None");
					oField.attachChange(that.onInputValueChange);
				}
			});
		},

		_setValueState: function() {
			var aMandatoryFields = JsonData.aMandatoryFields,
				oView = this.getView();
			$.each(aMandatoryFields, function(index, val) {
				var oField = oView.byId(val);
				if (oField) {
					oField.setValueState("None");
				}
			});
		},

		_attachChangeEventAllFields: function() {
			var aMandatoryFields = JsonData.aMandatoryFields,
				oView = this.getView(),
				that = this;
			$.each(aMandatoryFields, function(index, val) {
				var oField = oView.byId(val);
				if (oField) {
					oField.attachChange(that.onInputValueChange);
				}
			});
		},

		onInputValueChange: function(oEvent) {
			var oSrc = oEvent.getSource(),
				sPath = oSrc.getBindingContext().sPath,
				sPropertyPath = oSrc.getBindingPath("value"),
				sValue = oSrc.getValue();

			if (sValue.length === 0) {
				oSrc.getModel().setProperty(sPath + "/" + sPropertyPath, sValue);
			}
		},
		handleUpload: function() {
			var file, msgF, msg,
				oFileUpId = this.byId("fileUploader"),
				i18n = this.getResourceBundle(),
				domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					msgF = i18n.getText("MESSAGE_TXT_InvalidFile");
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file);
			}
		},
		_import: function(file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				var i18n = this.getResourceBundle();
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					//	xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show(i18n.getText("MESSAGE_TXT_InvalidExcel"), {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					if (sheetData[0].Name === undefined && sheetData[0].Notes === undefined && sheetData[0].Classification === undefined &&
						sheetData[0].Role === undefined && sheetData[0].Designation === undefined && sheetData[0].Classificationk === undefined &&
						sheetData[0].Rolek === undefined && sheetData[0].Designationk === undefined) {
						sap.m.MessageBox.show(i18n.getText("MESSAGE_TXT_InvalidExcel"), {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						return false;
					}
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i].Classification === undefined) {
							sheetData[i].Classification = "";
						}
						if (sheetData[i].Role === undefined) {
							sheetData[i].Role = "";
						}
						if (sheetData[i].Designation === undefined) {
							sheetData[i].Designation = "";
						}
						if (sheetData[i].Classificationk === undefined) {
							sheetData[i].Classificationk = "";
						}
						if (sheetData[i].Rolek === undefined) {
							sheetData[i].Rolek = "";
						}
						if (sheetData[i].Designationk === undefined) {
							sheetData[i].Designationk = "";
						}
						if (sheetData[i].Name === undefined) {
							sheetData[i].Name = "";
						}
						if (sheetData[i].Notes === undefined) {
							sheetData[i].Notes = "";
						}
					}
					that._knownPartyData(sheetData);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		/**
		 * Function to bind data for known parties
		 */
		_knownPartyData: function(newData) {
			var objArray = [],
				qtc,
				oClient = this._getHeaderContextObject(),
				data, Designation, Name, Classification, Role, Classificationk, Rolek, Designationk, obj,
				Length = newData.length;
			for (var k = 0; k < Length; k++) {
				data = newData[k];
				Designation = data.Designation.trim();
				Name = data.Name.trim();
				Classification = data.Classification.trim();
				Role = data.Role.trim();
				Classificationk = data.Classificationk.trim();
				Rolek = data.Rolek.trim();
				Designationk = data.Designationk.trim();
				obj = {
					"Cmino": oClient.Cmino,
					"Designation": Designation,
					"Knownpartyseq": k.toString(),
					"Classification": Classification,
					"Rolek": Rolek,
					"Designationk": Designationk,
					"Classificationk": Classificationk,
					"Role": Role,
					"Name": Name,
					"Comments": "",
					"Hasconflict": ""
				};
				if (Designation === "" && Name === "" && Role === "" && Classification) {
					continue;
				} else {
					objArray.push(obj);
					qtc = this.getModel();
					qtc.createEntry("/Cmiknownparties", {
						properties: obj
					});
				}
			}
			this._submitChanges();
		},
		handleSwitchChange: function(evt) {
			var source = evt.getSource(),
				path = source.getBinding("state").getPath(),
				state = evt.getParameter("state"),
				oContext = source.getBindingContext(),
				sPath = oContext.getPath(),
				oModel = oContext.getModel();
			oModel.setProperty(sPath + "/" + path, state);
		},
		handlePhoneValidation: function(evt) {
			var sPhoneValue = evt.getSource().getValue();
			var i18n = this.getResourceBundle();
			var sValue = "";
			if ($.isEmptyObject(sPhoneValue)) {
				return;
			}
			var rx = "\\d";
			if (sPhoneValue.match(rx)) {
				sValue = sPhoneValue;
			} else {
				var msg = i18n.getText("MESSAGE_TXT_ValidPhnNo");
				this._errorValidValueField(msg);
			}
			this.returnValidEntry(evt, sValue);
		},
		handleEmailValidation: function(evt) {
			var sEmailValue = evt.getSource().getValue();
			var i18n = this.getResourceBundle();
			var sValue = "";
			if ($.isEmptyObject(sEmailValue)) {
				return;
			}
			var re =
				/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if (re.test(String(sEmailValue).toLowerCase())) {
				sValue = sEmailValue;
			} else {
				var msg = i18n.getText("MESSAGE_TXT_ValidEmail");
				this._errorValidValueField(msg);
			}
			this.returnValidEntry(evt, sValue);
		},
		handleFaxValidation: function(evt) {
			var sFaxValue = evt.getSource().getValue();
			var i18n = this.getResourceBundle();
			var sValue = "";
			if ($.isEmptyObject(sFaxValue)) {
				return;
			}
			var rx = "\\d";
			if (sFaxValue.match(rx)) {
				sValue = sFaxValue;
			} else {
				var msg = i18n.getText("MESSAGE_TXT_ValidFax");
				this._errorValidValueField(msg);
			}
			this.returnValidEntry(evt, sValue);
		},
		returnValidEntry: function(evt, sValue) {
			var source = evt.getSource(),
				path = source.getBinding("value").getPath(),
				oContext = source.getBindingContext(),
				sPath = oContext.getPath(),
				oModel = oContext.getModel();
			oModel.setProperty(sPath + "/" + path, sValue);
		},
		getTableData: function(sTableId, metaInfo) {
			var aTableData = [],
				obj,
				oTable = this.getView().byId(sTableId);
			$.each(oTable.getItems(), function(rindex, row) {
				obj = row.getBindingContext().getObject();
				if (metaInfo) {
					if (metaInfo.keyFields) {
						$.extend(obj, metaInfo.keyFields);
					}
					if (metaInfo.sequence) {
						if (metaInfo.sequence.formatter) {
							obj[metaInfo.sequence.key] = metaInfo.sequence.formatter(rindex + 1);
						} else {
							obj[metaInfo.sequence.key] = rindex + 1;
						}
					}
				}
				delete(obj.__metadata);
				aTableData.push(obj);
			});
			return aTableData;
		},
		getTotalPerCent: function(client, sTableId) {
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var data = this.getTableData(sTableId);
			var percent = 0;
			data.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === client.Parvw) {
						val = oFloatFormat.format(sData.Percentage || sData.Allocation);
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
					}
				}
			});
			return percent;
		},
		checkClientType: function() {
			var aClientData = this.getTableData("cminewrequest.clientPartner.table_"),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === "ZK") {
						count++;
					}
				}
			});
			return count >= 1 ? false : true;
		},
		handleAllocationPercentage: function(oEvent) {
			var oInput = oEvent.getSource().getInnerControls()[0];
			var that = this;
			oInput.attachLiveChange(function(evt) {
				that.liveClientPercent(evt);
			});
		},
		handleAllocationPayerPercentage: function(oEvent) {
			var oInput = oEvent.getSource().getInnerControls()[0];
			var that = this;
			oInput.attachLiveChange(function(evt) {
				that.liveClientPercent(evt);
			});
		},
		handleAllocationMatterPartPercentage: function(oEvent) {
			var oInput = oEvent.getSource().getInnerControls()[0];
			var that = this;
			if (oInput.attachLiveChange) {
				oInput.attachLiveChange(function(evt) {
					that.liveClientPercent(evt);
				});
			}
		},
		changeMPOfficeDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				model.setProperty(sPath + "/OfficeCode", selData.OfficeCode);
				model.setProperty(sPath + "/OfficeName", value);
				source.getAggregation("_content").setValue(value);
				if (this.getTotalMPPerCent(source.getBindingContext().getObject()) >= 100 && (source.getBindingContext().getObject().Parvw !==
						"ZL")) {
					msg = i18n.getText("selectPert", source.getBindingContext().getObject().Parvwdesc);
					model.setProperty(sPath + "/OfficeCode", "");
					model.setProperty(sPath + "/OfficeName", "");
					model.setProperty(sPath + "/Allocation", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		changeMPTeamsDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = evt.getParameter("changes");
				model.setProperty(sPath + "/Teams", selData.Teams);
				model.setProperty(sPath + "/Teamsdesc", value);
				source.getAggregation("_content").setValue(value);
				if (this.getTotalMPPerCent(source.getBindingContext().getObject()) >= 100 && (source.getBindingContext().getObject().Parvw !==
						"ZL")) {
					msg = i18n.getText("selectPert", source.getBindingContext().getObject().Parvwdesc);
					model.setProperty(sPath + "/Teams", "");
					model.setProperty(sPath + "/Teamsdesc", "");
					model.setProperty(sPath + "/Allocation", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		getTotalMPPerCent: function(client) {
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var data = this.getTableData("cminewrequest.matter.matterPartner.table_");
			var percent = 0;
			data.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === client.Parvw && sData.OfficeName === client.OfficeName && (sData.Teams === client.Teams || sData.Teams ===
							"")) {
						val = sData.Allocation;
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
					}
				}
			});
			return percent;
		},
		liveClientPercent: function(evt) {
			var src = evt.getSource(),
				tPercent, that = this,
				val = 0,
				smartFld = src.getParent(),
				sValuepath = src.getBindingPath("value"),
				sPath = src.getBindingContext().getPath(),
				model = src.getBindingContext().getModel(),
				cData = smartFld.data(),
				sCurrValue = src.getValue().replace(/[^0-9^\.]+/g, ""),
				obj = src.getBindingContext().getObject();
			model.setProperty(sPath + "/" + sValuepath, sCurrValue);
			if (cData.evtSrc === "matterPartner") {
				tPercent = this.getTotalMPPerCent(obj);
			} else {
				tPercent = this.getTotalPerCent(obj, cData.dataTblId);
			}

			function validTotalPercent(totPerc, sCurrVal) {
				if (obj.__metadata.created) {
					val = totPerc + parseFloat(sCurrVal);
				} else {
					val = totPerc;
				}
				if ((val > 100)) {
					sCurrVal = sCurrVal.substring(0, sCurrVal.length - 1);
					model.setProperty(sPath + "/" + sValuepath, sCurrVal);
					if (cData.evtSrc === "matterPartner") {
						totPerc = that.getTotalMPPerCent(obj);
					} else {
						totPerc = that.getTotalPerCent(obj, cData.dataTblId);
					}
					validTotalPercent(totPerc, sCurrVal);
				} else {
					src.setValue(sCurrVal);
				}
			}
			validTotalPercent(tPercent, sCurrValue);
		},
		changeMatterInCurrDetails: function(evt) {
			var source = evt.getSource(),
				value = source.getValue(),
				path = source.getBindingPath("value"),
				oMatterContext = source.getBindingContext(),
				sPath = oMatterContext.getPath(),
				oMatterInModel = oMatterContext.getModel(),
				amount, str = value.replace(/[^0-9.]+/g, "");

			function count(s1, letter) {
				return (s1.match(RegExp(letter, "g")) || []).length;
			}

			function findAndReplace(string, target, replacement) {
				var i = 0,
					length = string.length;
				for (i; i < length; i++) {
					var count1 = count(string, "\\.");
					if (count1 > 1) {
						string = string.replace(target, replacement);
					}
				}
				return string;
			}
			amount = findAndReplace(str, ".", "");
			oMatterInModel.setProperty(sPath + "/" + path, amount);
			source.setValue(amount);
		},
		liveWIPPercentage: function(oEvent, sId) {
			var src = oEvent.getSource();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var sPercentValue;
			if (src.getBindingContext()) {
				var path = src.getBindingPath("value");
				var matterPath = src.getBindingContext().sPath;
				var matterModel = src.getBindingContext().getModel();
			}
			var sCurrValue = oEvent.getSource().getValue();
			sCurrValue = sCurrValue.replace(/[^0-9^\.]+/g, "");
			var validPh = /^[0-9]{0,3}\.?[0-9]{0,2}$/;
			if (sCurrValue) {
				if (sCurrValue.match(validPh)) {
					oEvent.getSource().setValue(sCurrValue);
					oEvent.getSource().setValueState("None");
				} else {
					sCurrValue = sCurrValue.substring(0, sCurrValue.length - 1);
					oEvent.getSource().setValue(sCurrValue);
				}
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, sCurrValue);
				}
			} else {
				oEvent.getSource().setValue(sCurrValue);
				oEvent.getSource().setValueState("None");
				if (src.getBindingContext()) {
					matterModel.setProperty(matterPath + "/" + path, sCurrValue);
				}
			}

			function validPercent(sCurrPercent) {
				var val = oFloatFormat.format(sCurrPercent);
				if (!val) {
					val = "0.00";
				}
				val = oFloatFormat.parse(val);
				sPercentValue = sCurrPercent;
				if (val > 100) {
					sPercentValue = sCurrPercent.substring(0, sCurrPercent.length - 1);
					matterModel.setProperty(matterPath + "/" + path, sPercentValue);
					validPercent(sPercentValue);
				} else {
					return sPercentValue;
				}
			}
			validPercent(sCurrValue);
			oEvent.getSource().setValue(sPercentValue);
			if (src.getBindingContext()) {
				matterModel.setProperty(matterPath + "/" + path, sPercentValue);
			}
		},

		onPressSubmitOcgTerms: function(oEvent) {
			var oModel = this.getModel(),
				msg, status, that = this,
				cData = oEvent.getSource().data(),
				termsListId = cData.termsListId,
				Cmino = cData.Cmino,
				ocgseq = cData.Cmiocgseq;
			oModel.callFunction(
				"/TriggerTermsWf", {
					method: "GET",
					urlParameters: {
						Termitemk: "",
						Termhdrk: "",
						Cmino: Cmino,
						Cmiocgsequence: ocgseq
					},
					success: function(oData) {
						if (oData.results) {
							if (oData.results.length) {
								if (oData.results[0].Error) {
									sap.m.MessageBox.show(oData.results[0].Message, sap.m.MessageBox.Icon.ERROR, "Error");
								} else {
									that._changeTermsDispStatus(termsListId, oData);

								}
							}
						}
					},
					error: function() {}
				});
		},
		_changeTermsDispStatus: function(termsListId, oData) { // disable submit and deletion once all terms has been posted successfully 
			var terms = this.byId(termsListId).getItems(),
				p, m,
				msg = oData.results[0].Message,
				statusk = msg.split("|")[0],
				status = msg.split("|")[1];
			terms.forEach(function(o) {
				p = o.getBindingContext().getPath();
				m = o.getBindingContext().getModel();
				if (!m.getProperty(p + "/Statusk")) {
					m.setProperty(p + "/Statusk", statusk);
					m.setProperty(p + "/Status", status);
					//	m.setProperty(p + "/expanded", "X");

				}
			});
			if (status) {
				sap.m.MessageBox.show(status, sap.m.MessageBox.Icon.INFORMATION, "Information");
			}
		},
		termsUpdateFinished: function(oEvent) {
			if (oEvent.getSource().getItems().length) {
				try {
					oEvent.getSource().getItems()[0].getContent()[0].setExpanded(true);
				} catch (e) {
					this._errorValidValueField(e.message);
				}
			}

		},
		showOcgAddterm: function(e, v) {
			if (!this.initialOcgLoad || this.initialOcgLoad === e.Cmiocgseq) {
				this.initialOcgLoad = e.Cmiocgseq;
				return true;
			} else {
				return false;
			}
		},
		// start of Client Partner dropdownlist
		samrtDpDwnCreated: function(evt) {
			this._oClientPartner.detachAfterOpen(this.attachAfterOpenDialog);
			this._oClientPartner.attachAfterOpen(evt.getSource(), this.attachAfterOpenDialog);
		},
		samrtDpDwnContactCreated: function(evt) {
			this._oContact.detachAfterOpen(this.attachAfterOpenDialog);
			this._oContact.attachAfterOpen(evt.getSource(), this.attachAfterOpenDialog);
		},
		samrtDpDwnInternalContactCreated: function(evt) {
			this._oIntContact.detachAfterOpen(this.attachAfterOpenDialog);
			this._oIntContact.attachAfterOpen(evt.getSource(), this.attachAfterOpenDialog);
		},
		samrtDpDwnMatterPartnerCreated: function(evt) {
			this._oMatterPartner.detachAfterOpen(this.attachAfterOpenDialog);
			this._oMatterPartner.attachAfterOpen(evt.getSource(), this.attachAfterOpenDialog);
		},
		samrtDpDwnMatterTypeCreated: function(evt) {
			var src = evt.getSource();
			var that = this;
			src.onAfterRendering = function() {
				that.samrtDpDwnMatter(this);
			};
		},
		samrtDpDwnMatter: function(src) {
			try {
				var dp = src.getInnerControls()[0],
					data = src.data(),
					inOutParams = JSON.parse('{' + data.inOutParams + '}');
				dp.bindAggregation("items", "/VL_SH_ZPRS_CMI_SH_MAT_TYPE_F", new sap.ui.core.Item({
					key: "{" + inOutParams.vList[0] + "}",
					text: "{" + inOutParams.vList[1] + "}"
				}));
				dp.getBinding("items")
					.filter([]);
				var oItem = src.getAggregation("_content"),
					obj = src.getBindingContext().getObject();
				oItem.setValue(obj[inOutParams.local[1]]);
			} catch (e) {
				sap.m.MessageBox.show(e.message, sap.m.MessageBox.Icon.ERROR, "Error");
			}
		},
		samrtDpDwnWIPCreated: function(evt) {
			var oControl = evt.getSource();
			var oInput = oControl.getInnerControls()[0];
			var that = this;
			if (oInput.attachLiveChange) {
				oInput.attachLiveChange(function(evt) {
					that.liveWIPPercentage(evt);
				});
			}
		},
		attachAfterOpenDialog: function(evt, src) { // binding change while converting samrt field to dropdown
			try {
				var dp = src.getInnerControls()[0],
					bi = dp.getBindingInfo("items"),
					data = src.data(),
					inOutParams = JSON.parse('{' + data.inOutParams + '}');
				dp.bindAggregation("items", bi.path, new sap.ui.core.Item({
					key: "{" + inOutParams.vList[0] + "}",
					text: "{" + inOutParams.vList[1] + "}"
				}));
				dp.getBinding("items")
					.filter(new sap.ui.model.Filter("PARTNERTYPE", sap.ui.model.FilterOperator.EQ, data.cFilterVal));

				var oItem = src.getAggregation("_content"),
					obj = src.getBindingContext().getObject();
				oItem.setValue(obj[inOutParams.local[1]]);
			} catch (e) {
				sap.m.MessageBox.show(e.message, sap.m.MessageBox.Icon.ERROR, "Error");
			}

		},
		smartDpDwnCahnge: function(evt, param) { // setting inoutparameter  while converting samrt field to dropdown
			var src = evt.getSource(),
				dp = src.getInnerControls()[0],
				i18n = this.getResourceBundle(),
				msg,
				inOutParams = JSON.parse('{' + src.data().inOutParams + '}');
			this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[0], dp.getSelectedItem().getKey());
			this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[1], dp.getSelectedItem().getText());
			if (src.data().cFilterVal === "MT") {
				this.getModel().setProperty(src.getBindingContext().getPath() + "/Zzmattercatdesc", "");
				this.getModel().setProperty(src.getBindingContext().getPath() + "/Zzmattercat", "");
			}
			if (src.data().cFilterVal === "CIC") {
				this.valueChangePartnerType(evt);
			}
			if (src.data().cFilterVal === "MP") {
				this.changeMPPTDetails(evt);
			}
			if (src.data().cFilterVal === "MIC") {
				var bcType = this.checkInternalContactPType(dp.getSelectedItem().getKey());
				if (!bcType) {
					msg = i18n.getText("existIContact", dp.getSelectedItem().getText());
					this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[0], "");
					this.getModel().setProperty(src.getBindingContext().getPath() + "/" + inOutParams.local[1], "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
				}
			}
		},
		checkInternalContactPType: function(sType) {
			var aClientData = this.getTableData("cminewrequest.matter.internalContact.table_"),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if ((sData.Parvw === "ZE" && sData.Parvw === sType) || (sData.Parvw === "ZL" && sData.Parvw === sType)) {
						count++;
					}
				}
			});
			if (this._oIntContact.data().bType === "Create") {
				return count >= 1 ? false : true;
			}
			return count > 1 ? false : true;
		},
		valueChangePartnerType: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData = source.getBindingContext().getObject(),
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				source.getAggregation("_content").setValue(value);
				if (selData.Parvw === "CS") {
					model.setProperty(sPath + "/Percentage", "0.00");
				}
				if (this.getTotalPerCent(source.getBindingContext().getObject(), "cminewrequest.clientPartner.table_") >= 100) {
					msg = i18n.getText("selectPert", value);
					model.setProperty(sPath + "/Parvw", "");
					model.setProperty(sPath + "/Parvwdesc", "");
					model.setProperty(sPath + "/Percentage", "");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
				var bcType = this.checkClientType(selData.Parvw);
				if (selData.Parvw === "ZK" && bcType) {
					model.setProperty(sPath + "/Percentage", "100");
					return;
				} else {
					model.setProperty(sPath + "/Percentage", "0.00");
				}
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		changeMPPTDetails: function(evt) {
			var source = evt.getSource(),
				model = source.getModel(),
				path = source.getBindingPath("value"),
				i18n = this.getResourceBundle(),
				value = source.getValue(),
				sPath = source.getBindingContext().getPath(),
				selData,
				msg,
				oItem = source.getAggregation("_content");
			if (oItem) {
				selData = source.getBindingContext().getObject();
				var bcType = this.checkMatterMPType(selData.Parvw);
				model.setProperty(sPath + "/Parvw", "");
				model.setProperty(sPath + "/Teams", "");
				model.setProperty(sPath + "/Teamsdesc", "");
				model.setProperty(sPath + "/Parvwdesc", "");
				model.setProperty(sPath + "/Allocation", "");
				if (!bcType) {
					msg = i18n.getText("allowMatterPart");
					oItem.setValue("");
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
				if (this.getTotalMPPerCent(selData) >= 100 && (selData.Parvw !==
						"ZL")) {
					msg = i18n.getText("selectPert", selData.Parvwdesc);
					sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.ERROR, "Error");
					return;
				}
				if (selData.Parvw === "ZL") {
					model.setProperty(sPath + "/Allocation", "100");
				}
				model.setProperty(sPath + "/Parvw", selData.Parvw);
				model.setProperty(sPath + "/Parvwdesc", value);
				oItem.setValue(value);
			} else {
				model.setProperty(sPath + "/" + path, value);
			}
		},
		checkMatterMPType: function(sType) {
			var aClientData = this.getTableData("cminewrequest.matter.matterPartner.table_"),
				count = 0;
			aClientData.filter(function(sData) {
				if (sData.Parvw) {
					if (sData.Parvw === "ZL" && sData.Parvw === sType) {
						count++;
					}
				}
			});
			if (this._oMatterPartner.data().bType === "Create") {
				return count >= 1 ? false : true;
			}
			return count > 1 ? false : true;
		},
		_createKnownParty: function() {
			if (this.getTableData("idKnownParty").length > 0) {
				return;
			}
			var oClient = this._getHeaderContextObject("idClientDetails");
			var oCnt = this.getModel().getProperty("/" + oClient.Clients.__ref);
			// Known Party
			var oKnownParty = this.JsonData._initialJSON()._KnownParty;
			oKnownParty.Name = oCnt.Client;
			oKnownParty.Cmino = oClient.Cmino;
			oKnownParty.Classification = oCnt.Classification;
			oKnownParty.Classificationk = oCnt.Classificationk;
			this._createContexts("/Cmiknownparties", oKnownParty);
		},
		_createMatterandIntPartner: function() {
			var aIntContact, oMatterPartner, oClient = this._getHeaderContextObject("idClientDetails");
			if (this.getTableData("cminewrequest.matter.internalContact.table_").length === 0) {
				aIntContact = this.JsonData._initialJSON()._InternalContact;
				for (var i = 0; i < aIntContact.length; i++) {
					var obj = aIntContact[i];
					obj.Cmino = oClient.Cmino;
					obj.Altpayerseq = i.toString();
					this._createContexts("/Cmialtpayers", obj);
				}
			}
			if (this.getTableData("cminewrequest.matter.matterPartner.table_").length === 0) {
				oMatterPartner = this.JsonData._initialJSON()._MatterPartner;
				oMatterPartner.Cmino = oClient.Cmino;
				this._createContexts("/Cmialtpayers", oMatterPartner);
			}
		},
		valueListChangedMatterQuote: function(evt) {
			try {
				this.getView().byId(evt.getSource().data().dependentField).fireValueListChanged();
			} catch (e) {
				this._errorValidValueField("function, valueListChangedMatterQuote-dependent fields auto value--->" + e.message);
			}
		},
		valueListChangedMatterLeadPartner: function(evt) {
			/*var data = evt.getSource().getBindingContext().getObject();
			this.setTableData("cminewrequest.matter.internalContact.table_", data);
			this.setTableData("cminewrequest.matter.matterPartner.table_", data);*/

			var ctxtData = evt.getSource().getBindingContext().getObject();
			var aIntContact = this.JsonData._initialJSON()._InternalContact,
				oSource = evt.getSource(),
				tblIds,
				oMatterPartner = [this.JsonData._initialJSON()._MatterPartner],
				self = this;
			this.prtnrExistForDelete = false;
			try {
				tblIds = JSON.parse(oSource.data().tableId);
				this._updatePartnerData(tblIds[0]);
				this._updatePartnerData(tblIds[1]);
				this._setDefaultPartnerData(aIntContact, ctxtData);
				this._setDefaultPartnerData(oMatterPartner, ctxtData);
			} catch (e) {
				this._errorValidValueField("function, _setDefaultPartnerData--->" + e.message);
			}
			jQuery.sap.delayedCall(1000, this, function() {
				self._submitChanges();
			});
		},
		_setDefaultPartnerData: function(srcData, ctxtData) {
			var name = ctxtData.Mma.split(" "),
				oClient = this._getHeaderContextObject("idClientDetails");
			for (var i = 0; i < srcData.length; i++) {
				var obj = srcData[i];
				obj.Cmino = oClient.Cmino;
				obj.Altpayerseq = i.toString();
				obj.OfficeName = ctxtData.Mmoffice;
				obj.OfficeCode = ctxtData.Mmofficek;
				obj.Email = ctxtData.Email;
				obj.Firstname = name[0];
				obj.Lastname = name[1] || "";
				this._createContexts("/Cmialtpayers", obj);
			}
		},
		_updatePartnerData: function(sTableId) {
			var sPath, sData,
				oTable = this.getView().byId(sTableId),
				oModel = oTable.getModel(),
				self = this;
			$.each(oTable.getItems(), function(rindex, row) {
				sPath = row.getBindingContext().getPath();
				sData = row.getBindingContext().getObject();
				if ((sData.Parvw === "ZL" && sData.Partnertype === "MIC") || (sData.Parvw === "ZE" && sData.Partnertype === "MIC") || (sData.Parvw ===
						"ZL" && sData.Partnertype === "MP")) {
					self.prtnrExistForDelete = true;
					oModel.remove(sPath);
				}
			});
		},
		onPressDeleteConfirm: function(oEvent) {
			var i18n = this.getResourceBundle(),
				oModel = this.getModel(),
				msg = i18n.getText("deleteButtonConfirmMessage"),
				oContext = oEvent.getParameter("listItem"),
				sPath = oContext.getBindingContextPath();
			sap.m.MessageBox.show(msg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirm",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function(oAction) {
					if (oAction === "YES") {
						oModel.remove(sPath, {
							success: function(res) {
								sap.m.MessageToast.show(i18n.getText("MESSAGE_TXT_DELRECORD"), {
									duration: 1000
								});
							},
							error: function(res) {

							}
						});
					}
				}.bind(this)
			});
		},
		handleDeleteTerms: function(oEvent) {
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var i18n = this.getResourceBundle(),
				oModel = this.getModel(),
				msg = i18n.getText("deleteButtonConfirmMessage");
			sap.m.MessageBox.show(msg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirm",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function(oAction) {
					if (oAction === "YES") {
						oModel.remove(sPath, {
							success: function(res) {
								sap.m.MessageToast.show(i18n.getText("MESSAGE_TXT_DeleteTerm"), {
									duration: 1000
								});
							},
							error: function(res) {

							}
						});
					}
				}.bind(this)
			});
		},
		handlePrimaryContact: function() {
			var contactSubmitData,
				i18n = this.getResourceBundle(),
				oGeneralModel = this.getModel("generalSettings"),
				iStep = oGeneralModel.getProperty("/currentStep"),
				wizard = this.byId("ncnmwizard"),
				oClient = this._getHeaderContextObject("idClientDetails"),
				tabBar = this.byId("cminewrequest.clientDetails.iconTabBar");
			var msg = "";
			var bFlag = false;
			var bContact = false;
			var validationMethod = {};
			this.ErrorMessage = [];
			if (oClient.Cmirequesttype === "NCNM" && iStep > 1) {
				contactSubmitData = this.getTableData("cminewrequest.idClientContact.table_");
				if (!(contactSubmitData.length)) {
					bFlag = true;
					bContact = true;
					this.ErrorMessage.push({
						title: "Client Contacts",
						msg: i18n.getText("MESSAGE_PRIMARY_CONTACT"),
						type: "CC",
						group: "Client Details"
					});
				}
				var validLP = this.checkValidationforLPAllocation();
				if (validLP) {
					bFlag = true;
					this.ErrorMessage.push({
						title: "Client Partners",
						msg: i18n.getText("clientAllocationPerct"),
						type: "LP",
						group: "Client Details"
					});
				}
			}
			var itemMPAllocation = this.checkValidationforMPAllocation();
			if (itemMPAllocation) {
				bFlag = true;
			}
			if (this.checkValidationforMultiAllocation()) {
				bFlag = true;
				this.ErrorMessage.push({
					title: "Multi Payer",
					msg: i18n.getText("multiAllocationPerct"),
					type: "MIP",
					group: "Billing Financial"
				});
			}
			for (var i = 0; i < this.ErrorMessage.length; i++) {
				this.ErrorMessage[i].msg = (i + 1) + ". " + this.ErrorMessage[i].msg;
			}
			validationMethod = {
				Message: msg,
				validFlag: bFlag,
				wizard: wizard,
				bContact: bContact,
				tabBar: tabBar
			};
			if (bFlag) {
				this.showMessages(validationMethod);
			}
			this.ErrorMessage = [];
			return validationMethod;
		},
		showMessages: function(validationMethod) {
			var oModel = new JSONModel();
			var that = this;
			oModel.setData(this.ErrorMessage);
			var list = new sap.m.List({
				showSeparators: "None"
			});
			var oCustomListItem = new sap.m.CustomListItem({
				content: [
					new sap.m.HBox({
						justifyContent: "SpaceBetween",
						items: [
							new sap.m.Text({
								text: "{msg}"
							}),
							new sap.m.Link({
								text: "Go to Contacts",
								visible: {
									path: 'type',
									formatter: function(value) {
										if (value === "CC") {
											return true;
										}
										return false;
									}
								},
								press: function() {
									that.oDialog.close();
									validationMethod.wizard.goToStep(validationMethod.wizard.getSteps()[1]);
									validationMethod.tabBar.setSelectedKey("CC");
									that._addoreditContact();
								}
							})
						]
					})
				]
			}).addStyleClass("sapUiSmallMarginTopBottom sapUiSmallMarginBeginEnd");
			list.bindAggregation("items", "/", oCustomListItem);
			list.setModel(oModel);
			this.oDialog = new sap.m.Dialog({
				resizable: false,
				title: "Error",
				content: list,
				state: 'Error',
				buttons: [new sap.m.Button({
					press: function() {
						this.getParent().close();
					},
					text: "Close"
				})],
				contentWidth: "600px",
				verticalScrolling: true
			});
			this.oDialog.open();
		},
		checkValidationforLPAllocation: function() {
			var oTableLPData = this.getTableData("cminewrequest.clientPartner.table_"),
				oGeneralModel = this.getModel("generalSettings"),
				oClient = this._getHeaderContextObject("idClientDetails"),
				iStep = oGeneralModel.getProperty("/currentStep"),
				oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
					decimals: 2
				}),
				val, percent = 0,
				count = 0;
			if (oClient.Cmirequesttype === "NCNM" && iStep > 1) {
				oTableLPData.filter(function(sData) {
					if (sData.Parvw === "ZK") {
						val = oFloatFormat.format(sData.Percentage);
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
						count++;
					}
				});
				if (count > 0 && percent < 100) {
					return true;
				}
			}
			return false;
		},
		checkValidationforMultiAllocation: function() {
			var oTableMultiPayer = this.getTableData("cminewrequest.matter.billindFinance.table_");
			var oGeneralModel = this.getModel("generalSettings");
			var iStep = oGeneralModel.getProperty("/currentStep");
			var oClient = this._getHeaderContextObject("idClientDetails");
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var percent = 0;
			var count = 0;
			if (oClient.Cmirequesttype === "NCNM" ? iStep > 4 : iStep > 2) {
				oTableMultiPayer.filter(function(sData) {
					if (sData.Firstname) {
						val = oFloatFormat.format(sData.Allocation);
						if (!val) {
							val = "0.00";
						}
						val = oFloatFormat.parse(val);
						percent = percent + val;
						count++;
					}
				});
				if (count > 0 && percent < 100) {
					return true;
				}
			}
			return false;
		},
		checkValidationforMPAllocation: function(rType) {
			var oGeneralModel = this.getModel("generalSettings");
			var iStep = oGeneralModel.getProperty("/currentStep");
			var oClient = this._getHeaderContextObject("idClientDetails");
			var oTableLead = this.getTableData("cminewrequest.matter.matterPartner.table_");
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimals: 2
			});
			var val;
			var object = {};
			var i18n = this.getResourceBundle();
			var bFlag = false;

			function filterAllocation(item, percent) {
				oTableLead.filter(function(sData) {
					if (sData.Parvw) {
						if (sData.Parvw === item.Parvw && sData.Teams === item.Teams && sData.OfficeCode === item.OfficeCode) {
							val = oFloatFormat.format(sData.Allocation);
							if (!val) {
								val = "0.00";
							}
							val = oFloatFormat.parse(val);
							percent = percent + val;
						}
					}
				});
				return percent;
			}
			if (oClient.Cmirequesttype === "NCNM" ? iStep > 4 : iStep > 2) {
				for (var i = 0; i < oTableLead.length; i++) {
					var item = oTableLead[i];
					var percent = 0;
					var totPercent = filterAllocation(item, percent);
					var itemString = item.Parvw + "" + item.OfficeName + "" + item.Teams;
					if (totPercent < 100 && object[itemString] === undefined) {
						if (item.Teamsdesc) {
							this.ErrorMessage.push({
								msg: i18n.getText("msgmatrpartAllocationPerct", [item.Parvwdesc, item.OfficeName,
									item.Teamsdesc
								]),
								type: "MP",
								title: "Matter Partners - Partner Type : " + item.Parvwdesc,
								group: "Matter Partners"
							});
						} else {
							this.ErrorMessage.push({
								msg: i18n.getText("msgmatrpartAllocationMPerct", [item.Parvwdesc, item.OfficeName]),
								type: "MP",
								title: "Matter Partners - Partner Type : " + item.Parvwdesc,
								group: "Matter Partners"
							});
						}
						bFlag = true;
					}
					object[itemString] = itemString;
				}
			}
			return bFlag;
		},
		// end of Client Partner dropdownlist
		_errorValidValueField: function(message) {
				sap.m.MessageBox.show(message, sap.m.MessageBox.Icon.ERROR, "Error");
			}
			/* page events*/
			/*onExit: function(oEvent) {
				var oModel = this.getModel();
				var that = this;
				if (!$.isEmptyObject(oModel.getPendingChanges())) {
					sap.m.MessageBox.show("Would you like to save pending changes?", {
						icon: "WARNING",
						title: "Pending Changes",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction === "YES") {
								that._submitChanges();
							}
						}
					});
				}
			}*/
	});

});