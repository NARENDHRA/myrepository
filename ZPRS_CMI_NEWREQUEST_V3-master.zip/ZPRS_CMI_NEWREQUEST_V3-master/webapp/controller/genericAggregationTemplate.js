/*globals XLSX xmlToJSON*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"cminewrequest/model/formatter",
	"sap/ui/comp/smartfield/SmartField"
], function(Controller, formatter, SmartField) {
	"use strict";
	return Controller.extend("cminewrequest.controller.genericAggregationTemplate", {
		templateKnownParties: function() {
			var addButton = new sap.m.Button({
				icon: "sap-icon://add",
				text: "",
				type: "Emphasized",
				press: this.showAddKnownPartyPopup.bind(this)
			});
			var oTemplate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{Name}"
					}),
					new SmartField({
						value: "{Classification}"
					}),
					new SmartField({
						value: "{Role}"
					}),
					new SmartField({
						value: "{Designation}"
					}),
					new sap.m.Button({
						icon: "sap-icon://bell",
						type: "Reject"
					}),
					new sap.m.Button({
						icon: "sap-icon://message-popup",
						type: "{=${Comments} ? 'Emphasized':'Default'}"
					}),
					new sap.m.Button({
						icon: "sap-icon://attachment",
						type: "Default"
					}),
					addButton
				]
			});
			oTemplate.addButton = addButton;
			return oTemplate;
		},
		templateContacts: function(e) {
			var oColumnListItem = new sap.m.ColumnListItem({
				cells: [
					new sap.ui.comp.smartfield.SmartField({
						value: "{Contacttypedesc}"
					}),
					new sap.m.HBox({
						justifyContent: "SpaceBetween",
						items: [new sap.ui.comp.smartfield.SmartField({
								value: "{Firstname}",
								placeholder: "First Name"
							}),
							new sap.ui.comp.smartfield.SmartField({
								value: "{Lastname}",
								placeholder: "Last Name"
							})
						]
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Functiondesc}"
					}),
					new sap.m.MaskInput({
						value: "{Phone}",
						mask: "999999999999999",
						placeholderSymbol: " "
					}),
					new sap.ui.comp.smartfield.SmartField({
						value: "{Email}"
					})
				]
			});
			return oColumnListItem;
		}
	});

});