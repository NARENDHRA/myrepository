sap.ui.define([
	"cminewrequest/controller/RequestBaseController"
], function(RequestBaseController) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView;
	return RequestBaseController.extend("cminewrequest.controller.NCNM", {

		onInit: function() {
			window.that = this;
			var oc = this.getOwnerComponent();
			oc.getRouter().getRoute("NCNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("CmiReviewNCNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReqNCNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReviewNCNM").attachPatternMatched(this._onObjectMatched, this);

			if (!this.getModel("generalSettings")) {
				this._createGeneralSettingsModel();
			}
			var oGeneral = this.getModel("generalSettings");
			oGeneral.setProperty("/bClientSubmitButton", true);
			oGeneral.setProperty("/clientValueHelp", false);
		},
		_onObjectMatched: function(oEvent) {
			var CmiNo = this.CmiNo = oEvent.getParameter("arguments").Cmino,
				oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: CmiNo,
					Matterk: "",
					Clientk: "",
					Cmirequesttype: "NCNM"
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));

		},
		onAfterRendering: function() {
			oDynamicSideView = this.getView().byId("ncnmDynamicSideContent");
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			jQuery.sap.delayedCall(2000, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterNCNM").getDomRef().getBoundingClientRect().top,
					tablePositionTop = this.byId("ncnmwizard").getDomRef().getBoundingClientRect().top,
					scrollHeight = window.innerHeight - tablePositionTop - footerHeight - 0;
				this.byId("ncnmwizard").setHeight(String(scrollHeight + "px"));
				this._attachChangeEventAllFields();
				this.fileattachmentFilter(this.byId("CD").getContent()[0], "CD");
				this.fileattachmentFilter(this.byId("MD").getContent()[0], "MD");
			}.bind(this));
		},
		handleSideContentPress: function(oEvent) {
			var i18n = this.getResourceBundle(),
				docBtn = this.getView().byId("btnSideCtntDoc"),
				defaultTab = oEvent.getSource().data("defTab"),
				cmntBtn = this.getView().byId("btnSideCtntCmnt");
			this.getView().byId("idAttachment").setSelectedKey(defaultTab);
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					docBtn.setVisible(false);
					cmntBtn.setIcon("sap-icon://hide");
					cmntBtn.setTooltip(i18n.getText("Hide"));
				} else {
					docBtn.setVisible(true);
					cmntBtn.setIcon("sap-icon://post");
					cmntBtn.setTooltip(i18n.getText("ShowCommets_BTN_TXT"));
				}
			}
		},
		handleSteps: function(oEvt) {
			var oCmihdrs = this._getHeaderContextObject("idClientDetails");
			var oModel = this.getModel();
			var oGeneralModel = this.getModel("generalSettings");
			oGeneralModel.setProperty("/currentStep", oEvt.getParameter("index"));
			if (!oCmihdrs.Clientdetails.__ref && oEvt.getParameter("index") === 2) {

				oModel.createEntry("/Cmiclientdetails", {
					properties: {
						Cmino: oCmihdrs.Cmino,
						Clientk: oCmihdrs.Clientk
					}
				});
				var c = this.getView().byId("idClientDetails");
				this._submitChanges(c.getElementBinding());
				return;
			}
			if (oEvt.getParameter("index") === 2) {
				var idSmartGroup = this.byId("cminewrequest.client.section_header_Address3");
				idSmartGroup.setEditMode(false);
			}
			if (!oCmihdrs.Knownparties.__ref && oEvt.getParameter("index") === 3) {
				this._createKnownParty();
				this._submitChanges();
				return;
			}
			if (!oCmihdrs.Matters.__ref && oEvt.getParameter("index") === 5) {
				oModel.createEntry("/Cmimatters", {
					properties: {
						Cmino: oCmihdrs.Cmino,
						Matter: oCmihdrs.Matterk
					}
				});
				//,Matter: oCmihdrs.Matterk
				oModel.createEntry("/Cmimatterdetails", {
					properties: {
						Cmino: oCmihdrs.Cmino,
						Matter: oCmihdrs.Matterk
					}
				});
				var matterInfo = this.getView().byId("cminewrequest.matter.Cmimatterdetails");
				var matterGeneral = this.getView().byId("cminewrequest.matter.section_header_gen1");
				this._submitChanges(matterGeneral.getElementBinding());
				matterInfo.getElementBinding().refresh();
				return;
			}
			if (!oCmihdrs.ConsiderationsN.__ref && oEvt.getParameter("index") === 6) {
				this.getConsiderations();
				return;
			} else if (oCmihdrs.ConsiderationsN.__ref && oEvt.getParameter("index") === 6) {
				this.setQuestionData(oCmihdrs.ConsiderationsN.Consideration);
			}
			this._submitChanges();
		},
		_bindView: function(sObjectPath) {
			var that = this;
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						//that.getView().setProperty("/busy", true);
					},
					dataReceived: function(data) {
						that.getView().getModel("generalSettings").setProperty("/Edit", data.getParameter("data").Edit);
					}
				}
			});

		}
	});

});