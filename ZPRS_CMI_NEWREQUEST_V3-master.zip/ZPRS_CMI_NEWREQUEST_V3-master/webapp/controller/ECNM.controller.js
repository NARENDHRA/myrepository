sap.ui.define([
	"cminewrequest/controller/RequestBaseController",
	"cminewrequest/model/JsonData"
], function(RequestBaseController, JsonData) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView;
	return RequestBaseController.extend("cminewrequest.controller.ECNM", {
		JsonData: JsonData,
		onInit: function() {
			var oc = this.getOwnerComponent();
			oc.getRouter().getRoute("ECNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("CmiReviewECNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReqECNM").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReviewECNM").attachPatternMatched(this._onObjectMatched, this);
			if (!this.getModel("generalSettings")) {
				this._createGeneralSettingsModel();
			}
			var oGeneral = this.getModel("generalSettings");
			oGeneral.setProperty("/bClientSubmitButton", true);
			oGeneral.setProperty("/clientValueHelp", true);
		},
		onAfterRendering: function() {
			oDynamicSideView = this.getView().byId("ecnmDynamicSideContent");
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			jQuery.sap.delayedCall(2000, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterECNM").getDomRef().getBoundingClientRect().top,
					tablePositionTop = this.byId("NRWizard").getDomRef().getBoundingClientRect().top,
					scrollHeight = window.innerHeight - tablePositionTop - footerHeight - 0;
				this.byId("NRWizard").setHeight(String(scrollHeight + "px"));
				this._attachChangeEventAllFields();
				this.fileattachmentFilter(this.byId("CD").getContent()[0], "CD");
				this.fileattachmentFilter(this.byId("MD").getContent()[0], "MD");
			}.bind(this));

		},
		handleSideContentPress: function(oEvent) {
			var i18n = this.getResourceBundle(),
				docBtn = this.getView().byId("btnSideCtntDoc"),
				defaultTab = oEvent.getSource().data("defTab"),
				cmntBtn = this.getView().byId("btnSideCtntCmnt");
			this.getView().byId("idAttachment").setSelectedKey(defaultTab);
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					docBtn.setVisible(false);
					cmntBtn.setIcon("sap-icon://hide");
					cmntBtn.setTooltip(i18n.getText("Hide"));
				} else {
					docBtn.setVisible(true);
					cmntBtn.setIcon("sap-icon://post");
					cmntBtn.setTooltip(i18n.getText("ShowCommets_BTN_TXT"));
				}
			}
		},
		_onObjectMatched: function(oEvent) {
			var CmiNo = this.CmiNo = oEvent.getParameter("arguments").Cmino,
				oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: CmiNo,
					Matterk: "",
					Clientk: "",
					Cmirequesttype: "ECNM"
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));

		},
		_bindView: function(sObjectPath) {
			var that = this;
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						//that.getView().setProperty("/busy", true);
					},
					dataReceived: function(data) {
						//that.getView().setProperty("/busy", false);
						that.getView().getModel("generalSettings").setProperty("/Edit", data.getParameter("data").Edit);
					}
				}
			});
		},
		handleSteps: function(oEvt) {
			var oCmihdrs = this._getHeaderContextObject("idClientDetails");
			//var oGenereal = this._getContextObject("cminewrequest.matter.matterDetails.general");
			// if matter is not created and its a matter creation step
			var oGeneralModel = this.getModel("generalSettings");
			oGeneralModel.setProperty("/currentStep", oEvt.getParameter("index"));
			if (!oCmihdrs.Knownparties.__ref && oEvt.getParameter("index") === 2) {
				this._createKnownParty();
				this._submitChanges();
				return;
			}
			if (!oCmihdrs.Matters.__ref && oEvt.getParameter("index") === 3) {
				var oModel = this.getModel();
				oModel.createEntry("/Cmimatters", {
					properties: {
						Cmino: oCmihdrs.Cmino,
						Matter: oCmihdrs.Matterk
					}
				});
				//,Matter: oCmihdrs.Matterk
				oModel.createEntry("/Cmimatterdetails", {
					properties: {
						Cmino: oCmihdrs.Cmino,
						Matter: oCmihdrs.Matterk
					}
				});
				var matterInfo = this.getView().byId("cminewrequest.matter.Cmimatterdetails");
				var matterGeneral = this.getView().byId("cminewrequest.matter.section_header_gen1");
				this._submitChanges(matterGeneral.getElementBinding());
				matterInfo.getElementBinding().refresh();

				return;
			}
			if (!oCmihdrs.ConsiderationsN.__ref && oEvt.getParameter("index") === 4) {
				this.getConsiderations();
				return;
			}
			this._submitChanges();
		}
	});

});