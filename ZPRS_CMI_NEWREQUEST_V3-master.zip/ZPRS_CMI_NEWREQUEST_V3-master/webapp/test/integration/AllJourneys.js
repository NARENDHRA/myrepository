jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"cminewrequest/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"cminewrequest/test/integration/pages/Worklist",
		"cminewrequest/test/integration/pages/Object",
		"cminewrequest/test/integration/pages/NotFound",
		"cminewrequest/test/integration/pages/Browser",
		"cminewrequest/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cminewrequest.view."
	});

	sap.ui.require([
		"cminewrequest/test/integration/WorklistJourney",
		"cminewrequest/test/integration/ObjectJourney",
		"cminewrequest/test/integration/NavigationJourney",
		"cminewrequest/test/integration/NotFoundJourney",
		"cminewrequest/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});