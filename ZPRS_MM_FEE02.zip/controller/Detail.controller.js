/*global location */
sap.ui.define([
	"feebillcollect/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"feebillcollect/model/formatter",
	"sap/ui/model/Filter"
], function(BaseController, JSONModel, formatter, Filter) {
	"use strict";

	return BaseController.extend("feebillcollect.controller.Detail", {

		formatter: formatter,

		onInit: function() {

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			// this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = "/" + sObjectId;
				var obj = this.getModel().getContext(sObjectPath).getObject();
				var sPath = "/Feedetails02(Ovptype='" + obj.Ovptype + "',Timeperiod='" + obj.Timeperiod + "',Clientk='" + obj.Clientk +
					"',Parvw='" + obj.Parvw + "',Currency='" + obj.Currency + "',Pernrk='" + obj.Pernrk + "')";
				this.sPath = sPath;
				this.filterobj = obj;
				this._bindView(sPath);
				this._CreatMatterDetTablecontextPath(sPath);
			}.bind(this));
		},
		_CreatMatterDetTablecontextPath: function(sPath) {
			var tableLog = this.getView().byId("SmartFeeMatterDetailTable");
			//tableLog.bindContext("items").setProperty("tableBindingPath", sPath + "/GetClient2Matterfeedetail");
			tableLog.rebindTable(true);
		},
		onBeforeRebindTable: function(oEvent) {
			// var aGlbFilter = this.getModel("appView").getProperty("/filters");
			// var aFilter = oEvent.getParameter('bindingParams').filters || [];
			// oEvent.getParameter('bindingParams').filters = aFilter.concat(aGlbFilter);

			var aGlbFilter = this.getModel("appView").getProperty("/filters"),
				bp = oEvent.getParameter("bindingParams");

			var aFilter = bp.filters || [];
			aFilter.push(
				new Filter("Clientk", "EQ", this.filterobj.Clientk),
				new Filter("Parvw", "EQ", this.filterobj.Parvw),
				new Filter("Currency", "EQ", this.filterobj.Currency),
				new Filter("Pernrk", "EQ", this.filterobj.Pernrk),
				new Filter("Timeperiod", "EQ", this.filterobj.Timeperiod));
			bp.filters = aFilter;

			// var oSrc = oEvent.getSource();
			// oSrc.setTableBindingPath(this.sPath + "/GetClient2Matterfeedetail");
		},
		_bindView: function(sPath) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/busy", false);
			this.getView().bindElement({
				path: sPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
			//this.getView().setBindingContext(this.getModel().getContext(sObjectPath)).getObject();
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				// this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				return;
			}
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		/**
		 * Set the full screen mode to false and navigate to master page
		 */
		onCloseDetailPress: function() {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("master");
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function() {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		}
	});

});