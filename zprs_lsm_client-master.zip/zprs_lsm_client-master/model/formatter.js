jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		formatDate: function(iValue, millisec) {
			var value1;
			if (!iValue) {
				return null;
			} else {
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
					style: "short"
				});
				value1 = oDateFormat.format(iValue);
				return value1;
			}
		},
		SeTStatusIcon: function(isError) {
			if (isError === "S") {
				return "sap-icon://message-success";
			} else if (isError === "E") {
				return "sap-icon://message-error";
			} else if (isError === null || isError === undefined) {
				return "";
			}
		},
		SeTStatusIconColor: function(isError) {
			if (isError === "S") {
				return "Green";
			} else if (isError === "E") {
				return "Red";
			} else if (isError === null || isError === undefined) {
				return "";
			}
		},

		// Color Change based on status in my work bench Fragment
			statusColorChange: function(sValue) {
			if (sValue === "New") {
				return "Warning";
			}
			if (sValue === "Approved") {
				return "Success";
			}
			if (sValue === "Approved with Scope Change") {
				return "Error";
			}
			if (sValue === "04") {
				return "Warning";
			}
			if (sValue === "05") {
				return "Error";
			}
		},
		statusTextChange: function(sValue) {
			if (sValue === "01") {
				return "Pending";
			}
			if (sValue === "02") {
				return "Approved";
			}
			if (sValue === "03") {
				return "Rejected";
			}
			if (sValue === "04") {
				return "In Process";
			}
			if (sValue === "05") {
				return "Hold Budget";
			}
		},
		statusColorChangePay: function(sValue) {
			if (sValue === "01") {
				return "Success";
			}
			if (sValue === "02") {
				return "Warning";
			}
			if (sValue === "03") {
				return "Warning";
			}
			if (sValue === "04") {
				return "Error";
			}

		},
		// Color Change based on status in my work bench Detail Page
		statusColorChangeInWBdetail: function(sValue) {
			if (sValue === "SUCCESS") {
				return "Success";
			}
		},

		statusColorChangeMB: function(sValue) {
			if (sValue === "New") {
				return "None";
			}
			if (sValue === "Approved with Scope Change") {
				return "Warning";
			}
			if (sValue === "Approved") {
				return "Success";
			}
		},

		statusColorTimeKeeper: function(sValue) {

			if (sValue === "A") {
				return "Success";
			}
			if (sValue === "P") {
				return "Warning";
			}
		},
		textChangeTimeKeeper: function(sValue) {

			if (sValue === "A") {
				return "Approved";
			}
			if (sValue === "P") {
				return "Pending";
			}
		}

	};

});