sap.ui.define([
	"lsmclient/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmclient/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("lsmclient.controller.lsmClient1", {
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// this.getView().setBusy(true);
			this.bServiceFlag = true;
			this.bTimeKeeperServiceFlag = true;
			var jsonModel = new sap.ui.model.json.JSONModel({
				"MyDashboard": true,
				"MyWorkbench": false,
				"ManageBudget": false,
				"TimeKeeperRate": false,
				"MyMatter": false,
				"MatterSummary": false,
				"ZzpymtDoc": false,
				"ExchangeRates": false,
				"Reports": false,
				Bukrs: true,
				Gjahr: true,
				Werks: true,
				Hkont: true,
				Status: true,
				RecordType: true,
				Posid: true,
				oZzrejComments: "",
				addBtnIsEnable: false,
				Sequence: true,
				FileTypeC: true
			}, true);
			this.getView().setModel(jsonModel, "JsonKey");

			var JsonModelButton = new JSONModel({
				"Print": false,
				"Accept": false,
				"Approve": false,
				"Reject": false,
				"UploadAttc": false,
				"Save": false,
				"invStatus": true,
				"payStatus": false,
				"MBApprove": false,
				Pending: 0,
				Approved: 0,
				Rejected: 0,
				InProcess: 0,
				HoldBudget: 0,
				Paid: 0,
				Processed: 0,
				ApprovedPayment: 0,
				Faild: 0
			}, true);
			this.getView().setModel(JsonModelButton, "JModelButton");

			var sideNavigation,
				oViewModel,
				iOriginalBusyDelay;

			/*	sideNavigation = this.getView().byId('sideNavigation');
				//var expanded = !sideNavigation.getExpanded();
				sideNavigation.setExpanded(false);*/

			this._oTableSearchState = [];

			//this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			this._oTableSearchState = [];

			this.pendingAndHoldBudgetTab(); // function calling for displaying button in footer 
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText")
					//	tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			this.getRouter().getRoute("lsmClient1").attachPatternMatched(this._onObjectMatched, this);

			this.sideKey = "";
			this._mFilters = {
				"pending": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "01")],
				"inProcess": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "04")],
				"approved": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "02")],
				"rejected": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "03")],
				"holdBudget": [new sap.ui.model.Filter("ZzinvStatus", "EQ", "05")],
				"paid": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "01")],
				"processed": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "02")],
				"approvedPayment": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "03")],
				"faild": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "04")]

			};
			this.oDataModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			this.oDataModelf = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV/");
			//	this._showFormFragment("MyDashboard");
			// this.getView().setBusy(false);
		},
		onMBApproveAction: function(evt) {
			var oSmtTable = this.getView().byId("idManageBudgetSubSection").getBlocks()[0].byId("ManBudgetSTable"),
				tbl = oSmtTable.getTable();
			var aIndices = tbl.getSelectedIndices();
			var mPlsSelOneMatr = "Select atleast one LineItem";
			if (aIndices.length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatr, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			var oAmount = [],
				oBukrs = [],
				oCurrency = [],
				oGjahr = [],
				oHkont = [],
				oPosid = [],
				oPspid = [],
				oOffice = [],
				oVendor = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var ctx = tbl.getContextByIndex(index),
					obj = ctx.getObject();
				oAmount.push(obj.Amount);
				oBukrs.push(obj.Bukrs);
				oCurrency.push(obj.Currency);
				oGjahr.push(obj.Gjahr);
				oHkont.push(obj.Hkont);
				oPosid.push(obj.Posid);
				oPspid.push(obj.Pspid);
				oVendor.push(obj.Vendor);
				oOffice.push(obj.Werks);
			});
			var oUrlParams = {
				Amount: oAmount,
				Bukrs: oBukrs,
				Currency: oCurrency,
				Gjahr: oGjahr,
				Hkont: oHkont,
				Posid: oPosid,
				Pspid: oPspid,
				Vendor: oVendor,
				Werks: oOffice
			};
			this.oDataModel1.callFunction("/BudgetApprove", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					var smg = oData.results[0].Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getModel().refresh();
					tbl.setBusy(false);
				},
				error: function(oError) {
					var sEmsg = "Error while Uploading";
					sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}
			});
			tbl.clearSelection();
		},
		onApproveAction: function(evt) {
			var oSmtTable = this.getView().byId("MyWorkBenchSTable"),
				tbl = oSmtTable.getTable();
			var aIndices = tbl.getSelectedContexts();
			var mPlsSelOneMatr = "Select atleast one LineItem";
			if (aIndices.length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatr, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			var oInvoiceNoArray = [],
				oStatusArray = [],
				oFileType = [],
				oSeqnrNo = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedItems(), function(i, index) {
				var obj = index.getBindingContext().getObject();
				oInvoiceNoArray.push(obj.ZzinvoiceNumber);
				oFileType.push(obj.Zzfiletype);
				oSeqnrNo.push(obj.Zzseqnr);
			});
			var oUrlParams = {
				Zzfiletype: oFileType,
				ZzinvoiceNumber: oInvoiceNoArray,
				Zzseqnr: oSeqnrNo
			};
			this.oDataModelf.callFunction("/ApproveInvoice", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					var smg = oData.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getModel().refresh();
					tbl.setBusy(false);
				},
				error: function(oError) {
					var sEmsg = oError.Message;
					sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}
			});
			tbl.removeSelections();
		},
		onAcceptInvoice: function(evt) {
			var oSmtTable = this.getView().byId("MyWorkBenchSTable"),
				tbl = oSmtTable.getTable();
			var aIndices = tbl.getSelectedContexts();
			var mPlsSelOneMatr = "Select atleast one LineItem";
			if (aIndices.length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatr, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			var oInvoiceNoArray = [],
				oStatusArray = [],
				oFileType = [],
				oSeqnrNo = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedItems(), function(i, index) {
				var obj = index.getBindingContext().getObject();
				oInvoiceNoArray.push(obj.ZzinvoiceNumber);
				oStatusArray.push("04");
				oFileType.push(obj.Zzfiletype);
				oSeqnrNo.push(obj.Zzseqnr);
			});
			var oUrlParams = {
				Status: oStatusArray,
				Zzfiletype: oFileType,
				ZzinvoiceNumber: oInvoiceNoArray,
				Zzseqnr: oSeqnrNo
			};
			this.oDataModelf.callFunction("/AcceptPending", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					var smg = oData.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getModel().refresh();
					tbl.setBusy(false);
				},
				error: function(oError) {
					var sEmsg = oError.Message;
					sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}
			});
			tbl.removeSelections();
		},

		onRejectPress: function(oEvt) {
			var src = oEvt.getSource();
			var fragPath = "lsmclient.fragment.Comment";
			if (!this.oQuick) {
				this.oQuick = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.oQuick);
			}
			var oSmtTable = this.getView().byId("MyWorkBenchSTable"),
				tbl = oSmtTable.getTable();
			var aIndices = tbl.getSelectedContexts();
			var mPlsSelOneMatr = "Select atleast one LineItem";
			if (aIndices.length === 0) {
				sap.m.MessageBox.show(mPlsSelOneMatr, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			this.oQuick.open();
		},
		onMultiComment: function(oEvt) {
			this.getModel("JsonKey").setProperty("/addBtnIsEnable", oEvt.getParameter("value") !== "");
		},
		onCancelPress: function(evt) {
			this.oQuick.close();
			var oViewModel = this.getView().getModel("JsonKey"),
				oNewComments = oViewModel.setProperty("/NewComments", "");
		},
		handleRejectpress: function(evt) {
			var oSmtTable = this.getView().byId("MyWorkBenchSTable"),
				tbl = oSmtTable.getTable();
			var oViewModel = this.getView().getModel("JsonKey"),
				oNewComments = oViewModel.getProperty("/NewComments");
			var oInvoiceNoArray = [],
				oFileType = [],
				oSeqnrNo = [];
			tbl.setBusy(true);
			$.each(tbl.getSelectedItems(), function(i, index) {
				var obj = index.getBindingContext().getObject();
				oInvoiceNoArray.push(obj.ZzinvoiceNumber);
				oFileType.push(obj.Zzfiletype);
				oSeqnrNo.push(obj.Zzseqnr);
			});
			var oUrlParams = {
				ZzComments: oNewComments,
				Zzfiletype: oFileType,
				ZzinvoiceNumber: oInvoiceNoArray,
				Zzseqnr: oSeqnrNo
			};
			this.oDataModelf.callFunction("/RejectInvoice", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					var smg = oData.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.setBusy(false);
					tbl.getModel().refresh();
				},
				error: function(oError) {
					var sEmsg = oError.Message;
					sap.m.MessageBox.show(sEmsg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}
			});
			this.oQuick.close();
			tbl.removeSelections();

		},
		press: function(evt) {
			var objectPageSectionId = evt.getSource().sDirectSectionId.split("--")[2];
			this.sideKey = objectPageSectionId;
			this.oDataModelBudget_srv = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// this.oDataModelBudget_srvMsurry = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_MATTER_SUMMARY_REPT_SRV/");
			// var objectPageSectionTitle = evt.getSource()._oCurrentTabSection.mProperties.title;
			// var oSmartTableAccrualSection = this.getView().byId(objectPageSectionId);
			// var oSmartTableAccrual = oSmartTableAccrualSection.getSubsections()[0].getBlocks()[0].byId("AccrualsSmartTable");
			if (objectPageSectionId === "idManageBudget") {
				var oSmartTableMB = this.getView().byId("idManageBudgetSubSection").getBlocks()[0].byId("ManBudgetSTable");
				var MBFlag = oSmartTableMB.getEnableAutoBinding();
				var that = this;
				that.ojsonModel = new JSONModel();
				this.oDataModelBudget_srv.read("BudgetDetailSet", {
					success: function(odata) {
						that.ojsonModel.setData(odata);
						that.getView().byId("idManageBudgetSubSection").setModel(that.ojsonModel, "ojsonModel");
					},
					error: function() {}
				});
				// if (!MBFlag) {
				// 	oSmartTableMB.setEnableAutoBinding(true);

				// 	this.getView().byId("idManageBudgetSubSection").setModel(this.oDataModelBudget_srv);
				// 	oSmartTableMB.rebindTable();
				// }

			}
			if (objectPageSectionId === "idAccruals") {
				var oSmartTableAccrual = this.getView().byId("idAccuralsSubSection").getBlocks()[0].byId("AccrualsSmartTable");
				var aFlag = oSmartTableAccrual.getEnableAutoBinding();
				if (!aFlag) {
					oSmartTableAccrual.setEnableAutoBinding(true);

					this.getView().byId("idAccuralsSubSection").setModel(this.oDataModelBudget_srv);
					oSmartTableAccrual.rebindTable();
				}

			}
			if (objectPageSectionId === "idReports") {
				var oSmartTableR = this.getView().byId("idReportsSubSection").getBlocks()[0].byId("ReportsSmartTable");
				var rFlag = oSmartTableR.getEnableAutoBinding();
				if (!rFlag) {
					// oSmartTableR.setEnableAutoBinding(true);

					this.getView().byId("idReportsSubSection").setModel(this.oDataModelBudget_srv);
					oSmartTableR.rebindTable();
				}

			}
			// if (objectPageSectionId === "idManageBudget" || objectPageSectionId === "idReports" || objectPageSectionId === "idAccruals") {
			// 	if (this.bServiceFlag) {
			// 		this.oDataModelBudget_srv = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// 		this.bServiceFlag = false;
			// 	}
			// 	this.getView().byId(objectPageSectionId).setModel(this.oDataModelBudget_srv);
			// }
			if (objectPageSectionId === "idTimeKeeper") {
				this.getRouter().navTo("timeKeeperRate", true);
				this._allSegmButtonFalse();
			}
			if (objectPageSectionId === "idMyMatter") {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "ZPRS_LSM_MYMATT",
						action: "display"
					}
				})) || "";
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
			}

			if (objectPageSectionId === "idMatterSummary") {
				var oDataModelMatterySummry_srv = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_MATTER_SUMMARY_REPT_SRV/");
				var oSmartTablMatterSummry = this.getView().byId("MatterSummrySubSec").getBlocks()[0].byId("MatterSummryId");
				//oSmartTablMatterSummry = oSmartTablMatterSummry.byId("MatterSummryId");
				var MSumFlag = oSmartTablMatterSummry.getEnableAutoBinding();
				if (!MSumFlag) {
					oSmartTablMatterSummry.setEnableAutoBinding(true);

					this.getView().byId("MatterSummrySubSec").setModel(oDataModelMatterySummry_srv);
					oSmartTablMatterSummry.rebindTable();
				}

			}
			if (objectPageSectionId === "idMyWBranch") {
				this.pendingAndHoldBudgetTab();
			}
			if (objectPageSectionId === "idManageBudget") {
				this.buttonSetVisible();
			}
			if (objectPageSectionId === "idMyMatter" || objectPageSectionId === "idMatterSummary" || objectPageSectionId === "idAccruals" ||
				objectPageSectionId === "idExchageRate" || objectPageSectionId === "idReports") {
				this._allSegmButtonFalse();
			}

			/*	var oObjectPageLayout1 = this.getView().byId("ObjectPageLayout");
			oObjectPageLayout1.scrollToSection("id1");*/
		},
		//ManageBedugt Excel downLoad
		onExportExcelTrigger: function(evt) {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV");
			var sUrl = oModel.sServiceUrl + "/BudgetDetailSet?$format=xlsx";

			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},

		handleDataReceived: function(oEvent) {
			// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV");
			var oModel = this.getOwnerComponent().getModel();

			var oViewModel = this.getModel("JModelButton");

			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Pending", oData);
				},
				filters: this._mFilters.pending
			});

			// read the count for InProcess
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/InProcess", oData);
				},
				filters: this._mFilters.inProcess
			});

			// read the count for Approved
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Approved", oData);
				},
				filters: this._mFilters.approved
			});

			// read the count for Rejected
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Rejected", oData);
				},
				filters: this._mFilters.rejected
			});
			// read the count for HoldBudget
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/HoldBudget", oData);
				},
				filters: this._mFilters.holdBudget
			});
			// read the count for Paid
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Paid", oData);
				},
				filters: this._mFilters.paid
			});
			// read the count for Processed
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Processed", oData);
				},
				filters: this._mFilters.processed
			});
			// read the count for ApprovedPayment
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/ApprovedPayment", oData);
					this.getView().setBusy(false);
				}.bind(this),
				filters: this._mFilters.approvedPayment

			});
			// read the count for Faild
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Faild", oData);
				},
				filters: this._mFilters.faild
			});
			this._hideColumns();
		},
		_hideColumns: function() {
			var oViewModel = this.getView().getModel("JsonKey");
			oViewModel.setProperty("/Sequence", false);
			oViewModel.setProperty("/FileTypeC", false);
		},

		_onObjectMatched: function(evt) {
			var that = this;
			var a = this.sideKey;

			if (a === "idTimeKeeper") {

				var oPageLayout = this.getView().byId("ObjectPageLayout"),
					sId = oPageLayout.getSections()[0].sId;
				oPageLayout.setSelectedSection(sId);
			}
			// this.getView().setBusy(false);

		},
		getTable: function() {
			var oTable = this.getView().byId("MyWorkBenchSTable");
			return oTable.getTable();
		},
		onBeforeRebindTable: function(oEvent) {

			var SegmentKey = this.getView().byId("idIconTabBarNoIconsLSM").getSelectedKey();
			var path = "ZzinvStatus";
			if (SegmentKey.search("my") >= 0) {
				var SegmentKey = SegmentKey.replace("my", '');
				path = "ZzpayStatus";
				//aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, SegmentKey));
			}

			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, SegmentKey));
			mBindingParams.filters = aFilter;
		},
		onSelectIconTabBarMyWB: function(oEvent) {
			var that = this;
			var oViewModel = that.getModel("JsonKey");
			var segmbtnKey = oEvent.mParameters.key;
			var segmbtnpayKey = oEvent.mParameters.key;
			var aFilter = [],
				path = "ZzinvStatus";
			var oTab = this.getTable(),
				cntx = oTab.getBinding("items");
			var oTable = this.getView().byId("MyWorkBenchSTable"),
				tbl = oTable.getTable();

			//SegmentKey = oEvent.getParameters().key;
			//    cntx.aApplicationFilters = null;

			if (segmbtnKey.search("my") >= 0) {
				var segmbtnKey1 = segmbtnKey.replace("my", '');
				path = "ZzpayStatus";
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey1));
			} else {
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));
			}

			cntx.filter(aFilter, "Application");

			switch (segmbtnKey) {
				case "01":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.pendingAndHoldBudgetTab();
					break;
				case "04":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.in_ProcessTab();
					break;
				case "02":
					oViewModel.setProperty("/ZzpymtDoc", true);
					that.approvedAndRejectTab();
					break;
				case "03":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.approvedAndRejectTab();
					break;
				case "05":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.pendingAndHoldBudgetTab();
					break;
				case "my01":
					oViewModel.setProperty("/ZzpymtDoc", true);
					that.myPaymentTab();
					break;
				case "my02":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.myPaymentTab();
					break;
				case "my03":
					oViewModel.setProperty("/ZzpymtDoc", true);
					that.myPaymentTab();
					break;
				case "my04":
					oViewModel.setProperty("/ZzpymtDoc", false);
					that.myPaymentTab();
					break;

			}
		},

		myPaymentTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/invStatus", false);
			oViewModel.setProperty("/payStatus", true);
			oViewModel.setProperty("/MBApprove", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},

		pendingAndHoldBudgetTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", true);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", true);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			oViewModel.setProperty("/MBApprove", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},
		in_ProcessTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", true);
			oViewModel.setProperty("/Reject", true);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			oViewModel.setProperty("/MBApprove", false);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},
		approvedAndRejectTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/Save", false);
			oViewModel.setProperty("/invStatus", true);
			oViewModel.setProperty("/payStatus", false);
			//	this.getView().byId("printAsPDF").setVisible(false);
			oViewModel.setProperty("/MBApprove", false);

		},
		_allSegmButtonFalse: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			// oViewModel.setProperty("/MBApprove", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
			oViewModel.setProperty("/Save", false);

			//	this.getView().byId("printAsPDF").setVisible(false);
		},
		sideNavigationMyWorkBench: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
			oViewModel.setProperty("/MBApprove", false);
		},
		setCurrentTab: function(SelKey) {
			var jKey = this.getView().getModel("JsonKey");

			$.each(jKey.getData(), function(pn, v) {
				if (pn === SelKey) {
					jKey.setProperty("/" + pn, true);
				} else {
					jKey.setProperty("/" + pn, false);
				}

			});
		},

		_pressNavigationListSelect: function(oItem) {
			// var that = this;
			// var itemKey = oItem.getParameter("item").getKey();
			// this.sideKey = itemKey;
			// this.setCurrentTab(itemKey);

			// if (itemKey === "MyDashboard") {
			// 	//	this.getView().byId("printAsPDF").setVisible(true);
			// 	this.getView().setModel(this.oDataModel1);
			// }

			// if (itemKey === "MyWorkbench") {
			// 	this.getView().setModel(this.oDataModel1);
			// 	//this.sideNavigationMyWorkBench();
			// 	this.pendingAndHoldBudgetTab();

			// }
			// if (itemKey === "ManageBudget") {
			// 	this._allSegmButtonFalse();
			// 	this.getView().setModel(this.oDataModel);
			// 	this.buttonSetVisible(); // button SetVisible true and false based on side Navigation
			// }
			// if (itemKey === "TimeKeeperRate") {

			// 	this.getRouter().navTo("timeKeeperRate", true);
			// 	this._allSegmButtonFalse();
			// }

			// if (itemKey === "MyMatter") {
			// 	this._allSegmButtonFalse();
			// }
			// if (itemKey === "MatterSummary") {
			// 	//this.getView().setModel(oDataModel);
			// 	this._allSegmButtonFalse();
			// }
			// if (itemKey === "Accruals") {
			// 	this._allSegmButtonFalse();
			// 	this.getView().setModel(this.oDataModel);
			// }
			// if (itemKey === "ExchangeRates") {
			// 	this.getView().setModel(this.oDataModel1);
			// 	this._allSegmButtonFalse();
			// }
			// if (itemKey === "Reports") {
			// 	this._allSegmButtonFalse();
			// 	this.getView().setModel(this.oDataModel);
			// }

		},

		pressDetailWorkBench: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext().getObject();
			this.getRouter().navTo("workBenchDetail", {
				filetype: obj.Zzfiletype,
				invoiceNumber: obj.ZzinvoiceNumber,
				seqnr: obj.Zzseqnr
			}, true);
		},

		pressNavigaAccrulas: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext().getObject();

			this.getRouter().navTo("accruals", {
				LawFirmMatterId: obj.Pspid

			}, true);
		},
		buttonSetVisible: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/Save", true);
			oViewModel.setProperty("/MBApprove", true);
		},

		onPressPrint: function(oEvent) {
			var that, myWBSmartTable, WBTable, pURL, oModel, url, invoiceNo;
			that = this;
			myWBSmartTable = this.getView().byId("MyWorkBenchSTable");
			WBTable = this.getView().byId("idwbTable");
			oModel = this.getView().getModel();
			var servUri = oModel.sServiceUrl;
			invoiceNo = WBTable.getSelectedItem().getBindingContext().getObject().ZzinvoiceNumber;
			var sRead = "/PrintInvoiceCollection(Vbeln='" + invoiceNo + "')" + "/$value";
			var mainUri = servUri + sRead;
			sap.m.URLHelper.redirect(mainUri, "_blank");

		},
		getTableMannegeBudget: function() {
			var otbl = this.getView().byId("ManBudgetSTable");
			return otbl.getTable();
		},
		// Manage Budget Save Functionality 
		onPressSave: function(oEvent) {
			var that, oselectedManageBudget, oTable, oSelectedRows, batchChanges, src;
			that = this;
			var oSmtTable = this.getView().byId("idManageBudgetSubSection").getBlocks()[0].byId("ManBudgetSTable"),
				oTable = oSmtTable.getTable();
			// oTable = this.getTableMannegeBudget();
			oSelectedRows = oTable.getSelectedIndices();
			src = oEvent.getSource();
			var arrBukrs = [],
				arrWerks = [],
				arrPspid = [],
				arrVendor = [],
				arrStatus = [],
				arrGjahr = [],
				arrPosid = [],
				arrHkont = [],
				arrAmount = [],
				arrRecordType = [],
				arrCurrency = [];
			batchChanges = [];

			$.each(oTable.getSelectedIndices(), function(i, o) {

				var obj = oTable.getContextByIndex(o).getObject();
				arrBukrs.push(obj.Bukrs);
				arrWerks.push(obj.Werks);
				arrPspid.push(obj.Pspid);
				arrVendor.push(obj.Vendor);
				arrStatus.push(obj.Status);
				arrGjahr.push(obj.Gjahr);
				arrPosid.push(obj.Posid);
				arrHkont.push(obj.Hkont);
				arrAmount.push(obj.Amount);
				arrRecordType.push(obj.RecordType);
				arrCurrency.push(obj.Currency);

				oselectedManageBudget = {
					Bukrs: arrBukrs.join("|"),
					Werks: arrWerks.join("|"),
					Pspid: arrPspid.join("|"),
					Vendor: arrVendor.join("|"),
					Status: arrStatus.join("|"),
					Gjahr: arrGjahr.join("|"),
					Posid: arrPosid.join("|"),
					Hkont: arrHkont.join("|"),
					Amount: arrAmount.join("|"),
					RecordType: arrRecordType.join("|"),
					Currency: arrCurrency.join("|")
				};

				//batchChanges.push(that.oDataModel.createBatchOperation("/BudgetChange", "PSO", oselectedManageBudget));
			});

			var VMatterModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			// var VMatterModel = this.getModel("VMatterModel");
			VMatterModel.callFunction("/BudgetChange", {
				method: "GET",
				urlParameters: oselectedManageBudget,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var oisError = oData.results[0].Iserror;
						var oMessage = oData.results[0].Message;
						var ctx = oTable.getContextByIndex(o);
						var isErrorPath = ctx.getPath() + "/Iserror";
						var MessagePath = ctx.getPath() + "/Message";

						var model = ctx.getModel("ojsonModel");
						model.setProperty(MessagePath, oMessage);
						model.setProperty(isErrorPath, oisError);

					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});
		},
		// Approve Functionality
		onPressApprove: function(oEvent) {
			var that, oselectedManageBudget, oTable, oSelectedRows, batchChanges, src;
			that = this;
			oTable = this.getTableMannegeBudget();
			oSelectedRows = oTable.getSelectedIndices();
			src = oEvent.getSource();
			var arrBukrs = [],
				arrWerks = [],
				arrPspid = [],
				arrVendor = [],
				arrStatus = [],
				arrGjahr = [],
				arrPosid = [],
				arrHkont = [],
				arrAmount = [],
				arrRecordType = [],
				arrCurrency = [];
			batchChanges = [];
			var MBudgetSTable = this.getView().byId("ManBudgetSTable");
			if (MBudgetSTable.getDomRef() !== null) {
				$.each(oTable.getSelectedIndices(), function(i, o) {

					var obj = oTable.getContextByIndex(o).getObject();
					arrBukrs.push(obj.Bukrs);
					arrWerks.push(obj.Werks);
					arrPspid.push(obj.Pspid);
					arrVendor.push(obj.Vendor);
					arrStatus.push(obj.Status);
					arrGjahr.push(obj.Gjahr);
					arrPosid.push(obj.Posid);
					arrHkont.push(obj.Hkont);
					arrAmount.push(obj.Amount);
					arrRecordType.push(obj.RecordType);
					arrCurrency.push(obj.Currency);

					oselectedManageBudget = {
						Bukrs: arrBukrs.join("|"),
						Werks: arrWerks.join("|"),
						Pspid: arrPspid.join("|"),
						Vendor: arrVendor.join("|"),
						Status: arrStatus.join("|"),
						Gjahr: arrGjahr.join("|"),
						Posid: arrPosid.join("|"),
						Hkont: arrHkont.join("|"),
						Amount: arrAmount.join("|"),
						RecordType: arrRecordType.join("|"),
						Currency: arrCurrency.join("|")
					};

				});
			}
			/*that.oDataModel.callFunction("/BudgetApprove", {
				method: "GET",
				urlParameters: oselectedManageBudget,
				success: function(oData) {
					var s = oData;
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});*/
		},
		onSelectReport: function(oEvent) {
			/*var IconTabFilterKey = oEvent.getParameter("item").selectedKey;
			var oDataModelRep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			if(IconTabFilterKey ==="Spendkey"){
			this.getView().setModel(oDataModelRep);
			}else{
			this.getView().setModel(oDataModelRep);	
			}*/
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		onPrintAsPDFPress: function() {
			var ctrlString = "width=800px, height=600px";
			var wind = window.open("", "PrintWindow", ctrlString);
			var chart1 = $("#application-LSMClient-display-component---worklist--idVizFrame1").outerHTML();
			var chart2 = $("#application-LSMClient-display-component---worklist--idVizFrame2").outerHTML();
			var chart3 = $("#application-LSMClient-display-component---worklist--idVizFrame3").outerHTML();
			var chart4 = $("#application-LSMClient-display-component---worklist--idVizFrame4").outerHTML();

			wind.document.write(chart1 + "<br/>" + chart2 + "<br/>" + chart3 + "<br/>" + chart4);
			wind.print();
			wind.close();
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		/*onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},*/

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onAfterRendering: function() {
			/*	if (this.getView().byId("idVizFrame1")) {
					var oVizFrame = this.getView().byId("idVizFrame1");
					var oPopOver = this.getView().byId("idPopOver1");
					oPopOver.connect(oVizFrame.getVizUid());

					var oVizFrame2 = this.getView().byId("idVizFrame2");
					var oPopOver2 = this.getView().byId("idPopOver2");
					oPopOver2.connect(oVizFrame2.getVizUid());

					var oVizFrame3 = this.getView().byId("idVizFrame3");
					var oPopOver3 = this.getView().byId("idPopOver3");
					oPopOver3.connect(oVizFrame3.getVizUid());

					var oVizFrame4 = this.getView().byId("idVizFrame4");
					var oPopOver4 = this.getView().byId("idPopOver4");
					oPopOver4.connect(oVizFrame4.getVizUid());
				}*/
			if (this.getView().byId("MyWorkBenchSTable")) {
				/*	var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame21");
					var oPopOver = this.getView().byId("idPopOver21");
					oPopOver.connect(oVizFrame.getVizUid());*/
				this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			}
		},
		// Excel Upload for ManageBudget section:
		handleUpload: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file, action);

			}
		},
		// Excel Sheet read function method
		_import: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}

					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["RecordType"] === undefined) {
							sheetData[i]["RecordType"] = "";
						}
						if (sheetData[i]["Vendor"] === undefined) {
							sheetData[i]["Vendor"] = "";
						}
						if (sheetData[i]["Vendor Name"] === undefined) {
							sheetData[i]["Vendor Name"] = "";
						}
						if (sheetData[i]["Compcode"] === undefined) {
							sheetData[i]["Compcode"] = "";
						}
						if (sheetData[i]["Office"] === undefined) {
							sheetData[i]["Office"] = "";
						}
						if (sheetData[i]["Matter"] === undefined) {
							sheetData[i]["Matter"] = "";
						}
						if (sheetData[i]["Matter Name"] === undefined) {
							sheetData[i]["Matter Name"] = "";
						}
						if (sheetData[i]["Status"] === undefined) {
							sheetData[i]["Status"] = "";
						}
						if (sheetData[i]["Fiscal Year"] === undefined) {
							sheetData[i]["Fiscal Year"] = "";
						}
						if (sheetData[i]["GL Account"] === undefined) {
							sheetData[i]["GL Account"] = "";
						}
						if (sheetData[i]["Amount"] === undefined) {
							sheetData[i]["Amount"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["Matter Phase"] === undefined) {
							sheetData[i]["Matter Phase"] = "";
						}

					}
					that.creatobjPy(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		creatobjPy: function(newData, action) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var RecordType = data["RecordType"].trim();
				var Vendor = data["Vendor"].trim();
				var VendorName = data["Vendor Name"].trim();
				var Compcode = data["Compcode"].trim();
				var Office = data["Office"].trim();
				var Matter = data["Matter"].trim();
				var MatterName = data["Matter Name"].trim();
				var Status = data["Status"].trim();
				var FiscalYear = data["Fiscal Year"].trim();
				var GLAccount = data["GL Account"].trim();
				var Amount = data["Amount"].trim();
				var Currency = data["Currency"].trim();
				var MatterPhase = data["Matter Phase"].trim();

				var obj = {
					"RecordType": RecordType,
					"Vendor": Vendor,
					"Bukrs": Compcode,
					"Werks": Office,
					"Name1": VendorName,
					"Pspid": Matter,
					"Post1": MatterName,
					"StatusText": Status,
					"Gjahr": FiscalYear,
					"Hkont": GLAccount,
					"Amount": Amount,
					"Currency": Currency,
					"Posid": MatterPhase
				};

				if (RecordType === "" && Vendor === "" && VendorName === "" && Compcode === "" && Office === "" && Matter === "" &&
					MatterName === "" && Status === "" && FiscalYear === "" && GLAccount === "" && Amount === "" && Currency === "" && MatterPhase ===
					"") {
					continue;
				} else {
					objArray.push(obj);
				}
			}
			var model = this.getView().getModel("ojsonModel"),
				results = model.getData().results;
			// results.push(objArray);
			this.getModel("ojsonModel").setProperty("/results", objArray.concat(results));

		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("MatterType", FilterOperator.Contains, sQuery)];
				}
				//this._applySearch(oTableSearchState);
			}

		}

	});

});