sap.ui.define([
	"lsmclient/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmclient/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, Controller, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("lsmclient.controller.WorkBenchDetail", {
		formatter: formatter,
		onInit: function() {
			this.getRouter().getRoute("workBenchDetail").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(evt) {
			/*if ("workBenchDetail" !== evt.getParameter("name")) {
				return;
			} else {*/
			// sap.ui.core.BusyIndicator.hide();
			var lvfiletype = evt.getParameter("arguments").filetype;
			var lvinvoiceNumber = evt.getParameter("arguments").invoiceNumber;
			//	var lvlineItemNumber =  evt.getParameter("arguments").lineItemNumber;
			var lvseqnr = evt.getParameter("arguments").seqnr;
			//this.getView().byId("wbDetail").setTitle(" Inovice Number : "+lvinvoiceNumber+" (review)");
			//this.displayData(lvfiletype, lvinvoiceNumber, lvseqnr);
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("InvHeaderSet", {
					ZzinvoiceNumber: lvinvoiceNumber,
					Zzfiletype: lvfiletype,
					Zzseqnr: lvseqnr
				});

				this._bindTable("/" + sObjectPath + "/InvHeaderToDetail");
				//	sap.ui.core.BusyIndicator.hide();
			}.bind(this));
			//	}
		},

		_bindTable: function(sObjectPath) {
			//sap.ui.core.BusyIndicator.show();
			this.sPath = sObjectPath;
			var oDataModel = this.getModel(),
				oTable = this.getTable();
			oTable.setBusy(true);
			var that = this;
			var oModelLocal = new sap.ui.model.json.JSONModel();
			oDataModel.read(sObjectPath, {
				success: function(oData, response) {
					//		sap.ui.core.BusyIndicator.hide();
					oModelLocal.setData({
						modelData: oData.results
					});
					oTable.setModel(oModelLocal);
					oTable.setSelectionMode("None");
					oTable.bindRows("/modelData");
					that.getView().byId("lblToolbar").setText(oData.results[0].Zzphase + "  " + oData.results[0].ZzphaseName +
						" Inovice Number : " +
						oData.results[0].ZzinvoiceNumber + " (review)");
					oTable.setBusy(false);
				},
				error: function(oError) {
					oTable.setBusy(false);
				}

			});
		},
		onExportExcelTrigger: function(evt) {
			var oModel = this.getOwnerComponent().getModel();
			var sUrl = oModel.sServiceUrl + this.sPath + "?$format=xlsx";

			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		getTable: function() {
			var oTable = this.getView().byId("MyWBDetailSTable");
			return oTable.getTable();
		},
		navTobackWorkBen: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("lsmClient", true);
		}

	});
});