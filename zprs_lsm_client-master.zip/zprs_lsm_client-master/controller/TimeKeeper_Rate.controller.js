sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"lsmclient/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("lsmclient.controller.TimeKeeper_Rate", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf lsmclient.view.TimeKeeper_Rate
		 */
		onInit: function() {
			this.getView().setBusy(true);
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
			this.oDataModelTimeKeeperRate = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_CREC_UPLOAD_MS_SRV/");
			this.getView().setModel(this.oDataModelTimeKeeperRate);
			var that = this;

			/* var	oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			oDataModelTimeKeeperRate.read("VendorDataSet", {
				
				success: function(oData, oResp) {
					oJsonModel.setData(oData);
					that.getView().setModel(oJsonModel);
				},
				error: function(oError) {

				}
			});*/
			this.getView().setBusy(false);

		},
		_handleRouteMatched: function(evt) {

		},
		// Excel upload Functn  
		handleUpload: function(evt) {
			var action = "";
			var file;
			var oFileUpId = this.byId("fileUploader");
			var domRef = oFileUpId.getFocusDomRef();
			if (oFileUpId.getValue() === "") {
				var msg = "Select file to Upload.";
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				return;
			}
			if (domRef.files[0] !== undefined) {
				file = domRef.files[0];
				if (file.type.indexOf("sheet") === "-1" && file.type.indexOf("excel") === "-1") {
					var msgF = "Invalid File\nUse Excel template to upload";
					sap.m.MessageBox.show(msgF, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					this.getView().byId("fileUploader").setValue("");
					return;
				}
				oFileUpId.clear();
				this._import(file, action);

			}

		},
		// Excel Sheet read function method
		_import: function(file, action) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						// thatUpload.getView().byId("fileUploader").setValue("");
						return false;
					}
					// if (sheetData[0]["Name"] === undefined && sheetData[0]["Classification"] === undefined && sheetData[0]["Role"] ===
					//  undefined && sheetData[0]["Designation"] === undefined) {
					//  sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
					//   title: "Error",
					//   styleClass: "sapUiSizeCompact messageBox",
					//   icon: sap.m.MessageBox.Icon.ERROR,
					//   actions: [sap.m.MessageBox.Action.OK]
					//  });
					//  //this.getView().byId("fileUploader").setValue("");
					//  return false;
					// }
					for (var i = 0; i < sheetData.length; i++) {
						if (sheetData[i]["RecordType"] === undefined) {
							sheetData[i]["RecordType"] = "";
						}
						if (sheetData[i]["Matter"] === undefined) {
							sheetData[i]["Matter"] = "";
						}
						if (sheetData[i]["TimeKeeper"] === undefined) {
							sheetData[i]["TimeKeeper"] = "";
						}
						if (sheetData[i]["Timekeeper Name"] === undefined) {
							sheetData[i]["Timekeeper Name"] = "";
						}
						if (sheetData[i]["Rate"] === undefined) {
							sheetData[i]["Rate"] = "";
						}
						if (sheetData[i]["Currency"] === undefined) {
							sheetData[i]["Currency"] = "";
						}
						if (sheetData[i]["PricingUnit"] === undefined) {
							sheetData[i]["PricingUnit"] = "";
						}
						if (sheetData[i]["Unit"] === undefined) {
							sheetData[i]["Unit"] = "";
						}
						if (sheetData[i]["DateFrom"] === undefined) {
							sheetData[i]["DateFrom"] = "";
						}
						if (sheetData[i]["DateTo"] === undefined) {
							sheetData[i]["DateTo"] = "";
						}
						if (sheetData[i]["Type"] === undefined) {
							sheetData[i]["Type"] = "";
						}

					}
					that.abd(sheetData, action);
				};
				reader.readAsArrayBuffer(file);
			}
		},
		onApprove: function() {
			this.abd([], "APR");
		},
		abd: function(newData, action) {
			var objArray = [];
			for (var k = 0; k < newData.length; k++) {
				var data = newData[k];
				var RecordType = data["RecordType"].trim();
				var Matter = data["Matter"].trim();
				var TimeKeeper = data["TimeKeeper"].trim();
				var TimekeeperName = data["Timekeeper Name"].trim();
				var Rate = data["Rate"].trim();
				var Currency = data["Currency"].trim();
				var PricingUnit = data["PricingUnit"].trim();
				var Unit = data["Unit"].trim();
				var DateFrom = new Date(data["DateFrom"].trim());
				var DateTo = new Date(data["DateTo"].trim());
				var Type = data["Type"].trim();
				var obj = {
					//	"RecordType": RecordType,
					"Pspid": Matter,
					"Pernr": TimeKeeper,
					"Sname": TimekeeperName,
					"RecordType": RecordType,
					"Kbetr": Rate,
					"Kpein": PricingUnit,
					"Kmein": Unit,
					"Datab": DateFrom,
					"Datbi": DateTo,
					"Kschl": Type,
					"Action": action,
					"Konwa": Currency
						// "Kunnr": "",
						// "Pernr": "",

					// "Datab": null,
					// "Datbi": null

				};

				if (RecordType === "" && Matter === "" && TimeKeeper === "" && TimekeeperName === "" && Rate === "" && Currency === "" &&
					PricingUnit === "" && Unit === "" && DateFrom === "" && DateTo === "" && Type === "") {
					continue;
				} else {
					objArray.push(obj);
				}
			}
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/");
			var oEntity = {
				// "Uname": "EXTUR",
				CrecToUser: objArray
			};
			var oSmtTable = this.getView().byId("timeKeeperSTable"),
				tbl = oSmtTable.getTable();
			tbl.setBusy(true);
			oModel.create("UserdataSet", oEntity, {
				success: function(oData, oResp) {
					// var smg = oData.Message;
					var smg = "SUCCESS:Condition Record Uploaded.Pending for Approval";
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getModel().refresh();
					tbl.setBusy(false);
				},
				error: function(oErr) {
					var smg = oErr.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}

			});
		},
		onExportExcelTimeKepeer: function(evt) {
			var sUrl = this.oDataModelTimeKeeperRate + this.sPath + "?$format=xlsx";
			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},

		onSelectionChange: function(oEvent) {
			/*	var sMatterId = oEvent.getSource().getBindingContext().getObject().Kunnr;
			this.getDetailData(sMatterId);*/
			//	var tbl = this.getView().byId("list"),
			var li = oEvent.getParameter("listItem") || oEvent.getSource();

			if (li.getSelected() === true || oEvent.getSource() instanceof sap.m.StandardListItem) {
				this.getDetailData(li);
			} else if (li.getSelected() === false) {
				var oList = this.getView().byId("list");
				if (oList.getSelectedItems().length !== 0) {
					this.getDetailData(oList.getSelectedItems()[0]);
				} else {
					// this.getRouter().getTargets().display("notFound");
				}
			}
		},
		getTable: function() {
			var oTable = this.getView().byId("timeKeeperSTable");
			return oTable.getTable();
		},
		getDetailData: function(oItem) {
			var that = this;
			var cntx = oItem.getBindingContextPath(),
				Rpath = cntx + "/CrecupdSet";
			this.sPath = Rpath;
			//	oModel = this.getView().getModel();
			// var tbl = this.getView().byId("detailTbl");
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.oDataModelTimeKeeperRate.read(Rpath, {

				success: function(oData, oResp) {

					oJsonModel.setData({
						modelData: oData.results
					});
					var oTable = that.getTable();
					oTable.setModel(oJsonModel);
					//	oTable.setSelectionMode("None");
					oTable.bindRows("/modelData");
				},
				error: function(oError) {

				}
			});
		},
		onUpdateFinished: function(oEvent) {
			var list = oEvent.getSource();
			if (list.getItems().length > 0) {
				//list.removeSelections(true);
				var selItem;
				if (list.getSelectedItems().length > 0) {
					selItem = list.getSelectedItems()[0];
				} else {
					selItem = list.getItems()[0];
				}
				list.setSelectedItem(selItem);
				this.getDetailData(selItem || oEvent.getSource());
				// this.setVisibility();
				//	this.onItemSelect(oEvent)
			} else {
				// this.getRouter().getTargets().display("notFound");
			}
		},
		navTobackTimeKeeper: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("lsmClient", true);
		},

		onPressApproveTK: function() {
			var oTable;
			oTable = this.getView().byId("timeKeeperSTable").getTable();
			var objArray = [];

			$.each(oTable.getSelectedIndices(), function(i, o) {
				var obj = oTable.getContextByIndex(o).getObject();
				obj.Action = "APR";
				delete obj["__metadata"];
				objArray.push(obj);
			});
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_CREC_UPLOAD_SRV/");
			var oEntity = {
				"Uname": "",
				CrecToUser: objArray
			};
			var oSmtTable = this.getView().byId("timeKeeperSTable"),
				tbl = oSmtTable.getTable();
			tbl.setBusy(true);
			oModel.create("UserdataSet", oEntity, {
				success: function() {
					var smg = "SUCCESS:Selected pending records Approved";
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.SUCCESS, "SUCCESS");
					tbl.getBinding().refresh(true);
					tbl.setBusy(false);
				},
				error: function(oErr) {
					var smg = oErr.Message;
					sap.m.MessageBox.show(smg, sap.m.MessageBox.Icon.ERROR, "ERROR");
					tbl.setBusy(false);
				}

			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf lsmclient.view.TimeKeeper_Rate
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf lsmclient.view.TimeKeeper_Rate
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf lsmclient.view.TimeKeeper_Rate
		 */
		//	onExit: function() {
		//
		//	}

	});

});