sap.ui.define([
	"lsmclient/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmclient/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController,Controller,JSONModel,History,formatter,Filter,FilterOperator) {
	"use strict";

	return BaseController.extend("lsmclient.controller.AccrualsDetail", {
        formatter:formatter,
		
		onInit: function() {
		this.getRouter().getRoute("accruals").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(evt) {
	
				var lvLawFirmMatterId = evt.getParameter("arguments").LawFirmMatterId;
//				this.getView().byId("inoviecNo").setText(" : "+lvinvoiceNumber+" (review)");
				this.displayData(lvLawFirmMatterId);
				
		
		},
		
	
		getTable: function() {
			var oTable = this.getView().byId("accrualsDetailSTable");
			return oTable.getTable();
		},

		displayData: function(lvLawFirmMatterId) {
			//this.onCancelJCM();
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			var path = "MatterAccrualListSet?$filter=LawFirmMatterId eq '"+lvLawFirmMatterId+"'";
			var oJsonModel = new sap.ui.model.json.JSONModel();
			var oTable = that.getTable();
				oTable.setBusy(true);
			oJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			oModel.read(path, null, null, true, function(oData, oResponse) {
					oTable.setBusy(false);
				oJsonModel.setData({
					modelData: oData.results
				});

				
				oTable.setModel(oJsonModel);
				oTable.setSelectionMode("None");
				oTable.bindRows("/modelData");
				that.getView().byId("lblToolbarAccurals").setText("     "+oData.results[0].LawFirmMatterId+"  "+oData.results[0].MatterName);

			}, function(oResponse) {
	oTable.setBusy(false);
			});
		},
			navTobackAccrulas: function() {
		
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("lsmClient", true);
				//	this.getRouter().navTo("workBenchDetail",{filetype:obj.Zzfiletype,invoiceNumber:obj.ZzinvoiceNumber,seqnr:obj.Zzseqnr}, true);
		
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf lsmclient.view.AccrualsDetail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf lsmclient.view.AccrualsDetail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf lsmclient.view.AccrualsDetail
		 */
		//	onExit: function() {
		//
		//	}

	});

});