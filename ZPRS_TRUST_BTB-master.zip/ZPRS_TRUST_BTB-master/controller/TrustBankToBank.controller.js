sap.ui.define([
	"trustbtb/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustbtb/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("trustbtb.controller.TrustBankToBank", {

		formatter: formatter,


		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			//window.that = this;
            this._formFragments = {};
			var oViewModel = new JSONModel({
				Office: "",
				TransferDate: null,
				Amount: "",
				AuthBy: "",
				Currency: "",
				AvailMattBal: "",
				TotMattBal: "",
				ReasonForTrns: "",
				SourceMatter: "",
				ClientNumS: "",
				SorcAccNum: "",
				DestinMatter: "",
				ClientNumD: "",
				DestAccNum: "",
				DocNo1: "",
				DocNo2: ""
			});
			this.setModel(oViewModel, "jsonViewMod");
			this.createEntry();
			if (!this.oOutputComp) {
				this.oOutputComp = sap.ui.getCore().createComponent({
					name: "fgt.trustdispdoc.control.comp.outputitems"
				});
			}
			this._showFormFragment("BankToBankTransfer");

		},
		createEntry: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/TrustbankSet", {});
				var c = oContextClients.getModel();
				oModel.setDefaultBindingMode("TwoWay");
				c.setProperty(oContextClients.getPath() + "/Office", "");

				c.setProperty(oContextClients.getPath() + "/TransferDate", null);
				c.setProperty(oContextClients.getPath() + "/Amount", "");
				c.setProperty(oContextClients.getPath() + "/AuthBy", "");
				c.setProperty(oContextClients.getPath() + "/Currency", "");
				c.setProperty(oContextClients.getPath() + "/ReasonForTrns", "");
				c.setProperty(oContextClients.getPath() + "/SourceMatter", "");
				c.setProperty(oContextClients.getPath() + "/ClientNumS", "");
				c.setProperty(oContextClients.getPath() + "/SorcAccNum", "");
				c.setProperty(oContextClients.getPath() + "/AvailMattBal", "");
				c.setProperty(oContextClients.getPath() + "/TotMattBal", "");
				c.setProperty(oContextClients.getPath() + "/DestinMatter", "");
				c.setProperty(oContextClients.getPath() + "/ClientNumD", "");
				c.setProperty(oContextClients.getPath() + "/DestAccNum", "");
				c.setProperty(oContextClients.getPath() + "/HbankDescD", "");
				c.setProperty(oContextClients.getPath() + "/HbankDescS", "");
				c.setProperty(oContextClients.getPath() + "/OfficeDesc", "");
				c.setProperty(oContextClients.getPath() + "/AuthByDesc", "");
				c.setProperty(oContextClients.getPath() + "/SorcMattDesc", "");
				c.setProperty(oContextClients.getPath() + "/ClntNumSDesc", "");
				c.setProperty(oContextClients.getPath() + "/DestMattDesc", "");
				c.setProperty(oContextClients.getPath() + "/DestClntDesc", "");

				that.getView().setBindingContext(oContextClients);
			});

		},

		handleChange: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
			if (source.getProperty("value") !== evt.getParameter("value")) {
				this.clearValue();
			}
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);

		},
			handleReasonForTransfer: function(evt) {
			var source = evt.getSource();
			var sPath = this.getView().getBindingContext().sPath;
			var path = source.getBindingPath("value");
			var value = source.getValue();
		
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);

		},
			handleDate: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("dateValue"),
				value = source.getDateValue(),
				sPath = this.getView().getBindingContext().sPath;
			if (!evt.getParameter("valid")) {
				source.setDateValue();
				this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, null);
				this.handleonValueInput(evt);
				return;
			}
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, value);
			this.handleonValueInput(evt);
		},
		onChangeAmount: function(evt) {
			var oModel = this.getView().getBindingContext().getModel(),
				oView = this.getView(),
				sPath = oView.getBindingContext().sPath;
			/*	ctx = oView.getBindingContext(),
				data = ctx.getObject();*/
			var JsonModel = this.getView().getModel("jsonViewMod");

			var vAmount = evt.getParameter("value");
			oModel.setProperty(sPath + "/Amount", evt.getParameter("value"));

			var validAmount = /^[1-9][0-9]*(\.{0,1}([0-9]){0,2})?$/;
			if (vAmount) {
				if (vAmount.startsWith("-")) {
					evt.getSource().setValueState("Error");
					return;
				}
				if (vAmount.match(validAmount)) {
					//	this.findAndReplace(vAmount, ".", "");
					evt.getSource().setValueState("None");

				} else {
					vAmount = vAmount.substring(0, vAmount.length - 1);
					vAmount = this.findAndReplace(vAmount, ".", "");
					evt.getSource().setValue(vAmount);
				}
			} else {
				evt.getSource().setValueState("Error");
			}

			var Amount = parseFloat(evt.getParameter("value"));
			var avaliableAmount = parseFloat(JsonModel.getProperty("/AvailMattBal"));
			if (Amount > avaliableAmount) {
				sap.m.MessageBox.show("Amount should be less than Available Matter Balance", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "WARNING",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						oModel.setProperty(sPath + "/" + "Amount", "");
					}
				});

			}
		},
		count: function(s1, letter) {
			return (s1.match(RegExp(letter, 'g')) || []).length;
		},

		findAndReplace: function(string, target, replacement) {
			var i = 0,
				length = string.length;
			for (i; i < length; i++) {
				var count1 = this.count(string, '\\.');
				if (count1 > 1) {
					string = string.replace(target, replacement);
				}
			}
			return string;
		},
		onChangeSourceMatter: function(evt) {
			var oModel = this.getView().getBindingContext().getModel(),
				JsonModel = this.getView().getModel("jsonViewMod"),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/" + "SorcAccNum", "");
			oModel.setProperty(sPath + "/" + "HbankDescS", "");
			oModel.setProperty(sPath + "/" + "Currency", "");
			JsonModel.setProperty("/AvailMattBal", "");
			JsonModel.setProperty("/TotMattBal", "");

		},

		onChangeDestinationMatter: function(evt) {
			var oModel = this.getView().getBindingContext().getModel(),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/" + "DestAccNum", "");
			oModel.setProperty(sPath + "/" + "HbankDescD", "");

			//	oModel.setProperty(sPath + "/" + "Currency", "");

		},
		onChangeBankAccNo: function() {

			var oModel = this.getOwnerComponent().getModel(),
				oView = this.getView(),
				that = this,
				jsonModel = oView.getModel("jsonViewMod"),
				ctx = oView.getBindingContext(),
				data = ctx.getObject();
			this.onChnageDestiAccNo();
			if (data.Office !== "" && data.SourceMatter !== "" && data.SorcAccNum !== "") {
				sap.ui.core.BusyIndicator.show();
				var sPath = "/Trustmatterbalances(Office='" + data.Office + "',SourceMatter='" + data.SourceMatter + "',AccNum='" + data.SorcAccNum +
					"')";
				oModel.read(sPath, {
					success: function(oData, oResp) {
						sap.ui.core.BusyIndicator.hide();
						jsonModel.setProperty("/AvailMattBal", oData.AvailMattBal);
						jsonModel.setProperty("/TotMattBal", oData.TotMattBal);
						that.handleAmountValid();
					}
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageBox.show("Please fill required field Office, Matter and Account Number", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "WARNING",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {

					}
				});
			}

		},
		jsonPropertyNull: function() {
			var JsonModel = this.getView().getModel("jsonViewMod");
			JsonModel.setProperty("/AvailMattBal", "");
			JsonModel.setProperty("/TotMattBal", "");
			JsonModel.setProperty("/ReasonForTrns", "");
		},

		onChnageDestiAccNo: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				oView = this.getView(),
				ctx = oView.getBindingContext(),
				data = ctx.getObject();
			var sPath = this.getView().getBindingContext().sPath;
			if (data.SorcAccNum === data.DestAccNum) {
				sap.m.MessageBox.show("Destination Account Number should not be same as Source Account Number", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "WARNING",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						oModel.setProperty(sPath + "/" + "DestAccNum", "");
						oModel.setProperty(sPath + "/" + "HbankDescD", "");
					}
				});

			}
		},
		onPressSave: function(oEvent) {
			var oViewModel = this.getModel("jsonViewMod");
			var bVal = this._handleValidation();
			if (!bVal) {
				return;
			}
			//		sap.ui.core.BusyIndicator.show();
			var oView = this.getView(),
				that = this,
				ctx = oView.getBindingContext(),
				data = ctx.getObject();
			var oOffice = formatter.validate(data.Office);
			var oTransferDate = formatter.formatDate(data.TransferDate);
			var oSourceMatter = formatter.validate(data.SourceMatter);
			var oClientNumSource = formatter.validate(data.ClientNumS);
			var oSourceAccNum = formatter.validate(data.SorcAccNum);
			var oDestinMatter = formatter.validate(data.DestinMatter);
			var oClientNumDest = formatter.validate(data.ClientNumD);
			var oDestAccNum = formatter.validate(data.DestAccNum);
			var oAmount = formatter.validate(data.Amount);
			var oCurrency = formatter.validate(data.Currency);
			var oAuthBy = formatter.validate(data.AuthBy);
			var JsonModel = this.getView().getModel("jsonViewMod"),
				AvailMattBal = parseFloat(JsonModel.getProperty("/AvailMattBal"));
			var oReasonForTrns = formatter.validate(data.ReasonForTrns);

			if (AvailMattBal <= 0 || oAmount <= 0) {
				sap.m.MessageBox.show("Available Matter Balance or Amount is less than zero, cannot save the record", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "WARNING",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						return;
					}
				});

			} else {

				var oModel = this.getOwnerComponent().getModel();
				var createpayload = {
					"Office": oOffice,
					"TransferDate": oTransferDate,
					"SourceMatter": oSourceMatter,
					"ClientNumS": oClientNumSource,
					"SorcAccNum": oSourceAccNum,
					"DestinMatter": oDestinMatter,
					"ClientNumD": oClientNumDest,
					"DestAccNum": oDestAccNum,
					"Amount": oAmount,
					"Currency": oCurrency,
					"AuthBy": oAuthBy,
					"ReasonForTrns": oReasonForTrns
				};

				oModel.create("/TrustbankSet", createpayload, {
					success: function(oData, oResp) {
						//	sap.ui.core.BusyIndicator.hide();
						var sflag = oData.GeneratedId;
						var msg = oData.Return;
						if (sflag === "S") {
							this.onMessageSuccessDialog(oData);
						} else {
							sap.m.MessageBox.show(msg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {

								}
							});
						}
					}.bind(this),
					error: function(oErr) {
						//	sap.ui.core.BusyIndicator.hide();
						var oResp = JSON.parse(oErr.responseText);
						if (oResp.error.innererror.errordetails.length > 0) {
							this.getOwnerComponent()._oErrorHandler._bMessageOpen = true;
						}
						var resp = oErr.responseText,
							result = resp ? resp : 1;
						if (result !== 1) {
							//var respError = that.converttoJson(result);
							//stop showing standar popup
							this.applyResp(jQuery.parseJSON(result));
						}
					}.bind(this)

				}, {
					async: true
				});

			}
		},

		onMessageSuccessDialog: function(oResp) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: 
				new sap.m.Text({
					text: oResp.Return
				}),
				buttons: [
					new sap.m.Button({
						text: "Display Document",
						press: function() {
							dialog.close();
							that._displayForm("display", oResp);
						}
					}),
					new sap.m.Button({
						text: "OK",
						press: function() {
							that.createEntry();
							that.jsonPropertyNull();
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

			_displayForm: function(sKey, oResp) {
			var oModel = this.getOwnerComponent().getModel(),
				oViewModel = this.getModel("jsonViewMod");

			if (oResp) {
				oViewModel.setProperty("/display", oResp);
			}

			var oContent = oViewModel.getProperty("/display");
			var DocNo = oViewModel.getProperty("/DocNo");
			if (sKey === "display") {
				this._showFormFragment("BankToBankDisplay");
				this.oOutputComp.invokeDocDisp(oContent.Gjahr, oContent.DocNo, oContent.Bukrs);
				this.getView().byId("idDispContainer").setComponent(this.oOutputComp);
			}
		},
		
	/*	handleDispDoc: function(evt) {
			var source = evt.getSource(),
				docNo,
				oViewModel = this.getModel("jsonViewMod");
			docNo = source.data("DocNo");
			if (docNo === oViewModel.getProperty("/DocNo1")) {
				oViewModel.setProperty("/btnDocNo1", false);
				oViewModel.setProperty("/btnDocNo2", true);
			}
			if (docNo === oViewModel.getProperty("/DocNo2")) {
				oViewModel.setProperty("/btnDocNo1", true);
				oViewModel.setProperty("/btnDocNo2", false);
			}
			oViewModel.setProperty("/DocNo", docNo);
			this._displayForm("display");
		},*/
		clearValue: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				jsonModel = this.getView().getModel("jsonViewMod"),
				sPath = this.getView().getBindingContext().sPath;
			oModel.setProperty(sPath + "/" + "TransferDate", null);
			oModel.setProperty(sPath + "/" + "Amount", "");
			oModel.setProperty(sPath + "/" + "AuthBy", "");
			oModel.setProperty(sPath + "/" + "Currency", "");
			oModel.setProperty(sPath + "/" + "ReasonForTrns", "");
			oModel.setProperty(sPath + "/" + "SourceMatter", "");
			oModel.setProperty(sPath + "/" + "ClientNumS", "");
			oModel.setProperty(sPath + "/" + "SorcAccNum", "");
			oModel.setProperty(sPath + "/HbankDescD", "");
			oModel.setProperty(sPath + "/HbankDescS", "");
			jsonModel.setProperty("/AvailMattBal", "");
			jsonModel.setProperty("/ReasonForTrns", "");
			jsonModel.setProperty("/TotMattBal", "");
			oModel.setProperty(sPath + "/" + "DestinMatter", "");
			oModel.setProperty(sPath + "/" + "ClientNumD", "");
			oModel.setProperty(sPath + "/" + "DestAccNum", "");
			oModel.setProperty(sPath + "/OfficeDesc", "");
			oModel.setProperty(sPath + "/AuthByDesc", "");
			oModel.setProperty(sPath + "/SorcMattDesc", "");
			oModel.setProperty(sPath + "/ClntNumSDesc", "");
			oModel.setProperty(sPath + "/DestMattDesc", "");
			oModel.setProperty(sPath + "/DestClntDesc", "");

		},

		_handleValidation: function() {

			var oView = this.getView();
			var oViewModel = this.getView().getModel("jsonViewMod");
			var aInputs = [
				oView.byId("idOffice"),
				oView.byId("idTransferDate"),
				oView.byId("idAmount"),
				oView.byId("idAuthBy"),
				//	oView.byId("idCurrency"),
				oView.byId("idReasonForTrns"),
				oView.byId("idSourceMatter"),
				//	oView.byId("idClientNumS"),
				oView.byId("idSorcAccNum"),
				//	oView.byId("idAvailMattBal"),
				//	oView.byId("idTotMattBal"),
				oView.byId("idDestinMatter"),
				//	oView.byId("idClientNumD"),
				oView.byId("idDestAccNum")

				//	oView.byId("idbankAccNum")
			];

			var bValidationError = false;

			// check that inputs are not empty
			// this does not happen during data binding as this is only triggered by changes
			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValue()) {
					oInput.setValueState("None");
					bValidationError = true;
				} else {
					oInput.setValueState("Error");
				}
			});

			jQuery.each(aInputs, function(i, oInput) {
				if (oInput.getValueState() === "Error") {
					bValidationError = false;
				}
			});

			//	bValidationError = this.handleAmountValid();

			if (!bValidationError) {
				sap.m.MessageBox.alert("Please fill all required fields");
			}
			return bValidationError;
		},

		handleAmountValid: function() {
			var oModel = this.getView().getBindingContext().getModel(),
				oView = this.getView(),
				sPath = oView.getBindingContext().sPath,
				ctx = oView.getBindingContext(),
				data = ctx.getObject(),
				AvailMattBal = parseFloat(parseFloat(this.getView().getModel("jsonViewMod").getProperty("/AvailMattBal")).toFixed(3)),
				Amount = parseFloat(parseFloat(data.Amount).toFixed(3));
			if (Amount !== "") {
				if (Amount > AvailMattBal) {
					sap.m.MessageBox.show("Amount should be less than Available Amount", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "WARNING",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							oModel.setProperty(sPath + "/" + "Amount", "");
						}
					});

				}
			}

		},

		handleonValueInput: function(evt) {
			var oSrc = evt.getSource();

			if (oSrc.getValue().length > 0) {
				oSrc.setValueState("None");
			} else {
				oSrc.setValueState("Error");
			}
		},

		handleOnNewDoc: function() {
			this._showFormFragment("BankToBankTransfer");
			this.createEntry();
			this.jsonPropertyNull();
		},

		//fragments
		_formFragments: {},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "trustbtb.fragments." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.getView().byId("page");

			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},

		onExit: function() {
			for (var sPropertyName in this._formFragments) {
				if (!this._formFragments.hasOwnProperty(sPropertyName)) {
					return;
				}

				this._formFragments[sPropertyName].destroy();
				this._formFragments[sPropertyName] = null;
			}

			if (this.oOutputComp) {
				this.oOutputComp.destroy();
			}
		}

	});
});