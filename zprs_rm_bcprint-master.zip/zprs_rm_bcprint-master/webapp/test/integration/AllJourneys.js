jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"rmbarcodeprint/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"rmbarcodeprint/test/integration/pages/Worklist",
		"rmbarcodeprint/test/integration/pages/Object",
		"rmbarcodeprint/test/integration/pages/NotFound",
		"rmbarcodeprint/test/integration/pages/Browser",
		"rmbarcodeprint/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "rmbarcodeprint.view."
	});

	sap.ui.require([
		"rmbarcodeprint/test/integration/WorklistJourney",
		"rmbarcodeprint/test/integration/ObjectJourney",
		"rmbarcodeprint/test/integration/NavigationJourney",
		"rmbarcodeprint/test/integration/NotFoundJourney",
		"rmbarcodeprint/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});