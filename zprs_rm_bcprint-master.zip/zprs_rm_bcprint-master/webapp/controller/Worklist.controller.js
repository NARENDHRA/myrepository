/* global html2pdf:true */
sap.ui.define([
	"rmbarcodeprint/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"rmbarcodeprint/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet",
	"rmbarcodeprint/libs/html2pdf",
	"rmbarcodeprint/libs/html2canvas.min",
	"rmbarcodeprint/libs/jspdf.debug"

], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast, Spreadsheet) {
	"use strict";

	return BaseController.extend("rmbarcodeprint.controller.Worklist", {

		formatter: formatter,
		_smartFilterBar: null,
		onInit: function() {
			this._smartFilterBar = this.getView().byId("printBarcodes");
			var jsBCPModel = new JSONModel({
				BCPrintBtn: false
			});
			this.setModel(jsBCPModel, "PBCView");
		},
		onAssignedFiltersChanged: function(oEvent) {
			var oStatusText = this.getView().byId("statusText");
			if (oStatusText && this._smartFilterBar) {
				var sText = this._smartFilterBar.retrieveFiltersWithValuesAsText();

				oStatusText.setText(sText);
			}
		},
		onSelectionRow: function(oEvt) {
			var oTable = this.getView().byId("LineItemsSmartTable").getTable(),
				oSelectedLength = oTable.getSelectedIndices(),
				PBCView = this.getView().getModel("PBCView");
			if (oSelectedLength) {
				PBCView.setProperty("/BCPrintBtn", true);
			} else {
				PBCView.setProperty("/BCPrintBtn", false);
			}

		},
		//Generate pdf
		generatePDF: function() {
			var element = document.getElementById(this.getView().getId() + '--idVBox');
			var options = {
				margin: 0.2,
				filename: "barcode",
				image: {
					type: 'jpeg',
					quality: 0.98
				},
				html2canvas: {
					scale: 4,
					dpi: 192,
					letterRendering: true,
					logging: true
				},
				jsPDF: {
					unit: 'in',
					format: 'letter',
					orientation: 'portrait'
						// orientation: 'landscape'
				}
			};
			html2pdf(element, options);
			this.getView().byId("idVBox").removeAllItems();
			// this.getView().byId("idVBox").setVisible(false);
		},

		//On Print Barcode For Smart Table
		onPrintBarcodePress: function(oEvnt) {
			// this.getView().byId("idVBox").setVisible(true);
			var oTable = this.getView().byId("LineItemsSmartTable").getTable();
			var oSelectedIndices = oTable.getSelectedIndices();
			var vbox = this.getView().byId("idVBox");
			$.each(oSelectedIndices, function(i, value) {
				var barcodetextitem = "*" + oTable.getContextByIndex(value).getProperty("Barcode") + "*";
				// var barcodetextitem = "*" + oSelectedIndices[i].getBindingContext().getProperty("Barcode") + "*";
				var box = new sap.m.VBox({
					items: [
						new sap.m.Text({
							text: barcodetextitem
						}).addStyleClass("barCode"),
						new sap.m.Text({
							text: oTable.getContextByIndex(value).getProperty("Barcode")
						}).addStyleClass("PDFtextClass")
					]
				}).addStyleClass("VBoxClass");
				vbox.insertItem(box, vbox.getItems().length);
			});
			jQuery.sap.delayedCall(1000, this, function() {
				this.generatePDF();
			});
		},
		_getTableData: function() {
			var oTable = this.getView().byId("LineItemsSmartTable").getTable(),
				oTabRows = oTable.getRows(),
				oTableData = [];
			$.each(oTabRows, function(i, rows) {
			var oContext = oTable.getRows()[i].getBindingContext();
				if (oContext !== undefined) {
					var oRowObj = oContext.getObject();
					oTableData.push(oRowObj);

				} else {
					return;
				}
			});
			return oTableData;
		},
		_createColumnConfig: function() {
			var i18nLabel = this.getView().getModel("i18n").getResourceBundle();

			return [{
				label: i18nLabel.getText("Barcode"),
				property: "Barcode"
			}, {
				label: i18nLabel.getText("WorkingOfficeName"),
				property: "Workingoffice"
			}, {
				label: i18nLabel.getText("WorkingOffice"),
				property: "Workingofficek"
			}];
		},
		onExportSpreadSheetPressed: function() {
			var aCols, oSettings, oSheet, oTableData;
			aCols = this._createColumnConfig();
			oTableData = this._getTableData();
			// oTableData = [{}];
			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: oTableData
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function() {
					MessageToast.show('Spreadsheet export has finished');
				})
				.finally(function() {
					// oSheet.destroy();
				});
		}

	});
});