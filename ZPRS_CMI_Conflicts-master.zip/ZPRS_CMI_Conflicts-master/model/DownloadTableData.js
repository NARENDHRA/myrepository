jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
conflictsn.model.DownloadTableData = {
	onDataExport: sap.m.Table.prototype.exportData || function(oModel, sPath, text, a) {
		var array = [];
		for (var i = 0; i < text.length; i++) {
			var obj = {
				name: text[i],
				template: {
					content: "{" + a[i] + "}"
				}
			};
			array.push(obj);
		}
		var oExport = new sap.ui.core.util.Export({
			exportType: new sap.ui.core.util.ExportTypeCSV({
				separatorChar: ","
			}),
			// Pass in the model created above
			models: oModel,
			// binding information for the rows aggregation
			rows: {
				path: sPath
			},
			// column definitions with column name and binding info for the content

			columns: array
		});
		// download exported file
		oExport.saveFile();
	}
};