sap.ui.define([
	"conflictsn/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"conflictsn/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Input",
	"sap/ui/layout/HorizontalLayout",
	"sap/ui/layout/VerticalLayout",
	"sap/m/Token",
	"sap/ui/table/TablePersoController",
	"conflictsn/model/PersoService",
	"conflictsn/model/DownloadTableData"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox, Button, Dialog, Label, Input,
	HorizontalLayout, VerticalLayout, Token, TablePersoController, PersoService, DownloadTableData) {
	"use strict";

	return BaseController.extend("conflictsn.controller.ConflictsSearch", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.oBusyDialog = new sap.m.BusyDialog();
			this.bOrgTree = false;
			this.Cmino = "";
			var oViewModel = new JSONModel({
				tableBusyDelay: 0,
				tableCount: 0,
				tableNoDataText: "To start, enter your selection criteria and run the search.",
				enableSubmitReview: false,
				enableBeginNewRequest: false,
				chartRoleBusy: false,
				chartPracticeGroupBusy: false,
				chartMatterStatusBusy: false,
				tableBusy: false
			});
			this.setModel(oViewModel, "worklistView");
			this.getRouter().getRoute("conflicts").attachPatternMatched(this._onObjectMatched, this);
			this.getRouter().getRoute("conflictsInbox").attachPatternMatched(this._onObjectMatched, this);

			var sPath = jQuery.sap.getModulePath("conflictsn.model", "/chart.json"),
				oChartModel = new JSONModel();

			$.ajax({
				url: sPath
			}).then(function(oData) {
				oChartModel.setData(oData);
				this.getView().setModel(oChartModel, "chartModel");

			}.bind(this));

			this.aChartFilter = [];

			this.oSmartFilter = this.getView().byId("ConflictSearchFilterID");
			this.orgHierarchyInit();
			var that = this;
			this.oSmartFilter.validateMandatoryFields = function() {
				var oControl = this.getControlByKey("Searchtermline"),
					aTokens = oControl.getAggregation("items")[0].getTokens(),
					sVal = oControl.getAggregation("items")[0].getValue();
				that.aTokenFilter = [];
				that.aSearchTokens = [];

				if (aTokens.length > 0 || sVal.length > 0) {
					if (aTokens) {
						aTokens.forEach(function(oToken) {
							that.aSearchTokens.push(oToken.getProperty("text"));
							that.aTokenFilter.push(new Filter("Searchtermline", "Contains", oToken.getProperty("text")));
						});
					}
					if (sVal) {
						that.aTokenFilter.push(new Filter("Searchtermline", "Contains", sVal));
					}
					return true;
				} else {
					return false;
				}
			};

			// init and activate controller
			this._oTPC = new TablePersoController({
				table: this.getView().byId("ConflictSearchTableId"),
				componentName: "conflictsn",
				persoService: PersoService
			});

			this.getModel("worklistView").setProperty("/panelVisible", true);
		},

		onPersoButtonPressed: function() {
			this._oTPC.openDialog();
		},

		_onObjectMatched: function(oEvent) {
			if (oEvent.getParameter("arguments").Searchid) {
				this.Searchid = oEvent.getParameter("arguments").Searchid;
				this.bindTableData(this.Searchid);
			}
		},

		bindTableData: function(searchid) {
			var that = this,
				oViewModel = this.getModel("worklistView"),
				aFilter = [];
			this.oCSTableModel = new JSONModel();
			this.getView().setModel(that.oCSTableModel, "csTableModel");
			this._oModel = this.getModel();

			this.oBusyDialog.open();
			aFilter.push(new Filter("Searchid", "EQ", searchid));
			var oJsonModel = new JSONModel();
			oJsonModel.loadData("/sap/opu/odata/sap/ZPRS_CMI_CONFLICTS_SRV/Searchheaders('" + searchid + "')");
			oJsonModel.attachRequestCompleted(function() {
				var sDate;
				if (oJsonModel.oData.d.Changedat === null) {
					sDate = new Date(parseInt(oJsonModel.oData.d.Createdat.split("(")[1].split(")")[0]));
				} else {
					sDate = new Date(parseInt(oJsonModel.oData.d.Changedat.split("(")[1].split(")")[0]));
				}
				var sCreatedDate = (sDate.getMonth() + 1) + "/" + sDate.getDate() + "/" + sDate.getFullYear() + "-" + sDate.getHours() + ":" +
					sDate.getMinutes() + ":" + sDate.getSeconds();
				that.getModel("worklistView").setProperty("/headerSearchTermLabel", "Search Name: ");
				that.getModel("worklistView").setProperty("/headerSearchTermText", oJsonModel.oData.d.Searchname + ", " + sCreatedDate);
				var oFilterData = JSON.parse(oJsonModel.oData.d.Searchstring);
				var multiOgNames = that.getView().byId("multiOgNames");
				if (oFilterData.hasOwnProperty("Searchtermline")) {
					$.each(oFilterData.Searchtermline.items, function(i, val) {
						multiOgNames.addToken(new sap.m.Token({
							text: val
						}));
					});
				}
				that.oSmartFilter.setFilterData(oFilterData);
			});

			this._oModel.read("/Searchresults", {
				filters: aFilter,
				success: function(oData) {
					that.oCSTableModel.setData(oData);
					that.getChartModel(oData);
					that.setCount();
					var oTable = that.getView().byId("ConflictSearchTableId");
					oTable._handleRowCountModeAuto();
					oViewModel.setProperty("/chartRoleBusy", false);
					oViewModel.setProperty("/chartPracticeGroupBusy", false);
					oViewModel.setProperty("/chartMatterStatusBusy", false);
					oViewModel.setProperty("/tableBusy", false);
					that.oBusyDialog.close();
				},
				error: function(oError) {
					oViewModel.setProperty("/chartRoleBusy", false);
					oViewModel.setProperty("/chartPracticeGroupBusy", false);
					oViewModel.setProperty("/chartMatterStatusBusy", false);
					oViewModel.setProperty("/tableBusy", false);
					if (that.msgBox) {
						return;
					}
					that.msgBox = MessageBox.error(oError.message, {
						title: "Error",
						actions: [MessageBox.Action.CLOSE]
					});
					this.oBusyDialog.close();
				}
			});
		},

		onHidePress: function() {
			this.byId("idSplitApp").setMode(sap.m.SplitAppMode.HideMode);
			this.getModel("worklistView").setProperty("/panelVisible", true);
		},

		onShowPress: function() {
			this.getModel("worklistView").setProperty("/panelVisible", false);
			this.byId("idSplitApp").setMode(sap.m.SplitAppMode.StretchCompressMode);
		},

		getChartModel: function(oData) {
			var arrayElementsRole = [],
				arrayElementsPracticeGroup = [],
				arrayElementsStatus = [],
				currentRole = null,
				cntRole = 0,
				currentPracticeGroup = null,
				cntPracticeGroup = 0,
				currentStatus = null,
				cntStatus = 0;

			this.getModel("chartModel").setData({
				"Role": [],
				"PracticeGroup": [],
				"MatterStatus": []
			});

			$.each(oData.results, function(i) {
				arrayElementsRole.push(oData.results[i].Role);
				arrayElementsPracticeGroup.push(oData.results[i].Practicegroup);
				arrayElementsStatus.push(oData.results[i].Matterstatus);
			});

			arrayElementsRole.sort();
			arrayElementsPracticeGroup.sort();
			arrayElementsStatus.sort();

			for (var i = 0; i < arrayElementsRole.length; i++) {
				if (arrayElementsRole[i] !== currentRole) {
					if (cntRole > 0) {
						this.getModel("chartModel").getData().Role.push({
							"Role": currentRole,
							"Count": cntRole
						});
					}
					currentRole = arrayElementsRole[i];
					cntRole = 1;
				} else {
					cntRole++;
				}
			}
			if (cntRole > 0) {
				this.getModel("chartModel").getData().Role.push({
					"Role": currentRole,
					"Count": cntRole
				});
			}

			for (i = 0; i < arrayElementsPracticeGroup.length; i++) {
				if (arrayElementsPracticeGroup[i] !== currentPracticeGroup) {
					if (cntPracticeGroup > 0) {
						this.getModel("chartModel").getData().PracticeGroup.push({
							"PracticeGroup": currentPracticeGroup,
							"Count": cntPracticeGroup
						});
					}
					currentPracticeGroup = arrayElementsPracticeGroup[i];
					cntPracticeGroup = 1;
				} else {
					cntPracticeGroup++;
				}
			}
			if (cntPracticeGroup > 0) {
				this.getModel("chartModel").getData().PracticeGroup.push({
					"PracticeGroup": currentPracticeGroup,
					"Count": cntPracticeGroup
				});
			}

			for (i = 0; i < arrayElementsStatus.length; i++) {
				if (arrayElementsStatus[i] !== currentStatus) {
					if (cntStatus > 0) {
						this.getModel("chartModel").getData().MatterStatus.push({
							"Status": currentStatus,
							"Count": cntStatus
						});
					}
					currentStatus = arrayElementsStatus[i];
					cntStatus = 1;
				} else {
					cntStatus++;
				}
			}
			if (cntStatus > 0) {
				this.getModel("chartModel").getData().MatterStatus.push({
					"Status": currentStatus,
					"Count": cntStatus
				});
			}

			this.getModel("chartModel").refresh();
		},

		onSearchFilter: function(oEvent) {
			var aFilter = oEvent.getSource().getFilters(),
				aFilters = aFilter.concat(this.aTokenFilter),
				oViewModel = this.getModel("worklistView"),
				that = this;
			this.oCSTableModel = new JSONModel();

			this.oBusyDialog.open();
			this.getModel().read("/Searchresults", {
				filters: aFilters,
				success: function(oData) {
					that.oCSTableModel.setData(oData);
					that.getView().setModel(that.oCSTableModel, "csTableModel");
					that.getChartModel(oData);
					that.setCount();

					var oTable = that.getView().byId("ConflictSearchTableId");
					oTable._handleRowCountModeAuto();

					oViewModel.setProperty("/chartRoleBusy", false);
					oViewModel.setProperty("/chartPracticeGroupBusy", false);
					oViewModel.setProperty("/chartMatterStatusBusy", false);
					oViewModel.setProperty("/tableBusy", false);

					that.oBusyDialog.close();
				},
				error: function(oError) {
					oViewModel.setProperty("/chartRoleBusy", false);
					oViewModel.setProperty("/chartPracticeGroupBusy", false);
					oViewModel.setProperty("/chartMatterStatusBusy", false);
					oViewModel.setProperty("/tableBusy", false);
					if (that.msgBox) {
						return;
					}
					that.msgBox = sap.m.MessageBox.error(oError.message, {
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE]
					});
					that.oBusyDialog.close();
				}
			});
		},

		onFilterChange: function() {
			this.getView().byId("savebtnId").setEnabled(false);

			this.addToken();

			var oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/chartRoleBusy", false);
			oViewModel.setProperty("/chartPracticeGroupBusy", false);
			oViewModel.setProperty("/chartMatterStatusBusy", false);
			oViewModel.setProperty("/tableBusy", false);
		},

		addToken: function() {
			var multiOgNames = this.getView().byId("multiOgNames");
			if (multiOgNames.getValue() !== "" && this.bOrgTree === false) {
				multiOgNames.addToken(new sap.m.Token({
					text: multiOgNames.getValue()
				}));
			}
			this.bOrgTree = false;
			multiOgNames.setValue("");
		},

		onSave: function() {
			var that = this;
			var dialog = new Dialog({
				title: "Confirm",
				type: "Message",
				content: [
					new VerticalLayout({
						content: [
							new Label({
								text: "Are you sure you want to Save your Search Results?"
							}),
							new HorizontalLayout({
								content: [
									new Label({
										text: "Search Name :",
										required: true,
										labelFor: "inputId"
									}).addStyleClass("sapUiTinyMargin"),
									new Input("inputId", {
										liveChange: function(oEvent) {
											var sText = oEvent.getParameter("value");
											var parent = oEvent.getSource().getParent().getParent().getParent();
											parent.getBeginButton().setEnabled(sText.length > 0);
										},
										width: "100%",
										placeholder: "Enter Search Name"
									})
								]
							}).addStyleClass("sapUiTinyMarginTop")
						]
					})
				],
				beginButton: new Button({
					text: "Submit",
					enabled: false,
					press: function() {
						var sText = sap.ui.getCore().byId("inputId").getValue();
						that.onDialogSave(sText);
						dialog.close();
					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		onDialogSave: function(sSearchName) {
			var aResults = this.getView().getModel("csTableModel").getData(),
				oFilterData = this.oSmartFilter.getFilterData(),
				that = this;
			oFilterData.Searchtermline = {
				items: this.aSearchTokens
			};
			var sFilterData = JSON.stringify(oFilterData);
			var oPayload = {
				"Searchname": sSearchName,
				"Searchstring": sFilterData,
				"Results": aResults
			};

			var oModel = this.getModel();
			this.oBusyDialog.open();
			oModel.create("/Searchheaders", oPayload, {
				success: function(oData) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.success(
						"'" + sSearchName + "' Search results saved successfully", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					that.Searchid = oData.Searchid;
					that.bindTableData(that.Searchid);
					this.oBusyDialog.close();
				}.bind(this),
				error: function(oError) {
					sap.m.MessageBox.error(oError.message, {
						title: "Error",
						actions: [sap.m.MessageBox.Action.CLOSE]
					});
					this.oBusyDialog.close();
				}.bind(this)
			});
		},

		onSubmitForReview: function() {
			var that = this,
				oModel = this.getModel(),
				batchChanges = [],
				oTable = this.getView().byId("ConflictSearchTableId"),
				aResults = this.getTableSelectedData(oTable),
				batchModel = new sap.ui.model.odata.ODataModel(oModel.sServiceUrl),
				rFlag = false;
			this._oTable = oTable;
			this.selectedRowIndices = oTable.getSelectedIndices();
			$.each(aResults, function(i, oRowData) {
				if (oRowData.Wfstatk !== "") {
					rFlag = true;
					MessageBox.information(
						"Conflict is already submitted for review", {}
					);
					this.byId("ConflictSearchTableId").removeSelectionInterval(this.selectedRowIndices[i], this.selectedRowIndices[i]);
					return;
				}
				batchChanges.push(batchModel.createBatchOperation("/Searchresults ", "POST", oRowData));
			}.bind(that));
			if (rFlag) {
				return;
			}
			batchModel.addBatchChangeOperations(batchChanges);
			batchModel.setUseBatch(true);
			batchModel.submitBatch(function() {
				that.getResults(that.Searchid);
				MessageBox.success("Submitted for Review", {});
				that.getModel("worklistView").setProperty("/enableBeginNewRequest", true);
			}, function(oError) {
				MessageBox.error(oError.message, {});
			});
		},

		getResults: function(searchid) {
			var that = this,
				oModel = this.getModel();
			oModel.read("/Searchheaders('" + searchid + "')", {
				urlParameters: {
					"$expand": "Results"
				},
				success: function(oData) {
					that.Cmino = oData.Cmino;
				},
				error: function(oError) {}
			});
		},

		onNewRequest: function() {
			var sObject = "ZPRS_CMI_NEWREQ",
				action = "display&/ConflictSearch/NewRequest/" + this.Cmino + "/" + this.Searchid;
			this._CrossApplicationNavigation(sObject, action);
		},

		_CrossApplicationNavigation: function(sObject, action) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: sObject,
					action: action
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onRowSelection: function(oEvent) {
			var oTable = oEvent.getSource(),
				aIndices = oTable.getSelectedIndices(),
				bVal = (aIndices.length > 0 ? true : false);

			if (this.Searchid && this.Searchid !== "") {
				this.getModel("worklistView").setProperty("/enableSubmitReview", bVal);
			}
		},

		getTableSelectedData: function(oTable) {
			var aResults = [];

			if (oTable) {
				var aIndices = oTable.getSelectedIndices();
				jQuery.each(aIndices, function(i, index) {
					var obj = oTable.getContextByIndex(index).getObject();
					if (obj.hasOwnProperty("__metadata")) {
						delete obj.__metadata;
					}
					aResults.push(obj);
				});
			}
			return aResults;
		},

		onSelectListItem: function() {
			var roleItems = this.getView().byId("idListRole").getSelectedItems(),
				PGItems = this.getView().byId("idListPG").getSelectedItems(),
				MSItems = this.getView().byId("idListMS").getSelectedItems(),
				aFilters = [],
				i;

			if (roleItems.length > 0) {
				for (i = 0; i < roleItems.length; i++) {
					aFilters.push(new Filter("Role", "EQ", roleItems[i].getTitle()));
				}
			}
			if (PGItems.length > 0) {
				for (i = 0; i < PGItems.length; i++) {
					aFilters.push(new Filter("Practicegroup", "EQ", PGItems[i].getTitle()));
				}
			}
			if (MSItems.length > 0) {
				for (i = 0; i < MSItems.length; i++) {
					aFilters.push(new Filter("Matterstatus", "EQ", MSItems[i].getTitle()));
				}
			}

			var oFilter = new Filter({
				filters: aFilters,
				and: false
			});

			var oBinding = this.getView().byId("ConflictSearchTableId").getBinding("rows");
			if (aFilters.length > 0) {
				oBinding.filter(oFilter);
			} else {
				oBinding.filter(aFilters);
			}
			this.setCount();
		},

		setCount: function() {
			var oBinding = this.getView().byId("ConflictSearchTableId").getBinding("rows"),
				oViewModel = this.getModel("worklistView");
			oViewModel.setProperty("/tableCount", oBinding.iLength);
			if (oBinding.iLength === 0) {
				oViewModel.setProperty("/tableNoDataText", "No Data");
			} else {
				if (this.getModel("csTableModel").getData().results[0].Cmino !== "") {
					this.getView().byId("savebtnId").setEnabled(false);
					this.getModel("worklistView").setProperty("/enableBeginNewRequest", true);
					this.Cmino = this.getModel("csTableModel").getData().results[0].Cmino;
				} else {
					this.getView().byId("savebtnId").setEnabled(true);
					this.getModel("worklistView").setProperty("/enableBeginNewRequest", false);
				}
			}
		},

		onExcelDownloadPressed: function() {
			var oTable = this.getView().byId("ConflictSearchTableId");
			var sModel = oTable.getBindingInfo("rows").model;
			var sPath = oTable.getBindingInfo("rows").path;
			var oModel = this.getView().getModel(sModel);
			var a = [];
			var text = [];
			for (var j = 0; j < oTable.getColumns().length; j++) {
				var colPath = oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path;
				for (var i = 0; i < oTable.getRows()[0].getCells().length; i++) {
					if (oTable.getRows()[0].getCells()[i].getBindingInfo("text").parts[0].path === colPath) {
						a.push(oTable.getColumns()[j].getTemplate().getBindingInfo("text").parts[0].path);
						text.push(oTable.getColumns()[j].getLabel().getText());
					}
				}
			}
			DownloadTableData.onDataExport(oModel, sPath, text, a);
		},

		/***** Custom Org tree code goes here *******/

		//call this function in onInit 
		orgHierarchyInit: function() {
			var oViewModel;
			this.setSuggestionConfig();
			this.OrgStructure = this.makeOrgStructure();
			oViewModel = new JSONModel({
				SearchHeader: {
					Position: "",
					SearchName: "",
					Relation: ""
				},
				primaryOrgData: [

				],
				OrgData: this.getOrgData() //Source for multiinput search
			});
			oViewModel.setSizeLimit(4444);
			this.setModel(oViewModel, "orghierarchyView");
			this.getView().byId("multiOgNames").setShowSuggestion(false);
		},

		onSearchChecked: function(oEvent) {
			if (oEvent.getParameters().selected) {
				this.getView().byId("multiOgNames").setShowSuggestion(true);
				var sVal = this.getView().byId("multiOgNames").getValue();
				this.getView().byId("multiOgNames").fireSuggest({suggestValue: sVal});
			} else {
				this.getView().byId("multiOgNames").setShowSuggestion(false);
			}
		},

		onSuggest: function(oEvent) {
			var oSrc = oEvent.getSource();
			var oPopup = oSrc._oSuggestionPopup;
			oPopup.attachBeforeOpen(function() {
				oPopup.setContentWidth("60%");
				oPopup.setContentHeight("60%");
			});
		},

		onTokenChange: function() {

		},

		getStaticData: function(filename) {
			var data;
			var sPath = jQuery.sap.getModulePath("conflictsn.model", "/" + filename);
			$.ajax({
				url: sPath,
				dataType: 'json',
				async: false,
				success: function(resp) {
					data = resp;
				}
			});

			return data;
		},
		getOrgData: function() {
			return this.getStaticData("orgSearchData.json");
		},
		openQuickView: function(evt) {

		},

		addOrgTree: function(evt, familyTree) {
			var model = this.getModel("orghierarchyView");

			if (familyTree) {

				model.getData().primaryOrgData.push(familyTree);
			} else {
				this.showMessageBox("Not able to find Org Tree");
			}

			model.refresh();

		},
		getFamilyTree: function(duns, ultimateParent) {
			this.getModel("orghierarchyView").getProperty("/primaryOrgData");
			var orgTree;

			orgTree = this.OrgStructure.filter(function(obj) {

				return ((obj.ultimateParentDuns === ultimateParent) || obj.duns === duns);

			});
			return (orgTree[0]) ? orgTree[0] : null;
		},
		makeOrgStructure: function() {
			// Preparing data hierarchical structure
			var orgTree = [],
				nObj,
				flatData = this.getStaticData("orgSearchData.json");

			function makeOrgData(dataArr, parent, parentObj) {
				dataArr.forEach(function(obj) {

					if ((obj.companyResults.duns === obj.companyResults.parentDuns) && !obj.parsed) {
						obj.parsed = true;
						nObj = Object.assign({}, obj.companyResults);
						orgTree.push(nObj);
						nObj.children = [];
						makeOrgData(dataArr, nObj.duns, nObj);
					} else if ((obj.companyResults.parentDuns === parent) && !obj.parsed) {

						if (!parentObj.children) {
							parentObj.children = [];
						}

						nObj = Object.assign({}, obj.companyResults);
						parentObj.children.push(nObj);
						obj.parsed = true;
						makeOrgData(dataArr, nObj.duns, nObj);
					} else if (!obj.parsed) {
						if (!obj.companyResults.parentDuns) {
							obj.parsed = true;
							nObj = Object.assign({}, obj.companyResults);
							orgTree.push(nObj);
						}
					}

				});
			}

			makeOrgData(flatData.resultSet.hit);
			return orgTree;
		},
		showMessageBox: function(msg) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.information(
				msg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		ItemSelected: function(evt) {
			this.getView().byId("inputOrg");
		},
		showOrgPopup: function(evt) {
			var selItems = evt.getSource()._getSuggestionsTable().getSelectedContexts(),
				dunsArr = [],
				pDunsArr = [],
				duns,
				upDuns,
				familyTree,
				obj, i;
			for (i in selItems) {
				obj = selItems[i];
				duns = obj.getObject().companyResults.duns;
				upDuns = obj.getObject().companyResults.ultimateParentDuns;

				if ($.inArray(duns, dunsArr) < 0 && $.inArray(upDuns, pDunsArr) < 0) {
					familyTree = this.getFamilyTree(duns, upDuns);
					this.addOrgTree(evt, familyTree);
				}
				dunsArr.push(duns);
				pDunsArr.push(upDuns);

			}
			this.showOrgTree();

		},
		showOrgTree: function() {
			var model = this.getModel("orghierarchyView"),
				orgTreeTbl,
				that = this;

			this.bOrgTree = true;

			if (!this.OrgTreegDialog) {
				this.OrgTreegDialog = sap.ui.xmlfragment("conflictsn.fragments.OrgTreePopup", this);
			}
			this.getView().addDependent(this.OrgTreegDialog);
			orgTreeTbl = sap.ui.getCore().byId("OrgTreeTblPopup");

			this.OrgTreegDialog.attachAfterClose(function() {
				that.addToken();
				orgTreeTbl.clearSelection();
				model.getData().primaryOrgData = [];
				model.refresh();
			});

			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.OrgTreegDialog);
			this.OrgTreegDialog.open();

		},
		setSuggestionConfig: function() {
			var searchBoxId = this.getView().byId("multiOgNames"),
				suggTbl = searchBoxId._getSuggestionsTable(),
				enFlag,
				suggBtn = suggTbl.getParent().getFooter().getContent()[1];

			suggBtn.setText("Corporate Tree");
			suggBtn.setEnabled(false);
			suggTbl.getParent().attachAfterClose(function() {
				suggBtn.setEnabled(false);
			});
			suggTbl.setMode("MultiSelect");
			suggTbl._fireSelectionChangeEvent = function(evt) {
				enFlag = (evt[0].getParent().getSelectedItem()) ? true : false;
				suggBtn.setEnabled(enFlag);
			};
		},
		handleOrgTreeClose: function() {
			this.OrgTreegDialog.close();
		},
		handleOrgAdd: function() {
			var orgTreeTbl = sap.ui.getCore().byId("OrgTreeTblPopup"),
				selectedRows = orgTreeTbl.getBinding().getSelectedContexts(),
				multiOgNames = this.getView().byId("multiOgNames");

			this.addToken();

			selectedRows.forEach(function(obj) {

				multiOgNames.addToken(new Token({
					text: obj.getObject().companyName,
					key: obj.getObject().duns
				}));

			}, this);

			multiOgNames.setValue("");
			this.OrgTreegDialog.close();
		}

	});
});