sap.ui.define([
	"trustreversal/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"trustreversal/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("trustreversal.controller.TrustReversal", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/TrustreversalSet", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/CompCode", "");
				c.setProperty(oContextClients.getPath() + "/FiscalYear", "");
				c.setProperty(oContextClients.getPath() + "/SourceMatter", "");
				c.setProperty(oContextClients.getPath() + "/DocNumber", "");

				that.getView().setBindingContext(oContextClients);
			});

		},
		handleChangeDocNumber: function(evt) {
			var source = evt.getSource();
			var path = source.getBindingPath("value");
			var value = source.getValue();
			// set Value for Trust Revarsal Details Context
			var DocContext = this.getView().getBindingContext();
			var sPath = DocContext.getPath();
			var oDocNumberModel = DocContext.getModel();
			oDocNumberModel.setProperty(sPath + "/" + path, value);

		},
		onSavePress: function() {
			var oView = this.getView(),
				ctx = oView.getBindingContext(),
				obj = ctx.getObject();
			var CompCodeValue, FiscalYearValue, SourceMatterValue, DocNumberValue;
			CompCodeValue = obj.CompCode;
			FiscalYearValue = obj.FiscalYear;
			SourceMatterValue = obj.SourceMatter;
			DocNumberValue = obj.DocNumber;
			var oModel = this.getOwnerComponent().getModel();
			var createPayloadData = {
				"CompCode": CompCodeValue,
				"FiscalYear": FiscalYearValue,
				"SourceMatter": SourceMatterValue,
				"DocNumber": DocNumberValue
			};
			oModel.create("/TrustreversalSet", createPayloadData, function(oData, Response) {
					oData.Status = "S";
					if (oData.Status === "S") {
						sap.m.MessageBox.show(oData.Message, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {

							}
						});
					} else {
						sap.m.MessageBox.show(
							oData.Message, {
								icon: sap.m.MessageBox.Icon.WARNING,
								title: "Alert",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {

								}
							}
						);
					}
				},
				function(oResponse) {

					var err = (JSON.parse(oResponse.response.body).error.message.value);
					var msg = err;
					sap.m.MessageBox.show(
						"Create Operation Failed.", {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {

							}
						}
					);
				});

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("DocNumber", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("CompCode")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});