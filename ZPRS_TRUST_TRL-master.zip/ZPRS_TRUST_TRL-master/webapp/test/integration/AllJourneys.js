jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"trustreversal/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"trustreversal/test/integration/pages/Worklist",
		"trustreversal/test/integration/pages/Object",
		"trustreversal/test/integration/pages/NotFound",
		"trustreversal/test/integration/pages/Browser",
		"trustreversal/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "trustreversal.view."
	});

	sap.ui.require([
		"trustreversal/test/integration/WorklistJourney",
		"trustreversal/test/integration/ObjectJourney",
		"trustreversal/test/integration/NavigationJourney",
		"trustreversal/test/integration/NotFoundJourney",
		"trustreversal/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});