sap.ui.define([], function() {
	"use strict";
	return {
		_loadExcelJSONData: function() {
			var obj = {
				"Matter": "",
				"Kostl": "",
				"Amount": "",
				// "Taxcode": "",
				"Narr": "",
				"Workdate": null,
				"Reference": ""
			};
			return obj;
		}
	};
});