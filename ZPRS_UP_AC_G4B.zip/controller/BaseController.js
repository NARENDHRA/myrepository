sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/comp/smartfield/SmartField"
], function(Controller, SmartField) {
	"use strict";

	return Controller.extend("uploadanticipationcosts.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		//Excel data add to table
		handleValueChange: function(oEvnt) {
			var oViewModel = this.getView().getModel("worklistView"),
				// office = oViewModel.getProperty("/Office"),
				Tdate = oViewModel.getProperty("/Tdate"),
				Totamt = oViewModel.getProperty("/Totamt");
			var m = this.getView().getBindingContext().getModel(),
				p = this.getView().getBindingContext().getPath();
			var office = m.getProperty(p + "/Office");
			if (office === "") {
				oViewModel.setProperty("/OfficeState", "Error");
				var isState = true;
			}
			if (Tdate === null) {
				oViewModel.setProperty("/TdateState", "Error");
				isState = true;
			}
			if (Totamt === "") {
				oViewModel.setProperty("/AmountState", "Error");
				isState = true;
			}
			if (isState === true) {
				sap.m.MessageBox.warning("Please provide the mandartory fields to upload excel File");
				isState = false;
				return;
			}
			var oFileUpId = this.byId("fileUpload"),
				domRef = oFileUpId.getFocusDomRef(),
				file = domRef.files[0];
			oFileUpId.clear();
			this._import(file);
		},
		_import: function(file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function(evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}

					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function(sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUploader").setValue("");
						return false;
					}
					that._creatobjPy(sheetData);

				};
				reader.readAsArrayBuffer(file);
			}
		},
		_creatobjPy: function(Data) {
			var oMod = this.getView().getModel(),
				excelData = [],
				oViewModel = this.getView().getModel("worklistView");
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MM.dd.yyyy",
				UTC: true
			});
			//Excel Header set
			for (var k = 0; k < Data.length; k++) {
				var data = Data[k];
				var Matter = data["Matter"] ? data["Matter"].trim() : "";
				var costCode = data["Cost Code"] ? data["Cost Code"].trim() : "";
				var oAmount = data["Amount"] ? data["Amount"].trim() : "";
				// var TaxCode = data["Tax Code"] ? data["Tax Code"].trim() : "";
				var Narrative = data["Narrative"] ? data["Narrative"].trim() : "";
				var TransactionDate = data["Work Date"] ? data["Work Date"].trim() : null;
				var Reference = data["Reference"] ? data["Reference"].trim() : "";
				if (TransactionDate) {
					// var oTdate = dateFormat.format(new Date(TransactionDate));
					TransactionDate = new Date(TransactionDate);
				} else {
					TransactionDate = null;
				}
				if (costCode.length === 1) {
					costCode = "000" + costCode;
				}
				var obj = {
					"Matter": Matter,
					"Kostl": costCode,
					"Amount": oAmount,
					// "Taxcode": TaxCode,
					"Narr": Narrative,
					"Workdate": TransactionDate,
					"Reference": Reference,
					"Belnr": ""
				};
				excelData.push(obj);
			}
			//End Excel header
			var oTable = this.getView().byId("idAnticipationTable");
			var that = this;
			$.each(excelData, function(i, val) {
				// val.Useraction = "CREATE";
				// val.Createdat = new Date(val.Createdat);
				var oContext = oMod.createEntry("/AnticipationItemS", {
					properties: val
				});

				var items = new sap.m.ColumnListItem({
					cells: [
						new SmartField({
							value: "{Matter}",
							editable: true,
							change: that.onChangeMatter.bind(that)
						}),
						new SmartField({
							value: "{Kostl}",
							editable: true,
							change: that.onChangeKostl.bind(that)
						}),
						new SmartField({
							value: "{Amount}",
							editable: true,
							type: "Number",
							textAlign: "Right",
							uomVisible: false,
							change: that.onChangeAmount.bind(that),
							innerControlsCreated: that.oninnerControlCreated.bind(that)
						}),
						// new SmartField({
						// 	value: "{Taxcode}",
						// 	editable: true,
						// 	change: that.onChangeTaxcode.bind(that)
						// }),
						new SmartField({
							value: "{Narr}",
							editable: true,
							change: that.onChangeNarr.bind(that),
							width: "60rem"
						}),
						new sap.m.DatePicker({
							dateValue: "{Workdate}",
							change: that.onChangeWorkdate.bind(that)
						}),
						new SmartField({
							editable: true,
							value: "{Reference}",
							change: that.onChangeReference.bind(that)
						}),
						new SmartField({
							editable: true,
							value: "{Belnr}"
						})
					]
				});
				items.setBindingContext(oContext);
				oTable.addItem(items);

			});
			// oViewModel.setProperty("/isSaveBtnEnable", true);
		},
		oninnerControlCreated: function(evt) {
			var src = evt.getSource();
			src.getInnerControls()[0].setTextAlign("Right");
		}

	});

});