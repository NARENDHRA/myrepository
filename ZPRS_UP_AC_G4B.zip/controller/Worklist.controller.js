sap.ui.define([
	"uploadanticipationcosts/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"uploadanticipationcosts/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/comp/smartfield/SmartField",
	"sap/ui/export/Spreadsheet",
	"uploadanticipationcosts/model/JsonData"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox, SmartField, Spreadsheet, JsonData) {
	"use strict";

	return BaseController.extend("uploadanticipationcosts.controller.Worklist", {
		JsonData: JsonData,
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay;
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				Tdate: null,
				OfficeState: "None",
				TdateState: "None",
				AmountState: "None",
				Office: "",
				Totamt: "",
				Currency: "",
				ErrorList: []
			});
			this.setModel(oViewModel, "worklistView");
			this._createentery();
			this.getOwnerComponent().getModel().setDefaultBindingMode("TwoWay");
		},
		_createentery: function() {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded().then(function() {
				var oContextClients = oModel.createEntry("/AnticipationS", {});
				var c = oContextClients.getModel();
				c.setProperty(oContextClients.getPath() + "/Office", "");
				c.setProperty(oContextClients.getPath() + "/Tdate", "");
				c.setProperty(oContextClients.getPath() + "/Totamt", "");
				c.setProperty(oContextClients.getPath() + "/Currency", "");
				that.getView().setBindingContext(oContextClients);
			});
		},
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Kschl")
			});
		},
		//handle line items add to table
		onAddRowPress: function() {
			var oViewModel = this.getView().getModel("worklistView"),
				Tdate = oViewModel.getProperty("/Tdate"),
				Totamt = oViewModel.getProperty("/Totamt");
			var m = this.getView().getBindingContext().getModel(),
				p = this.getView().getBindingContext().getPath();
			var office = m.getProperty(p + "/Office");
			if (office === "") {
				oViewModel.setProperty("/OfficeState", "Error");
				var isState = true;
			}
			if (Tdate === null) {
				oViewModel.setProperty("/TdateState", "Error");
				isState = true;
			}
			if (Totamt === "") {
				oViewModel.setProperty("/AmountState", "Error");
				isState = true;
			}
			if (isState === true) {
				sap.m.MessageBox.warning("Please provide the mandartory fields to add line item");
				isState = false;
				return;
			}
			var oViewModel = this.getView().getModel(),
				oContext = this.getView().getModel().createEntry("/AnticipationItemS", {
					properties: {
						"Office": this.oOfficeId,
						"Matter": "",
						"Kostl": "",
						"Amount": "",
						// "Taxcode": "",
						"Narr": "",
						"Workdate": null,
						"Reference": "",
						"Belnr": ""

					}
				});
			var oTable = this.getView().byId("idAnticipationTable");
			var that = this;
			var items = new sap.m.ColumnListItem({
				cells: [
					new SmartField({
						value: "{Matter}",
						editable: true,
						change: that.onChangeMatter.bind(that)
					}),
					new SmartField({
						value: "{Kostl}",
						editable: true,
						change: that.onChangeKostl.bind(that)
					}),
					new SmartField({
						value: "{Amount}",
						editable: true,
						type: "Number",
						textAlign: "Right",
						uomVisible: false,
						change: that.onChangeAmount.bind(that),
						innerControlsCreated: that.oninnerControlCreated.bind(that)
					}),
					// new SmartField({
					// 	value: "{Taxcode}",
					// 	editable: true,
					// 	change: that.onChangeTaxcode.bind(that)
					// }),
					new SmartField({
						value: "{Narr}",
						editable: true,
						change: that.onChangeNarr.bind(that),
						width: "60rem"
					}),
					new sap.m.DatePicker({
						dateValue: "{Workdate}",
						change: that.onChangeWorkdate.bind(that)
					}),
					new SmartField({
						editable: true,
						value: "{Reference}",
						change: that.onChangeReference.bind(that)
					}),
					new SmartField({
						editable: true,
						value: "{Belnr}"
					})

				]
			});
			items.setBindingContext(oContext);
			oTable.addItem(items);
			oViewModel.setProperty("/isSaveBtnEnable", true);
		},
		handleDeleteMatter: function(oEvt) {
			var oTable = oEvt.getSource(),
				oItmSel = oEvt.getParameter("listItem");
			oTable.removeItem(oItmSel);
		},

		OnPressSaveData: function(evt) {
			var oModel, oTable, oItems, that = this,
				oDocumentArray = [],
				oAnticipationItemS = [],
				reqFieldsmsg = "Please provide all required fields",
				wmsg = "Please add atleast one line item before save",
				oViewModel = this.getView().getModel("worklistView"),
				isValidate = true;
			var batchChanges = [];
			var m = this.getView().getBindingContext().getModel(),
				p = this.getView().getBindingContext().getPath();

			oModel = this.getOwnerComponent().getModel();
			oTable = this.getView().byId("idAnticipationTable");
			oItems = oTable.getItems();
			var TotalAmount = oViewModel.getProperty("/Totamt"),
				office = m.getProperty(p + "/Office"),
				oTdate = oViewModel.getProperty("/Tdate"),
				oCurrency = oViewModel.getProperty("/Currency");
			var aMessage = [];
			if (oItems.length === 0) {
				MessageBox.error(wmsg);
				return;
			}
			//Looping for validation 
			var oSumTot = 0;
			var oNumber = 0;
			$.each(oItems, function(i, obj) {
				var oTabRowCells = oItems[i].getCells();
				var ctx = oItems[i].getBindingContext().getObject();
				if (oNumber <= i) {
					oSumTot += Number(ctx.Amount);
					oNumber++;
				}
				ctx["Tdate"] = oTdate;
				ctx["Currency"] = oCurrency;
				$.each(oTabRowCells, function(c, val) {
					var oCellBind = oTabRowCells[c]._oValueBind;
					if (oCellBind !== undefined) {
						var oCell = oTabRowCells[c]._oValueBind.path;
						if ((oCell === "Matter") || (oCell === "Kostl") || (oCell === "Amount") || (oCell ===
								"Narr")) {
							var oCellValue = oTabRowCells[c].getValue();
							if (oCellValue === "") {
								oTabRowCells[c].setValueState("Error");
								isValidate = false;
							}
						}
					}
				});
				delete(ctx.__metadata);
				oAnticipationItemS.push(ctx);
				if (ctx.Belnr !== "") {
					oDocumentArray.push(ctx.Belnr);
				}
			});
			//End Looping for validation
			if (!isValidate) {
				MessageBox.error(
					reqFieldsmsg);
				return;
			}
			if (Number(TotalAmount) !== oSumTot) {
				MessageBox.error("Total amount does not match with total line item amounts");
				return;
			}
			if (oDocumentArray.length > 0) {
				MessageBox.alert("Anticipations have already beed created for the above line items");
				return;
			}
			var oPayload = {
				"Office": office,
				"Totamt": TotalAmount,
				"Tdate": oTdate,
				"Currency": oCurrency,
				"AnticipationItemSet": oAnticipationItemS
			};
			this.getView().setBusy(true);
			var that = this;
			oModel.create("/AnticipationS", oPayload, {
				success: function(oData, response) {
					var res = oData.AnticipationItemSet.results;
					var oItem = oTable.getItems();
					$.each(oItem, function(o, index) {
						var ctxm = oItem[o].getBindingContext();
						var mt = ctxm.getModel(),
							path = ctxm.getPath();
						var oBelnr = res[o].Belnr;
						mt.setProperty(path + "/Belnr", oBelnr);
					});
					that.getView().setBusy(false);
					MessageBox.success("Document Posted Successfully");
				},
				error: function(oErr) {
					var resp = oErr.responseText,
						result = resp ? resp : 1;
					if (result !== 1) {
						that.applyResp(jQuery.parseJSON(result));
					}
					that.getView().setBusy(false);
				}
			});

		},
		applyResp: function(respError) {
			this.getModel("worklistView").setProperty("/ErrorList", respError.error.innererror.errordetails);
			if (!this.errorList) {
				this.errorList = sap.ui.xmlfragment(this.getView().getId(), "uploadanticipationcosts.fragments.ErrorList",
					this);
				this.getView().addDependent(this.errorList);
			}
			this.errorList.openBy(this.getView().byId("isSaveUpload"));
		},
		onChangeMatter: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Matter", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeKostl: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Kostl", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeAmount: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Amount", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeTaxcode: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Taxcode", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeCurrency: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value;
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeNarr: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Narr", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		onChangeWorkdate: function(evt) {
			// var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			// 	pattern: "MM.dd.yyyy",
			// 	UTC: true
			// });
			// var src = evt.getSource();
			// var state = src.getValueState();
			// var oVal = evt.getParameters().value,
			// 	srcPath = src.getBindingContext().getPath(),
			// 	srcModel = src.getBindingContext().getModel();
			// var oFInVal1 = dateFormat.format(new Date(oVal));
			// srcModel.setProperty(srcPath + "/Workdate", new Date(oVal));
			// if (state === "Error" && oVal !== "") {
			// 	evt.getSource().setValueState("None");
			// }
		},
		onChangeReference: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value,
				srcPath = src.getBindingContext().getPath(),
				srcModel = src.getBindingContext().getModel();
			// srcModel.setProperty(srcPath + "/Reference", oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},

		onChangeValues: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value;
			var sPath = this.getView().getBindingContext().sPath;
			var path = src.getBindingPath("value");
			this.getView().getBindingContext().getModel().setProperty(sPath + "/" + path, oVal);
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
			this.oOfficeId = oVal;
		},
		onChangeValuesAmount: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value;
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		datechange1: function(evt) {
			var src = evt.getSource();
			var state = src.getValueState();
			var oVal = evt.getParameters().value;
			if (state === "Error" && oVal !== "") {
				evt.getSource().setValueState("None");
			}
		},
		createColumnConfig: function() {
			var i18nLabel = this.getView().getModel("i18n").getResourceBundle();
			return [{
					label: "Matter",
					property: "Matter",
					type: 'number'
				}, {
					label: "Cost Code",
					property: "Kostl",
					type: 'string'
				}, {
					label: "Amount",
					property: "Amount",
					type: 'number',
					scale: 3
				},
				// {
				// 	label: "Tax Code",
				// 	property: "Taxcode",
				// 	type: 'number',
				// 	scale: 3
				// },
				{
					label: "Narrative",
					property: "Narr",
					type: 'string'
				}, {
					label: "Work Date",
					property: "Workdate",
					type: 'date'
				}, {
					label: "Reference",
					property: "Reference",
					type: 'string'
				}
			];
		},
		onExportDownload: function(oEvnt) {
			var aCols, oSettings, oSheet, oExcelJson = [];
			oExcelJson.push(this.JsonData._loadExcelJSONData());
			aCols = this.createColumnConfig();
			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: oExcelJson
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function() {
					sap.m.MessageToast.show('Spreadsheet export has finished');
				})
				.finally(function() {
					oSheet.destroy();
				});
		},
		OnPressRefreshData: function(evt) {
			var oViewModel = this.getView().getModel("worklistView");
			this._createentery();
			oViewModel.setProperty("/Tdate", null);
			oViewModel.setProperty("/Totamt", "");
			oViewModel.setProperty("/Currency", "");
			var otable = this.getView().byId("idAnticipationTable");
			otable.removeAllItems();
		}

	});
});