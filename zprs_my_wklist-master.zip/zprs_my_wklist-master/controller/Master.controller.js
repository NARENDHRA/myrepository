/*global history */
sap.ui.define([
	"myworklist1/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"myworklist1/model/formatter",
	"myworklist1/model/grouper",
	"myworklist1/model/GroupSortState",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, grouper, GroupSortState, History,
	MessageBox, Sorter, MessageToast) {
	"use strict";

	return BaseController.extend("myworklist1.controller.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {
			// Control state model
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oGroupSortState = new GroupSortState(oViewModel, grouper.groupUnitNumber(this.getResourceBundle()));

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
			// BG
			this.setroleModel();
			//test git check-in
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
			// hide pull to refresh if necessary
			this.byId("pullToRefresh").hide();
			var list = oEvent.getSource();
			if (list.getItems().length > 0) {
				//list.removeSelections(true);
				var selItem;
				if (list.getSelectedItems().length > 0) {
					selItem = list.getSelectedItems()[0];
				} else {
					selItem = list.getItems()[0];
				}
				list.setSelectedItem(selItem);
				this._showDetail(selItem || oEvent.getSource());
				this.setVisibility();
				//	this.onItemSelect(oEvent);
			} else {
				this.getRouter().getTargets().display("notFound");
			}
		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				this._oListFilterState.aSearch = [new Filter("SearchString", FilterOperator.Contains, sQuery)];
			} else {
				this._oListFilterState.aSearch = [];
			}
			this._oListFilterState.aSearch = this._oListFilterState.aSearch.concat(this.clientsFilter);
			this._applyFilterSearch();
		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oList.getBinding("items").refresh();
		},

		/**
		 * Event handler for the sorter selection.
		 * @param {sap.ui.base.Event} oEvent the select event
		 * @public
		 */
		onSort: function(oEvent) {
			var sKey = oEvent.getSource().getSelectedItem().getKey(),
				aSorters = this._oGroupSortState.sort(sKey);
			this._applyGroupSort(aSorters);
		},

		/**
		 * Event handler for the grouper selection.
		 * @param {sap.ui.base.Event} oEvent the search field event
		 * @public
		 */
		onGroup: function(oEvent) {
			var sKey = oEvent.getSource().getSelectedItem().getKey(),
				aSorters = this._oGroupSortState.group(sKey);

			this._applyGroupSort(aSorters);
		},

		/**
		 * Event handler for the filter button to open the ViewSettingsDialog.
		 * which is used to add or remove filters to the master list. This
		 * handler method is also called when the filter bar is pressed,
		 * which is added to the beginning of the master list when a filter is applied.
		 * @public
		 */
		onOpenViewSettings: function() {
			if (!this._oViewSettingsDialog) {
				this._oViewSettingsDialog = sap.ui.xmlfragment("myworklist1.view.ViewSettingsDialog", this);
				this.getView().addDependent(this._oViewSettingsDialog);
				// forward compact/cozy style into Dialog
				this._oViewSettingsDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
			this._oViewSettingsDialog.open();
		},

		/**
		 * Event handler called when ViewSettingsDialog has been confirmed, i.e.
		 * has been closed with 'OK'. In the case, the currently chosen filters
		 * are applied to the master list, which can also mean that the currently
		 * applied filters are removed from the master list, in case the filter
		 * settings are removed in the ViewSettingsDialog.
		 * @param {sap.ui.base.Event} oEvent the confirm event
		 * @public
		 */
		onConfirmViewSettingsDialog: function(oEvent) {
			var aFilterItems = oEvent.getParameters().filterItems,
				aFilters = [],
				aCaptions = [];

			// update filter state:
			// combine the filter array and the filter string
			aFilterItems.forEach(function(oItem) {
				switch (oItem.getKey()) {
					case "Filter1":
						aFilters.push(new Filter("Netwr", FilterOperator.LE, 100));
						break;
					case "Filter2":
						aFilters.push(new Filter("Netwr", FilterOperator.GT, 100));
						break;
					default:
						break;
				}
				aCaptions.push(oItem.getText());
			});

			this._oListFilterState.aFilter = aFilters;
			this._updateFilterBar(aCaptions.join(", "));
			this._applyFilterSearch();
		},

		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			/*	// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
				this.onItemSelect(oEvent);
				//	this._showDetail(oEvent.getSource()); */
			// Hansapriya changes
			var li = oEvent.getParameter("listItem") || oEvent.getSource();
			if (li.getSelected() === true) {
				this._showDetail(li);
				this.onItemSelect(oEvent);
			} else if (li.getSelected() === false) {
				var oList = this.getView().byId("list");
				if (oList.getSelectedItems().length !== 0) {
					this._showDetail(oList.getSelectedItems()[0]);
				} else {
					this.getRouter().getTargets().display("notFound");
				}
			}
			var tbl = this.getView().byId("list");
			var isStatusDiff = this.checkForSameStatus(tbl);
			if (!isStatusDiff) {
				li.setSelected(false);
				//tbl.setSelectedItem(li, false);
			}
		},
		onItemSelect: function(oEvent) {
			var tbl = this.getView().byId("list"),
				li = oEvent.getParameter("listItem") || oEvent.getSource(),
				isStatusDiff = this.checkForSameStatus(tbl);
			if (!isStatusDiff) {
				li.setSelected(false);
				MessageToast.show("Select Draft bill with same status", {
					duration: 4000
				});
				return;
			}
			if (li.getSelected() === true || oEvent.getSource() instanceof sap.m.ObjectListItem) {
				this._showDetail(li);
			} else if (li.getSelected() === false) {
				var oList = this.getView().byId("list");
				if (oList.getSelectedItems().length !== 0) {
					this._showDetail(oList.getSelectedItems()[0]);
				} else {
					this.getRouter().getTargets().display("notFound");
				}
			}
			this.setVisibility();
		},
		checkForSameStatus: function(tbl) {
			var currtStatus;
			var sameStatus = true;
			$.each(tbl.getSelectedItems(), function(i, o) {
				var selCntx = o.getBindingContext();
				if (!currtStatus) {
					currtStatus = selCntx.getProperty("StatusCode");
				}
				var isEq = parseInt(currtStatus) === parseInt(selCntx.getProperty("StatusCode"));
				if (!isEq) {
					sameStatus = false;
					return sameStatus;
				}
			});
			return sameStatus;
		},
		setVisibility: function() {
			var tbl, that = this,
				Finalbill = [],
				SubmitApproval = [];
			tbl = this.getView().byId("list");
			if (tbl.getSelectedContexts().length > 0) {
				var roles = [];
				$.each(tbl.getSelectedItems(), function(i, o) {
					var selCntx = o.getBindingContext();
					var oData = selCntx.getObject();
					roles.push(oData.Role);
					SubmitApproval.push(oData.SubmitApproval);
					Finalbill.push(oData.Finalbill);
				});
				that.setActionbtnVisibility(roles, {
					fb: Finalbill,
					sp: SubmitApproval
				});
			} else {
				that.setActionbtnVisibility();
			}
		},
		setActionbtnVisibility: function(role, selItem) {
			var actBtn, roles, page, that;
			that = this;
			roles = this.getView().getModel("roleModel");
			page = this.getView().byId("page");
			page.removeAllCustomFooterContent();

			if (role) {
				/*	actBtn = new sap.m.Button({
						text: "Save",
						press: [that.onUserActionPress, that]
					});
					actBtn.data("ActionCode", "SAVE");*/
				actBtn = new sap.m.Button({
					tooltip: "Add Comment",
					icon: "sap-icon://comment",
					press: [that.showQickView, that],
					customData: {
						Type: "sap.ui.core.CustomData",
						key: "ActionCode",
						value: "SAVE"
					}
				});
				page.addCustomFooterContent(actBtn);

				/*actBtn = new sap.m.Button({
					text: "Add Comment",
					press: [that.showQickView, that]
				});
				actBtn.data("caller", "multi");*/
				page.addCustomFooterContent(actBtn);

				$.each(roles.getData(), function(i, rObj) {
					var isTrue = true;
					// logic to control final billing
					if (role.indexOf("01") >= 0) {
						if (rObj.Action === "SUB" && selItem.fb.indexOf("") >= 0) {
							isTrue = false;
						} else if (rObj.Action === "SFA" && selItem.sp.indexOf("") >= 0) {
							isTrue = false;
						}
					}
					if (role.indexOf(rObj.Role) >= 0 && isTrue) {
						actBtn = new sap.m.Button({
							tooltip: rObj.DecisionText,
							icon: "sap-icon://" + rObj.InconIndicator,
							press: [that.onUserActionPress, that]
						});
						actBtn.data("ActionCode", rObj.Action);
						page.addCustomFooterContent(actBtn);
					}
				});
			}
		},
		showQickView: function(oEvt) {
			var src = oEvt.getSource();
			var fragPath = "myworklist1.fragments.Comment";
			var worklistModel = this.getView().getModel("masterView");
			var worklistData = worklistModel.getData();
			worklistData.NewComments = "";
			worklistModel.setData(worklistData);
			worklistModel.refresh();
			if (!this.oQuick) {
				this.oQuick = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.oQuick);
			}
			this.oQuick.setBindingContext(src.getBindingContext());
			this.oQuick.openBy(src);
		},
		handlCommentClose: function(oEvt) {
			this.displayCmt.close();
		},
		handleCommentAdd: function(oEvent) {
			this.onUserActionPress(oEvent);
			this.oQuick.close();
		},
		setroleModel: function() {
			var that = this;
			this.getOwnerComponent().getModel().read("/RoleActionListSet", {
				success: function(oData) {
					var roleModel = new JSONModel(oData.results);
					that.getView().setModel(roleModel, "roleModel");
				},
				error: function(oData) {

				}
			});
		},
		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function() {
			this._oList.removeSelections(true);
		},

		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader: function(oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			this.getView().byId("searchField").setValue(""); //Clear search field on nav back
			var bReplace = !Device.system.phone;
			this.getRouter().navTo("master1", {}, bReplace);
			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.publish("worklist", "fromMtoM1", {});
			/*	var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				window.history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: "#Shell-home"
						}
					});
				}*/
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function() {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Bname",
				groupBy: "None"
			});
		},

		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */
		_onMasterMatched: function(oEvent) {
			this.client = oEvent.getParameter("arguments");
			this.setListBinding(this.client.client);

			/*this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
				function(mParams) {
					if (mParams.list.getMode() === "None") {
						return;
					}
					var sObjectId = mParams.firstListitem.getBindingContext().getProperty("Vbeln");
					this.getRouter().navTo("object", {
						objectId: sObjectId
					}, true);
				}.bind(this),
				function(mParams) {
					if (mParams.error) {
						return;
					}
					this.getRouter().getTargets().display("detailNoObjectsAvailable");
				}.bind(this)
			);*/
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem) {
			oItem.focus();
			var bReplace = !Device.system.phone,
				urlParams = [];
			urlParams.push(oItem.getBindingContext().getProperty("Vbeln"));
			urlParams.push(oItem.getBindingContext().getProperty("Role"));
			urlParams.push(oItem.getBindingContext().getProperty("WiId"));
			// Hansapriya changes
			urlParams.push(Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1));
			var oSelectFlag = true; // oItem.getProperty("selected");
			if (oSelectFlag === true) { // till here Hansapriya changes
				// this.getRouter().navTo("object", {
				// 	client:this.client.client,
				// 	Vbeln:oItem.getBindingContext().getProperty("Vbeln"),
				// 	Role:oItem.getBindingContext().getProperty("Role"),
				// 	WiId:oItem.getBindingContext().getProperty("WiId")

				// }, bReplace);
				this.getRouter().getTargets().display("object");

				$.sap.require("sap.ui.core.EventBus");
				var oBus = sap.ui.getCore().getEventBus();

				var isMulti = false;
				var list = this.getView().byId("list");
				if (list.getSelectedContexts().length > 1) {
					isMulti = true;
				}
				oBus.publish("worklist", "fromWLMaster", {
					client: this.client.client,
					Vbeln: oItem.getBindingContext().getProperty("Vbeln"),
					Role: oItem.getBindingContext().getProperty("Role"),
					WiId: oItem.getBindingContext().getProperty("WiId"),
					isMulti: isMulti

				});
			}
			//	this.getRouter().navTo("object", {objectId:src.getSelectedContexts()}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function(iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function() {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
				//Changed by Hansapriya ; JIRA BM-334
				this.getRouter().getTargets().display("notSearched");
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},

		/**
		 * Internal helper method to apply both group and sort state together on the list binding
		 * @param {sap.ui.model.Sorter[]} aSorters an array of sorters
		 * @private
		 */
		_applyGroupSort: function(aSorters) {
			this._oList.getBinding("items").sort(aSorters);
		},

		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function(sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},
		onMultiSelectPress: function(oEvent) {
			var list = this.getView().byId("list");
			if (oEvent.getSource().getPressed()) {
				list.setMode("MultiSelect");
			} else {
				list.setMode("SingleSelectMaster");
			}
		},
		setListBinding: function(client) {
			var list = this.getView().byId("list");
			var filters = [];
			$.each(client.split(','), function(i, s) {
				filters.push(new Filter("Kunnr", FilterOperator.EQ, s.toString()));
			});
			this.clientsFilter = filters;
			//	if (!list.getBindingInfo('items')) {
			list.bindItems({
				path: "/WorklistItemsSet",
				filters: filters,
				template: new sap.m.ObjectListItem({
					type: "{= ${device>/system/phone} ? 'Active' : 'Active'}",
					title: "{Vbeln}",
					number: "{path:'NetValue' ,type: 'sap.ui.model.type.Float'}",
					numberUnit: "{Zzmcurr}",
					numberState: {
						path: "Priority",
						formatter: function(priority) {
							if (priority === "L") {
								return "Success";
							}
							if (priority === "M") {
								return "Warning";
							}
							if (priority === "H") {
								return "Error";
							}
							return "None";
						}
					},
					press: [this.onItemSelect, this],
					firstStatus: new sap.m.ObjectStatus({
						title: "{Status}",
						tooltip: "{Status}"
					}),
					attributes: [new sap.m.ObjectAttribute({
						text: "{Post1}",
						tooltip: "{Post1}"
					}),
					new sap.m.ObjectAttribute({
						title: "{i18n>matRepGrp}",
						text: "{Zzmatgrp}"
					})]
				})
			});
			/*} 
			else {
				list.getBinding("items").filter(filters);
			}*/
		},
		onPrintPress: function(oEvent) {
			var wlModel, filter, printUrl, billNumb, oTable;
			oTable = this.getView().byId("list");
			//billNumb = oEvent.getSource().data().billNumb;
			wlModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_MY_WORKLIST_SRV/");
			var DraftBillText = this.getResourceBundle().getText("DraftBill");
			var fnSuccess = function(data) {
				printUrl = "/sap/opu/odata/SAP/zprs_bill_edit_srv/PDFOutCollection(Kappl='V1',Kschl='";
				printUrl = printUrl + data.results[0].Kschl + "',DraftBill='" + billNumb + "')/$value";
				sap.m.URLHelper.redirect(printUrl, true);
			};
			var fnError = function(err) {

			};
			if (oTable.getSelectedItems().length === 1) {
				billNumb = oTable.getSelectedItem().getBindingContext().getObject().Vbeln;
				filter = "?$filter=(Kappl eq 'V1' and Vbeln eq '" + billNumb + "')";
				wlModel.read("/DbOutputTypeSet" + filter, {
					success: fnSuccess,
					error: fnError
				});
			} else if (oTable.getSelectedItems().length > 1) {
				var draftbill = [];
				$.each(oTable.getSelectedItems(), function(i, o) {
					draftbill.push(o.getBindingContext().getObject().Vbeln);
				});
				wlModel.read("/DBillMassPrint?Vbeln='" + draftbill.toString() + "'", {
					success: function(data) {
						var reslength = data.results.length;
						var resVbeln = " ";
						for (var i = 0; i < reslength; i++) {
							resVbeln = resVbeln + "," + data.results[i].Vbeln;
						}
						resVbeln = resVbeln.substring(2);
						MessageBox.information(DraftBillText + " " + resVbeln + " " + data.results[0].Message);
					},
					error: fnError
				});
			}
		},
		handleViewSettingsDialogButtonPressed: function(oEvent) {
			if (!this.filterDialog) {
				this.filterDialog = sap.ui.xmlfragment("myworklist1.fragments.filterDialog", this);
				this.getView().addDependent(this.filterDialog);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.filterDialog);
			this.filterDialog.open();
		},
		onUserActionPress: function(oEvt) {
				var tbl = this.getView().byId("list");
			var UserActioPress = this.getResourceBundle().getText("UserActioPress");
			if (tbl.getSelectedContexts().length === 0) {
				MessageBox.warning(UserActioPress);
				return;
			}
			this.getView().setBusyIndicatorDelay(0);
			this.getView().setBusy(true);
			var ActionText = oEvt.getSource().getTooltip();
			var userAction = oEvt.getSource().data().ActionCode,
				PopUpTextYes = this.getResourceBundle().getText("PopUpTextYes"),
				PopUpTextNo = this.getResourceBundle().getText("PopUpTextNo"),
				PopUpTitleText = this.getResourceBundle().getText("PopUpTitleText"),
				that = this;
			if (userAction === "SAVE") {
				that.onUserActionPress1(userAction);
			} else {
				var dialog = new sap.m.Dialog({
					title: PopUpTitleText,
					type: 'Message',
					content: new sap.m.Text({
						text: ActionText
					}),
					beginButton: new sap.m.Button({
						text: PopUpTextYes,
						press: function() {
							that.onUserActionPress1(userAction);
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: PopUpTextNo,
						press: function() {
							that.getView().setBusy(false);
							dialog.close();
							return;
						}

					}),
					afterClose: function() {
						// that.getView().setBusy(false);
						dialog.destroy();
					}
				});

				dialog.open();
			}

		},
		onUserActionPress1: function(userAction) {
			var tbl = this.getView().byId("list");
			try {
				var batchChanges = [];
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_MY_WORKLIST_SRV/"); //this.getOwnerComponent().getModel();
				oModel.attachRequestSent(this.onRequestSent);
				var worklistModel = this.getView().getModel("masterView");
				var worklistData = worklistModel.getData();
				$.each(tbl.getSelectedContexts(), function(i, o) {
					var OData = o.getObject();
					OData.Action = userAction;
					if (userAction === "SAVE") {
						OData.NewComments = worklistData.NewComments;
					}
					batchChanges.push(oModel.createBatchOperation("/WorklistItemsSet", "POST", OData));
				});
				oModel.addBatchChangeOperations(batchChanges);
				oModel.setUseBatch(true);

				var that = this;
				oModel.submitBatch(function(data) {
					//	tbl.removeSelections();
					//tbl.getModel().refresh(true);
					
					var resObj = data.__batchResponses[0].__changeResponses[0].data;
					if (resObj.Error === "X") {
						MessageBox.error(resObj.Message);
					} else {
						// MessageBox.success(that._oResourceBundle.getText("successText"));
							that.onRefresh();
					}
					that.getView().setBusy(false);	
				}, function(err) {
					that.getView().setBusy(false);
					MessageBox.error(that._oResourceBundle.getText("errorText"));
				});
			} catch (e) {
				that.getView().setBusy(false);
			}
		},
		onRequestSent: function(oEvt) {
			this.getView().setBusy(true);
		},
		applyFilter: function(oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("list");

			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");

			// apply sorter to binding
			// (grouping comes before sorting)
			var aSorters = [];
			if (mParams.groupItem && mParams.groupItem.getKey() !== "") {
				var sPath = mParams.groupItem.getKey();
				var bDescending = mParams.groupDescending;
				//	var vGroup = this.mGroupFunctions[sPath];
				aSorters.push(new Sorter(sPath, bDescending, true));
			}
			var sortPath = mParams.sortItem.getKey();
			var sortbDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sortPath, sortbDescending));
			oBinding.sort(aSorters);

			// apply filters to binding
			var aFilters = [];
			var that = this;
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var fKey = oItem.getKey();
				var sValue1 = oItem.getText();
				if (oItem instanceof sap.m.ViewSettingsCustomItem) {
					var filters = that.createFiltersFromList(oItem, fKey);
					aFilters = aFilters.concat(filters);
				} else {
					var oFilter = new Filter(fKey, FilterOperator.Contains, sValue1);
					aFilters.push(oFilter);
				}
			});
			oEvent.getSource().fireFilterDetailPageOpened();
			oBinding.filter(aFilters);
		},
		createFiltersFromList: function(custItem, key) {
			var list = custItem.getCustomControl(),
				selItems = list.getSelectedItems(),
				aFilters = [],
				that = this;

			$.each(selItems, function(i, item) {
				var ctx = item.getBindingContext();
				var oFilter = new Filter(key, that.getOperator(custItem), ctx.getProperty(key));
				aFilters.push(oFilter);
			});
			return aFilters;
		},
		getOperator: function(custItem) {
			var opttype = custItem.data().Type;
			if (opttype) {
				switch (opttype) {
					case "Edm.Int":
						return FilterOperator.EQ;
					case "Edm.String":
						return FilterOperator.Contains;
				}
			}
			return FilterOperator.Contains;
		},
		filterListChange: function(evt) {
			var index = evt.getSource().data().index;
			var oCustomFilter = this.filterDialog.getFilterItems()[index];
			var list = oCustomFilter.getCustomControl();
			if (oCustomFilter && list.getSelectedItems().length > 0) {
				oCustomFilter.setFilterCount(list.getSelectedItems().length);
				oCustomFilter.setSelected(true);
			} else {
				oCustomFilter.setFilterCount(0);
				oCustomFilter.setSelected(false);
			}
		},
		handleResetFilters: function(evt) {
			$.each(this.filterDialog.getFilterItems(), function(i, oItem) {
				if (oItem instanceof sap.m.ViewSettingsCustomItem) {
					var list = oItem.getCustomControl();
					//list.setSelectAll(false);
					oItem.setFilterCount(0);
				}
				oItem.setSelected(false);
			});
		}
	});

});