/*global location */
sap.ui.define([
	"myworklist1/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"myworklist1/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageBox',
	'sap/ui/model/Sorter'
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox, Sorter) {
	"use strict";

	return BaseController.extend("myworklist1.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			var comModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_BILL_EDIT_SRV/");
			this.setModel(comModel, "comModel");
			var attachmentModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_FILE_ATTACHMENT_UI_SRV/");
			this.setModel(attachmentModel, "atthModel");
			attachmentModel.attachRequestCompleted(this.setAttachmentCount, this);

			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.subscribe("worklist", "fromWLMaster", this.fromWLMaster, this);
			//	attachmentModel.attachRequestCompleted(this.attachmentLoaded,this);
		},
		fromWLMaster: function(sChannelId, sEventId, oData) {
			var cmtInput = this.getView().byId("cmtInput");
			cmtInput.setValue("");
			cmtInput.setEnabled(!oData.isMulti);
			var sObjectId = oData;
			if(this.getModel()){
				this.getModel().metadataLoaded().then(function() {
					var sObjectPath = this.getModel().createKey("WorklistItemsSet", {
						Vbeln: sObjectId.Vbeln,
						Role: sObjectId.Role,
						WiId: sObjectId.WiId
					});
					this._bindView("/" + sObjectPath, sObjectId);
				}.bind(this));
				this.bindAttachement(sObjectId.Vbeln);
				this.bindComments(sObjectId.Vbeln);
			}
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("detailView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});

			oShareDialog.open();
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments");//oEvent.getParameter("arguments").objectId.split(",");
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("WorklistItemsSet", {
					Vbeln: sObjectId.Vbeln,
					Role: sObjectId.Role,
					WiId: sObjectId.WiId
				});
				this._bindView("/" + sObjectPath, sObjectId);
			}.bind(this));
			this.bindAttachement(sObjectId[0]);
			this.bindComments(sObjectId[0]);
		},
		bindComments: function(sObjectId) {
			var comTbl = this.getView().byId("commentsList");
			var filters = [];
			filters.push(new Filter("Area", FilterOperator.EQ, "W2"));
			filters.push(new Filter("Vbeln", FilterOperator.EQ, sObjectId));
			//	if(!comTbl.getBindingInfo("items")){
			comTbl.bindItems({
				path: "comModel>/WFCommentsSet",
				filters: filters,
				sorts: [new Sorter("Date", true)],
				template: new sap.m.FeedListItem({
					senderActive: false,
					sender: "{comModel>Username}",

					timestamp: {
						parts: [{
							path: "comModel>Date"
						}, {
							path: "comModel>Time"
						}],
					formatter: function(date, time) {
							// Date Formate Written By Naresh KUMAR Issue No: BM-439(On Bind Comment)
							var dt = date.split("T");
							var c = time.slice(2, 4) + ":" + time.slice(5, 7) + ":" + time.slice(8, 10);
							// return date.replace("00:00:00", c);
							var fine = dt[0].concat("T" + c);
							var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
													style: "medium",UTC:true
												});
							var fdt = new Date(fine);
							var TZOffsetMs = fdt.getTimezoneOffset() * 60 * 1000;
							var dateStr = dateFormat.format(new Date(fine));
							return dateStr;
						}
					},
					text: "{comModel>Usercomment}"
				})
			});

			/*	}else{
					comTbl.getBinding("items").filter(filters);
				}*/
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath, sObjectId) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Uname,
				sObjectName = oObject.Bname,
				oViewModel = this.getModel("detailView");

			//	this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		switchApp: function(oEvent) {
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.toExternal({
				target: {
					semanticObject: "ZPRS_OI_01",
					action: "display"
				}
			});
		},
		gotoBillEditor: function(oEvent) {
			var oSelItem, oContext, oObj, billerUrl;
			oSelItem = oEvent.getSource();
			oContext = oSelItem.getBindingContext();
			oObj = oContext.getObject();
			billerUrl = "/sap/bc/ui5_ui5/sap/zprs_bedit/index.html#/narrative/" + oObj.Vbeln;
			sap.m.URLHelper.redirect(billerUrl, true);
		},
		onPress: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject(),
				billerUrl;
			switch (oObj.Role) {
				case "01":
					billerUrl = "/sap/bc/ui5_ui5/sap/zprs_bedit/index.html#/main/" + oObj.Vbeln;
					sap.m.URLHelper.redirect(billerUrl, true);
					break;
				case "02":
				case "03":
				case "04":
					billerUrl = "/sap/bc/ui5_ui5/sap/zprs_wrkflw/index.html#/narrative/" + oObj.Vbeln;
					sap.m.URLHelper.redirect(billerUrl, true);
					break;
			}
		},
		bindAttachement: function(vbeln) {
			var uplTemplate, uplColl, filters = [];
			uplTemplate = new sap.m.UploadCollectionItem({
				documentId: "{atthModel>LoioId}",
				fileName: "{atthModel>Descript}",
				mimeType: "{atthModel>Docuclass}",
				thumbnailUrl: "{thumbnailUrl}",
				"url": "/sap/opu/odata/SAP/ZPRS_FILE_ATTACHMENT_SRV/FileDispCollection(Loio='{atthModel>LoioId}',Ext='{atthModel>Docuclass}',Fname='{atthModel>Descript}')/$value",
				enableEdit: true,
				enableDelete: true,
				visibleDelete: true,
				visibleEdit: false,
				attributes: [new sap.m.ObjectAttribute({
					title: "Uploaded By",
					text: "{atthModel>CreaUser}"
				}), new sap.m.ObjectAttribute({
					title: "Uploaded On",
					text: {
						parts: [{
							path: "atthModel>CrDate"
						}, {
							path: "atthModel>CtTime"
						}],
						formatter: function(date, time) {
							// Date Formate Written By Naresh KUMAR Issue No: BM-439(On Bind Comment)
							var dt = date.split("T");
							var c = time.slice(2, 4) + ":" + time.slice(5, 7) + ":" + time.slice(8, 10);
							// return date.replace("00:00:00", c);
							var fine = dt[0].concat("T" + c);
							var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
													style: "medium"
												});
							var fdt = new Date(fine);
							var TZOffsetMs = fdt.getTimezoneOffset() * 60 * 1000;
							var dateStr = dateFormat.format(new Date(fine));
							return dateStr;
						}
					}
				})]
			});

			uplColl = this.getView().byId("UploadCollection");
			filters.push(new Filter("Vbeln", FilterOperator.EQ, vbeln));
			uplColl.bindAggregation("items", {
				path: "atthModel>/FileListSet",
				filters: filters,
				template: uplTemplate
			});
		},
		onChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			this.oUploadCollection = oUploadCollection;
			oUploadCollection.setUploadUrl("/sap/opu/odata/SAP/ZPRS_FILE_ATTACHMENT_SRV/FileAttachSet");
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oUploadCollection.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: this.getView().getBindingContext().getProperty("Vbeln") + '|' + oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadComplete: function(oEvent) {
			var atthModel;
			atthModel = this.getView().getModel("atthModel");
			atthModel.refresh();
			//	this.setAttachmentCount(oEvent);
		},
		setAttachmentCount: function(oEvent) {
			var tab = this.getView().byId("idIconTabBarMulti");
			tab.getItems()[1].setCount(this.getAttachmentCount());
		},
		onFileDeleted: function(oEvent) {
			var docId, delUrl, atthModel, source;
			source = oEvent.getSource();
			docId = oEvent.getParameter("documentId");
			delUrl = "sap/opu/odata/SAP/ZPRS_FILE_ATTACHMENT_SRV/FileListSet(Vbeln='" + this.getView().getBindingContext().getProperty("Vbeln") +
				"',Objkey='" + docId + "')/FileDelete?";
			atthModel = this.getView().getModel("atthModel");
			source.setBusy(true);
			atthModel.read("/FileListSet(Vbeln='" + this.getView().getBindingContext().getProperty("Vbeln") + "',Objkey='" + docId +
				"',LoioId='')/FileDelete?", {
					success: function(data) {
						atthModel.refresh();
						source.setBusy(false);
					},
					error: function(data) {
						source.setBusy(false);
					}
				});
		},
		getAttachmentCount: function() {
			var aItems = this.getView().byId("UploadCollection").getItems();
			return aItems.length;
		},
		onDownloadPress: function(oEvent) {
			var billNumb, downldUrl;
			billNumb = this.getView().getBindingContext().getProperty("Vbeln");
			downldUrl = "/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/WFCommentsDownloadSet(Vbeln='" + billNumb + "')/$value";
			sap.m.URLHelper.redirect(downldUrl, true);
		},
		onPost: function(oEvt) {
			this.getView().setBusyIndicatorDelay(0);
			this.getView().setBusy(true);
			try {
				var batchChanges = [],
					oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_MY_WORKLIST_SRV/"),
					cntx = this.getView().getBindingContext(),
					OData = cntx.getObject(),
					that = this;
				oModel.attachRequestSent(this.onRequestSent);
				OData.NewComments = oEvt.getParameter("value");
				OData.Action = "SAVE";
				batchChanges.push(oModel.createBatchOperation("/WorklistItemsSet", "POST", OData));

				oModel.addBatchChangeOperations(batchChanges);
				//submit changes and refresh the table and display message&nbsp;\&nbsp;
				oModel.setUseBatch(true);

				var success = function(data) {
					that.getView().setBusy(false);
					var cmtModel = that.getView().getModel("comModel"),
						m = cntx.getModel(),
						cmtInput = that.getView().byId("cmtInput");
					cmtModel.refresh();
					cmtInput.setValue("");
					m.setProperty(cntx.getPath() + "/NewComments", "");
					var resObj = data.__batchResponses[0].__changeResponses[0].data;
					if (resObj.Error === "X") {
						MessageBox.error(resObj.Message);
					} else {
						MessageBox.success(that._oResourceBundle.getText("successText"));
					}
				};
				oModel.submitBatch(success, function(err) {
					that.getView().setBusy(false);
					MessageBox.error(that._oResourceBundle.getText("errorText"));
				});
			} catch (e) {
				that.getView().setBusy(false);
			}
		},
		onRequestSent: function(oEvt) {
			this.getView().setBusy(true);
		},
		handleAuditTrailReport: function(oEvent) {
				var oSelItem = oEvent.getSource();
				var oContext = oSelItem.getBindingContext();
				var oHref = "#ZPRS_WF_DA-display&/" + oContext.getProperty("Vbeln");
				oSelItem.setHref(oHref);
			}
			/*,
			attachmentLoaded:function(oEvent){
				var tab = this.getView().byId("idIconTabBarMulti");
				tab.getItems()[1].setCount(oEvent.getParameter("total"));
			}*/
	});

});