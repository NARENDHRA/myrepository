sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		SeTRateIsErrorIcon: function(IsError) {
			if (IsError === "S")
				return "sap-icon://message-success";
			else if (IsError === "X")
				return "sap-icon://message-error";
			else if (IsError === "W")
				return "sap-icon://message-warning";

			else if (IsError === "" || IsError === null || IsError === undefined)
				return "";

		},
		SeTRateIconColor: function(IsError) {

			if (IsError === "S")
				return "Green";
			else if (IsError === "X")
				return "Red";
			else if (IsError === "W")
				return "Orange";
		},
			SeTStatusIcon: function(IsError) {
			if (IsError === "S")
				return "sap-icon://message-success";
			else if (IsError === "X")
				return "sap-icon://message-error";
			else if (IsError === "W")
				return "sap-icon://message-warning";

			else if (IsError === "" || IsError === null || IsError === undefined)
				return "";

		},
		SeTStatusIconColor: function(IsError) {

			if (IsError === "S")
				return "Green";
			else if (IsError === "X")
				return "Red";
			else if (IsError === "W")
				return "Orange";
		},
		SeTCommentIcon: function(WfComments) {
			if (WfComments === "X")
				return "sap-icon://comment";

			else if (WfComments === "" || WfComments === null || WfComments === undefined)
				return "";

		},
		SeTCommentIconColor: function(WfComments) {

			if (WfComments === "X")
				return "Blue";

		},
		SeTAttachmentIcon: function(isattachment) {

			if (isattachment === "" || isattachment === null || isattachment === undefined)
				return "";
			else 
				return "sap-icon://document";

		},
		SeTAttachmentIconColor: function(isattachment) {
			if (isattachment !== "")
				return "Blue";
		},
		SeTIconToolTip: function(Message) {

			return Message;
		},
		SeTCheckBoxStatus: function(Zzprtoninv) {
			if (Zzprtoninv === "X") {
				return true;
			}
			return false;
		},
		SeTReviewedStatus: function(Zzreview) {
			if (Zzreview === "X"){
				return "Reviewed";
			}
			return "";

		},
		SeTStatusIsErrorIcon: function(isIsError) {
				if (isIsError === "S")
				return "sap-icon://message-success";
			else if (isIsError === "X")
				return "sap-icon://message-error";
			else if (isIsError === "W")
				return "sap-icon://message-warning";

			else if (isIsError === "" || isIsError === null || isIsError === undefined)
				return "";
		},
		SeTStatusIsErrorIconColor: function(isIsError){
			if (isIsError === "S")
				return "Green";
			else if (isIsError === "X")
				return "Red";
			else if (isIsError === "W")
				return "Orange";
			
		},
		// 	convertTimestamp: function(date, time) {//function(oDate, oTime) {
		// 					var dt = date.split("T");
		// 					var c = time.slice(2, 4) + ":" + time.slice(5, 7) + ":" + time.slice(8, 10);
		// 					// return date.replace("00:00:00", c);
		// 					var fine = dt[0].concat("T" + c);
		// 					var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
		// 											style: "medium",UTC:true
		// 										});
		// 					var fdt = new Date(fine);
		// 					var TZOffsetMs = fdt.getTimezoneOffset() * 60 * 1000;
		// 					var dateStr = dateFormat.format(new Date(fine));
		// 					return dateStr;
		// 	/*var sDate = oDate.split("T");
		// 	var sTime = oTime.slice(2, 4) + ":" + oTime.slice(5, 7) + ":" + oTime.slice(8, 10);
		// 	var sTimestamp = sDate[0].concat("," + " " + sTime);
		// 	return sTimestamp;*/
		// },
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		}

	};

});