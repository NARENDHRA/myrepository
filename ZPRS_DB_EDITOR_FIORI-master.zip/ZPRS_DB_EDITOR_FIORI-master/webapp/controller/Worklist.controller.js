sap.ui.define([
	"bdeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"bdeditor/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, History, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("bdeditor.controller.Worklist", {

		formatter: formatter,
		onInit: function() {

			var oView = this.getView();
			// this.samplemtd();
			this.oModel1 = new JSONModel();
			var oSrchObj = {
				Matters: [],
				Clients: []
			};
			this.oModel1.setData(oSrchObj);
			var oViewMod, oValueModel;
			oViewMod = new JSONModel({
				dot: ".",
				isVisible: false,
				FotterButton: false,
				PrintDB: false,
				NarrativeButton: false,
				NavButtonEnabled: false,
				MainButtons: true,
				NewComments: "",
				Narrative: true,
				LitemEdit: true,
				LitemTransfer: true,
				LitemEditTransfer: true,
				LitemTransferT: true,
				isMainTable: true,
				isNarrativeTab: false,
				isLineItemEditTab: false,
				islineItemTransferTab: false,
				isOrderItem: false,
				isBillSummary: false,
				isFilterBar: true,
				HeadEditButton: false,
				LineEditTrnsferButton: false,
				LineEditButton: false,
				visibleRowCount: 9,
				isMainTblColmns: true,
				ToRateOverRideButton: true
			});
			this.setModel(oViewMod, "IconTab");

			var dateTo = new Date();
			// var odatetimeto = dateTo + "T00:00:00";
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "YYYY-MM-dd"
				}),
				dateFormatted = dateFormat.format(dateTo),
				odatetimeto = dateFormatted + "T00:00:00",
				odateFrom = "2014-01-01T00:00:00";

			oValueModel = new JSONModel({
				WriteInputAmount: "",
				WriteInputQty: "",
				RateInputAmount: "",
				dateto: odatetimeto,
				datefrom: odateFrom,
				vbelnValue:""
			});
			this.setModel(oValueModel, "oValueModel");
			
			// this.onFilterButton();
			// this.byId("idsmartTable").setInitiallyVisibleFields("Message,WfStatusText,Status,BaName,ClientName,Pspid,Post1,Vbeln,Budat,Waers,NetFees,NetCost,Tax,NetAmount ");

			// this.getView().byId("idsmartTableNE").setInitiallyVisibleFields("Posnr,Budat,Sname,Pernr,Zzwerks,Narrative");

			var oIconTabBar = oView.byId("idIconTabBarNoIcons");

			oIconTabBar.setSelectedKey("ME");
			this.sKey = "ME";
			var comModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIP_EDITOR_SRV/");
			this.setModel(comModel1, "comModel");
			var AttachModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_FILE_ATTACHMENT_SRV/");
			this.setModel(AttachModel, "AttachModel");
		},
		handleDataReceived: function(oEvent) {
			var oSource = oEvent.getSource(),
				oViewMod = this.getModel("IconTab"),
				oTbl = oSource.getTable(),
				rows = oTbl.getBinding().getLength(),
				IconTab = this.getModel("IconTab");
			IconTab.setProperty("/visibleRowCount", rows);
			if (rows >= 9) {
				IconTab.setProperty("/visibleRowCount", 9);
			}
			oViewMod.setProperty("/isMainTblColmns", false);
		},
		handleDataReceivedNarrative: function(oEvent) {
			var oSource = oEvent.getSource(),
				oViewMod = this.getModel("IconTab"),
				oTbl = oSource.getTable(),
				rows = oTbl.getBinding().getLength(),
				IconTab = this.getModel("IconTab");
			IconTab.setProperty("/visibleRowCount", rows);
			if (rows >= 9) {
				IconTab.setProperty("/visibleRowCount", 9);
			}
			oViewMod.setProperty("/isMainTblColmns", false);
			// oViewMod.setProperty("/Narrative",true);
			// oViewMod.setProperty("/LitemEdit",true);
			// oViewMod.setProperty("/LitemTransfer", true);

		},
		onBeforeRebindTable: function(oEvent) {

			var mBindingParams = oEvent.getParameter("bindingParams");
			if (this.aFilter !== undefined && this.aFilter !== null) {
				mBindingParams.filters.push(this.aFilter);
			}

		},
		onFilterButton: function() {

			if (this._oDialog) {
				this._oDialog.destroy();

			}

			this._oDialog = sap.ui.xmlfragment("bdeditor.fragments.Filter", this);

			this.getView().addDependent(this._oDialog);
			this._oDialog.setModel(this.oModel1, "nemod");
			this._oDialog.open();

			var odate = new sap.ui.model.json.JSONModel();
			odate.setData({
				dateValue: new Date()
			});
			this.getView().setModel(odate, "fdate");
			sap.ui.getCore().byId("Dateto").setDateValue(new Date());
			var ocor = sap.ui.getCore();
			this._mid = ocor.byId("matterInputId");
			this._client = ocor.byId("clientInputId");
			this._PartnerNum = ocor.byId("partnerInputId");
			this._billofc = ocor.byId("BilOfcInputId");
			this._salesorg = ocor.byId("SalesOrgInputId");
			this._MRGroup = ocor.byId("MRepotGrpInputId");
			this._gbillId = ocor.byId("groupBillInputId");
			this._DBillId = ocor.byId("DBIdInputId");

			// this.theTokenInput= this.getView().byId("multiInput");

		},

		onGoClick: function() {
			var oTable = this.getTable();
			// var oModel = oView.getModel();
			var ocor = sap.ui.getCore();
			//var mid = ocor.byId("matterid").getValue();
			var oview = this.getView();
			var datefrom = ocor.byId("Datefrom").getValue();
			var odatetimefrom = datefrom + "T00:00:00";
			var dateTo = ocor.byId("Dateto").getValue();
			var odatetimeto = dateTo + "T00:00:00";

			var matter = this._mid.getValue();
			var check = ocor.byId("checkid").getSelected();
			var aFilter = [];
			var oFilter;
			// var oMatter = [];
			$.each(this.oModel1.getData().Matters, function(i, m) {
				aFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, m.MatterId));
			});
			$.each(this.oModel1.getData().Clients, function(i, m) {
				aFilter.push(new sap.ui.model.Filter("Client", sap.ui.model.FilterOperator.EQ, m.ClientId));
			});
			// oMatter = this._mid.getTokens();

			oFilter = new sap.ui.model.Filter("Budat", sap.ui.model.FilterOperator.GE, odatetimefrom);
			aFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter("Budat", sap.ui.model.FilterOperator.LE, odatetimeto);
			aFilter.push(oFilter);
			if (matter !== "") {
				oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, matter);
				aFilter.push(oFilter);
			}
			var opartnerType = ocor.byId("idpartnerType").getSelectedKey();
			if (opartnerType !== "") {
				oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, opartnerType);
				aFilter.push(oFilter);
			}
			var client = this._client.getValue();
			if (client !== "") {
				oFilter = new sap.ui.model.Filter("Client", sap.ui.model.FilterOperator.EQ, client);
				aFilter.push(oFilter);
			}
			var PNumber = this._PartnerNum.getValue();
			if (PNumber !== "") {
				oFilter = new sap.ui.model.Filter("MpatnerParvw", sap.ui.model.FilterOperator.EQ, PNumber);
				aFilter.push(oFilter);
			}
			var billocf = this._billofc.getValue();
			if (billocf !== "") {
				oFilter = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, billocf);
				aFilter.push(oFilter);
			}
			var salesorg = this._salesorg.getValue();
			if (salesorg !== "") {
				oFilter = new sap.ui.model.Filter("Vkorg", sap.ui.model.FilterOperator.EQ, salesorg);
				aFilter.push(oFilter);
			}
			var MgrpRep = this._MRGroup.getValue();
			if (MgrpRep !== "") {
				oFilter = new sap.ui.model.Filter("Rptgroup", sap.ui.model.FilterOperator.EQ, MgrpRep);
				aFilter.push(oFilter);
			}
			var grpBilId = this._gbillId.getValue();
			if (grpBilId !== "") {
				oFilter = new sap.ui.model.Filter("Mgbill", sap.ui.model.FilterOperator.EQ, grpBilId);
				aFilter.push(oFilter);
			}
			var Dbill = this._DBillId.getValue();
			if (Dbill !== "") {
				oFilter = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, Dbill);
				aFilter.push(oFilter);
			}
			if(check)
			{
			this.getRouter().navTo("object", {
				Pspid: matter,
				BudatFrom:odatetimefrom,
				BudateTo:odatetimeto
			});
			}else{
			this.aFilter = aFilter;
			oTable.getBinding("rows").filter(this.aFilter);
			}
			this._oDialog.close();
			this._oDialog.destroy();
		},
		onclose: function() {
			this._oDialog.close();
		},
		DocPress: function(oevent) {

			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment("bdeditor.fragments.DocumentFilter", this);
			this.getView().addDependent(this._oDialog);
			var ocor = sap.ui.getCore();
			var tab = ocor.byId("TableDialog");
			var bind = tab.getBinding("items");
			bind.filter(this.aFilter);

			this._oDialog.open();

		},
		onAdditionalWip: function(oEvt) {
			var fragPath = "bdeditor.fragments.AdditionalWip";

			if (!this.additionalwip) {
				this.additionalwip = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.additionalwip);
			}

			var ocor = sap.ui.getCore();
			var tab = ocor.byId("TableDialog");
			var oValueMod = this.getModel("oValueModel"),
				odateto = oValueMod.getProperty("/dateto"),
				odatefrom = oValueMod.getProperty("/datefrom"),
				aFilter = [],
				oFilter,
				oTable = this.getTable(),
				context1 = oTable.getContextByIndex(0),
				obj = context1.getObject(),
				Pspid = obj.Pspid,
				oWipvbeln = obj.Vbeln;
			this.oWipvbeln = oWipvbeln;
			oFilter = new sap.ui.model.Filter("Budat", sap.ui.model.FilterOperator.GE, odatefrom);
			aFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter("Budat", sap.ui.model.FilterOperator.LE, odateto);
			aFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid);
			aFilter.push(oFilter);

			var comModel = this.getModel("comModel");
			var oModelLocal = new sap.ui.model.json.JSONModel();

			comModel.read("/WipDetailsSet",

				{
					filters: aFilter,

					success: function(data, response) {
						oModelLocal.setData(data);
						tab.setModel(oModelLocal, "AdditionalWipMod");

					},
					error: function(oError) {

					}

				}
			);

			// this.additionalwip.openBy(oEvt.getSource());
			this.additionalwip.open();
		},
		onWipAddDraftBill: function(oevt) {
			var ocor = sap.ui.getCore(),
				tbl = ocor.byId("TableDialog"),
				oBelnrArray = [],
				oBuzeiArray = [],
				// oVbelnArray = [],
				oBudatArray = [];

			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var obj = context1.getObject();
				// oVbelnArray.push(obj.Vbeln);
				oBelnrArray.push(obj.Belnr);
				oBuzeiArray.push(obj.Buzei);
				oBudatArray.push(obj.Budat);

			});

			var AddWipModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			var oUrlParams = {
				Vbeln: this.oWipvbeln,
				Belnr: oBelnrArray,
				Buzei: oBuzeiArray,
				Budat: oBudatArray
			};

			AddWipModel.callFunction("/AddLateWip", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(tbl.getSelectedIndices(), function(i, o) {

						var ctx = tbl.getContextByIndex(o);
						var isErrorPath = ctx.getPath() + "/Iserror";
						var MessagePath = ctx.getPath() + "/Message";

						var model = ctx.getModel();
						model.setProperty(MessagePath, oData.Message);

						model.setProperty(isErrorPath, oData.IsError);

					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		onWipCancel: function() {
			this.additionalwip.close();

		},
		onCommentClick: function(oEvt) {

			var src = oEvt.getSource();

			var fragPath = "bdeditor.fragments.DisplayComment";
			var obj = src.getBindingContext().getObject();

			if (!this.displayCmt) {
				this.displayCmt = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.displayCmt);
			}
			var comList = sap.ui.getCore().byId("commentsList");
			var binding = comList.getBinding("items");
			var filters = [];

			filters.push(new Filter("Vbeln", FilterOperator.EQ, obj.Vbeln));
			binding.filter(filters);
			this.displayCmt.openBy(oEvt.getSource());
		},
		onAttachmentClick: function(oEvt) {
			var src = oEvt.getSource();

			var fragPath = "bdeditor.fragments.DisplayAttachments";
			var obj = src.getBindingContext().getObject();

			if (!this.displayAttachment) {
				this.displayAttachment = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.displayAttachment);
			}
			var comList = sap.ui.getCore().byId("AttachList");
			var binding = comList.getBinding("items");
			var filters = [];

			filters.push(new Filter("Vbeln", FilterOperator.EQ, obj.Vbeln));
			binding.filter(filters);
			this.displayAttachment.openBy(oEvt.getSource());
		},

		MenuButtonActio: function(oEvent) {
			var oItem = oEvent.getParameter("item");

		},
		onStatusClick: function(oEvt) {
			// var src = oEvt.getSource();

			var fragPath = "bdeditor.fragments.Statuschange";
			// var obj = src.getBindingContext().getObject();

			if (!this.statusAttachment) {
				this.statusAttachment = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.statusAttachment);
			}
			var ActionSheetList = sap.ui.getCore().byId("ActionList");
			var binding = ActionSheetList.getBinding("items");

			var cFilter;
			var dFilter = [];
			var oTable = this.getTable();
			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				// var TypeApprov = context1.getProperty("TypeOfApproval");
				var vbeln = context1.getProperty("Vbeln");
				cFilter = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, vbeln);
				dFilter.push(cFilter);

			});
			// cFilter = new sap.ui.model.Filter("TypeOfApproval", sap.ui.model.FilterOperator.EQ, "W");
			// dFilter.push(cFilter);

			// var changeStatusModel = new sap.ui.model.json.JSONModel();
			// var oModel = this.getView().getModel();
			// oModel.read("/DbStatusSet", {
			// 	filters: dFilter,
			// 	success: function(data, response) {
			// 		changeStatusModel.setData(data);
			// 		// ActionSheetList.setModel(changeStatusModel);
			// 		this.getView().setModel(changeStatusModel, "changeStatusModel");

			// 	},
			// 	error: function(oError) {

			// 	}
			// });
			binding.filter(dFilter);
			// var data = this.getView().getModel("changeStatusModel").getData();
			this.statusAttachment.openBy(oEvt.getSource());
		},
		ActionListItemPress: function(oEvent) {
			var osrc = oEvent.getSource(),
				ActionTxt = osrc.getText(),
				fields = ActionTxt.split(" "),
				ActionTextState = fields[0],
				oTable = this.getTable(),
				oVbelnArray = [],
				TYPEOFAPPROVALArray = [];

			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var obj = context1.getObject();
				oVbelnArray.push(obj.Vbeln);
				TYPEOFAPPROVALArray.push(obj.TypeOfApproval);

			});
			var FinalBillModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			var oUrlParams = {
				VBELN: oVbelnArray,
				TYPEOFAPPROVAL: TYPEOFAPPROVALArray,
				STATUS: ActionTextState
			};

			FinalBillModel.callFunction("/ChangeStatus", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							// var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							// model.setProperty(VbelnPath, a[0].Vbeln);
							model.setProperty(isErrorPath, a[0].Error);
						}
					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		// onrepricing: function(){
			
		// },
		onLineItemRepricePress: function(oEvt) {
			var osrc = oEvt.getSource(),
				lineitemTxt = osrc.getText(),
				fields = lineitemTxt.split(" "),
				lineitemTxtState = fields[0],
				oAction = "REPRICEITM",
				oMainTable = this.getTable(),
				Mainindex = oMainTable.getSelectedIndices(),
				MainTblContx = oMainTable.getContextByIndex(Mainindex),
				mainpath = MainTblContx.getPath(),
				oSecondaryTable = this.getView().byId("idsmartTableNE").getTable(),
				Secind = oSecondaryTable.getSelectedIndices(),
				SecTblContx = oSecondaryTable.getContextByIndex(Secind);
			// odataodj = [];

			var odataodj = {
				Action: oAction,
				BlockNarrative: MainTblContx.getProperty("BlockNarrative"),
				Message: MainTblContx.getProperty("Message"),
				Status: MainTblContx.getProperty("Status"),
				WfStatusText: MainTblContx.getProperty("WfStatusText"),
				WfComments: MainTblContx.getProperty("WfComments"),
				isattachment: MainTblContx.getProperty("isattachment"),
				BaName: MainTblContx.getProperty("BaName"),
				ClientName: MainTblContx.getProperty("ClientName"),
				Pspid: MainTblContx.getProperty("Pspid"),
				Post1: MainTblContx.getProperty("Post1"),
				Vbeln: MainTblContx.getProperty("Vbeln"),
				Budat: MainTblContx.getProperty("Budat"),
				Waers: MainTblContx.getProperty("Waers"),
				NetFees: MainTblContx.getProperty("NetFees"),
				NetCost: MainTblContx.getProperty("NetCost"),
				Tax: MainTblContx.getProperty("Tax"),
				NetAmount: MainTblContx.getProperty("NetAmount"),
				VbelnVf: MainTblContx.getProperty("VbelnVf"),
				Werks: MainTblContx.getProperty("Werks"),
				Zzcreditamt: MainTblContx.getProperty("Zzcreditamt"),
				Client: MainTblContx.getProperty("Client"),
				PriceCntrl: lineitemTxtState,
				OrderItemSet: [{
					// PriceCntrl: lineitemTxtState,
					// ToWtgbtr: SecTblContx.getProperty("ToWtgbtr"),
					// ToMegbtr: SecTblContx.getProperty("ToMegbtr"),
					Vbeln: SecTblContx.getProperty("Vbeln"),
					Posnr: SecTblContx.getProperty("Posnr"),
					Zzreview: SecTblContx.getProperty("Zzreview"),
					Sname: SecTblContx.getProperty("Sname"),
					Pernr: SecTblContx.getProperty("Pernr"),
					Zzwerks: SecTblContx.getProperty("Zzwerks"),
					Narrative: SecTblContx.getProperty("Narrative"),

					IsError: SecTblContx.getProperty("IsError"),
					Message: SecTblContx.getProperty("Message"),
					Zzprtoninv: SecTblContx.getProperty("Zzprtoninv"),
					Budat: SecTblContx.getProperty("Budat"),
					Ptext: SecTblContx.getProperty("Ptext"),
					Awtyp: SecTblContx.getProperty("Awtyp"),

					Lstar: SecTblContx.getProperty("Lstar"),
					LstarDesc: SecTblContx.getProperty("LstarDesc"),
					Belnr: SecTblContx.getProperty("Belnr"),
					Meinh: SecTblContx.getProperty("Meinh"),
					Waers: SecTblContx.getProperty("Waers"),
					BaseRate: SecTblContx.getProperty("BaseRate"),
					ActualRate: SecTblContx.getProperty("ActualRate"),

					BaseValue: SecTblContx.getProperty("BaseValue"),
					ActualValue: SecTblContx.getProperty("ActualValue"),
					BaseQty: SecTblContx.getProperty("BaseQty"),
					ActualQty: SecTblContx.getProperty("ActualQty"),
					ZwriteoffAmt: SecTblContx.getProperty("ZwriteoffAmt"),
					ZwriteoffQty: SecTblContx.getProperty("ZwriteoffQty"),
					Kzwi6: SecTblContx.getProperty("Kzwi6"),

					Kzwi5: SecTblContx.getProperty("Kzwi5"),
					Kzwi4: SecTblContx.getProperty("Kzwi4"),
					NetBillValue: SecTblContx.getProperty("NetBillValue"),
					Tax: SecTblContx.getProperty("Tax"),
					Phase: SecTblContx.getProperty("Phase"),
					ToVbeln: SecTblContx.getProperty("ToVbeln"),

					ToPercent: SecTblContx.getProperty("ToPercent"),
					ToZztskcd: SecTblContx.getProperty("ToZztskcd"),
					ToZzactcd: SecTblContx.getProperty("ToZzactcd"),
					ToZzfftskcd: SecTblContx.getProperty("ToZzfftskcd"),
					ToZzffactcd: SecTblContx.getProperty("ToZzffactcd")
				}]

			};
			var LineitemModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");
			LineitemModel.create("/BillSummarySet", odataodj, null, function(data) {

				var result = data.OrderItemSet.results,
					// iserroe = result[0].IsError,
					// Msg = result[0].Message;

					ctx = oSecondaryTable.getContextByIndex(Secind);
				var isErrorPath = ctx.getPath() + "/IsError";
				var MessagePath = ctx.getPath() + "/Message";
				// var VbelnPath = ctx.getPath() + "/Vbeln";
				var model = ctx.getModel();
				model.setProperty(MessagePath, result[0].Message);
				model.setProperty(isErrorPath, result[0].IsError);

			}, function() {

			});

		},
		onLineItemReprice: function(oEvt) {

			var fragPath = "bdeditor.fragments.LineItemRepriceMent";

			if (!this.onLineItemRepricefrag) {
				this.onLineItemRepricefrag = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.onLineItemRepricefrag);
			}

			this.onLineItemRepricefrag.openBy(oEvt.getSource());
		},
		onhandleRepriceClose: function() {
			this.onLineItemRepricefrag.close();
		},
		handlCommentClose: function(oEvt) {
			this.displayCmt.close();
		},
		handlAttachClose: function() {
			this.displayAttachment.close();
		},
		handleStatusClose: function() {
			this.statusAttachment.close();
		},
		OnAddCommentClick: function(oEvt) {
			var fragPath = "bdeditor.fragments.Comment";

			if (!this.addComment) {
				this.addComment = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.addComment);
			}
			this.addComment.openBy(oEvt.getSource());
		},
		handleCommentAdd: function(oEvt) {
			var oTable = this.getTable();
			var batchChanges = [];
			var worklistModel = this.getView().getModel("IconTab");
			var worklistData = worklistModel.getData();
			var NewComments = worklistData.NewComments;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_BILL_EDIT_SRV/"); //this.getOwnerComponent().getModel();
			oModel.attachRequestSent(this.onRequestSent);

			$.each(oTable.getSelectedIndices(), function(i, o) {

				var ctx = oTable.getContextByIndex(o);
				var oSelectedBillDraft = {
					Vbeln: ctx.getProperty("Vbeln"),
					Usercomment: NewComments
				};

				// var m = ctx.getModel();
				// m.setProperty(ctx.getPath() + "/Newcomments", "");
				batchChanges.push(oModel.createBatchOperation("/WFCommentsSet", "POST", oSelectedBillDraft));
			});
			oModel.addBatchChangeOperations(batchChanges);
			oModel.setUseBatch(true);

			this.addComment.close();
		},
		onChange: function(oEvent) {
			var oUploadCollection = oEvent.getSource();
			this.oUploadCollection = oUploadCollection;
			oUploadCollection.setUploadUrl("/sap/opu/odata/SAP/ZPRS_FILE_ATTACHMENT_SRV/FileAttachSet");
			// Header Token
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oUploadCollection.getModel().getSecurityToken()
			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		},
		onBeforeUploadStarts: function(oEvent) {
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: this.getView().getBindingContext().getProperty("Vbeln") + '|' + oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		onUploadComplete: function(oEvent) {
			var atthModel;
			atthModel = this.getView().getModel("atthModel");
			atthModel.refresh();
			//	this.setAttachmentCount(oEvent);
		},
		FinalBillClick: function() {
			// if (this._FinalBillDialog) {
			// 	this._FinalBillDialog.destroy();
			// }
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment("bdeditor.fragments.CreatFinalBill", this);

			this.getView().addDependent(this._oDialog);
			sap.ui.getCore().byId("BillingDate").setDateValue(new Date());

			this._oDialog.open();
		},
		onFinalBillclose: function() {
			this._oDialog.close();
		},
		oClickFinalBill: function(oEvent) {
			var oTable = this.getTable();

			// var oFModel = this.getOwnerComponent().getModel();
			var ocor = sap.ui.getCore();
			var BillingDate = ocor.byId("BillingDate").getValue();
			var idFinalBillType = ocor.byId("idFinalBillType").getSelectedKey();
			var oVbelnArray = [];

			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var obj = context1.getObject();
				oVbelnArray.push(obj.Vbeln);

			});
			var FinalBillModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			var oUrlParams = {
				VBELN: oVbelnArray,
				GROUPBILL: "",
				FKDAT: BillingDate,
				FKART: idFinalBillType
			};

			FinalBillModel.callFunction("/CreateFinal", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							// var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							// model.setProperty(VbelnPath, a[0].Vbeln);
							model.setProperty(isErrorPath, "S");
						}
					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});
			this._oDialog.close();

		},
		oClickCancelBill: function(oEvent) {
			var oTable = this.getTable();

			var oVbelnArray = [];

			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var obj = context1.getObject();
				oVbelnArray.push(obj.Vbeln);

			});
			var FinalBillModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");
			// this.setModel(FinalBillModel);
			// oVbelnArray.push("70000786");

			var oUrlParams = {
				Vbeln: oVbelnArray
			};

			FinalBillModel.callFunction("/DraftCancel", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							// var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							// model.setProperty(VbelnPath, a[0].Vbeln);
							model.setProperty(isErrorPath, "S");
						}
					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		getTable: function() {
			var oTable = this.getView().byId("idsmartTable");
			return oTable.getTable();
		},
		onDisplayLog: function(oEvent) {
			var oTable = this.getTable();
			// var oView = this.getView();
			var oFModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			// var oFModel1 = this.getOwnerComponent().getModel();
			var cFilter;
			var dFilter = [];

			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var newpspid = context1.getProperty("Vbeln");
				cFilter = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, newpspid);
				dFilter.push(cFilter);

			});
			if (dFilter.length > 1) {
				dFilter = [new Filter(dFilter, true)];
			}
			var oPath1 = "/GetLogSet";
			var mParameters1 = {
				filters: dFilter,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {

							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);

							model.setProperty(isErrorPath, a[0].Error);

						}
					});

				},
				error: function(oError) {
					// sap.m.MessageBox.show("Error");
				}
			};
			oFModel1.read(oPath1, mParameters1);
		},
		onPrintDraftBill: function() {
			var oTable = this.getTable();
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment("bdeditor.fragments.PrintDraftBill", this);

			this.getView().addDependent(this._oDialog);

			var index = oTable.getSelectedIndex();
			var context1 = oTable.getContextByIndex(index);
			var Vbeln = context1.getObject().Vbeln;
			var Pspid = context1.getObject().Pspid;
			var idFinalBillType = sap.ui.getCore().byId("idDBillType");
			var sFilter = [];
			sFilter.push(new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, "V1"));
			sFilter.push(new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, Vbeln));
			sFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			var Bind = idFinalBillType.getBinding("items");
			Bind.filter(sFilter);
			this._oDialog.open();
		},
		oClickDBillPrint: function(oEvent) {

			var oTable = this.getTable();
			var oFModel = this.getOwnerComponent().getModel();
			var ocor = sap.ui.getCore();
			var idFinalBillType = ocor.byId("idDBillType").getSelectedKey();
			var index = oTable.getSelectedIndex();
			var context1 = oTable.getContextByIndex(index);
			var Kappl = "V1";
			var DraftBill = context1.getObject().Vbeln;
			// var sRead = /PDFOutCollection(Kappl="V1",Kschl="ZDR1",DraftBill="70000774")/$value;
			var servUri = oFModel.sServiceUrl;
			var sRead = "/PDFOutCollection(Kappl='" + Kappl + "',Kschl='" + idFinalBillType + "',DraftBill='" + DraftBill + "')" + "/$value";

			var mainUri = servUri + sRead;

			sap.m.URLHelper.redirect(mainUri, true);
			// var sampleurl = uri+sRead;
			// oFModel.read(sRead, null, null, true, function(oData, oResponse){

			// // oResponse.requestUri;
			// },function(){

			// });

			this._oDialog.close();

		},
		onPrintFinalBill: function() {
			var oTable = this.getTable();
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			this._oDialog = sap.ui.xmlfragment("bdeditor.fragments.PrintFinalBill", this);

			this.getView().addDependent(this._oDialog);
			// var VbelnArray = [];
			var Pspid;
			var sFilter = [];
			$.each(oTable.getSelectedIndices(), function(i, o) {
				var context1 = oTable.getContextByIndex(o);
				var sobj = context1.getObject();
				Pspid = sobj.Pspid;
				sFilter.push(new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sobj.Vbeln));
			});

			var idFinalBillType = sap.ui.getCore().byId("idDBillType1");

			sFilter.push(new sap.ui.model.Filter("Kappl", sap.ui.model.FilterOperator.EQ, "V3"));
			// sFilter.push(new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, VbelnArray));
			sFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			var Bind = idFinalBillType.getBinding("items");
			Bind.filter(sFilter);
			this._oDialog.open();
		},
		onPostPonePress: function() {
			var action = "POSTPONE",
				oVbelnArray = [],
				oPosnrArray = [],
				PercentageArray = [],
				HoursArray = [],
				ToActivityCodeArray = [],
				ToFfActivityCodeArray = [],
				ToFfTaskCodeArray = [],
				ToTaskCodeArray = [],
				WBS_NODE2Array = "",
				ToMatterArray = [],
				CounterArray = "",
				ToVbelnArray = [],
				ToPhaseCodeArray = "";
			var oTable = this.getView().byId("idsmartTableNE").getTable();
			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var obj = context1.getObject();
				oVbelnArray.push(obj.Vbeln);
				oPosnrArray.push(obj.Belnr);
				PercentageArray.push(obj.ToPercent);
				HoursArray.push(obj.ToMegbtr);
				ToActivityCodeArray.push(obj.ToZzactcd);
				ToFfActivityCodeArray.push(obj.ToZzffactcd);
				ToFfTaskCodeArray.push(obj.ToZzfftskcd);
				ToTaskCodeArray.push(obj.ToZztskcd);
				// WBS_NODE2Array.push(obj.Vbeln);
				ToMatterArray.push(obj.Phase);
				// CounterArray.push(obj.Vbeln);
				ToVbelnArray.push(obj.ToVbeln);
				// ToPhaseCodeArray.push(obj.Vbeln);
			});
			var FinalBillModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			var oUrlParams = {
				Action: action,
				Vbeln: oVbelnArray,
				Posnr: oPosnrArray,
				Percentage: PercentageArray,
				Hours: HoursArray,
				ToActivityCode: ToActivityCodeArray,
				ToFfActivityCode: ToFfActivityCodeArray,
				ToFfTaskCode: ToFfTaskCodeArray,
				ToTaskCode: ToTaskCodeArray,
				WBS_NODE2: WBS_NODE2Array,
				ToMatter: ToMatterArray,
				Counter: CounterArray,
				ToVbeln: ToVbelnArray,
				ToPhaseCode: ToPhaseCodeArray

			};

			FinalBillModel.callFunction("/BillTransfer", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/IsError";
							var MessagePath = ctx.getPath() + "/Message";
							// var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							// model.setProperty(VbelnPath, a[0].Vbeln);
							if (a[0].IsError === "") {
								model.setProperty(isErrorPath, "S");
							} else {
								model.setProperty(isErrorPath, a[0].Iserror);
							}
						}
					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});
		},
		onConsolidate: function() {

			var action = "CONSOLIDATE",
				oVbelnArray = [],
				oPosnrArray = [],
				PercentageArray = [],
				HoursArray = [],
				ToActivityCodeArray = [],
				ToFfActivityCodeArray = [],
				ToFfTaskCodeArray = [],
				ToTaskCodeArray = [],
				WBS_NODE2Array = "",
				ToMatterArray = [],
				CounterArray = "",
				ToVbelnArray = [],
				ToPhaseCodeArray = "";
			var oTable = this.getView().byId("idsmartTableNE").getTable();
			$.each(oTable.getSelectedIndices(), function(i, index) {
				var context1 = oTable.getContextByIndex(index);
				var obj = context1.getObject();
				oVbelnArray.push(obj.Vbeln);
				oPosnrArray.push(obj.Belnr);
				PercentageArray.push(obj.ToPercent);
				HoursArray.push(obj.ToMegbtr);
				ToActivityCodeArray.push(obj.ToZzactcd);
				ToFfActivityCodeArray.push(obj.ToZzffactcd);
				ToFfTaskCodeArray.push(obj.ToZzfftskcd);
				ToTaskCodeArray.push(obj.ToZztskcd);
				// WBS_NODE2Array.push(obj.Vbeln);
				ToMatterArray.push(obj.Phase);
				// CounterArray.push(obj.Vbeln);
				ToVbelnArray.push(obj.ToVbeln);
				// ToPhaseCodeArray.push(obj.Vbeln);
			});
			var FinalBillModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");

			var oUrlParams = {
				Action: action,
				Vbeln: oVbelnArray,
				Posnr: oPosnrArray,
				Percentage: PercentageArray,
				Hours: HoursArray,
				ToActivityCode: ToActivityCodeArray,
				ToFfActivityCode: ToFfActivityCodeArray,
				ToFfTaskCode: ToFfTaskCodeArray,
				ToTaskCode: ToTaskCodeArray,
				WBS_NODE2: WBS_NODE2Array,
				ToMatter: ToMatterArray,
				Counter: CounterArray,
				ToVbeln: ToVbelnArray,
				ToPhaseCode: ToPhaseCodeArray

			};

			FinalBillModel.callFunction("/BillTransfer", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData) {
					$.each(oTable.getSelectedIndices(), function(i, o) {
						var context1 = oTable.getContextByIndex(o);
						var sobj = context1.getObject();
						// var sobj = o.getBindingContext().getObject();

						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Vbeln === oo.Vbeln;
						});
						if (a.length === 1) {
							// var ctx = o.getBindingContext();
							var ctx = oTable.getContextByIndex(o);
							var isErrorPath = ctx.getPath() + "/IsError";
							var MessagePath = ctx.getPath() + "/Message";
							// var VbelnPath = ctx.getPath() + "/Vbeln";
							var model = ctx.getModel();
							model.setProperty(MessagePath, a[0].Message);
							// model.setProperty(VbelnPath, a[0].Vbeln);
							if (a[0].Iserror === "") {
								model.setProperty(isErrorPath, "S");
							} else {
								model.setProperty(isErrorPath, a[0].Iserror);
							}
						}
					});
				},

				error: function(oError) {
					sap.m.MessageBox.show("Error");

				}
			});

		},
		onWriteUpDown: function(oevn) {
			var fragPath = "bdeditor.fragments.WriteupDown",
				ocor = sap.ui.getCore();

			if (!this.writeupDowm) {
				this.writeupDowm = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.writeupDowm);
			}
			var oTable = this.getView().byId("idsmartTableNE").getTable(),
				ind = oTable.getSelectedIndices(),
				fTblContx = oTable.getContextByIndex(ind);
			ocor.byId("idWriteUpDown").setBindingContext(fTblContx);
			this.writeupDowm.open();
			// return fTblContx;
		},
		onWriteUpDownClick: function() {
			var oValueModel = this.getModel("oValueModel"),
				ToWtgbtr = oValueModel.getProperty("/WriteInputAmount"),
				ToMegbtr = oValueModel.getProperty("/WriteInputQty"),
				oAction = "WRITEUP";
			this.onWriteUpDownOverride(oAction, ToWtgbtr, ToMegbtr);
		},
		onWriteUpDownClose: function() {
			this.writeupDowm.close();
		},
		onRateOverride: function(oevn) {
			var fragPath = "bdeditor.fragments.RateOverride",
				ocor = sap.ui.getCore();

			if (!this.RateOverride) {
				this.RateOverride = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.RateOverride);
			}
			var oTable = this.getView().byId("idsmartTableNE").getTable(),
				ind = oTable.getSelectedIndices(),
				fTblContx = oTable.getContextByIndex(ind);
			ocor.byId("idRateOverride").setBindingContext(fTblContx);
			this.getModel("IconTab").setProperty("/ToRateOverRideButton", true);
			this.RateOverride.open();
			// return fTblContx;
		},
		onRateOverrideClick: function(oEvent) {
			var oValueModel = this.getModel("oValueModel"),
				ToWtgbtr = oValueModel.getProperty("/RateInputAmount"),
				ToMegbtr = "0",
				oAction = "RATE";
			this.onWriteUpDownOverride(oAction, ToWtgbtr, ToMegbtr);
		},
		onWriteUpDownOverride: function(oAction, ToWtgbtr, ToMegbtr) {
			var oViewMod = this.getModel("IconTab"),
				RateOverrideModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/"),
				// oAction = "RATE",
				// batchChanges = [],
				// oModel = this.getView().getModel(),
				oMainTable = this.getTable(),
				Mainindex = oMainTable.getSelectedIndices(),
				MainTblContx = oMainTable.getContextByIndex(Mainindex),
				mainobj = MainTblContx.getObject(),
				mainpath = MainTblContx.getPath(),
				oSecondaryTable = this.getView().byId("idsmartTableNE").getTable(),
				Secind = oSecondaryTable.getSelectedIndices(),
				SecTblContx = oSecondaryTable.getContextByIndex(Secind);

			// var	oValueModel = this.getModel("oValueModel"),
			// 	rateValue = oValueModel.getProperty("/RateInputAmount");

			var odataodj = {
				Action: oAction,
				BlockNarrative: MainTblContx.getProperty("BlockNarrative"),
				Message: MainTblContx.getProperty("Message"),
				Status: MainTblContx.getProperty("Status"),
				WfStatusText: MainTblContx.getProperty("WfStatusText"),
				WfComments: MainTblContx.getProperty("WfComments"),
				isattachment: MainTblContx.getProperty("isattachment"),
				BaName: MainTblContx.getProperty("BaName"),
				ClientName: MainTblContx.getProperty("ClientName"),
				Pspid: MainTblContx.getProperty("Pspid"),
				Post1: MainTblContx.getProperty("Post1"),
				Vbeln: MainTblContx.getProperty("Vbeln"),
				Budat: MainTblContx.getProperty("Budat"),
				Waers: MainTblContx.getProperty("Waers"),
				NetFees: MainTblContx.getProperty("NetFees"),
				NetCost: MainTblContx.getProperty("NetCost"),
				Tax: MainTblContx.getProperty("Tax"),
				NetAmount: MainTblContx.getProperty("NetAmount"),
				VbelnVf: MainTblContx.getProperty("VbelnVf"),
				Werks: MainTblContx.getProperty("Werks"),
				Zzcreditamt: MainTblContx.getProperty("Zzcreditamt"),
				Client: MainTblContx.getProperty("Client"),
				OrderItemSet: [{
					ToWtgbtr: ToWtgbtr,
					ToMegbtr: ToMegbtr,
					Vbeln: SecTblContx.getProperty("Vbeln"),
					Posnr: SecTblContx.getProperty("Posnr"),
					Zzreview: SecTblContx.getProperty("Zzreview"),
					Sname: SecTblContx.getProperty("Sname"),
					Pernr: SecTblContx.getProperty("Pernr"),
					Zzwerks: SecTblContx.getProperty("Zzwerks"),
					Narrative: SecTblContx.getProperty("Narrative"),

					IsError: SecTblContx.getProperty("IsError"),
					Message: SecTblContx.getProperty("Message"),
					Zzprtoninv: SecTblContx.getProperty("Zzprtoninv"),
					Budat: SecTblContx.getProperty("Budat"),
					Ptext: SecTblContx.getProperty("Ptext"),
					Awtyp: SecTblContx.getProperty("Awtyp"),

					Lstar: SecTblContx.getProperty("Lstar"),
					LstarDesc: SecTblContx.getProperty("LstarDesc"),
					Belnr: SecTblContx.getProperty("Belnr"),
					Meinh: SecTblContx.getProperty("Meinh"),
					Waers: SecTblContx.getProperty("Waers"),
					BaseRate: SecTblContx.getProperty("BaseRate"),
					ActualRate: SecTblContx.getProperty("ActualRate"),

					BaseValue: SecTblContx.getProperty("BaseValue"),
					ActualValue: SecTblContx.getProperty("ActualValue"),
					BaseQty: SecTblContx.getProperty("BaseQty"),
					ActualQty: SecTblContx.getProperty("ActualQty"),
					ZwriteoffAmt: SecTblContx.getProperty("ZwriteoffAmt"),
					ZwriteoffQty: SecTblContx.getProperty("ZwriteoffQty"),
					Kzwi6: SecTblContx.getProperty("Kzwi6"),

					Kzwi5: SecTblContx.getProperty("Kzwi5"),
					Kzwi4: SecTblContx.getProperty("Kzwi4"),
					NetBillValue: SecTblContx.getProperty("NetBillValue"),
					Tax: SecTblContx.getProperty("Tax"),
					Phase: SecTblContx.getProperty("Phase"),
					ToVbeln: SecTblContx.getProperty("ToVbeln"),

					ToPercent: SecTblContx.getProperty("ToPercent"),
					ToZztskcd: SecTblContx.getProperty("ToZztskcd"),
					ToZzactcd: SecTblContx.getProperty("ToZzactcd"),
					ToZzfftskcd: SecTblContx.getProperty("ToZzfftskcd"),
					ToZzffactcd: SecTblContx.getProperty("ToZzffactcd")
				}]

			};

			RateOverrideModel.create("/BillSummarySet", odataodj, null, function(data) {

				var result = data.OrderItemSet.results,
					// iserroe = result[0].IsError,
					// Msg = result[0].Message;

					ctx = oSecondaryTable.getContextByIndex(Secind);
				var isErrorPath = ctx.getPath() + "/IsError";
				var MessagePath = ctx.getPath() + "/Message";
				// var VbelnPath = ctx.getPath() + "/Vbeln";
				var model = ctx.getModel();
				model.setProperty(MessagePath, result[0].Message);
				model.setProperty(isErrorPath, result[0].IsError);

			}, function() {

			});

		},
		onRateOverrideClose: function() {
			this.RateOverride.close();
		},
		onReviewPress: function() {
			var temp = "X";
			this.Review(temp);
		},
		onUnReviewPress: function() {
			var temp = "";
			this.Review(temp);
		},
		Review: function(temp) {
			var oAction = "LINEEDIT",
				oMainTable = this.getTable(),
				Mainindex = oMainTable.getSelectedIndices(),
				MainTblContx = oMainTable.getContextByIndex(Mainindex),
				mainpath = MainTblContx.getPath(),
				oSecondaryTable = this.getView().byId("idsmartTableNE").getTable();
			var odataodj = [];
			// Secind = oSecondaryTable.getSelectedIndices(),
			// SecTblContx = oSecondaryTable.getContextByIndex(Secind);

			$.each(oSecondaryTable.getSelectedIndices(), function(i, o) {
				var SecTblContx = oSecondaryTable.getContextByIndex(o);
				// context1.getObject().setProperty("Zzreview", temp);
				// var zzrev = context1.getObject().Zzreview;

				var sobj = {

					Vbeln: MainTblContx.getProperty("Vbeln"),
					Posnr: SecTblContx.getProperty("Posnr"),
					Zzreview: temp,
					Sname: SecTblContx.getProperty("Sname"),
					Pernr: SecTblContx.getProperty("Pernr"),
					Zzwerks: SecTblContx.getProperty("Zzwerks"),
					Narrative: SecTblContx.getProperty("Narrative"),
					Budat: SecTblContx.getProperty("Budat")
						// IsError: SecTblContx.getProperty("IsError"),
						// Message: SecTblContx.getProperty("Message"),
						// Zzprtoninv: SecTblContx.getProperty("Zzprtoninv"),
						// Budat: SecTblContx.getProperty("Budat"),
						// Ptext: SecTblContx.getProperty("Ptext"),
						// Awtyp: SecTblContx.getProperty("Awtyp"),

					// Lstar: SecTblContx.getProperty("Lstar"),
					// LstarDesc: SecTblContx.getProperty("LstarDesc"),
					// Belnr: SecTblContx.getProperty("Belnr"),
					// Meinh: SecTblContx.getProperty("Meinh"),
					// Waers: SecTblContx.getProperty("Waers"),
					// BaseRate: SecTblContx.getProperty("BaseRate"),
					// ActualRate: SecTblContx.getProperty("ActualRate"),

					// BaseValue: SecTblContx.getProperty("BaseValue"),
					// ActualValue: SecTblContx.getProperty("ActualValue"),
					// BaseQty: SecTblContx.getProperty("BaseQty"),
					// ActualQty: SecTblContx.getProperty("ActualQty"),
					// ZwriteoffAmt: SecTblContx.getProperty("ZwriteoffAmt"),
					// ZwriteoffQty: SecTblContx.getProperty("ZwriteoffQty"),
					// Kzwi6: SecTblContx.getProperty("Kzwi6"),

					// Kzwi5: SecTblContx.getProperty("Kzwi5"),
					// Kzwi4: SecTblContx.getProperty("Kzwi4"),
					// NetBillValue: SecTblContx.getProperty("NetBillValue"),
					// Tax: SecTblContx.getProperty("Tax"),
					// Phase: SecTblContx.getProperty("Phase"),
					// ToVbeln: SecTblContx.getProperty("ToVbeln"),
					// ToMegbtr: SecTblContx.getProperty("ToMegbtr"),

					// ToPercent: SecTblContx.getProperty("ToPercent"),
					// ToZztskcd: SecTblContx.getProperty("ToZztskcd"),
					// ToZzactcd: SecTblContx.getProperty("ToZzactcd"),
					// ToZzfftskcd: SecTblContx.getProperty("ToZzfftskcd"),
					// ToZzffactcd: SecTblContx.getProperty("ToZzffactcd")
				};
				odataodj.push(sobj);
			});
			var revObj = {
				Action: oAction,
				BlockNarrative: MainTblContx.getProperty("BlockNarrative"),
				Message: MainTblContx.getProperty("Message"),
				Status: MainTblContx.getProperty("Status"),
				WfStatusText: MainTblContx.getProperty("WfStatusText"),
				WfComments: MainTblContx.getProperty("WfComments"),
				isattachment: MainTblContx.getProperty("isattachment"),
				BaName: MainTblContx.getProperty("BaName"),
				ClientName: MainTblContx.getProperty("ClientName"),
				Pspid: MainTblContx.getProperty("Pspid"),
				Post1: MainTblContx.getProperty("Post1"),
				Vbeln: MainTblContx.getProperty("Vbeln"),
				Budat: MainTblContx.getProperty("Budat"),
				Waers: MainTblContx.getProperty("Waers"),
				NetFees: MainTblContx.getProperty("NetFees"),
				NetCost: MainTblContx.getProperty("NetCost"),
				Tax: MainTblContx.getProperty("Tax"),
				NetAmount: MainTblContx.getProperty("NetAmount"),
				VbelnVf: MainTblContx.getProperty("VbelnVf"),
				Werks: MainTblContx.getProperty("Werks"),
				Zzcreditamt: MainTblContx.getProperty("Zzcreditamt"),
				Client: MainTblContx.getProperty("Client"),

				OrderItemSet: odataodj

			};
			var ReviewModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");
			ReviewModel.create("/BillSummarySet", revObj, null, function(oData) {

				$.each(oSecondaryTable.getSelectedIndices(), function(i, o) {
					var context1 = oSecondaryTable.getContextByIndex(o);
					var sobj = context1.getObject();
					// var sobj = o.getBindingContext().getObject();

					var a = $.grep(oData.OrderItemSet.results, function(oo, ii) {
						return sobj.Posnr === oo.Posnr;
					});
					if (a.length === 1) {

						var ctx = oSecondaryTable.getContextByIndex(o);
						var Zzreviewpath = ctx.getPath() + "/Zzreview";

						var model = ctx.getModel();
						model.setProperty(Zzreviewpath, a[o].Zzreview);

					}
				});

			}, function() {

			});
		},
		onFullWriteDown: function() {
			var oAction = "WRITEUP",
				oMainTable = this.getTable(),
				Mainindex = oMainTable.getSelectedIndices(),
				MainTblContx = oMainTable.getContextByIndex(Mainindex),
				mainpath = MainTblContx.getPath(),
				oSecondaryTable = this.getView().byId("idsmartTableNE").getTable();
			var odataodj = [];
			// Secind = oSecondaryTable.getSelectedIndices(),
			// SecTblContx = oSecondaryTable.getContextByIndex(Secind);

			$.each(oSecondaryTable.getSelectedIndices(), function(i, o) {
				var SecTblContx = oSecondaryTable.getContextByIndex(o);
				// context1.getObject().setProperty("Zzreview", temp);
				// var zzrev = context1.getObject().Zzreview;

				var sobj = {

					Vbeln: SecTblContx.getProperty("Vbeln"),
					Posnr: SecTblContx.getProperty("Posnr"),
					Zzreview: SecTblContx.getProperty("Zzreview"),
					Sname: SecTblContx.getProperty("Sname"),
					Pernr: SecTblContx.getProperty("Pernr"),
					Zzwerks: SecTblContx.getProperty("Zzwerks"),
					Narrative: SecTblContx.getProperty("Narrative"),

					IsError: SecTblContx.getProperty("IsError"),
					Message: SecTblContx.getProperty("Message"),
					Zzprtoninv: SecTblContx.getProperty("Zzprtoninv"),
					Budat: SecTblContx.getProperty("Budat"),
					Ptext: SecTblContx.getProperty("Ptext"),
					Awtyp: SecTblContx.getProperty("Awtyp"),

					Lstar: SecTblContx.getProperty("Lstar"),
					LstarDesc: SecTblContx.getProperty("LstarDesc"),
					Belnr: SecTblContx.getProperty("Belnr"),
					Meinh: SecTblContx.getProperty("Meinh"),
					Waers: SecTblContx.getProperty("Waers"),
					BaseRate: SecTblContx.getProperty("BaseRate"),
					ActualRate: SecTblContx.getProperty("ActualRate"),

					BaseValue: SecTblContx.getProperty("BaseValue"),
					ActualValue: SecTblContx.getProperty("ActualValue"),
					BaseQty: SecTblContx.getProperty("BaseQty"),
					ActualQty: SecTblContx.getProperty("ActualQty"),
					ZwriteoffAmt: SecTblContx.getProperty("ZwriteoffAmt"),
					ZwriteoffQty: SecTblContx.getProperty("ZwriteoffQty"),
					Kzwi6: SecTblContx.getProperty("Kzwi6"),

					Kzwi5: SecTblContx.getProperty("Kzwi5"),
					Kzwi4: SecTblContx.getProperty("Kzwi4"),
					NetBillValue: SecTblContx.getProperty("NetBillValue"),
					Tax: SecTblContx.getProperty("Tax"),
					Phase: SecTblContx.getProperty("Phase"),
					ToVbeln: SecTblContx.getProperty("ToVbeln"),
					ToMegbtr: SecTblContx.getProperty("ToMegbtr"),

					ToPercent: SecTblContx.getProperty("ToPercent"),
					ToZztskcd: SecTblContx.getProperty("ToZztskcd"),
					ToZzactcd: SecTblContx.getProperty("ToZzactcd"),
					ToZzfftskcd: SecTblContx.getProperty("ToZzfftskcd"),
					ToZzffactcd: SecTblContx.getProperty("ToZzffactcd")
				};
				odataodj.push(sobj);
			});
			var revObj = {
				Action: oAction,
				BlockNarrative: MainTblContx.getProperty("BlockNarrative"),
				Message: MainTblContx.getProperty("Message"),
				Status: MainTblContx.getProperty("Status"),
				WfStatusText: MainTblContx.getProperty("WfStatusText"),
				WfComments: MainTblContx.getProperty("WfComments"),
				isattachment: MainTblContx.getProperty("isattachment"),
				BaName: MainTblContx.getProperty("BaName"),
				ClientName: MainTblContx.getProperty("ClientName"),
				Pspid: MainTblContx.getProperty("Pspid"),
				Post1: MainTblContx.getProperty("Post1"),
				Vbeln: MainTblContx.getProperty("Vbeln"),
				Budat: MainTblContx.getProperty("Budat"),
				Waers: MainTblContx.getProperty("Waers"),
				NetFees: MainTblContx.getProperty("NetFees"),
				NetCost: MainTblContx.getProperty("NetCost"),
				Tax: MainTblContx.getProperty("Tax"),
				NetAmount: MainTblContx.getProperty("NetAmount"),
				VbelnVf: MainTblContx.getProperty("VbelnVf"),
				Werks: MainTblContx.getProperty("Werks"),
				Zzcreditamt: MainTblContx.getProperty("Zzcreditamt"),
				Client: MainTblContx.getProperty("Client"),

				OrderItemSet: odataodj

			};
			var ReviewModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_BILL_EDIT_SRV/");
			ReviewModel.create("/BillSummarySet", revObj, null, function(oData) {

				$.each(oSecondaryTable.getSelectedIndices(), function(i, o) {
					var context1 = oSecondaryTable.getContextByIndex(o);
					var sobj = context1.getObject();
					// var sobj = o.getBindingContext().getObject();

					var a = $.grep(oData.OrderItemSet.results, function(oo, ii) {
						return sobj.Belnr === oo.Belnr;
					});
					if (a.length === 1) {

						var ctx = oSecondaryTable.getContextByIndex(o);

						var isErrorPath = ctx.getPath() + "/IsError";
						var MessagePath = ctx.getPath() + "/Message";

						var model = ctx.getModel();
						model.setProperty(MessagePath, a[0].Message);
						if (a[0].IsError === "") {
							model.setProperty(isErrorPath, "S");
						} else {
							model.setProperty(isErrorPath, a[0].IsError);
						}
					}
				});

			}, function() {

			});
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			this.selIdx = oEvent.getParameter("rowIndex");
			var oViewMod = this.getModel("IconTab");
			var length = oEvent.getSource().getSelectedIndices().length;
			if (length === 1) {
				oViewMod.setProperty("/isVisible", true);
				oViewMod.setProperty("/PrintDB", true);
				oViewMod.setProperty("/FotterButton", true);
			} else if (length > 1) {
				oViewMod.setProperty("/FotterButton", true);
				oViewMod.setProperty("/PrintDB", false);
				oViewMod.setProperty("/isVisible", false);
			} else {
				oViewMod.setProperty("/isVisible", false);
				oViewMod.setProperty("/PrintDB", false);
				oViewMod.setProperty("/FotterButton", false);
			}

		},
		onPressNETbl: function(oEvent) {
			var oViewMod = this.getModel("IconTab");
			var length = oEvent.getSource().getSelectedIndices().length;
			if (length >= 1) {
				oViewMod.setProperty("/NavButtonEnabled", true);
			} else {
				oViewMod.setProperty("/NavButtonEnabled", false);
			}
		},
		MainTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isFilterBar", true);
			oViewMod.setProperty("/isMainTable", true);
			oViewMod.setProperty("/isOrderItem", false);
			oViewMod.setProperty("/isBillSummary", false);

			oViewMod.setProperty("/MainButtons", true);
			oViewMod.setProperty("/NarrativeButton", false);
			oViewMod.setProperty("/HeadEditButton", false);
			oViewMod.setProperty("/LineEditButton", false);
			oViewMod.setProperty("/LineEditTrnsferButton", false);
		},
		narrativeEditTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isFilterBar", false);
			oViewMod.setProperty("/MainButtons", false);
			oViewMod.setProperty("/NarrativeButton", true);
			oViewMod.setProperty("/HeadEditButton", false);
			oViewMod.setProperty("/LineEditButton", false);
			oViewMod.setProperty("/LineEditTrnsferButton", false);
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isOrderItem", true);
			oViewMod.setProperty("/isBillSummary", false);

			oViewMod.setProperty("/Narrative", true);
			oViewMod.setProperty("/LitemTransferT", false);
			oViewMod.setProperty("/LitemEdit", false);
			oViewMod.setProperty("/LitemTransfer", false);
			oViewMod.setProperty("/LitemEditTransfer", false);

		},
		lineItemEditTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isFilterBar", false);
			oViewMod.setProperty("/MainButtons", false);
			oViewMod.setProperty("/NarrativeButton", false);
			oViewMod.setProperty("/HeadEditButton", false);
			oViewMod.setProperty("/LineEditButton", true);
			oViewMod.setProperty("/LineEditTrnsferButton", false);
			oViewMod.setProperty("/Narrative", false);
			oViewMod.setProperty("/LitemEdit", true);
			oViewMod.setProperty("/LitemTransfer", true);
			oViewMod.setProperty("/LitemTransferT", true);
			oViewMod.setProperty("/LitemEditTransfer", true);
			// switch table visibiility an rebind table	
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isOrderItem", true);
			oViewMod.setProperty("/isBillSummary", false);

		},
		lineItemTransferTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isFilterBar", false);
			oViewMod.setProperty("/MainButtons", false);
			oViewMod.setProperty("/NarrativeButton", false);
			oViewMod.setProperty("/HeadEditButton", false);
			oViewMod.setProperty("/LineEditButton", false);
			oViewMod.setProperty("/LineEditTrnsferButton", true);

			oViewMod.setProperty("/Narrative", false);
			oViewMod.setProperty("/LitemEdit", true);
			oViewMod.setProperty("/LitemTransfer", false);
			oViewMod.setProperty("/LitemTransferT", false);
			oViewMod.setProperty("/LitemEditTransfer", true);

			// switch table visibiility an rebind table	
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isOrderItem", true);
			oViewMod.setProperty("/isBillSummary", false);
		},
		headerEditTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isFilterBar", false);
			oViewMod.setProperty("/MainButtons", false);
			// oViewMod.setProperty("/Narrative", false);
			oViewMod.setProperty("/NarrativeButton", false);
			oViewMod.setProperty("/HeadEditButton", true);
			oViewMod.setProperty("/LineEditButton", false);
			oViewMod.setProperty("/LineEditTrnsferButton", false);
		},
		billSummaryTabFields: function() {
			var oViewMod = this.getModel("IconTab");
			oViewMod.setProperty("/isMainTable", false);
			oViewMod.setProperty("/isFilterBar", false);
			oViewMod.setProperty("/isOrderItem", false);
			oViewMod.setProperty("/isBillSummary", true);
			oViewMod.setProperty("/isMainTable", false);

			oViewMod.setProperty("/MainButtons", false);
			oViewMod.setProperty("/NarrativeButton", false);
			oViewMod.setProperty("/HeadEditButton", false);
			oViewMod.setProperty("/LineEditButton", false);
			oViewMod.setProperty("/LineEditTrnsferButton", false);
		},
		setIconTab: function(evn) {
			var oIconTabBar = this.getView().byId("idIconTabBarNoIcons"),
				sKey = oIconTabBar.getSelectedKey();
			switch (sKey) {
				case "Main":
					this.MainTabFields();
					break;
				case "NarrativeEdit":

					this.reBindSecondTable("/OrderItemSet", "BillDetailSet", "idsmartTableNE");

					this.narrativeEditTabFields();

					break;
				case "LineItemEdit":
					this.lineItemEditTabFields();
					this.reBindSecondTable("/OrderItemSet", "BillDetailSet", "idsmartTableNE");

					break;
				case "LineItemTransfer":
					this.lineItemTransferTabFields();
					this.reBindSecondTable("/OrderItemSet", "BillDetailSet", "idsmartTableNE");
					break;
				case "HeaderEdit":
					this.headerEditTabFields();
					// this.reBindPrimaryTable("BillSummarySet");
					break;
				case "BillSummary":

					this.billSummaryTabFields();
					this.reBindBillSummaryTable("/PriceByMatnr", "PriceInfoByMatnrSet", "idsmartTableBS");
					this.BillSummaryform();
					break;

			}
		},

		BillSummaryform: function() {
			var otbl = this.getTable(),
				fTblContx = otbl.getContextByIndex(this.selIdx);
			/*var formid = this.getView().byId("BillSummaryFormId");
			formid.setBindingContext(fTblContx);*/
			this.getView().byId("billHeaderList").setBindingContext(fTblContx);
			this.getView().byId("billSmAmountList").setBindingContext(fTblContx);
		},
		reBindSecondTable: function(path, eSet, tableId) {
			var oTable = this.getView().byId(tableId),
				otbl = this.getTable(),
				fTblContx = otbl.getContextByIndex(this.selIdx),
				DBEdit = fTblContx.getProperty("BlockNarrative"),
				Iseditable = fTblContx.getProperty("Iseditable"),
				Pspid = fTblContx.getProperty("Pspid"),
				Posnr = fTblContx.getProperty("Posnr");
			// var DBEdit = fTblContx.getObject().BlockNarrative;
			if (Iseditable === "X") {
				//sap.m.MessageBox.show("Draft Bill is not Editable", sap.m.MessageBox.Icon.Alert, "Line Item Transfer");
			}
			var tbPath = fTblContx.getPath() + path;
			oTable.getEntitySet(eSet);
			oTable.setTableBindingPath(tbPath);
			oTable.rebindTable();
			this.getCodesSet(Pspid, Posnr);

		},
		reBindBillSummaryTable: function(path, eSet, tableId) {
			var oTable = this.getView().byId(tableId),
				otbl = this.getTable(),
				fTblContx = otbl.getContextByIndex(this.selIdx),
				PriceByMatnrPath = fTblContx.getPath() + path,
				tkPath = fTblContx.getPath() + "/HeaderToGroupInfo",
				oModel = this.getView().getModel(),
				that = this;

			var PriceByMatnrModel = new sap.ui.model.json.JSONModel();
			var iOriginalBusyDelay;

			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			oModel.read(PriceByMatnrPath, {
				success: function(data, response) {
					PriceByMatnrModel.setData(data);
					that.getView().setModel(PriceByMatnrModel, "PriceByMatnrModel");
					jQuery.sap.delayedCall(iOriginalBusyDelay, this, function() {
						oTable.setBusy(false);
					});
				},
				error: function(oError) {

					jQuery.sap.delayedCall(iOriginalBusyDelay, this, function() {
						oTable.setBusy(false);
					});
				}
			});
			var oTab = this.getView().byId("BillSummaryTKId");
			var HeaderToGroupInfoModel = new sap.ui.model.json.JSONModel();
			oModel.read(tkPath, {
				success: function(data, response) {
					HeaderToGroupInfoModel.setData(data);
					oTab.setModel(HeaderToGroupInfoModel, "HeaderToGroupInfoModel");
					jQuery.sap.delayedCall(iOriginalBusyDelay, this, function() {
						oTab.setBusy(false);
					});
				},
				error: function(oError) {

					jQuery.sap.delayedCall(iOriginalBusyDelay, this, function() {
						oTab.setBusy(false);
					});
				}
			});

		},
		/// method for  Task Code fileds 
		getCodesSet: function(Pspid, posnr) {
			// var ocor = sap.ui.getCore();
			// var datefrom = ocor.byId("Datefrom").getValue();
			// var odatetimefrom = datefrom + "T00:00:00";
			// var dateTo = ocor.byId("Dateto").getValue();
			// var odatetimeto = dateTo + "T00:00:00";

			var dateTo = new Date();
			// var odatetimeto = dateTo + "T00:00:00";
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "YYYY-MM-dd"
			});
			var dateFormatted = dateFormat.format(dateTo);
			var odatetimeto = dateFormatted + "T00:00:00";
			var actCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(actCodeJSONModel, "actCodeModel");
			var actCodeModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIPCODES_SRV/");
			actCodeModel.setUseBatch(true);
			// ActCodeModel  with filter Values of  Matter and Workdate	
			var actCodeFilter = [],
				batchrequest = [],
				callBacks = [];
			actCodeFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			actCodeFilter.push(new sap.ui.model.Filter("Workdate", sap.ui.model.FilterOperator.EQ, "2014-01-01T00:00:00"));
			var mParameters = {
				filters: actCodeFilter,
				error: function(oError) {
					// this.getTable().setBusy(false);
				}
			};
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				actCodeJSONModel.setData(oData);
				actCodeJSONModel.refresh();
			};

			//actCodeModel.read("/ActCodeSet", mParameters);
			callBacks["ActCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				actCodeJSONModel.setData(oData);
				actCodeJSONModel.refresh();
			};
			var entityType = actCodeModel.oMetadata._getEntityTypeByPath("/ActCodeSet"),
				readPath = "/ActCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(actCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// TaskCode model passing with Filter Value with PhaseCode.

			var taskCodeFilter = [];
			taskCodeFilter.push(new sap.ui.model.Filter("Phasecode", sap.ui.model.FilterOperator.EQ, ""));

			var taskCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(taskCodeJSONModel, "taskCodeModel");
			mParameters.filters = taskCodeFilter;
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				taskCodeJSONModel.setData(oData);
				taskCodeJSONModel.refresh();
			};

			//actCodeModel.read("/TaskCodeSet", mParameters);
			callBacks["TaskCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				taskCodeJSONModel.setData(oData);
				taskCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/TaskCodeSet");
			readPath = "/TaskCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(taskCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// FFTaskCode model with filter value with  matter

			var fftaskCodeFilter = [];
			fftaskCodeFilter.push(new sap.ui.model.Filter("Matter", sap.ui.model.FilterOperator.EQ, Pspid));

			var ffTaskCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(ffTaskCodeJSONModel, "fftaskCodeModel");
			mParameters.filters = fftaskCodeFilter;
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				ffTaskCodeJSONModel.setData(oData);
				ffTaskCodeJSONModel.refresh();
			};
			//actCodeModel.read("/FfTaskCodeSet", mParameters);
			callBacks["FfTaskCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				ffTaskCodeJSONModel.setData(oData);
				ffTaskCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/FfTaskCodeSet");
			readPath = "/FfTaskCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(fftaskCodeFilter, actCodeModel.oMetadata,
				entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// PhaseCode model with filter values with matter (Pspid) & workdate	
			var phaseCodeFilter = [];
			phaseCodeFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			phaseCodeFilter.push(new sap.ui.model.Filter("Workdate", sap.ui.model.FilterOperator.EQ, odatetimeto));
			var phaseCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(phaseCodeJSONModel, "phaseCodeModel");
			mParameters.filters = phaseCodeFilter;
			mParameters.success = function(oData, response) {
				phaseCodeJSONModel.setData(oData);
				phaseCodeJSONModel.refresh();
			};

			//actCodeModel.read("/PhaseCodeSet", mParameters);
			callBacks["PhaseCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				phaseCodeJSONModel.setData(oData);
				phaseCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/PhaseCodeSet");
			readPath = "/PhaseCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(phaseCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// make a batch call
			actCodeModel.addBatchReadOperations(batchrequest);
			actCodeModel.submitBatch(
				function(r) {
					var callEntity;
					$.each(r.__batchResponses, function(i, br) {
						if (br && br.data) {
							callEntity = br.data.__metadata.title;
							callBacks[callEntity](br.data);
						}
					});
				},
				function(e) {

				},
				true);
		},
		// Replace Words
		getReplaceModel: function() {
			var oReplaceModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_WIP_EDITOR_SRV/");
			var otbl = this.getTable(),
				fTblContx = otbl.getContextByIndex(this.selIdx),
				Pspid = fTblContx.getProperty("Pspid"),
				Kunnr = fTblContx.getProperty("Client");
			// var that = this;
			var replaceJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(replaceJSONModel, "replaceModel");
			var replaceFilter = [];
			replaceFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			replaceFilter.push(new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.EQ, Kunnr));
			var mParameters = {
				filters: replaceFilter,
				error: function(oError) {

				}
			};
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				replaceJSONModel.setData(oData);
				replaceJSONModel.refresh();
			};
			oReplaceModel.read("/ReplaceWordsSet", mParameters);

		},
		OnReplaceWord: function(evvt) {

			var sFrgmntName = "ReplaceWords";
			if (!this.replaceWordoDailog) {
				this.replaceWordoDailog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
				this.getView().addDependent(this.replaceWordoDailog);
			}
			this.replaceWordoDailog.open(this);
			this.getReplaceModel();

		},
		onReplaceSelected: function(evt) {
			var changeFrom = sap.ui.getCore().byId("ChangeFrom").getValue();
			var changeTo = sap.ui.getCore().byId("ChangeTo").getValue();
			var tbl = this.getView().byId("idsmartTableNE").getTable();
			//	var oNarrativeArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var narrative = context1.getPath() + "/Narrative";
				var obj = context1.getObject();
				var str = obj.Narrative;
				var finRep = str.replace(changeFrom, changeTo);
				var model = context1.getModel();
				model.setProperty(narrative, finRep);

			});
			this.onCancelDialog();

		},
		// save button
		OnSavePress: function(evt) {

			var tbl = this.getView().byId("idsmartTableNE").getTable();
			var oModel = this.getOwnerComponent().getModel();
			//	var oNarrativeArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var narrative = context1.getPath();
				var obj = context1.getObject();
				var str = obj.Narrative;
				var oEntry = {};
				oEntry.Narrative = str;
				oModel.update(narrative, oEntry, null, function() {
					MessageToast.show(" Narrative Update Successfully");
				}, function() {
					MessageToast.show(" Narrative Update UnSuccessfully");
				});
			});

		},
		onCancelDialog: function() {
			this.replaceWordoDailog.close();
		},

		OnUpdateCodeed: function(evt) {

			var fragPath = "bdeditor.fragments.updatecode";

			if (!this.updateCodeoDailog) {
				this.updateCodeoDailog = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.updateCodeoDailog);
			}
			this.updateCodeoDailog.openBy(evt.getSource());

		},
		closeDialogUp: function(oEvt) {
			this.updateCodeoDailog.close();
		},
		OnSplitTransfer: function(oEvt) {
			var tbl = this.getView().byId("idsmartTableNE").getTable(),
				aNavValues = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var osCtx = tbl.getContextByIndex(index);
				var obj = osCtx.getObject();
				aNavValues.push(obj);
			});
			this.getRouter().navTo("SplitWip", {
				Belnr: aNavValues[0].Belnr
			});
			var delayInvk = (function(av) {
				return function() {
					$.sap.require("sap.ui.core.EventBus");
					var oBus = sap.ui.getCore().getEventBus();
					oBus.publish("splitWip", "fromWipDetail", av);
				};
			})(aNavValues);
			jQuery.sap.delayedCall(1000, this, delayInvk);
		},
		OnMassTransfer: function(evt) {
			var tbl = this.getView().byId("idsmartTableNE").getTable();
			var aNavValues = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var osCtx = tbl.getContextByIndex(index);
				var obj = osCtx.getObject();
				aNavValues.push(obj);
			});
			this.getRouter().navTo("massTransfer", {
				Belnr: aNavValues[0].Belnr
			});
			var delayInvk = (function(av) {
				return function() {
					$.sap.require("sap.ui.core.EventBus");
					var oBus = sap.ui.getCore().getEventBus();
					oBus.publish("massTransfer", "fromWipDetail", av);
				};
			})(aNavValues);
			jQuery.sap.delayedCall(1000, this, delayInvk);

		},

		// 	reBindPrimaryTable: function(eSet) {

		// 		var otbl = this.getTable(),
		// 		fTblContx = otbl.getContextByIndex(this.selIdx);
		// 	var tbPath = fTblContx.getPath();
		// 	 otbl.getEntitySet(eSet);
		// 	 otbl.setTableBindingPath(tbPath);
		// 	otbl.rebindTable();
		// },

		// fragment selection screen F4 helps
		// Search Help For Billing Office
		handleValueHelpBillofc: function(oEvent) {

			var sFieldName1 = "Werks";
			var sFrgmntName = "billingofc";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._billofc.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchBilling: function(evt) {
			var sFieldName1 = "Werks";
			// var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				// var BillofcInput = this.getView().byId("idbillingOffice");
				this._billofc.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// Search Help For Billing Parnter
		handleValueHelpBillpart: function(oEvent) {

			var sFieldName1 = "Pernr";
			var sFrgmntName = "billingpartner";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._PartnerNum.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchpartner: function(evt) {
			var sFieldName1 = "Pernr";
			// var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelppartnerClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				// var BillofcInput = this.getView().byId("idbillingOffice");
				this._PartnerNum.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},

		// Search Help For Client
		handleValueHelpClient: function(oEvent) {
			var sFieldName1 = "Kunnr";
			var sFrgmntName = "clientf4";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._client.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchclient: function(evt) {
			//	var sFieldName1 = "Kunnr";
			var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		_handleValueHelpclientClose: function(evt) {
			var oView = this.getView();
			var oSelectedItems = evt.getParameters().selectedItems;
			var aFilter = [],
				len = oSelectedItems.length,
				i, j, ke, tok, count;
			var oMultiInputclient = sap.ui.getCore().byId("clientInputId");
			oMultiInputclient.destroyTokens();
			var oModel1Data = this.oModel1.getData();
			var oModelLen = oModel1Data.Clients.length;

			for (i = 0; i < len; i++) {
				count = 0;
				ke = oSelectedItems[i].getProperty("title");
				if (oModelLen === 0) {
					oModel1Data.Clients.push({
						ClientId: ke
					});
				} else {
					for (j = 0; j < oModelLen; j++) {
						if (ke === oModel1Data.Clients[j].ClientId) {
							count++;
						}
					}
					if (count === 0) {
						oModel1Data.Clients.push({
							ClientId: ke
						});
					}
				}
			}

			var that = this;
			that.aTokens = [];
			var arr1 = [],
				k,
				len1 = oModel1Data.Clients.length;

			if (oMultiInputclient.getTokens().length === 0) {

				for (k = 0; k < len1; k++) {
					that.aTokens.push(new sap.m.Token({
						text: oModel1Data.Clients[k].ClientId,
						key: oModel1Data.Clients[k].ClientId

					}));
				}

				oMultiInputclient.setTokens(that.aTokens);
			}
			this.oModel1.refresh();
			this._valueHelpDialog.destroy(); //since we r destroying this, we cant do remember selected items
		},

		// matter
		//	search Help For Matters
		handleValueHelpMatter: function(oEvent) {

			var sFieldName1 = "Pspid";
			var sFrgmntName = "matters";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);

			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						// var bMultiSelect = !!oEvent.getSource().data("multi");
						sap.ui.getCore().byId("idMatter").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchmatter: function(evt) {
			//	var sFieldName1 = "Kunnr";
			var sFieldName2 = "Post1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			evt.getSource().getBinding("items").filter(aFilter);
		},
		// _handleValueHelpmatterClose: function(evt) {
		// 	// var mat = this._mid;
		// 	var oSelectedItem = evt.getParameter("selectedItem");
		// 	if (oSelectedItem) {
		// 		// var matterInput = sap.ui.getCore().byId("idMatter");
		// 		this._mid.setValue(oSelectedItem.getTitle());
		// 	}
		// 	this._valueHelpDialog.destroy();
		// },
		handleValueHelpmatterClose: function(evt) {
			var oView = this.getView();
			var oSelectedItems = evt.getParameters().selectedItems;
			var aFilter = [],
				len = oSelectedItems.length,
				i, j, ke, tok, count;
			var oMultiInputMatter = sap.ui.getCore().byId("matterInputId");
			oMultiInputMatter.destroyTokens();
			var oModel1Data = this.oModel1.getData();
			var oModelLen = oModel1Data.Matters.length;

			for (i = 0; i < len; i++) {
				count = 0;
				ke = oSelectedItems[i].getProperty("title");
				if (oModelLen === 0) {
					oModel1Data.Matters.push({
						MatterId: ke
					});
				} else {
					for (j = 0; j < oModelLen; j++) {
						if (ke === oModel1Data.Matters[j].MatterId) {
							count++;
						}
					}
					if (count === 0) {
						oModel1Data.Matters.push({
							MatterId: ke
						});
					}
				}
			}

			var that = this;
			that.aTokens = [];
			var arr1 = [],
				k,
				len1 = oModel1Data.Matters.length;

			if (oMultiInputMatter.getTokens().length === 0) {

				for (k = 0; k < len1; k++) {
					that.aTokens.push(new sap.m.Token({
						text: oModel1Data.Matters[k].MatterId,
						key: oModel1Data.Matters[k].MatterId

					}));
				}

				oMultiInputMatter.setTokens(that.aTokens);
			}
			this.oModel1.refresh();
			this._valueHelpDialog.destroy(); //since we r destroying this, we cant do remember selected items

		},
		onTokenUpdate: function(evt) {
			var tokenChangetype = evt.getParameters().type;
			var oModel1Data = this.oModel1.getData();
			var arr = [];
			arr = oModel1Data.Matters;
			//arr = this.oModel1.getData().Matters;

			var i, len = oModel1Data.Matters.length;
			if (tokenChangetype === "removed") {
				var delToken = evt.getParameters().token.getText();

				for (i = 0; i < len; i++) {
					if (delToken === this.oModel1.getProperty("/Matters/" + i + "/MatterId")) {
						//            arr[i].pop();// wrong function
						arr.splice(i, 1); //arr.splice(index,int) int=no. of elements from the index

					}

				}
				oModel1Data.Matters = arr;
				this.oModel1.setData(oModel1Data);
				this.oModel1.refresh();

			}

		},

		// Search Help For Sales Org
		handleValueHelpsaleorg: function(oEvent) {

			var sFieldName1 = "Vkorg";
			var sFrgmntName = "salesorg";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._salesorg.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchsaleorg: function(evt) {
			var sFieldName1 = "Vkorg";
			// var sFieldName2 = "Name1";
			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelpsaleorgClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {

				this._salesorg.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// Search Help For Matter report Group
		handleValueHelpMreportGroup: function(oEvent) {

			var sFieldName1 = "Rptgroup";
			var sFrgmntName = "matterreportgroup";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._MRGroup.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchMreportGroup: function(evt) {
			var sFieldName1 = "Rptgroup";

			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelpMreportGroupClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {

				this._MRGroup.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},
		// Search Help For Group Bill Id
		handleValueHelpGroupbill: function(oEvent) {

			var sFieldName1 = "Zzgrpbill";
			var sFrgmntName = "groupbillid";
			var sInputValue = oEvent.getSource().getValue();
			this._valueHelpDialog = sap.ui.xmlfragment("bdeditor.fragments." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);

			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpDialog.getBinding("items").filter(aFilter);
			}
			this._valueHelpDialog.open(sInputValue);
			var that = this;
			if (oEvent.getSource().getValue())
				this._valueHelpDialog.attachConfirm(that, function(evt) {
					if (evt === "confirm") {
						this._gbillId.setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
						that._valueHelpDialog.destroy();
					}
				}, null);
		},
		handleValueHelpSearchGroupbill: function(evt) {
			var sFieldName1 = "Zzgrpbill";

			var sValue = evt.getParameter("value");
			var oFilter;
			var aFilter = [];
			if (sValue !== "") {

				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);

			}
			evt.getSource().getBinding("items").filter(aFilter);

		},
		_handleValueHelpGroupbillClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this._gbillId.setValue(oSelectedItem.getTitle());
			}
			this._valueHelpDialog.destroy();
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Vbeln", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {

			var oTable = this.getTable();
			this.resetTableSelection();
			// oTable.getBinding("rows").filter(this.aFilter);
			// oTable.refresh();
		},
		onRefreshNarrative: function() {
			var tbl = this.getView().byId("idsmartTableNE").getTable();
			this.resetTableSelectionNarrative();
			// tbl.refresh();
		},
		resetTableSelectionNarrative: function() {
			var tbl = this.getView().byId("idsmartTableNE").getTable();
			$.each(tbl.getSelectedIndices(), function(i, o) {
				// var idx = indices[i];
				//	tbl.isIndexSelected(idx);

				var ctx = tbl.getContextByIndex(i);
				//var ctx = tbl.getBinding("rows");
				var model = ctx.getModel();
				var isErrorPath = ctx.getPath() + "/IsError";
				model.setProperty(isErrorPath, "");
				var isMessagePath = ctx.getPath() + "/Message";
				model.setProperty(isMessagePath, "");
				// var isMessagePath = ctx.getPath() + "/Message";
				// model.setProperty(isMessagePath, "");
			});
			tbl.clearSelection();
		},
		resetTableSelection: function() {
			var tbl = this.getTable();
			var indices = tbl.getSelectedIndices();
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var idx = indices[i];
				//	tbl.isIndexSelected(idx);

				var ctx = tbl.getContextByIndex(idx);
				//var ctx = tbl.getBinding("rows");
				var model = ctx.getModel();
				var isErrorPath = ctx.getPath() + "/Iserror";
				model.setProperty(isErrorPath, "");
				var isMessagePath = ctx.getPath() + "/Message";
				model.setProperty(isMessagePath, "");
			});
			tbl.clearSelection();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Vbeln")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			var oTable = this.getTable();
			oTable.getBinding("rows").filter(oTableSearchState);
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				// oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});