/*global location */

sap.ui.define([
	"bdeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"bdeditor/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, History, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("bdeditor.controller.SplitWip", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getRouter().getRoute("SplitWip").attachPatternMatched(this._onObjectMatchedm, this);
			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.subscribe("splitWip", "fromWipDetail", this.fromWipDetail, this);
		},
		fromWipDetail: function(sChannelId, sEventId, oData) {
			var splitWipModel = new JSONModel({
					splitWip: oData
				}),
				oTable = this.getTable();
			oTable.setModel(splitWipModel);
			oTable.bindRows({
				path: "/splitWip"
			});
		},
		getTable: function() {
			return this.getView().byId("splitWipTbl");
		},
		_onObjectMatchedm: function(oEvent) {
		},

		OnsplitCancel: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
		OnSplit:function(oEvt){
			
		}
	});

});