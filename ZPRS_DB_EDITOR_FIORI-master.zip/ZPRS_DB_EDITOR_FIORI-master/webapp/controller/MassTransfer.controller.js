/*global location */

sap.ui.define([ 
	"bdeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"bdeditor/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, History, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("bdeditor.controller.MassTransfer", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getRouter().getRoute("massTransfer").attachPatternMatched(this._onObjectMatchedm, this);
			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.subscribe("massTransfer", "fromWipDetail", this.fromWipDetail, this);
		},
		fromWipDetail:function(sChannelId, sEventId, oData) {
			var mtModel = new JSONModel({massTransfer:oData}),oTable = this.getTable();
			oTable.setModel(mtModel);
			oTable.bindRows({
				path: "/massTransfer"
			});
		},
		getTable:function(){
			return this.getView().byId("splitWipTbl");
		},
	

		_onObjectMatchedm: function(oEvent) {
			
 var a;
		
		},
	

	
		OnMassTransferBack: function() {
		var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		
		// _bindView: function(sObjectPath) {
		// 	var oViewModel = this.getModel("detailView"),
		// 		oDataModel = this.getModel();

		// 	this.getView().bindElement({
		// 		path: sObjectPath,
		// 		events: {
		// 			change: this._onBindingChange.bind(this),
		// 			dataRequested: function() {
		// 				oDataModel.metadataLoaded().then(function() {
		// 					// Busy indicator on view should only be set if metadata is loaded,
		// 					// otherwise there may be two busy indications next to each other on the
		// 					// screen. This happens because route matched handler already calls '_bindView'
		// 					// while metadata is loaded.
		// 					oViewModel.setProperty("/busy", true);
		// 				});
		// 			},
		// 			dataReceived: function() {
		// 				oViewModel.setProperty("/busy", false);
		// 			}
		// 		}
		// 	});
		// },

		// _onBindingChange: function() {
		// 	var oView = this.getView(),
		// 		oViewModel = this.getModel("detailView"),
		// 		oElementBinding = oView.getElementBinding();

		// 	// No data for the binding
		// 	if (!oElementBinding.getBoundContext()) {
		// 		this.getRouter().getTargets().display("objectNotFound");
		// 		return;
		// 	}

		// 	var oResourceBundle = this.getResourceBundle(),
		// 		oObject = oView.getBindingContext().getObject(),
		// 		sObjectId = oObject.Pspid,
		// 		sObjectName = oObject.Pspid;

		// 	// Everything went fine.
		// 	oViewModel.setProperty("/busy", false);
		// 	oViewModel.setProperty("/shareSendEmailSubject",
		// 		oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		// 	oViewModel.setProperty("/shareSendEmailMessage",
		// 		oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		// }

	});

});