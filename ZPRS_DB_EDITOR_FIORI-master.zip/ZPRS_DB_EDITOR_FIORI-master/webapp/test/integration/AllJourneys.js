jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"bdeditor/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"bdeditor/test/integration/pages/Worklist",
		"bdeditor/test/integration/pages/Object",
		"bdeditor/test/integration/pages/NotFound",
		"bdeditor/test/integration/pages/Browser",
		"bdeditor/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "bdeditor.view."
	});

	sap.ui.require([
		"bdeditor/test/integration/WorklistJourney",
		"bdeditor/test/integration/ObjectJourney",
		"bdeditor/test/integration/NavigationJourney",
		"bdeditor/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});
