jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"cmiamendment/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"cmiamendment/test/integration/pages/Worklist",
		"cmiamendment/test/integration/pages/Object",
		"cmiamendment/test/integration/pages/NotFound",
		"cmiamendment/test/integration/pages/Browser",
		"cmiamendment/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cmiamendment.view."
	});

	sap.ui.require([
		"cmiamendment/test/integration/WorklistJourney",
		"cmiamendment/test/integration/ObjectJourney",
		"cmiamendment/test/integration/NavigationJourney",
		"cmiamendment/test/integration/NotFoundJourney",
		"cmiamendment/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});