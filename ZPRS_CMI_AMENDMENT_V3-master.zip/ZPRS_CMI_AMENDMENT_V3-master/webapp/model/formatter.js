jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		isClientEditable: function(e, r) {
			if (e === "X" && r !== "MA") {
				return true;
			}
			return false;
		},
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		myBooleanV: function(sValue) {
			if (sValue) {
				return true;
			} else {
				return false;
			}
		},
		checkTeamButton: function(sValue) {
			if (sValue === "ZL" || sValue === "ZR") {
				return false;
			} else {
				return true;
			}
		},
		editRequestScreen: function(sValue) {
			if (sValue) {
				return true;
			}
			return false;
		},
		isExtSubmitEnabled: function(step, bEdit) {
			if (step === 4 && bEdit) {
				return true;
			}
			return false;
		},
		isSubmitEnabledMA: function(step, bEdit) {
			if (step === 4 && bEdit) {
				return true;
			}
			return false;
		},
		isSubmitEnabledCA: function(step, bEdit) {
			if (step === 3 && bEdit) {
				return true;
			}
			return false;
		},
		isSubmitTermsEnabled: function(status, bEdit) {
			if (!status && bEdit) {
				return true;
			}
			return false;
		},
		isDeleteTermsEnabled: function(status, bEdit) {
			if (($.isEmptyObject(status) || status === "Rejected") && bEdit) {
				return true;
			}
			return false;
		},
		singleDates: function(oDate, oTime) {
			var oDateFormat;
			oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
				pattern: "dd.MM.YYYY"
			});
			var TimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "hh:mm:ss"
			});
			if (oDate !== null) {
				var dateTime = "";
				if (typeof(oDate) === "object") {
					var date = oDateFormat.format(oDate);
					var time = TimeFormat.format(oDate);
					dateTime = date + " " + time;
					return dateTime;
				} else if (typeof(oDate) === "string") {
					if (oDate !== "") {
						var year = oDate.substring(0, 4);
						var month = oDate.substring(4, 6);
						var day = oDate.substring(6, 8);
						var hr = oDate.substring(8, 10);
						var mn = oDate.substring(10, 12);
						var s = oDate.substring(12, 14);
						var sDate = new Date(year, month - 1, day, hr, mn, s);
						var sFDate = oDateFormat.format(sDate);
						var sFTime = TimeFormat.format(sDate);
						dateTime = sFDate + " " + sFTime;
						return dateTime;
					}
					return dateTime;
				} else {
					return dateTime;
				}
			} else {
				return oDate;
			}
		}
	};

});