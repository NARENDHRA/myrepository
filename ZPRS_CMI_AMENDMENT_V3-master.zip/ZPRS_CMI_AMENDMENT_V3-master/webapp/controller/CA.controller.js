sap.ui.define([
	"cmiamendmentnew/controller/RequestBaseController"
], function(RequestBaseController) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView;
	return RequestBaseController.extend("cmiamendmentnew.controller.CA", {
		onInit: function() {
			var oc = this.getOwnerComponent();
			oc.getRouter().getRoute("CA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("CmiReviewCA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReqCA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReviewCA").attachPatternMatched(this._onObjectMatched, this);
			this._createGeneralSettingsModel();
		},
		onAfterRendering: function() {
			oDynamicSideView = this.getView().byId("CADynamicSideContent");
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			jQuery.sap.delayedCall(2000, this, function() {
				var idSmartGroup = this.byId("cmiamendmentnew.client.clientInternationalVersionInput_");
				idSmartGroup.setEditMode(false);
				var footerHeight = window.innerHeight - this.byId("idFooterCA").getDomRef().getBoundingClientRect().top,
					tablePositionTop = this.byId("CAwizard").getDomRef().getBoundingClientRect().top,
					scrollHeight = window.innerHeight - tablePositionTop - footerHeight - 0;
				this.byId("CAwizard").setHeight(String(scrollHeight + "px"));
				this._attachChangeEventAllFields();
				this.fileattachmentFilter(this.byId("CD").getContent()[0], "CD");
			}.bind(this));
		},
		handleSteps: function(oEvt) {
			var oGeneralModel = this.getModel("generalSettings");
			oGeneralModel.setProperty("/currentStep", oEvt.getParameter("index"));

			if (oEvt.getParameter("index") === 2) {
				var idSmartGroup = this.byId("cmiamendmentnew.client.section_header_Address3");
				idSmartGroup.setEditMode(false);
				this.onSaveClientAmendment();
			}
		},
		handleSideContentPress: function(oEvent) {
			var i18n = this.getResourceBundle(),
				docBtn = this.getView().byId("btnSideCtntDoc"),
				defaultTab = oEvent.getSource().data("defTab"),
				cmntBtn = this.getView().byId("btnSideCtntCmnt");
			this.getView().byId("idAttachment").setSelectedKey(defaultTab);
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					docBtn.setVisible(false);
					cmntBtn.setIcon("sap-icon://hide");
					cmntBtn.setTooltip(i18n.getText("Hide"));
					if (defaultTab === "CD") {
						this.onDocumentClick();
					}
				} else {
					docBtn.setVisible(true);
					cmntBtn.setIcon("sap-icon://post");
					cmntBtn.setTooltip(i18n.getText("ShowCommets_BTN_TXT"));
				}
			}
		},
		isNewCmi: function(args) {
			var oModel = this.getOwnerComponent().getModel("readCmi");
			this.getModel("generalSettings").setProperty("/Cmino", args.Cmino);
			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: args.Cmino,
					Matterk: "",
					Clientk: args.Key,
					Cmirequesttype: "CA"
				});
				oModel.read("/" + sObjectPath, {
					success: function(resp) {
						this._bindView("/" + sObjectPath, args);

					}.bind(this),
					error: function(resp) {
						var oModelC = this.getOwnerComponent().getModel();
						sObjectPath = oModelC.createKey("Cmihdrs", {
							Cmino: "",
							Matterk: "",
							Clientk: args.Key,
							Cmirequesttype: "CA"
						});

						this._bindView("/" + sObjectPath, args);

					}.bind(this)
				});
			}.bind(this));
		},
		_onObjectMatched: function(oEvent) {
			var args = oEvent.getParameter("arguments");
			this.args = args;
			this.isNewCmi(args);
		},
		_bindView: function(sObjectPath) {
			//var oModel = this.getOwnerComponent().getModel();
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						this.getView().setBusy(true);
					}.bind(this),
					dataReceived: function(data) {
						this.getView().setBusy(false);
						var gsettingModel = this.getView().getModel("generalSettings");
						if (gsettingModel) {
							gsettingModel.setProperty("/Edit", data.getParameter("data").Edit);
						}
					}.bind(this)
				}
			});
		},
		onSaveClientAmendment: function(oEvt) {
			var oModel = this.getOwnerComponent().getModel("createAmend");
			var oClientCtx = this.getBindingContextbyId("idClientDetails");
			if (oClientCtx && oClientCtx.getObject().Cmino !== this.args.Cmino) {
				oModel.createEntry("/Cmihdrs", {
					properties: {
						Cmino: this.args.Cmino,
						Clientk: this.args.Key,
						Cmirequesttype: "CA"
					}
				});
				if (oClientCtx) {
					var oClient = $.extend({}, oClientCtx.getObject(), true);
					delete oClient.__metadata;
					oClient.Cmino = this.args.Cmino;
					oModel.createEntry("/Cmiclients", {
						properties: oClient
					});
				}
				var oClientdetailCtx = this.getBindingContextbyId("cmiamendmentnew.client.CmiClientGeneralData");
				if (oClientdetailCtx) {
					var oClientdetail = $.extend({}, oClientdetailCtx.getObject(), true);
					delete oClientdetail.__metadata;
					oClientdetail.Cmino = this.args.Cmino;
					oModel.createEntry("/Cmiclientdetails", {
						properties: oClientdetail
					});
				}
				var Clientcontacts = this.getView().byId("cmiamendmentnew.idClientContact.table_");
				if (Clientcontacts) {
					$.each(Clientcontacts.getItems(), function(ci, contact) {
						var oContext = contact.getBindingContext();
						var oContact = $.extend({}, oContext.getObject(), true);
						delete oContact.__metadata;
						oContact.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmiclntcontacts", {
							properties: oContact
						});
					}.bind(this));
				}

				var Clientpartner = this.getView().byId("cmiamendmentnew.clientPartner.table_");
				if (Clientpartner) {
					$.each(Clientpartner.getItems(), function(ci, partner) {
						var oContext = partner.getBindingContext();
						var oPartner = $.extend({}, oContext.getObject(), true);
						delete oPartner.__metadata;
						oPartner.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmileadpartners", {
							properties: oPartner
						});
					}.bind(this));
				}
				// var ocgs = this.getView().byId("UploadCollection");
				// $.each(ocgs.getItems(), function(ocgi, ocg) {
				// 		var oContext = ocg.getBindingContext();
				// 		var oOcg = $.extend({}, oContext.getObject(), true);
				// 		delete oOcg.__metadata;
				// 		oOcg.Cmino = this.args.Cmino;
				// 		oModel.createEntry("/Cmiocgs", {
				// 			properties: oOcg
				// 		});
				// 	}.bind(this));
				oModel.submitChanges({
					success: function(res) {
						this.getOwnerComponent().getModel().resetChanges();
						oModel = this.getOwnerComponent().getModel();
						var cmiNo = res.__batchResponses[0].__changeResponses[1].data.Cmino;
						var ClnNo = res.__batchResponses[0].__changeResponses[1].data.Clientk;
						var sObjectPath = oModel.createKey("Cmihdrs", {
							Cmino: cmiNo,
							Matterk: "",
							Clientk: ClnNo,
							Cmirequesttype: "CA"
						});

						this._bindView("/" + sObjectPath);
					}.bind(this),
					error: function(res) {

					}.bind(this)
				});
			} else {
				oModel = this.getOwnerComponent().getModel();
				oModel.submitChanges({
					success: function(res) {

					}.bind(this),
					error: function(res) {

					}.bind(this)
				});
			}
		}
	});

});