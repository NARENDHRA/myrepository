sap.ui.define([
		"cmiamendmentnew/controller/BaseController",
		"sap/ui/model/json/JSONModel"
	], function (BaseController, JSONModel) {
		"use strict";

		return BaseController.extend("cmiamendmentnew.controller.App", {

			onInit : function () {
				var oViewModel,
					fnSetAppNotBusy,
					oDataModel = this.getOwnerComponent().getModel(),
					iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

				oViewModel = new JSONModel({
					busy : true,
					delay : 0
				});
				this.setModel(oViewModel, "appView");
                oDataModel.setDefaultBindingMode("TwoWay");
				fnSetAppNotBusy = function() {
					var sMode = oDataModel.getDefaultBindingMode();
					oViewModel.setProperty("/busy", false);
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				};

				this.getOwnerComponent().getModel().metadataLoaded().
					then(fnSetAppNotBusy);

				// apply content density mode to root view
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
		});

	}
);