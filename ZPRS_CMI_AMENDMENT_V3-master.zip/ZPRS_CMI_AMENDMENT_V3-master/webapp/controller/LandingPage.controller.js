sap.ui.define([
	"cmiamendmentnew/controller/RequestBaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"cmiamendmentnew/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"cmiamendmentnew/model/JsonData"
], function(RequestBaseController, JSONModel, History, formatter, Filter, FilterOperator, JsonData) {
	"use strict";
	return RequestBaseController.extend("cmiamendmentnew.controller.LandingPage", {
		// change this function origninal once back services are stablized
		onPressSubmit_continueworking: function(oEvent) {
			this._AmendmentRequestPopup.close();
			// this.getRouter().navTo("CA", {
			// 	Cmino: "1000000053"
			// }, true);
		},
		formatter: formatter,
		JsonData: JsonData,
		onInit: function() {
			// var oc = this.getOwnerComponent(),
			var oViewData, oViewSettingsModel;
			oViewData = this.JsonData._initialJSON();
			oViewSettingsModel = new sap.ui.model.json.JSONModel(oViewData);
			this.getView().setModel(oViewSettingsModel, "generalSettings");
			// oc.getRouter().getRoute("LandingPage").attachPatternMatched(this._onObjectMatched, this);
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.attachRoutePatternMatched(this._onObjectMatched1, this);
		},
		_onObjectMatched1: function(oEvent) {
			var oParameters = oEvent.getParameters();
			if (oParameters.name !== "AmendmentReq" && oParameters.name !== "LandingPage") {
				return;
			}
			if (oParameters.name === "AmendmentReq") {
				this.showAmendmentRequestPopup(oParameters.arguments);
			} else {
				this.showAmendmentRequestPopup();
			}
			// this.showAmendmentRequestPopup();
		},
		_onObjectMatched: function(oEvent) {

			this.showAmendmentRequestPopup();
		},
		showAmendmentRequestPopup: function(oEvent) {
			if (!this._AmendmentRequestPopup) {
				this._AmendmentRequestPopup = sap.ui.xmlfragment(this.getView().getId(), "cmiamendmentnew.fragment.AmendmentRequest", this);
				this.getView().addDependent(this._AmendmentRequestPopup);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._AmendmentRequestPopup);
			var oViewModel = this.getView().getModel("generalSettings");
			if (!oEvent) {
				var oClientList = this.byId("cmiamendment.idClientList");
				this.getOwnerComponent().getModel().metadataLoaded().then(function() {
					this.cmiHdrs = this._createContexts("/Cmihdrs", {
						Cmino: "$000000001"
					});
					var oContextClient = this._createContexts("/Cmiclients", {});
					oClientList.setBindingContext(oContextClient);
					this._AmendmentRequestPopup.open();
				}.bind(this));
			} else {
				if (oEvent.Request === "CA") {
					oViewModel.setProperty("/bclientVisibility", true);
					oViewModel.setProperty("/bmatterVisibility", false);
					oViewModel.setProperty("/bMatterRBtn", false);
					oViewModel.setProperty("/bclientRBtn", true);
					this._createorDeleteContext(oEvent.Request);
				} else if (oEvent.Request === "MA") {
					oViewModel.setProperty("/bmatterVisibility", true);
					oViewModel.setProperty("/bclientVisibility", false);
					oViewModel.setProperty("/bMatterRBtn", true);
					oViewModel.setProperty("/bclientRBtn", false);

					this._createorDeleteContext(oEvent.Request);
				}
				oViewModel.setProperty("/oClientObj/Cmirequesttype", oEvent.Request);
				this._AmendmentRequestPopup.open();
			}

		},
		onSelect: function(oEvent) {
			var oViewModel = this.getView().getModel("generalSettings"),
				sSelectedText = oEvent.getSource().data("selection");
			oViewModel.setProperty("/oClientObj/Cmirequesttype", sSelectedText);
			if (sSelectedText === "CA" && oEvent.getParameter("selected")) {
				oViewModel.setProperty("/bclientVisibility", true);
				oViewModel.setProperty("/bmatterVisibility", false);
				this._createorDeleteContext(sSelectedText);
				} else if (sSelectedText === "MA" && oEvent.getParameter("selected")) {
				oViewModel.setProperty("/bmatterVisibility", true);
				oViewModel.setProperty("/bclientVisibility", false);
				this._createorDeleteContext(sSelectedText);
			}
			oViewModel.setProperty("/bSubBtnVisibility", false);
		},
		_createorDeleteContext: function(sSelected) {
			var sId = (sSelected === "CA") ? "cmiamendment.idClientList" : "cmiamendment.idMatterList";
			var sContext = (sSelected === "CA") ? "Cmiclients" : "Cmimatters";
			var sdeleteId = (sSelected === "CA") ? "cmiamendment.idMatterList" : "cmiamendment.idClientList";
			var oControl = this.byId(sId);
			var oContext = this._createContexts("/" + sContext, {});
			oControl.setBindingContext(oContext);
			this._deleteContexts(this.getBindingContextbyId(sdeleteId));
		},
		onPressSubmit: function(oEvent) {
			this._AmendmentRequestPopup.close();
			var key,
				oGeneral = this.getModel("generalSettings"),
				sReqType = oGeneral.getProperty("/oClientObj/Cmirequesttype");
			if (sReqType === "CA") {
				var oClient = this.getBindingContextbyId("cmiamendment.idClientList").getObject();
				key = oClient.Clientk;
			} else {
				var oMatter = this.getBindingContextbyId("cmiamendment.idMatterList").getObject();
				key = oMatter.Matter;
			}
			this.getCmiNumber(key, sReqType);
			//this.getMatterdetailtoAmend(key, sReqType);
		},
		onClientChange: function(oEvt){
			var oGeneral = this.getModel("generalSettings"),
			val = oEvt.getParameters().value;
			if(val){
				oGeneral.setProperty("/bSubBtnVisibility", true);
			}
		},
			onMatterChange: function(oEvt){
			var oGeneral = this.getModel("generalSettings"),
			val = oEvt.getParameters().value;
			if(val){
				oGeneral.setProperty("/bSubBtnVisibility", true);
			}
		},
		getCmiNumber: function(key, sReqType) {
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/Cminumber", {
				success: function(resp) {
					oModel.resetChanges();
					this.getRouter().navTo(sReqType, {
						Cmino: resp.results[0].Cmino,
						Key: key
					}, true);
				}.bind(this),
				error: function(resp) {

				}
			});
		},
		submitChanges: function(sReqType) {
			var oModel = this.getOwnerComponent().getModel();
			oModel.submitChanges({
				success: function(res) {
					var cmiNo = res.__batchResponses[0].__changeResponses[1].data.Cmino;
					var MtrNo = res.__batchResponses[0].__changeResponses[1].data.Matterk;
					var ClnNo = res.__batchResponses[0].__changeResponses[1].data.Clientk;
					this.getRouter().navTo(sReqType, {
						Cmino: cmiNo,
						Key: sReqType === "CA" ? ClnNo : MtrNo
					}, true);

				}.bind(this),
				error: function(res) {
					// delete or reset pending changes: discuss with BG

				}
			});
		},
		getMatterdetailtoAmend: function(key, sReqType) {
			var oModel = this.getOwnerComponent().getModel(),
				clientdetails = {
					Clients: "Cmiclient",
					Clientdetails: "Cmiclientdetails",
					Clientcontacts: "Cmiclntcontacts",
					Leadpartners: "Cmileadpartners",
					Ocgs: "Cmiocgs",
					//Matters: "Cmimatter",
					//Matterdetails: "Cmimatterdetails",
					//Knownparties: "Cmiknownparty",
					//Altpayers: "Cmialtpayer",
					//ConsiderationsN: "CmiconsiderationsN",
					Comments: "Cmicomments",
					Documents: "Cmidocuments"
				},
				clientAmend = "Clients,Clientdetails,Clientcontacts,Leadpartners,Ocgs,Comments,Documents",
				matterAmend = "Matters,Matterdetails,Knownparties,Altpayers,Comments,Documents",
				expandParam = sReqType === "MA" ? matterAmend : clientAmend,
				urlParams = {
					"$expand": expandParam
				};
			var sObjectPath = oModel.createKey("Cmihdrs", {
				Cmino: "",
				Matterk: sReqType === "MA" ? key : "",
				Clientk: sReqType === "CA" ? key : "",
				Cmirequesttype: "CA"
			});
			oModel.read("/" + sObjectPath, {
				urlParameters: urlParams,
				success: function(resp) {
					var oContext;
					this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Clientk", sReqType === "CA" ? key : "");
					this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Matterk", sReqType === "MA" ? key : "");
					this.cmiHdrs.getModel().setProperty(this.cmiHdrs.getPath() + "/Cmirequesttype", sReqType);

					$.each(clientdetails, function(i, obj) {
						if (resp[i].hasOwnProperty("results") && $.isArray(resp[i]["results"])) {
							$.each(resp[i].results, function(ii, aObject) {
								delete aObject.__metadata;
								aObject.Cmino = "$000000001";
								oContext = this._createContexts("/" + obj,
									$.extend({}, aObject, true)
								);
							}.bind(this));
						} else {
							delete resp[i].__metadata;
							resp[i].Cmino = "$000000001";
							oContext = this._createContexts("/" + obj,
								$.extend({}, resp[i], true)
							);
						}
					}.bind(this));
					this.submitChanges(sReqType);
				}.bind(this),
				error: function(resp) {

				}
			});
		},
		onCloseDialog: function(oEvent) {
			this._AmendmentRequestPopup.close();
			if (!oEvent.getParameter("origin")) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.backToPreviousApp();
			}
		},
		_navigateToPage: function() {
			var bClient = this.getModel("generalSettings").getProperty("/bclientVisibility");
			var sView = bClient ? "CA" : "MA";
			this.getRouter().navTo(sView, true);
		}

	});
});