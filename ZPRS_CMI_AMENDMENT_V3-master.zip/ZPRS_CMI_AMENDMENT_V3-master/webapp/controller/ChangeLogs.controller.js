sap.ui.define([
	"cmiamendmentnew/controller/RequestBaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("cmiamendmentnew.controller.ChangeLogs", {

		onInit: function(evt) {
			var oc = this.getOwnerComponent();
			oc.getRouter().getRoute("ChangeLogs").attachPatternMatched(this._onObjectMatched, this);
		},
		_createContextPath: function(m, urlParam) {
			var tableLog = this.getView().byId("TableChangeLog");
			var sObjectPath = m.createKey("Cmihdrs", {
				Cmino: urlParam.Cmino,
				Cmirequesttype: '',
				Clientk: '',
				Matterk: ''
			});
			
			tableLog.bindContext("items").setProperty("tableBindingPath", "/" + sObjectPath + "/Changelog");
			tableLog.rebindTable(true);
		},
		_onObjectMatched: function(evt) {
			var m = this.getOwnerComponent().getModel();
			var urlParam = evt.getParameter("arguments");

			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				this._createContextPath(m, urlParam);
			}.bind(this));

			/*	this.getView().bindElement({
					path: "/" + sObjectPath,
					events: {
						dataRequested: function() {},
						dataReceived: function(data) {}
					}
				});*/

		},
		onBeforeBindLogData: function(evt) {
			//	evt.getSource().bindContext("items").bindContext("items").setProperty("tableBindingPath",this.logBindingPath);
		}

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf cmiamendmentnew.view.ChangeLogs
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf cmiamendmentnew.view.ChangeLogs
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf cmiamendmentnew.view.ChangeLogs
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf cmiamendmentnew.view.ChangeLogs
		 */
		//	onExit: function() {
		//
		//	}

	});

});