sap.ui.define([
	"cmiamendmentnew/controller/RequestBaseController",
	"cmiamendmentnew/model/JsonData",
	"cmiamendmentnew/model/formatter"
	//	"fgt/cmi/lib/controller/BaseController"
], function(RequestBaseController, JsonData, formatter) {
	"use strict";
	var sCurrentBreakpoint, oDynamicSideView;
	return RequestBaseController.extend("cmiamendmentnew.controller.MA", {
		JsonData: JsonData,
		formatter: formatter,
		onInit: function() {
			var oc = this.getOwnerComponent();
			oc.getRouter().getRoute("MA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("CmiReviewMA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReqMA").attachPatternMatched(this._onObjectMatched, this);
			oc.getRouter().getRoute("MyInboxReviewMA").attachPatternMatched(this._onObjectMatched, this);
			this._createGeneralSettingsModel();
		},
		onAfterRendering: function() {
			oDynamicSideView = this.getView().byId("MADynamicSideContent");
			sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			jQuery.sap.delayedCall(2000, this, function() {
				var footerHeight = window.innerHeight - this.byId("idFooterMA").getDomRef().getBoundingClientRect().top,
					tablePositionTop = this.byId("MAWizard").getDomRef().getBoundingClientRect().top,
					scrollHeight = window.innerHeight - tablePositionTop - footerHeight - 0;
				this.byId("MAWizard").setHeight(String(scrollHeight + "px"));
				this._attachChangeEventAllFields();
				this.fileattachmentFilter(this.byId("MD").getContent()[0], "MD");
			}.bind(this));
		},
		handleSteps: function(oEvt) {
			var oGeneralModel = this.getModel("generalSettings");
			oGeneralModel.setProperty("/currentStep", oEvt.getParameter("index"));
			if (oEvt.getParameter("index") === 2) {
				this.onSaveClientAmendment();
			}
			if (oEvt.getParameter("index") === 4) {
				//	this.getConsiderations();
				return;
			}

		},
		handleSideContentPress: function(oEvent) {
			var i18n = this.getResourceBundle(),
				docBtn = this.getView().byId("btnSideCtntDoc"),
				defaultTab = oEvent.getSource().data("defTab"),
				cmntBtn = this.getView().byId("btnSideCtntCmnt");
			this.getView().byId("idAttachment").setSelectedKey(defaultTab);
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(!oDynamicSideView.getShowSideContent());
				if (oDynamicSideView.getShowSideContent()) {
					docBtn.setVisible(false);
					cmntBtn.setIcon("sap-icon://hide");
					cmntBtn.setTooltip(i18n.getText("Hide"));
					if (defaultTab === "MD") {
						this.onDocumentClick();
					}
				} else {
					docBtn.setVisible(true);
					cmntBtn.setIcon("sap-icon://post");
					cmntBtn.setTooltip(i18n.getText("ShowCommets_BTN_TXT"));
				}
			}
		},
		isNewCmi: function(args) {
			this.getModel("generalSettings").setProperty("/Cmino", args.Cmino);
			var oModel = this.getOwnerComponent().getModel("readCmi");
			oModel.metadataLoaded().then(function() {
				var sObjectPath = oModel.createKey("Cmihdrs", {
					Cmino: args.Cmino,
					Matterk: args.Key,
					Clientk: "",
					Cmirequesttype: "MA"
				});
				oModel.read("/" + sObjectPath, {
					success: function(resp) {
						this._bindView("/" + sObjectPath, args);

					}.bind(this),
					error: function(resp) {
						var oModelC = this.getOwnerComponent().getModel();
						sObjectPath = oModelC.createKey("Cmihdrs", {
							Cmino: "",
							Matterk: args.Key,
							Clientk: "",
							Cmirequesttype: "MA"
						});
						this._bindView("/" + sObjectPath, args);

					}.bind(this)
				});
			}.bind(this));
		},
		_onObjectMatched: function(oEvent) {
			var args = oEvent.getParameter("arguments");
			this.args = args;
			var name = oEvent.getParameter("name");
			if (name !== "MA") {
				this.getModel("generalSettings").setProperty("/LogState", true);
			}
			this.isNewCmi(args);
		},
		_bindView: function(sObjectPath) {
			//var oModel = this.getOwnerComponent().getModel();
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					dataRequested: function() {
						this.getView().setBusy(true);
					}.bind(this),
					dataReceived: function(data) {
						this.getView().setBusy(false);
						var gsettingModel = this.getView().getModel("generalSettings");
						if (gsettingModel) {
							gsettingModel.setProperty("/Cmirequesttype", data.getParameter("data").Cmirequesttype);
							gsettingModel.setProperty("/Edit", data.getParameter("data").Edit);
						}
						this.getConsiderations();
					}.bind(this)
				}
			});
		},
		onSaveClientAmendment: function(oEvt) {
			var oModel = this.getOwnerComponent().getModel("createAmend");
			var oMattersctx = this.getBindingContextbyId("cmiamendmentnew.matter.matterDetails.general");
			if (oMattersctx && oMattersctx.getObject().Cmino !== this.args.Cmino) {
				var oClientCtx = this.getBindingContextbyId("idClientDetails");
				oModel.createEntry("/Cmihdrs", {
					properties: {
						Cmino: this.args.Cmino,
						Matterk: this.args.Key,
						Cmirequesttype: "MA",
						Clientk: oClientCtx.getObject().Clientk
					}
				});
				// var oClient = $.extend({}, oClientCtx.getObject(), true);
				// delete oClient.__metadata;
				// oClient.Cmino = this.args.Cmino;
				// oModel.createEntry("/Cmiclients", {
				// 	properties: oClient
				// });

				if (oMattersctx) {
					var oMatter = $.extend({}, oMattersctx.getObject(), true);
					delete oMatter.__metadata;
					oMatter.Cmino = this.args.Cmino;
					oModel.createEntry("/Cmimatters", {
						properties: oMatter
					});
				}
				var oMatterdetailsctx = this.getBindingContextbyId("cmiamendmentnew.matter.Cmimatterdetails");
				if (oMatterdetailsctx) {
					var oMatterdetail = $.extend({}, oMatterdetailsctx.getObject(), true);
					delete oMatterdetail.__metadata;
					oMatterdetail.Cmino = this.args.Cmino;
					oModel.createEntry("/Cmimatterdetails", {
						properties: oMatterdetail
					});
				}
				var KnownParty = this.getView().byId("idKnownParty");
				if (KnownParty) {
					$.each(KnownParty.getItems(), function(ci, kp) {
						var oContext = kp.getBindingContext();
						var okp = $.extend({}, oContext.getObject(), true);
						delete okp.__metadata;
						okp.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmiknownparties", {
							properties: okp
						});
					}.bind(this));
				}
				var BillingFinance = this.getView().byId("cmiamendmentnew.matter.billindFinance.table_");
				if (BillingFinance) {
					$.each(BillingFinance.getItems(), function(ci, bf) {
						var oContext = bf.getBindingContext();
						var obf = $.extend({}, oContext.getObject(), true);
						delete obf.__metadata;
						obf.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmialtpayers", {
							properties: obf
						});
					}.bind(this));
				}
				var InternalContact = this.getView().byId("cmiamendmentnew.matter.internalContact.table_");
				if (InternalContact) {
					$.each(InternalContact.getItems(), function(ci, ic) {
						var oContext = ic.getBindingContext();
						var oic = $.extend({}, oContext.getObject(), true);
						delete oic.__metadata;
						oic.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmialtpayers", {
							properties: oic
						});
					}.bind(this));
				}

				var Matterpartner = this.getView().byId("cmiamendmentnew.matter.matterPartner.table_");
				if (Matterpartner) {
					$.each(Matterpartner.getItems(), function(ci, partner) {
						var oContext = partner.getBindingContext();
						var oPartner = $.extend({}, oContext.getObject(), true);
						delete oPartner.__metadata;
						oPartner.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmialtpayers", {
							properties: oPartner
						});
					}.bind(this));
				}

				var WorkOffice = this.getView().byId("cmiamendmentnew.matter.workOffice.table_");
				if (WorkOffice) {
					$.each(WorkOffice.getItems(), function(ci, office) {
						var oContext = office.getBindingContext();
						var oOffice = $.extend({}, oContext.getObject(), true);
						delete oOffice.__metadata;
						oOffice.Cmino = this.args.Cmino;
						oModel.createEntry("/Cmimatteroffices", {
							properties: oOffice
						});
					}.bind(this));
				}

				var oClient = this._getHeaderContextObject("idClientDetails");
				oModel.createEntry("/CmiconsiderationsN", {
					properties: {
						Cmino: this.args.Cmino,
						Clientk: oClient.Clientk,
						Matterk: oClient.Matterk,
						Consideration: this.getQuestionData()
					}
				});

				oModel.submitChanges({
						success: function(res) {
							this.getOwnerComponent().getModel().resetChanges();
							oModel = this.getOwnerComponent().getModel();
							var cmiNo = res.__batchResponses[0].__changeResponses[0].data.Cmino;
							var Matterk = res.__batchResponses[0].__changeResponses[0].data.Matterk;
							var sObjectPath = oModel.createKey("Cmihdrs", {
								Cmino: cmiNo,
								Matterk: Matterk,
								Clientk: "",
								Cmirequesttype: "MA"
							});

							this._bindView("/" + sObjectPath);
						}.bind(this),
						error: function(res) {

						}.bind(this)
					});
			} else {
				oModel = this.getOwnerComponent().getModel();
				oModel.submitChanges({
					success: function(res) {

					}.bind(this),
					error: function(res) {

					}.bind(this)
				});
			}
		}
	});

});