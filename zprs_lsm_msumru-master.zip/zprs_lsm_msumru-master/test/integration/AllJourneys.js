jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsmmattersummary/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsmmattersummary/test/integration/pages/Worklist",
		"lsmmattersummary/test/integration/pages/Object",
		"lsmmattersummary/test/integration/pages/NotFound",
		"lsmmattersummary/test/integration/pages/Browser",
		"lsmmattersummary/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmmattersummary.view."
	});

	sap.ui.require([
		"lsmmattersummary/test/integration/WorklistJourney",
		"lsmmattersummary/test/integration/ObjectJourney",
		"lsmmattersummary/test/integration/NavigationJourney",
		"lsmmattersummary/test/integration/NotFoundJourney",
		"lsmmattersummary/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});