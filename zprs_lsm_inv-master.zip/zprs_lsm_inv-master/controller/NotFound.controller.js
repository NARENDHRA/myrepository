sap.ui.define([
		"lsminvoice/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("lsminvoice.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);