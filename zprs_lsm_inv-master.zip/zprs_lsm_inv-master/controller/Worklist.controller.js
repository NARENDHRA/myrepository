sap.ui.define([
		"lsminvoice/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History",
		"lsminvoice/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
		"use strict";

		return BaseController.extend("lsminvoice.controller.Worklist", {

			formatter: formatter,

			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			/**
			 * Called when the worklist controller is instantiated.
			 * @public
			 */
			onInit: function() {
				
			this.getView().setBusy(true);	
			this.bServiceFlag = true;
			this.bTimeKeeperServiceFlag = true;
			var jsonModel = new sap.ui.model.json.JSONModel({
				"MyDashboard": true,
				"MyWorkbench": false,
				"ManageBudget": false,
				"TimeKeeperRate": false,
				"MyMatter": false,
				"MatterSummary": false,

				"ExchangeRates": false,
				"Reports": false,
				Bukrs: true,
				Gjahr: true,
				Werks: true,
				Hkont: true,
				Status: true,
				RecordType: true,
				Posid: true
			}, true);
			this.getView().setModel(jsonModel, "JsonKey");

			var JsonModelButton = new JSONModel({
				"Print": false,
				"Accept": false,
				"Approve": false,
				"Reject": false,
				"UploadAttc": false,
				"Save": false,
				"invStatus":true,
				"payStatus":false,
			
				Paid: 0,
				Processed: 0,
				ApprovedPayment: 0,
				Faild: 0
			}, true);
			this.getView().setModel(JsonModelButton, "JModelButton");

			var sideNavigation,
				oViewModel,
				iOriginalBusyDelay;

			/*	sideNavigation = this.getView().byId('sideNavigation');
				//var expanded = !sideNavigation.getExpanded();
				sideNavigation.setExpanded(false);*/

			this._oTableSearchState = [];

			this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			this._oTableSearchState = [];

		
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

		//	this.getRouter().getRoute("lsmClient").attachPatternMatched(this._onObjectMatched, this);

			this.sideKey = "";
			this._mFilters = {
				
				"paid": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "01")],
				"processed": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "02")],
				"approvedPayment": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "03")],
				"faild": [new sap.ui.model.Filter("ZzpayStatus", "EQ", "04")]

			};

			//	this.oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
			//	this.oDataModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV/");
			//	this._showFormFragment("MyDashboard");
			

		},

		press: function(evt) {
			var objectPageSectionId = evt.getSource().sDirectSectionId.split("--")[2];
			var objectPageSectionTitle = evt.getSource()._oCurrentTabSection.mProperties.title;

			if (objectPageSectionId === "idManageBudget" || objectPageSectionId === "idReports" || objectPageSectionId === "idAccruals") {
				if (this.bServiceFlag) {
					this.oDataModelBudget_srv = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_VMATTERS_BUDGET_SRV/");
					this.bServiceFlag = false;
				}
				this.getView().byId(objectPageSectionId).setModel(this.oDataModelBudget_srv);
			}
			if (objectPageSectionId === "idTimeKeeper") {
				this.getRouter().navTo("timeKeeperRate", true);
				this._allSegmButtonFalse();
			}
			if (objectPageSectionId === "idMyWBranch") {
				this.pendingAndHoldBudgetTab();
			}
			if (objectPageSectionId === "idManageBudget") {
				this.buttonSetVisible();
			}
			if (objectPageSectionId === "idMyMatter" || objectPageSectionId === "idMatterSummary" || objectPageSectionId === "idAccruals" ||
				objectPageSectionId === "idExchageRate" || objectPageSectionId === "idReports") {
				this._allSegmButtonFalse();
			}

			/*	var oObjectPageLayout1 = this.getView().byId("ObjectPageLayout");
		oObjectPageLayout1.scrollToSection("id1");*/
		},

		handleDataReceived: function(oEvent) {
			// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV");
			var oModel = this.getOwnerComponent().getModel();

			var oViewModel = this.getModel("JModelButton");

		
			// read the count for Paid
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Paid", oData);
				},
				filters: this._mFilters.paid
			});
			// read the count for Processed
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Processed", oData);
				},
				filters: this._mFilters.processed
			});
			// read the count for ApprovedPayment
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/ApprovedPayment", oData);
				
					this.getView().setBusy(false);
				}.bind(this),
				filters: this._mFilters.approvedPayment
			});
			// read the count for Faild
			oModel.read("/InvHeaderSet/$count", {
				success: function(oData) {
					oViewModel.setProperty("/Faild", oData);
				},
				filters: this._mFilters.faild
			});
		
		},

	
		getTable: function() {
			var oTable = this.getView().byId("MyWorkBenchSTable");
			return oTable.getTable();
		},
		onBeforeRebindTable: function(oEvent) {

			var SegmentKey = this.getView().byId("idIconTabBarNoIconsLSM").getSelectedKey();
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter("ZzpayStatus", sap.ui.model.FilterOperator.EQ, SegmentKey));
			mBindingParams.filters = aFilter;
		},
		onSelectIconTabBarMyWB: function(oEvent) {
			var that = this;
			var segmbtnKey = oEvent.mParameters.key;
			
			var aFilter = [],
				path = "ZzpayStatus";
			var oTab = this.getTable(),
				cntx = oTab.getBinding("items");
			//SegmentKey = oEvent.getParameters().key;
			//    cntx.aApplicationFilters = null;
             	aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));
			/*if (segmbtnKey.search("my") >= 0) {
			var	segmbtnKey1 = segmbtnKey.replace("my", '');
				path = "ZzpayStatus";
				aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey1));
			}else{
			aFilter.push(new sap.ui.model.Filter(path, sap.ui.model.FilterOperator.EQ, segmbtnKey));	
			}*/
			
			cntx.filter(aFilter, "Application");

			switch (segmbtnKey) {
			
				case "01":
					that.myPaymentTab();
					break;
				case "02":
					that.myPaymentTab();
					break;
				case "03":
					that.myPaymentTab();
					break;
				case "04":
					that.myPaymentTab();
					break;

			}
		},

		myPaymentTab: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", true);
			//	oViewModel.setProperty("/Refresh", true);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", true);
			oViewModel.setProperty("/invStatus", false);
			oViewModel.setProperty("/payStatus", true);
			//	this.getView().byId("printAsPDF").setVisible(false);

		},

	
		_allSegmButtonFalse: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
			oViewModel.setProperty("/Save", false);
			//	this.getView().byId("printAsPDF").setVisible(false);
		},
		sideNavigationMyWorkBench: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", false);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/UploadAttc", false);
		},
		setCurrentTab: function(SelKey) {
			var jKey = this.getView().getModel("JsonKey");

			$.each(jKey.getData(), function(pn, v) {
				if (pn === SelKey) {
					jKey.setProperty("/" + pn, true);
				} else {
					jKey.setProperty("/" + pn, false);
				}

			});
		},

		

		pressDetailWorkBench: function(oEvent) {
			var obj = oEvent.getSource().getBindingContext().getObject();

			this.getRouter().navTo("workBenchDetail", {
				filetype: obj.Zzfiletype,
				invoiceNumber: obj.ZzinvoiceNumber,
				seqnr: obj.Zzseqnr
			}, true);
		},

	
		buttonSetVisible: function() {
			var oViewModel = this.getModel("JModelButton");
			oViewModel.setProperty("/Print", false);
			//	oViewModel.setProperty("/Refresh", false);
			oViewModel.setProperty("/Accept", false);
			oViewModel.setProperty("/Approve", true);
			oViewModel.setProperty("/Reject", false);
			oViewModel.setProperty("/Save", true);

		},

		onPressPrint: function(oEvent) {

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_LSW_SRV/");
			var oView = this.getView(),
				oJson = new sap.ui.model.json.JSONModel();
			oModel.read("/InvHeaderSet", {
				/*	parameters: {
						select: 'ZzbillingOfficeName,ZzinvoiceTotal'
					},*/
				success: function(oData) {
					var results = oData.results;
					var aRes = [];
					var sum = 0;
					for (var i = 0; i < results.length; i++) {
						if (i + 1 < results.length) {
							if (results[i].ZzbillingOfficeName === results[i + 1].ZzbillingOfficeName) {
								sum += parseFloat(results[i].ZzinvoiceTotal);
							} else {
								var obj = {
									"ZzbillingOfficeName": results[i].ZzbillingOfficeName,
									"ZzinvoiceTotal": sum
								};
								aRes.push(obj);
							}
						}
					}
					oJson.setData({
						"invModelData": aRes
					});
					oView.setModel(oJson, "invModel");
				}
			});
			
			
		

			/*	var that, myWBSmartTable, WBTable, pURL, oModel, url, invoiceNo;
				that = this;
				myWBSmartTable = this.getView().byId("MyWorkBenchSTable");
				WBTable = this.getView().byId("idwbTable");
				oModel = this.getView().getModel();
				var servUri = oModel.sServiceUrl;
				invoiceNo = WBTable.getSelectedItem().getBindingContext().getObject().ZzinvoiceNumber;
				var sRead = "/PrintInvoiceCollection(Vbeln='" + invoiceNo + "')" + "/$value";
				var mainUri = servUri + sRead;
				sap.m.URLHelper.redirect(mainUri, "_blank");*/

		},
		getTableMannegeBudget: function() {
			var otbl = this.getView().byId("ManBudgetSTable");
			return otbl.getTable();
		},
		
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},
		onAfterRendering: function() {
		
			//	this.getView().byId("MyWorkBenchSTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			
		},
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("MatterType", FilterOperator.Contains, sQuery)];
				}
				//this._applySearch(oTableSearchState);
			}

		}

		});
	}
);