jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsminvoice/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsminvoice/test/integration/pages/Worklist",
		"lsminvoice/test/integration/pages/Object",
		"lsminvoice/test/integration/pages/NotFound",
		"lsminvoice/test/integration/pages/Browser",
		"lsminvoice/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsminvoice.view."
	});

	sap.ui.require([
		"lsminvoice/test/integration/WorklistJourney",
		"lsminvoice/test/integration/ObjectJourney",
		"lsminvoice/test/integration/NavigationJourney",
		"lsminvoice/test/integration/NotFoundJourney",
		"lsminvoice/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});