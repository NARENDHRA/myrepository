sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		status: function(status) {
			if (status) {
				return "Success";
			} else {
				return "None";
			}
		},
		currencyformate: function(svalue) {
			var currency_symbols = {
				'USD': '$', // US Dollar
				'CAD': '$', //Candain Doller
				'SGD': '$', //singapur Doller
				'AUD': '$',//Australia Doller
				'EUR': '€', // Euro
				'CRC': '₡', // Costa Rican Colón
				'GBP': '£', // British Pound Sterling
				'ILS': '₪', // Israeli New Sheqel
				'INR': '₹', // Indian Rupee
				'JPY': '¥', // Japanese Yen
				'KRW': '₩', // South Korean Won
				'NGN': '₦', // Nigerian Naira
				'PHP': '₱', // Philippine Peso
				'PLN': 'zł', // Polish Zloty
				'PYG': '₲', // Paraguayan Guarani
				'THB': '฿', // Thai Baht
				'UAH': '₴', // Ukrainian Hryvnia
				'VND': '₫' // Vietnamese Dong
			};

			var currency_name = svalue;

			if (currency_symbols[currency_name] !== undefined) {
				return currency_symbols[currency_name];
			}
		}

	};

});