jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"lsmcmatter/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"lsmcmatter/test/integration/pages/Worklist",
		"lsmcmatter/test/integration/pages/Object",
		"lsmcmatter/test/integration/pages/NotFound",
		"lsmcmatter/test/integration/pages/Browser",
		"lsmcmatter/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "lsmcmatter.view."
	});

	sap.ui.require([
		"lsmcmatter/test/integration/WorklistJourney",
		"lsmcmatter/test/integration/ObjectJourney",
		"lsmcmatter/test/integration/NavigationJourney",
		"lsmcmatter/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});