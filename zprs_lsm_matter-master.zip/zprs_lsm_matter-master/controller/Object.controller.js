/*global location*/
sap.ui.define([
	"lsmcmatter/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"lsmcmatter/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, History, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("lsmcmatter.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0,
					CreateMatter: true,
					EditMatter: true,
					Save: false,
					Cancle: false,
					MatterDesc: "",
					CmiRec: "",
					editMatter: false,
					Pspid: "",
					MFala: true
				});
			var TabSwitchMod = new JSONModel({
				General: true,
				LegalTeam: false,
				LawSuit: false,
				StoreNo: "",
				CaseType: "",
				MatterType: "",
				PracticeArea: "",
				CaseTypeSec: "",
				Facility: "",
				PrimaryIssues: "",
				State: "",
				SecondaryIssue: "",
				County: "",
				Outcome: ""
			});
			this.setModel(TabSwitchMod, "TabSwitchMod");
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			// F4 help model
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			this.getView().setModel(fo4Model, "fo4Model");
			// model for Legal Team Attrony column
			this.oAttorModel();
			// Empty json model binging for Create function
			this.createObject();
		},
		onAfterRendering: function() {
			if (!this.oModel) {
				this.oModel = this.getView().getModel();
			}
			this.oModel.setDefaultBindingMode("TwoWay");
		},

		oAttorModel: function() {
			var that = this;
			var aAttroneyJson = new sap.ui.model.json.JSONModel();
			var AttorneyModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			AttorneyModel.read("/ZprsShParvwLsmSet", {
				success: function(data, response) {
					aAttroneyJson.setData({
						Modeldata: data.results
					});
					that.getView().setModel(aAttroneyJson, "aAttroneyJson");
				},
				error: function(oError) {}
			});
		},
		createObject: function() {
			this.oeditFragModel = new sap.ui.model.json.JSONModel("/webapp/model/editfragData.json");
			this.generalFragModel = new sap.ui.model.json.JSONModel("/webapp/model/generalCreate.json");
			this.finalresFragModel = new sap.ui.model.json.JSONModel("/webapp/model/finalResCreate.json");
			this.lawSuitFragModel = new sap.ui.model.json.JSONModel("/webapp/model/lawSuitCreate.json");
			this.legalTeamFragModel = new sap.ui.model.json.JSONModel("/webapp/model/legalTeamCreate.json");
			this.DemandOfferFragModel = new sap.ui.model.json.JSONModel("/webapp/model/DemandOfferCreate.json");
			this.AttachfragModel = new sap.ui.model.json.JSONModel("/webapp/model/AttachDataCreate.json");
		},
		// onedit matter button press
		onEditMatter: function(evt) {
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			var oviewModel = this.getView().getModel("objectView");
			oviewModel.setProperty("/Save", true);
			oviewModel.setProperty("/Cancle", true);
			oviewModel.setProperty("/EditMatter", false);
			oviewModel.setProperty("/CreateMatter", false);
			oviewModel.setProperty("/editMatter", true);
			oviewModel.setProperty("/MFalg", false);

		},
		// on Cancle matter button press
		onCancleEdit: function(evt) {
			var oView = this.getView();
			if (!this.oModel) {
				this.oModel = this.getView().getModel();
			}
			var oviewModel = this.getView().getModel("objectView");
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oviewModel.setProperty("/Save", false);
			oviewModel.setProperty("/Cancle", false);
			oviewModel.setProperty("/EditMatter", true);
			oviewModel.setProperty("/CreateMatter", true);
			oviewModel.setProperty("/editMatter", false);
			var oMianModel = oView.getModel("oMDLocal");
			//Setting Display Data
			this.getView().byId("GeneralID").setModel(this.onTabModel, "onTabModel");
			this.getView().byId("editlegalTeam").setModel(this.onlegalModel, "onlegalModel");
			this.getView().byId("LawSuiteID").setModel(this.onlawModel, "onlawModel");
			this.getView().byId("DOID").setModel(this.onDemandModel, "onDemandModel");
			this.getView().byId("FRID").setModel(this.onFRModel, "onFRModel");
			this.getView().byId("AttachmentID").setModel(this.attchModel, "attchModel");
			this.getView().byId("HeaderID").setModel(this.TabSwitchMod);
			this.getView().byId("HeaderID").setModel(oMianModel, "oMDLocal");
		},

		onCreateMatter: function(evt) {
			var oView = this.getView();
			var oviewModel = this.getView().getModel("objectView");
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oviewModel.setProperty("/Save", true);
			oviewModel.setProperty("/Cancle", true);
			oviewModel.setProperty("/EditMatter", false);
			oviewModel.setProperty("/CreateMatter", false);
			oviewModel.setProperty("/editMatter", true);
			oviewModel.setProperty("/MFalg", true);
			this.setNullData();
			this.editFragBinding();
			this.getView().byId("HeaderID").setModel(this.oeditFragModel, "oMDLocal");

		},
		editFragBinding: function() {

			this.getView().byId("HeaderID").setModel(this.oeditFragModel);
			this.getView().byId("GeneralID").setModel(this.generalFragModel, "onTabModel");
			this.getView().byId("editlegalTeam").setModel(this.legalTeamFragModel, "onlegalModel");
			this.getView().byId("LawSuiteID").setModel(this.lawSuitFragModel, "onlawModel");
			this.getView().byId("DOID").setModel(this.DemandOfferFragModel, "onDemandModel");
			this.getView().byId("FRID").setModel(this.finalresFragModel, "onFRModel");
			this.getView().byId("AttachmentID").setModel(this.AttachfragModel, "attchModel");

			// this.Editfragment.setModel(this.oeditFragModel);
			// this.generaleditFrag.setModel(this.generalFragModel, "onTabModel");
			// this.finalReseditfrag.setModel(this.finalresFragModel, "onFRModel");
			// this.lawSuiteditfrag.setModel(this.lawSuitFragModel, "onlawModel");
			// this.legaleditfrag.setModel(this.legalTeamFragModel, "onlegalModel");
			// this.DemandOffeditfrag.setModel(this.DemandOfferFragModel, "onDemandModel");
			// this.attchEditfrag.setModel(this.AttachfragModel, "attchModel");
		},
		setNullData: function() {
			var oView = this.getView();
			var oviewModel = this.getView().getModel("objectView");
			var oSetModel = this.getView().getModel("TabSwitchMod");
			oviewModel.setProperty("/Status", "");
			oSetModel.setProperty("/CaseType", "");
			oSetModel.setProperty("/MatterType", "");
			oSetModel.setProperty("/PracticeArea", "");
			oSetModel.setProperty("/CaseTypeSec", "");
			oSetModel.setProperty("/PrimaryIssues", "");
			oSetModel.setProperty("/State", "");
			oSetModel.setProperty("/Facility", "");
			oSetModel.setProperty("/SecondaryIssue", "");
			oSetModel.setProperty("/County", "");
			oSetModel.setProperty("/Outcome", "");
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.sMatterno = sObjectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("HeaderSet", {
					Pspid: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();
			var oModel = this.getOwnerComponent().getModel();
			var oMDLocal = new sap.ui.model.json.JSONModel();
			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);
			var that = this;
			oModel.read(sObjectPath, {
				success: function(data, response) {
					oMDLocal.setData(data);
					that.getView().setModel(oMDLocal, "oMDLocal");
				},
				error: function(oError) {

				}

			});

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
			this.oTabModel(sObjectPath);
			this.svalue = sObjectPath;
		},
		oTabModel: function(sObjectPath) {
			this.obj = sObjectPath;
			var oModel = this.getOwnerComponent().getModel();
			var onTabModel = new sap.ui.model.json.JSONModel();
			var oPath = this.obj + "/HeaderToGeneralSet";
			var that = this;
			oModel.read(oPath, {
				success: function(data, response) {
					onTabModel.setData(data);
					that.getView().setModel(onTabModel, "onTabModel");
				},
				error: function(oError) {}
			});
			var onlegalModel = new sap.ui.model.json.JSONModel();
			var oPathl = this.obj + "/HeaderToLegalTeamSet";
			// var that = this;
			oModel.read(oPathl, {
				success: function(data, response) {
					onlegalModel.setData({
						modelData: data.results
					});
					that.getView().setModel(onlegalModel, "onlegalModel");
				},
				error: function(oError) {}
			});
			var onlawModel = new sap.ui.model.json.JSONModel();
			var oPathLaw = this.obj + "/HeaderToLawSuitSet";
			// var that = this;
			oModel.read(oPathLaw, {
				success: function(data, response) {
					onlawModel.setData(data);
					that.getView().setModel(onlawModel, "onlawModel");
				},
				error: function(oError) {}
			});

			var onDemandModel = new sap.ui.model.json.JSONModel();
			var oPathDemand = this.obj + "/HeaderToDemandSet";
			oModel.read(oPathDemand, {
				success: function(data, response) {
					onDemandModel.setData(data);
					that.getView().setModel(onDemandModel, "onDemandModel");
				},
				error: function(oError) {}
			});

			var onFRModel = new sap.ui.model.json.JSONModel();
			var oPathFR = this.obj + "/HeaderToFinalResolSet";
			// var that = this;
			oModel.read(oPathFR, {
				success: function(data, response) {
					onFRModel.setData(data);
					that.getView().setModel(onFRModel, "onFRModel");
				},
				error: function(oError) {}
			});
			var accModel = new sap.ui.model.json.JSONModel();
			var oPathAcc = this.obj + "/HeaderToAccrual";
			// var that = this;
			oModel.read(oPathAcc, {
				success: function(data, response) {
					accModel.setData({
						modelData: data
					});
					that.getView().setModel(accModel, "accModel");
				},
				error: function(oError) {}
			});

			var IncModel = new sap.ui.model.json.JSONModel();
			var oPathIn = this.obj + "/HeaderToInvoiceSet";
			// var that = this;
			oModel.read(oPathIn, {
				success: function(data, response) {
					IncModel.setData({
						modelData: data.results
					});
					that.getView().setModel(IncModel, "IncModel");
				},
				error: function(oError) {}
			});

		},
		// F4 help for all input fileds .
		_onSelectSearchHelpSrvF4: function(oEvent) {
			var oFilter, aFilter, oSource, sInputValue, sValueHelpSrv, fo4Model, customFields, that;
			customFields = oEvent.getSource().data();
			sInputValue = oEvent.getSource().getValue();
			sValueHelpSrv = "/sap/opu/odata/sap/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/";
			fo4Model = new sap.ui.model.odata.ODataModel(sValueHelpSrv, {
				json: true,
				loadMetadataAsync: true
			});
			fo4Model.setDefaultBindingMode("TwoWay");
			this._oDialog = sap.ui.xmlfragment("lsmcmatter.fragments.dailogSearch." + customFields.fName, this);
			this.getView().addDependent(this._oDialog);
			this.setModel(fo4Model, "fo4Model");
			// create a filter for the binding
			aFilter = [];
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(customFields.ffName, sap.ui.model.FilterOperator.Contains, sInputValue);
				aFilter.push(oFilter);
				this._oDialog.getBinding("items").filter(aFilter);
			}
			this._oDialog.open(sInputValue);
			that = this;
			oSource = oEvent.getSource();
			this._oDialog.attachConfirm(that, function(evt) {
				var svalue = evt.getParameter("selectedItem");
				oSource.setValue(svalue.getTitle());
				that._oDialog.destroy();
			}, null);
		},
		_handleF4Close: function(evt) {
			var oSelectedItem, oCustomFields;
			oCustomFields = evt.getSource().data();
			oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				sap.ui.getCore().byId(oCustomFields.fName).setValue(oSelectedItem.getTitle());

			}
			this._oDialog.destroy();
		},
		_handleF4Search: function(oEvent) {
			var aFilter, sValue, oCustomFields, oFilter;
			oCustomFields = oEvent.getSource().data();
			aFilter = [];
			sValue = oEvent.getParameter("value");
			if (sValue !== "") {
				oFilter = new sap.ui.model.Filter(oCustomFields.ffName, sap.ui.model.FilterOperator.Contains, sValue);
				aFilter.push(oFilter);
			}
			oEvent.getSource().getBinding("items").filter(aFilter);

		},
		// onSave function for both changes and create button
		onSaveMatter: function(evt) {
			var oView = this.getView();
			// var BtnTxt = evt.getSource().getText();
			//var oCmiRec = oView.getBindingContext().getProperty("CmiRec");
			//General Model Data 
			var tbl = oView.byId("editlegalTeam");
			var oMianModel = oView.getModel("oMDLocal");
			this.objHeader = oMianModel.oData;

			var oModelGeneral = oView.getModel("onTabModel");
			this.objGeneral = oModelGeneral.oData;
			// LeaglTeam Model Data
			var oModelLegal = oView.getModel("onlegalModel"),
				objLegal = oModelLegal.oData,
				oresults = objLegal.modelData,
				// lawSuit Model Data
				oModelLawSuit = oView.getModel("onlawModel"),
				objLawsuit = oModelLawSuit.oData,
				//Demand Offer Model Data
				oModelDemand = oView.getModel("onDemandModel"),
				objDemand = oModelDemand.oData,
				//Final Resolution Model Data
				oModelFinRes = oView.getModel("onFRModel"),
				objFinRes = oModelFinRes.oData;
			var oViewModel = this.getView().getModel("objectView"),
				ActionTxt = oViewModel.getProperty("/MFalg");
			var oAction;
			if (ActionTxt) {
				oAction = "create";
			} else {
				oAction = "change";
			}

			var oObjectParm = {
				Action: oAction,
				AdrLine1: this.objHeader.AdrLine1,
				AdrLine2: this.objHeader.AdrLine2,
				AuthorizationAmount: objDemand.AuthorizationAmount,
				CaseType: this.objGeneral.CaseType,
				CaseTypeSec: this.objGeneral.CaseTypeSec,
				City: this.objHeader.City,
				CloseDate: this.objGeneral.CloseDate,
				CmiRec: this.objHeader.CmiRec,
				ConferenceDate: objLawsuit.ConferenceDate,
				County: objLawsuit.County,
				Court: objLawsuit.Court,
				CurrentOffer: objDemand.CurrentOffer,
				DemandAmount: objDemand.DemandAmount,
				DetailToLegalTeamSet: oresults,
				DetailToNarrativesSet: [],
				Facility: objLawsuit.Facility,
				FinResAmt: objFinRes.FinResAmt,
				Iserror: "",
				MatterCuky: this.objGeneral.MatterCuky,
				MatterSubtype: this.objGeneral.MatterSubtype,
				MatterType: this.objGeneral.MatterType,
				MediationDate: objLawsuit.MediationDate,
				Message: "",
				OcFirm: "",
				OpenDate: this.objGeneral.OpenDate,
				Outcome: objFinRes.Outcome,
				OutcomeSub: objFinRes.OutcomeSub,
				Payer: objFinRes.Payer,
				PaymentAmount: objFinRes.PaymentAmount,
				PaymentDate: objFinRes.PaymentDate,
				Post1: this.objHeader.Post1,
				PracticeArea: this.objGeneral.PracticeArea,
				PrimaryIssues: objLawsuit.PrimaryIssues,
				Pspid: this.objGeneral.Pspid,
				Pstlz: this.objHeader.Pstlz,
				Region: this.objHeader.Region,
				ResolutionDate: objFinRes.ResolutionDate,
				SecondaryIssues: objLawsuit.SecondaryIssues,
				SettlementDate: objLawsuit.SettlementDate,
				State: objLawsuit.State,
				Status: this.objHeader.Status,
				StoreName: this.objHeader.StoreName,
				StoreNo: this.objHeader.StoreNo,
				TrialDate: objLawsuit.TrialDate,
				TotResAmt: objFinRes.TotResAmt
			};

			var oChangeModel = this.getOwnerComponent().getModel();
			var that = this;
			oChangeModel.create("/MatterDetailSet", oObjectParm, {
				success: function(oData, response) {
					var smg = oData.Message;
					MessageToast.show(smg);
					that.onCancleEdit();
				},
				error: function() {
					MessageToast.show("error");
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.Pspid,
				sObjectName = oObject.Pspid;

			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		handleDelete: function(oEvent) {
			var oTable = oEvent.getSource();
			var oModel = this.getView().getModel("onlegalModel");
			var oList = oEvent.getParameters("listItem").listItem,
				oItem = oEvent.getParameters("listItem").listItem,
				sPath = oItem.getBindingContext().getPath();
			var index = oEvent.getParameters("listItem").listItem.getBindingContextPath();

			var oConfirmMsg = "Are you sure you want to delete?";
			sap.m.MessageBox.confirm(oConfirmMsg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirmation",
				onClose: function(oEvent1) {
					if (oEvent1 === "OK") {
						// Condition for existing row or New row.....if it is new row index will be undefine 
						if (index) {
							index = index.charAt(index.lastIndexOf('/') + 1);

							if (index !== -1) {
								var data = oModel.getData().modelData;
								data.splice(index, 1);

								oModel.setData({
									modelData: data
								});

							}
						} else if (index === undefined) {

							oTable.removeItem(oList);
						}
					}
				}
			});

			// after deletion put the focus back to the list
			oList.attachEventOnce("updateFinished", oList.focus, oList);
			// send a delete request to the odata service
			//this.oModel.remove(sPath);
		},
		// F4 Help for AttorneyId
		handleValueHelpAttorneyId: function(evt) {
			var aFilter = [],
				tbl,
				matterNo = this.sMatterno;
			var MatterNo = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, matterNo);
			aFilter.push(MatterNo);
			tbl = this.getView().byId("editlegalTeam");
			var attorneyModel = new sap.ui.model.json.JSONModel();
			// var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			// fo4Model.read("/PartnerDetailSet", {
			// 	filters: aFilter,
			// 	success: function(oData) {

			// 	},
			// 	error: function(oError) {
			// 	}
			// });

		},
		//F4 help for Payer
		_onValueHelpRequestPayer: function(evt) {
			var aFilter = [],
				sfragmentName,
				matterNo = this.sMatterno,
				oPayer = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, "PY"),
				MatterNo = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, matterNo);
			sfragmentName = "lsmcmatter.fragments.dailogSearch.Payer";
			aFilter.push(oPayer);
			aFilter.push(MatterNo);
			var oPayerModel = new sap.ui.model.json.JSONModel();
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_LSW_CMATTER_SEARCHHELP_SRV/");
			var that = this;
			fo4Model.read("/PartnerDetailSet", {
				filters: aFilter,
				success: function(oData) {
					oPayerModel.setData(oData);
					if (!that._valueHelpPayerDialog) {
						that._valueHelpPayerDialog = sap.ui.xmlfragment(sfragmentName, that);
						that.getView().addDependent(that._valueHelpPayerDialog);
					}
					that._valueHelpPayerDialog.setModel(oPayerModel, "oPayerModel");
					that._valueHelpPayerDialog.open();
				},
				error: function(oError) {}
			});

		},
		_handlePayerClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var payerInput = this.getView().byId("PayerId");
				var valuetxt = oSelectedItem.getTitle();
				payerInput.setValue(valuetxt);
			}
			// this._valueHelpPayerDialog.close();
		},

		onAddRowPress: function(oEvent) {
			//get Model
			var aAttroneyJson = this.getView().getModel("aAttroneyJson");
			//get Table
			//var oTable = this.getView().byId("editlegalTeam");
			var oTable = oEvent.getSource().getParent().getParent();
			//Create Template and DropdownBox
			var oItemSelectTemplate = new sap.ui.core.Item({
				key: "{Parvw}",
				text: "{Parvw}-{Vtext}"
			});
			var NewComboBox = new sap.m.Select({
				width: "100%"
			});
			NewComboBox.setModel(aAttroneyJson);
			NewComboBox.bindAggregation("items", "/Modeldata", oItemSelectTemplate);
			//Create all Inputs
			var NewAttorneyId = new sap.m.Input("", {});
			var NewName = new sap.m.Input("", {});
			var NewAddress = new sap.m.Input("", {});
			var NewBillings = new sap.m.Input("", {});
			var NewRate = new sap.m.Input("", {});
			var NewHours = new sap.m.Input("", {});
			//Create ColumnListItem and add cells to it
			var columnListItemNewLine = new sap.m.ColumnListItem({
				type: sap.m.ListType.Inactive,
				mode: sap.m.ListMode.Delete,
				// delete actually calls handle delete function 
				delete: this.deletePress(),
				unread: false,
				vAlign: "Middle",
				cells: [NewComboBox, NewAttorneyId, NewName, NewAddress, NewBillings, NewRate, NewHours]
			});
			//Add List Item to the Table
			oTable.addItem(columnListItemNewLine);
		},
		deletePress: function() {}

	});

});